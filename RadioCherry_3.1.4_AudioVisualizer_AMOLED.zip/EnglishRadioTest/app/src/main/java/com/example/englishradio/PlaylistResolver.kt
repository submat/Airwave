package com.example.englishradio

import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

/** Resolves directory-style .m3u and .pls files to the first direct audio URL.
 * HLS .m3u8 manifests are intentionally left untouched for Media3's HLS module.
 */
internal object PlaylistResolver {
    fun isPlaylistUrl(url: String): Boolean {
        val path = runCatching { URI(url).path.lowercase() }.getOrDefault(url.lowercase())
        return path.endsWith(".m3u") || path.endsWith(".pls")
    }

    fun resolve(inputUrl: String): String = resolve(inputUrl, 0, mutableSetOf())

    private fun resolve(url: String, depth: Int, visited: MutableSet<String>): String {
        if (depth >= 4 || !isPlaylistUrl(url) || !visited.add(url)) return url
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 9000
            readTimeout = 9000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "RadioCherry/2.3 (Android Internet Radio)")
            setRequestProperty("Accept", "audio/x-scpls,audio/mpegurl,application/vnd.apple.mpegurl,text/plain,*/*")
        }
        val finalPlaylistUrl = connection.url.toString()
        val text = try {
            connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                val out = StringBuilder()
                val buffer = CharArray(4096)
                var total = 0
                while (true) {
                    val read = reader.read(buffer)
                    if (read <= 0) break
                    total += read
                    if (total > 256 * 1024) break
                    out.append(buffer, 0, read)
                }
                out.toString()
            }
        } finally {
            connection.disconnect()
        }
        val candidate = parsePlaylist(text).firstOrNull() ?: return url
        val resolved = runCatching { URI(finalPlaylistUrl).resolve(candidate).toString() }.getOrDefault(candidate)
        return if (isPlaylistUrl(resolved)) resolve(resolved, depth + 1, visited) else resolved
    }

    private fun parsePlaylist(body: String): List<String> {
        val lines = body.removePrefix("\uFEFF").lines().map { it.trim() }.filter { it.isNotEmpty() }
        val plsFiles = lines.mapNotNull { line ->
            if (line.startsWith("File", ignoreCase = true) && line.contains('=')) line.substringAfter('=').trim() else null
        }.filter { it.startsWith("http://", true) || it.startsWith("https://", true) }
        if (plsFiles.isNotEmpty()) return plsFiles
        return lines.filterNot { it.startsWith('#') || it.startsWith(';') }
            .filter { it.startsWith("http://", true) || it.startsWith("https://", true) || it.startsWith('/') }
    }
}
