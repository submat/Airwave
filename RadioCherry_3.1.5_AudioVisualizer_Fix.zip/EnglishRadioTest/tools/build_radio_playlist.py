#!/usr/bin/env python3
"""
build_radio_playlist.py
Builds ONE language-grouped playlist of free internet-radio stations from the
community radio-browser.info database (https://www.radio-browser.info).

Rules applied
  * the stream URL must END in .mp3 or .m3u8   (--loose also accepts ".mp3?token=...")
  * only stations the database currently flags as working (lastcheckok = 1)
  * music-style stations only: news / talk / sports / Quran-recitation / sermons
    are filtered out (--include-talk keeps them)
  * grouped by language, e.g. group-title="Hindi / Bollywood", "Tamil", "Russian"
  * each stream appears once; duplicate station names inside a language are collapsed

Usage
  python build_radio_playlist.py                      -> radio_cherry_stations.m3u8
  python build_radio_playlist.py --check              also test every stream first (slower, cleanest list)
  python build_radio_playlist.py --only hindi,tamil   only some groups
  python build_radio_playlist.py --per-language 100   lighter file (0 = no limit)
  python build_radio_playlist.py --https-only         only https:// streams (if the app refuses plain http)
  python build_radio_playlist.py --format json        or csv
  python build_radio_playlist.py --list-groups        show the language groups

Needs Python 3.8+ and nothing else (standard library only).
"""
from __future__ import annotations

import argparse
import csv
import json
import random
import re
import socket
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from http.client import BadStatusLine, HTTPException

UA = "radio-cherry-playlist-builder/1.0"
FALLBACK_SERVERS = [
    "https://de1.api.radio-browser.info",
    "https://nl1.api.radio-browser.info",
    "https://at1.api.radio-browser.info",
    "https://all.api.radio-browser.info",
]
EXT = (".mp3", ".m3u8")

# (group title, language names as radio-browser spells them, extra tags that also count).
# Order matters: a station that lists several languages goes to the FIRST group it matches,
# so the Indian languages come first and English last.
CATALOG = [
    ("Hindi / Bollywood", ["hindi"], ["bollywood"]),
    ("Tamil", ["tamil"], []),
    ("Telugu", ["telugu"], []),
    ("Malayalam", ["malayalam"], []),
    ("Kannada", ["kannada"], []),
    ("Bengali", ["bengali", "bangla"], []),
    ("Marathi", ["marathi"], []),
    ("Gujarati", ["gujarati"], []),
    ("Punjabi", ["punjabi", "panjabi"], []),
    ("Odia", ["odia", "oriya"], []),
    ("Assamese", ["assamese", "asomiya"], []),
    ("Urdu", ["urdu"], []),
    ("Nepali", ["nepali"], []),
    ("Sinhala", ["sinhala", "sinhalese"], []),
    ("Kashmiri", ["kashmiri"], []),
    ("Konkani", ["konkani"], []),
    ("Bhojpuri", ["bhojpuri"], []),
    ("Rajasthani", ["rajasthani"], []),
    ("Haryanvi", ["haryanvi"], []),
    ("Sindhi", ["sindhi"], []),
    ("Maithili", ["maithili"], []),
    ("Tulu", ["tulu"], []),
    ("Manipuri", ["manipuri", "meitei"], []),
    ("Russian", ["russian"], []),
    ("Spanish", ["spanish"], []),
    ("Arabic", ["arabic"], []),
    ("Portuguese", ["portuguese"], []),
    ("French", ["french"], []),
    ("German", ["german"], []),
    ("Italian", ["italian"], []),
    ("Turkish", ["turkish"], []),
    ("Persian", ["persian", "farsi"], []),
    ("Chinese", ["chinese", "mandarin", "cantonese"], []),
    ("Japanese", ["japanese"], []),
    ("Korean", ["korean"], []),
    ("Indonesian", ["indonesian"], []),
    ("Malay", ["malay"], []),
    ("Thai", ["thai"], []),
    ("Vietnamese", ["vietnamese"], []),
    ("Filipino", ["filipino", "tagalog"], []),
    ("Polish", ["polish"], []),
    ("Ukrainian", ["ukrainian"], []),
    ("Dutch", ["dutch"], []),
    ("Greek", ["greek"], []),
    ("Hebrew", ["hebrew"], []),
    ("Swahili", ["swahili"], []),
    ("Romanian", ["romanian"], []),
    ("Hungarian", ["hungarian"], []),
    ("Czech", ["czech"], []),
    ("Serbian", ["serbian"], []),
    ("Croatian", ["croatian"], []),
    ("Bulgarian", ["bulgarian"], []),
    ("Swedish", ["swedish"], []),
    ("Norwegian", ["norwegian"], []),
    ("Danish", ["danish"], []),
    ("Finnish", ["finnish"], []),
    ("Albanian", ["albanian"], []),
    ("Armenian", ["armenian"], []),
    ("Azerbaijani", ["azerbaijani", "azeri"], []),
    ("Georgian", ["georgian"], []),
    ("Kazakh", ["kazakh"], []),
    ("Uzbek", ["uzbek"], []),
    ("Kurdish", ["kurdish"], []),
    ("Pashto", ["pashto"], []),
    ("Amharic", ["amharic"], []),
    ("Somali", ["somali"], []),
    ("Hausa", ["hausa"], []),
    ("Afrikaans", ["afrikaans"], []),
    ("Burmese", ["burmese"], []),
    ("Khmer", ["khmer"], []),
    ("Mongolian", ["mongolian"], []),
    ("Catalan", ["catalan"], []),
    ("English", ["english"], []),
]

# --- "music only" heuristics -------------------------------------------------
HARD_BAD_TAGS = {
    "quran", "quran recitation", "holy quran", "koran", "sermon", "sermons",
    "lecture", "lectures", "bible", "audiobook", "audiobooks", "podcast",
    "podcasts", "weather", "traffic", "parliament",
}
SOFT_BAD_TAGS = {
    "news", "talk", "talk radio", "news talk", "sports", "sport", "politics",
    "current affairs", "information",
}
MUSIC_TAGS = {
    "music", "pop", "rock", "hits", "top 40", "top40", "bollywood", "dance",
    "electronic", "hip hop", "hip-hop", "rap", "r&b", "jazz", "classical",
    "folk", "country", "oldies", "retro", "latin", "indie", "metal", "house",
    "techno", "trance", "lounge", "chillout", "ambient", "soul", "blues",
    "reggae", "love songs", "film songs", "songs", "ghazal", "bhajan",
    "devotional", "kirtan",
}
BAD_NAME = re.compile(
    r"(?<!\w)(news|talk|sports?|podcasts?|quran|qur'an|koran|sermons?|bible|"
    r"noticias|deportes|nachrichten|haberler?)(?!\w)|новости|القرآن|قرآن|القران",
    re.IGNORECASE,
)


def log(msg: str = "") -> None:
    print(msg, file=sys.stderr, flush=True)


# --- radio-browser API -------------------------------------------------------
def discover_servers() -> list[str]:
    """Mirror discovery as described at https://api.radio-browser.info"""
    names: list[str] = []
    try:
        infos = socket.getaddrinfo("all.api.radio-browser.info", 443, proto=socket.IPPROTO_TCP)
        for ip in sorted({i[4][0] for i in infos}):
            try:
                host = socket.gethostbyaddr(ip)[0]
            except OSError:
                continue
            if host.endswith("radio-browser.info"):
                names.append("https://" + host)
    except OSError:
        pass
    names = sorted(set(names))
    random.shuffle(names)
    return names + [s for s in FALLBACK_SERVERS if s not in names]


class Api:
    def __init__(self, servers: list[str], ctx: ssl.SSLContext, timeout: float = 40, pause: float = 0.25):
        self.servers = list(servers)
        self.ctx = ctx
        self.timeout = timeout
        self.pause = pause

    def get(self, path: str, **params):
        query = urllib.parse.urlencode(
            {k: (str(v).lower() if isinstance(v, bool) else v) for k, v in params.items()}
        )
        last: Exception | None = None
        for i, base in enumerate(list(self.servers)):
            req = urllib.request.Request(
                f"{base.rstrip('/')}{path}?{query}",
                headers={"User-Agent": UA, "Accept": "application/json"},
            )
            try:
                with urllib.request.urlopen(req, timeout=self.timeout, context=self.ctx) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                if i:  # keep the server that worked at the front
                    self.servers.insert(0, self.servers.pop(i))
                time.sleep(self.pause)
                return data
            except (OSError, ValueError, HTTPException) as exc:
                last = exc
        raise RuntimeError(f"all radio-browser servers failed ({last})")


def fetch_matches(api: Api, kind: str, term: str, scan: int, page: int = 1000) -> list[dict]:
    """Stations whose `language` or `tag` matches `term`, most-voted first."""
    out: list[dict] = []
    offset = 0
    while offset < scan:
        batch = api.get(
            "/json/stations/search",
            **{
                kind: term,
                "hidebroken": True,
                "order": "votes",
                "reverse": True,
                "offset": offset,
                "limit": min(page, scan - offset),
            },
        )
        if not isinstance(batch, list) or not batch:
            break
        out.extend(batch)
        offset += len(batch)
    return out


# --- filtering helpers -------------------------------------------------------
def norm_list(s) -> list[str]:
    return [x.strip().lower() for x in (s or "").split(",") if x.strip()]


def truthy(v) -> bool:
    return str(v).strip().lower() in ("1", "true", "yes")


def good_url(u, loose: bool) -> bool:
    if not isinstance(u, str):
        return False
    u = u.strip()
    if not re.match(r"https?://\S+$", u, re.IGNORECASE):
        return False
    if loose:
        u = u.split("#", 1)[0].split("?", 1)[0]
    return u.lower().endswith(EXT)


def pick_url(st: dict, loose: bool, https_only: bool = False) -> str | None:
    for key in ("url_resolved", "url"):
        u = st.get(key)
        if good_url(u, loose) and (not https_only or u.strip().lower().startswith("https://")):
            return u.strip()
    return None


def url_key(u: str) -> tuple:
    p = urllib.parse.urlsplit(u.strip())
    return (p.netloc.lower(), p.path, p.query)


def is_music(st: dict) -> bool:
    tags = set(norm_list(st.get("tags")))
    if tags & HARD_BAD_TAGS:
        return False
    if BAD_NAME.search(st.get("name") or ""):
        return False
    if tags & SOFT_BAD_TAGS and not tags & MUSIC_TAGS:
        return False
    return True


def assign(st: dict, index: dict, hindi, english):
    best = None
    for tok in norm_list(st.get("language")):
        order = index.get(tok)
        if order is None:
            m = re.match(r"[a-zÀ-￿]+", tok)
            order = index.get(m.group(0)) if m else None
        if order is not None and (best is None or order < best):
            best = order
    if hindi is not None and "bollywood" in norm_list(st.get("tags")) and (best is None or best == english):
        best = hindi
    return best


def clean(s, limit: int = 120) -> str:
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    return s[:limit].strip()


def attr(s) -> str:
    return clean(s).replace('"', "'")


def label(title: str) -> str:
    return title.split(" / ")[0]


# --- collect -> filter -> cap ------------------------------------------------
def collect(api: Api, catalog: list, args) -> dict:
    index: dict[str, int] = {}
    for order, (_t, aliases, _g) in enumerate(catalog):
        for a in aliases:
            index.setdefault(a.lower(), order)
    hindi = next((i for i, c in enumerate(catalog) if c[0].startswith("Hindi")), None)
    english = next((i for i, c in enumerate(catalog) if c[0] == "English"), None)
    groups: dict[int, list] = {i: [] for i in range(len(catalog))}
    by_url: dict[tuple, dict] = {}
    seen: set = set()

    for order, (title, aliases, tags) in enumerate(catalog):
        queries = [("language", a) for a in aliases] + [("tag", t) for t in tags]
        scanned = 0
        for kind, term in queries:
            try:
                recs = fetch_matches(api, kind, term, args.scan)
            except RuntimeError as exc:
                log(f"  ! {title} ({kind}={term}): {exc}")
                continue
            scanned += len(recs)
            for st in recs:
                key = st.get("stationuuid") or st.get("url_resolved") or st.get("url")
                if not key or key in seen:
                    continue
                seen.add(key)
                if not truthy(st.get("lastcheckok", 1)):
                    continue
                url = pick_url(st, args.loose, args.https_only)
                if not url:
                    continue
                if not args.include_talk and not is_music(st):
                    continue
                g = assign(st, index, hindi, english)
                if g is None:
                    continue
                uk = url_key(url)
                prev = by_url.get(uk)
                if prev is not None:  # same stream already listed; prefer the https spelling
                    if url.lower().startswith("https") and prev["url"].lower().startswith("http:"):
                        prev["url"] = url
                    continue
                try:
                    votes = int(st.get("votes") or 0)
                except (TypeError, ValueError):
                    votes = 0
                cand = {
                    "name": clean(st.get("name")) or urllib.parse.urlsplit(url).netloc,
                    "url": url,
                    "country": (st.get("countrycode") or "").strip().upper(),
                    "codec": st.get("codec") or "",
                    "bitrate": st.get("bitrate") or 0,
                    "tags": st.get("tags") or "",
                    "votes": votes,
                    "homepage": st.get("homepage") or "",
                    "favicon": st.get("favicon") or "",
                }
                by_url[uk] = cand
                groups[g].append(cand)
        log(f"[{order + 1}/{len(catalog)}] {title}: scanned {scanned}, candidates so far {sum(len(v) for v in groups.values())}")
    return groups


def make_probe(ctx: ssl.SSLContext, timeout: float):
    def probe(url: str) -> bool:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "*/*"})
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
                if resp.status != 200:
                    return False
                if url.lower().split("?", 1)[0].endswith(".m3u8"):
                    head = resp.read(4096).decode("utf-8", "ignore").lstrip("﻿ \r\n\t")
                    return head.startswith("#EXTM3U")
                ctype = (resp.headers.get("Content-Type") or "").lower()
                chunk = resp.read(2048)
                return len(chunk) >= 512 and not ctype.startswith("text/")
        except BadStatusLine as exc:  # old Shoutcast servers answer "ICY 200 OK"
            return str(getattr(exc, "line", "")).upper().startswith("ICY")
        except Exception:
            return False

    return probe


def finalize(groups: dict, catalog: list, args, probe) -> tuple[list[dict], list[tuple[str, int]]]:
    rows: list[dict] = []
    summary: list[tuple[str, int]] = []
    pool = ThreadPoolExecutor(max_workers=args.workers) if args.check else None
    cap = args.per_language
    for order in sorted(groups):
        cands = groups[order]
        if not cands:
            continue
        title = catalog[order][0]
        cands.sort(key=lambda c: (-c["votes"], c["name"].lower()))
        uniq: list[dict] = []
        names: set = set()
        for c in cands:  # collapse repeated station names inside one language
            k = (re.sub(r"\W+", "", c["name"].lower()) or c["url"], c["country"])
            if k in names:
                continue
            names.add(k)
            uniq.append(c)
        if pool is not None:
            alive: list[dict] = []
            i, step = 0, max(args.workers * 2, 16)
            while i < len(uniq) and (cap == 0 or len(alive) < cap):
                batch = uniq[i:i + step]
                for c, ok in zip(batch, pool.map(lambda x: probe(x["url"]), batch)):
                    if ok:
                        alive.append(c)
                i += step
                log(f"    checking {title}: {len(alive)} alive so far")
            uniq = alive
        if cap:
            uniq = uniq[:cap]
        for c in uniq:
            rows.append({"group": title, "language": label(title), **c})
        summary.append((title, len(uniq)))
    if pool is not None:
        pool.shutdown()
    return rows, summary


# --- writers -----------------------------------------------------------------
def write_m3u(path: str, rows: list[dict], logos: bool) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write("#EXTM3U\n")
        for r in rows:
            attrs = [f'tvg-language="{attr(r["language"])}"']
            if r["country"]:
                attrs.append(f'tvg-country="{attr(r["country"])}"')
            fav = r["favicon"]
            if logos and re.match(r"https?://[^\s\"]+$", fav or ""):
                attrs.append(f'tvg-logo="{fav}"')
            attrs.append(f'group-title="{attr(r["group"])}"')
            name = re.sub(r"\s*,\s*", " - ", r["name"])
            f.write(f'#EXTINF:-1 {" ".join(attrs)},{name}\n{r["url"]}\n')


FIELDS = ["group", "name", "url", "language", "country", "codec", "bitrate", "tags", "votes", "homepage", "favicon"]


def write_json(path: str, rows: list[dict]) -> None:
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump([{k: r[k] for k in FIELDS} for r in rows], f, ensure_ascii=False, indent=1)


def write_csv(path: str, rows: list[dict]) -> None:
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


# --- main --------------------------------------------------------------------
def build_catalog(args) -> list:
    catalog = list(CATALOG)
    if args.only:
        wanted = [t.strip().lower() for t in args.only.split(",") if t.strip()]
        catalog = [c for c in catalog if any(t in c[0].lower() or t in c[1] for t in wanted)]
    if args.extra:
        for name in [t.strip().lower() for t in args.extra.split(",") if t.strip()]:
            catalog.append((name.title(), [name], []))
    return catalog


def main() -> int:
    ap = argparse.ArgumentParser(description="Build a language-grouped radio playlist (.mp3 / .m3u8 streams only).")
    ap.add_argument("-o", "--out", help="output file (default radio_cherry_stations.m3u8 / .json / .csv)")
    ap.add_argument("--format", choices=["m3u", "json", "csv"], default="m3u")
    ap.add_argument("--only", help="comma list of languages/groups to build, e.g. hindi,tamil,russian")
    ap.add_argument("--extra", help="extra radio-browser language names, each becomes its own group, e.g. swahili,hausa")
    ap.add_argument("--per-language", type=int, default=500, help="max stations per language group, 0 = no limit (default 500)")
    ap.add_argument("--scan", type=int, default=5000, help="max database records to read per language (default 5000)")
    ap.add_argument("--check", action="store_true", help="probe every stream and keep only the ones that answer")
    ap.add_argument("--workers", type=int, default=24, help="parallel probes for --check")
    ap.add_argument("--timeout", type=float, default=8, help="seconds per probe for --check")
    ap.add_argument("--loose", action="store_true", help="also accept URLs like .mp3?token=abc")
    ap.add_argument("--https-only", action="store_true", help="keep only https:// streams (newer Android blocks plain http in some apps)")
    ap.add_argument("--include-talk", action="store_true", help="do not filter out news/talk/sports/Quran stations")
    ap.add_argument("--logos", action="store_true", help="add tvg-logo attributes (bigger file, app loads icons)")
    ap.add_argument("--server", help="comma-separated API base URLs (default: discover radio-browser mirrors)")
    ap.add_argument("--cafile", help="extra CA bundle (corporate TLS inspection)")
    ap.add_argument("--list-groups", action="store_true")
    args = ap.parse_args()

    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(errors="replace")
    catalog = build_catalog(args)
    if args.list_groups:
        for title, aliases, tags in catalog:
            print(f"{title:22} languages={','.join(aliases)}" + (f" tags={','.join(tags)}" if tags else ""))
        return 0
    if not catalog:
        log("No language group matches --only.")
        return 2

    ctx = ssl.create_default_context(cafile=args.cafile) if args.cafile else ssl.create_default_context()
    servers = [s.strip() for s in args.server.split(",") if s.strip()] if args.server else discover_servers()
    api = Api(servers, ctx)
    log(f"Reading radio-browser.info via {servers[0]} ... ({len(catalog)} language groups)")
    groups = collect(api, catalog, args)
    probe = make_probe(ctx, args.timeout) if args.check else None
    rows, summary = finalize(groups, catalog, args, probe)
    if not rows:
        log("Nothing found - check your internet connection / proxy and try again.")
        return 2

    ext = {"m3u": ".m3u8", "json": ".json", "csv": ".csv"}[args.format]
    out = args.out or f"radio_cherry_stations{ext}"
    if args.format == "m3u":
        write_m3u(out, rows, args.logos)
    elif args.format == "json":
        write_json(out, rows)
    else:
        write_csv(out, rows)

    print(f"\nWrote {len(rows)} stations in {len(summary)} groups -> {out}\n")
    for title, n in summary:
        print(f"  {title:24}{n:>6}")
    if not args.check:
        print("\nTip: add --check to keep only streams that answer right now (takes longer).")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        log("\nCancelled.")
        sys.exit(130)
