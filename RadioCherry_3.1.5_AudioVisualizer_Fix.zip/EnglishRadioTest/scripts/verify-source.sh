#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$ROOT/app/src/main/java/com/example/englishradio/MainActivity.kt"
TV="$ROOT/app/src/main/java/com/example/englishradio/TvActivity.kt"
LINKCHECK="$ROOT/app/src/main/java/com/example/englishradio/StationLinkChecker.kt"
CATALOGUE="$ROOT/app/src/main/java/com/example/englishradio/RadioCatalogueRepository.kt"
PLAYLIST_RESOLVER="$ROOT/app/src/main/java/com/example/englishradio/PlaylistResolver.kt"
IMPORTED="$ROOT/app/src/main/java/com/example/englishradio/ImportedStations.kt"
PLAYBACK="$ROOT/app/src/main/java/com/example/englishradio/PlaybackService.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
APP_GRADLE="$ROOT/app/build.gradle.kts"
ROOT_GRADLE="$ROOT/build.gradle.kts"
STRINGS="$ROOT/app/src/main/res/values/strings.xml"

fail() { echo "::error::$*" >&2; exit 1; }
require() {
    local file="$1" needle="$2" description="$3"
    grep -Fq -- "$needle" "$file" || fail "Missing $description ($needle) in ${file#"$ROOT/"}"
}
require_regex() {
    local file="$1" pattern="$2" description="$3"
    grep -Eq -- "$pattern" "$file" || fail "Missing $description in ${file#"$ROOT/"}"
}
require_count() {
    local file="$1" needle="$2" expected="$3" description="$4"
    local actual
    actual="$(grep -Fc -- "$needle" "$file" || true)"
    [[ "$actual" == "$expected" ]] || fail "$description: expected $expected occurrence(s), found $actual"
}

# This source package is Radio Cherry 3.1.5. Do not revert the app version
# merely to satisfy a CI script left over from the 3.1.5 baseline.
require "$APP_GRADLE" 'versionCode = 16' 'versionCode 16'
require "$APP_GRADLE" 'versionName = "3.1.5"' 'versionName 3.1.5'
require "$STRINGS" '<string name="app_name">radio cherry</string>' 'application name'

# Mobile navigation, theme and shell.
require "$MAIN" 'RadioTab.NOW_PLAYING' 'Now Playing tab'
require "$MAIN" 'RadioTab.BROWSE' 'Browse tab'
require "$MAIN" 'RadioTab.FAVORITES' 'Favorites tab'
require "$MAIN" 'isSystemInDarkTheme()' 'system theme detection'
require "$MAIN" 'background = Color(0xFF000000)' 'AMOLED black background'
require "$MAIN" 'horizontalScroll(rememberScrollState())' 'horizontal scrolling'
require "$MAIN" 'theme_mode' 'persisted theme mode'
require "$MAIN" 'private fun PageHero' 'mobile PageHero'
require "$MAIN" 'PageHero("radio cherry"' 'Now Playing PageHero'
require_count "$MAIN" 'SectionHeading("Genres"' 1 'Browse Genres section'
require_count "$MAIN" 'GenreGrid(genres, activeGenre, onGenre, palette)' 1 'Browse GenreGrid'
require "$MAIN" 'private fun RadioBottomNavigation' 'radio bottom navigation'
if grep -Fq 'Text("Radio Cherry"' "$MAIN"; then
    fail 'Duplicate Radio Cherry empty-state title remains below the hero.'
fi

# Media-session actions and supported Media3 button icons.
require "$PLAYBACK" 'ACTION_PREVIOUS' 'previous action'
require "$PLAYBACK" 'ACTION_NEXT' 'next action'
require "$PLAYBACK" 'CommandButton.ICON_PREVIOUS' 'previous media command icon'
require "$PLAYBACK" 'CommandButton.ICON_NEXT' 'next media command icon'
if grep -Eq 'ICON_SKIP_PREVIOUS|ICON_SKIP_NEXT' "$PLAYBACK"; then
    fail 'Unsupported Media3 CommandButton icon constant found.'
fi

# Android TV launcher and navigation.
require "$TV" 'class TvActivity' 'TV activity'
require "$MANIFEST" 'android.intent.category.LEANBACK_LAUNCHER' 'Leanback launcher category'
require "$MANIFEST" 'android:name="android.software.leanback" android:required="false"' 'optional Leanback feature'
require "$MANIFEST" 'android:banner="@drawable/tv_banner"' 'TV banner resource'
require "$TV" 'TvPage.BROWSE' 'TV Browse page'
require "$TV" 'onCheckLinks = { settingsOpen = false; stationLinkCheckOpen = true }' 'TV Settings link-check action'
require "$MAIN" 'Icons.Default.Link' 'mobile link-check action'
require "$LINKCHECK" 'object StationLinkChecker' 'station playback checker'
require "$LINKCHECK" 'player.volume = 0f' 'muted station probes'
require "$LINKCHECK" 'PLAYING' 'confirmed playback status'
require "$LINKCHECK" 'IcyInfo' 'current song metadata capture'
require "$LINKCHECK" 'MediaStore.Downloads.EXTERNAL_CONTENT_URI' 'Downloads report export'
require "$LINKCHECK" 'station_link_check_session.jsonl' 'append-only station-check recovery journal'
require "$LINKCHECK" 'stream.fd.sync()' 'durable per-result journal checkpoint'
require "$LINKCHECK" 'suspend fun resume(context: Context)' 'interrupted-run resume path'
require "$LINKCHECK" 'DEFAULT_BATCH_SIZE = 5000' '5,000-station default batch size'
require "$LINKCHECK" 'BATCH_SIZE_OPTIONS = listOf(500, 1000, 2500, 5000, 10000)' 'expanded selectable station batch sizes'
require "$LINKCHECK" 'CURRENT_BATCH_SCHEMA_VERSION = 2' 'versioned batch-session migration'
require "$LINKCHECK" 'suspend fun migrateLegacyBatchPlan' 'safe migration of existing station-check sessions'
require "$LINKCHECK" 'Batch $shownBatch of $batchCount' 'visible batch number and total'
require "$LINKCHECK" 'suspend fun advanceBatch(context: Context, nextBatchIndex: Int)' 'durable next-batch checkpoint'
require "$LINKCHECK" 'suspend fun updateBatchSize(context: Context, batchSize: Int)' 'persisted batch-size selection'
require "$LINKCHECK" 'RUN NEXT / RESUME BATCH' 'separate next-batch and resume control'
require "$LINKCHECK" 'reuseExisting = true' 'single cumulative CSV reused across batches'
require "$LINKCHECK" 'appendLine(row.toCsvLine())' 'incremental CSV report writing'
require "$LINKCHECK" 'suspend fun loadQualityUpdates' 'compact quality-state replay'
require "$LINKCHECK" 'if (results.size >= 60)' 'bounded on-screen station result history'
require "$LINKCHECK" 'view.keepScreenOn = running' 'awake display during active scan'
require "$CATALOGUE" 'stations.clear()' 'batched catalogue status replacement'
require "$CATALOGUE" 'stations.addAll(updatedStations)' 'batched catalogue status replacement'
require "$LINKCHECK" 'group.isTrackSelected(index) && group.isTrackSupported(index)' 'selected decoded audio-track verification'
require "$LINKCHECK" 'quality_status,probe_status,country,country_code,language,genre,codec,bitrate_kbps' 'quality and station metadata report columns'
require "$PLAYLIST_RESOLVER" 'if (responseCode !in 200..299) throw IOException("HTTP $responseCode")' 'playlist HTTP error classification'
require "$CATALOGUE" 'private const val TARGET_STATIONS = 50_000' '50,000-station catalogue target'
require "$CATALOGUE" 'hidebroken=true' 'directory-level candidate pre-filter'
require "$CATALOGUE" 'formatPriority' 'Media3 codec prioritisation'
require "$CATALOGUE" 'stations.addAll(additions)' 'batched catalogue merge'
require "$CATALOGUE" 'qualityStatus = "UNVERIFIED"' 'candidate quality initial state'
require "$CATALOGUE" 'CACHE_MAX_AGE_MS' 'periodic catalogue refresh policy'
require "$MAIN" 'onRefreshCatalogue' 'mobile catalogue refresh control'
require "$TV" 'onRefreshCatalogue' 'TV catalogue refresh control'
require "$IMPORTED" 'import-supplied-bollywood-gaane-purane' 'compiled international station catalogue'
require "$ROOT/app/src/main/AndroidManifest.xml" 'android.permission.WRITE_EXTERNAL_STORAGE' 'legacy Downloads export permission'

# Mobile visualizer audio path. The current implementation deliberately uses
# a MobileAudioFrame holder plus callback coalescing; the former raw callback
# signature and a direct Handler.post() are obsolete implementation details.
require "$MAIN" 'private data class MobileAudioFrame' 'mobile audio-frame model'
require "$MAIN" 'waveform: FloatArray, level: Float' 'mobile waveform frame helper signature'
require "$MAIN" 'android.os.Handler(android.os.Looper.getMainLooper()).post' 'main-looper frame dispatch'
require "$MAIN" 'val audioFrame = remember { mutableStateOf(MobileAudioFrame()) }' 'stable mobile audio-frame holder'
require "$MAIN" 'Visualizer(sessionId)' 'Android Visualizer session'
require "$MAIN" 'onWaveFormDataCapture' 'waveform capture callback'
require "$MAIN" 'AtomicBoolean(false)' 'mobile frame publish coalescing flag'
require "$MAIN" 'AtomicReference<Pair<FloatArray, Float>?>(null)' 'latest mobile audio-frame reference'
require "$MAIN" 'mainHandler.postDelayed(publishFrame, 50L)' 'coalesced mobile frame publish'
require "$MAIN" 'val currentAudioFrame = audioFrame.value' 'Canvas-scoped audio-frame read'
require "$MAIN" 'val sampleIndex = (t * (waveform.size - 1))' 'waveform-to-hero mapping'

# TV audio path: coalesce waveform and FFT data into one frame, and consume it
# in the visual scene Canvas rather than from the root TV screen.
require "$TV" 'framePublishPending = AtomicBoolean(false)' 'TV frame publish coalescing flag'
require "$TV" 'mainHandler.postDelayed(publishFrame, 50L)' 'coalesced TV frame publish'
require "$TV" 'audioFrame: State<TvAudioFrame>' 'TV audio-frame state passed to scene'
require "$TV" 'val currentFrame = audioFrame.value' 'Canvas-scoped TV audio-frame read'
require "$TV" 'onFftDataCapture' 'FFT capture callback'
require "$TV" 'val metadataTop = maxHeight * 0.735f' 'station metadata lane below orbital field'
require "$TV" 'if (fullScreen) h * 0.365f else h * 0.35f' 'upper orb placement'
require "$TV" 'val waveCenterY = h * 0.385f' 'waveform alignment with orb'
require "$TV" 'val fullWidthBottomBars = fullScreen' 'consistent full-screen spectrum lane for all styles'
require "$TV" 'val arcY = h * if (fullScreen) 0.90f else 0.88f' 'bottom spectrum rail'
require "$TV" 'val maxBarHeight = minDim * if (fullScreen) 0.045f else 0.085f' 'spectrum height limit'
require "$TV" 'TvMiniVisualizerButton(Icons.Default.SkipPrevious, "Previous station", onPrevious' 'Now Playing previous icon control'
require "$TV" 'TvMiniVisualizerButton(Icons.Default.Stop, "Stop playback", onStopPlayback' 'Now Playing stop icon control'
require "$TV" 'TvMiniVisualizerButton(Icons.Default.Timer,' 'Now Playing sleep timer icon control'

# Visualizer palette and scene identity.
require "$MAIN" 'contourCount = 13' 'hero contour count'
require "$MAIN" 'glowSpecs' 'hero glow specifications'
require "$MAIN" '0xFF17D9D0' 'teal accent'
require "$MAIN" '0xFF398CFB' 'electric-blue accent'
require "$MAIN" '0xFF9E49F0' 'violet accent'

# Android SDK, AGP, Kotlin and JVM compatibility.
require_regex "$APP_GRADLE" 'compileSdk[[:space:]]*=[[:space:]]*36' 'compileSdk 36'
require_regex "$APP_GRADLE" 'targetSdk[[:space:]]*=[[:space:]]*36' 'targetSdk 36'
require "$ROOT_GRADLE" 'id("com.android.application") version "8.13.2" apply false' 'Android Gradle Plugin 8.13.2'
require "$ROOT_GRADLE" 'id("org.jetbrains.kotlin.android") version "2.2.21" apply false' 'Kotlin Android plugin 2.2.21'
require "$ROOT_GRADLE" 'id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false' 'Kotlin Compose plugin 2.2.21'
require "$APP_GRADLE" 'jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17' 'JVM 17 target'

# Station catalogue source assets and compile-time station count.
require "$ROOT/app/src/main/assets/playlists/list.txt" '#EXTM3U' 'world-radio playlist asset'
require "$ROOT/app/src/main/res/drawable/ic_launcher_foreground.png" '' 'mobile/TV adaptive foreground icon'
require "$ROOT/app/src/main/res/drawable-nodpi/tv_banner.png" '' 'TV launcher banner artwork'
require "$ROOT/tools/build_radio_playlist.py" 'def main() -> int:' 'station playlist builder utility'
require_count "$IMPORTED" 'Station("import-supplied-' 95 'newly compiled unique station entries'

echo 'Radio Cherry 3.1.5 identity, station catalogue, silent playback checker, Downloads report export, mobile/TV entry points, navigation, media controls and visualizer source verified.'
