#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$ROOT/app/src/main/java/com/example/englishradio/MainActivity.kt"
TV="$ROOT/app/src/main/java/com/example/englishradio/TvActivity.kt"
PLAYBACK="$ROOT/app/src/main/java/com/example/englishradio/PlaybackService.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
APP_GRADLE="$ROOT/app/build.gradle.kts"
ROOT_GRADLE="$ROOT/build.gradle.kts"
STRINGS="$ROOT/app/src/main/res/values/strings.xml"

fail() { echo "::error::$*" >&2; exit 1; }
require() {
    local file="$1" needle="$2" description="$3"
    grep -Fq -- "$needle" "$file" || fail "Missing $description ($needle) in ${file#"$ROOT/"}"
}
require_regex() {
    local file="$1" pattern="$2" description="$3"
    grep -Eq -- "$pattern" "$file" || fail "Missing $description in ${file#"$ROOT/"}"
}
require_count() {
    local file="$1" needle="$2" expected="$3" description="$4"
    local actual
    actual="$(grep -Fc -- "$needle" "$file" || true)"
    [[ "$actual" == "$expected" ]] || fail "$description: expected $expected occurrence(s), found $actual"
}

# This source package is Radio Cherry 3.1.5. Do not revert the app version
# merely to satisfy a CI script left over from the 3.1.5 baseline.
require "$APP_GRADLE" 'versionCode = 16' 'versionCode 16'
require "$APP_GRADLE" 'versionName = "3.1.5"' 'versionName 3.1.5'
require "$STRINGS" '<string name="app_name">radio cherry</string>' 'application name'

# Mobile navigation, theme and shell.
require "$MAIN" 'RadioTab.NOW_PLAYING' 'Now Playing tab'
require "$MAIN" 'RadioTab.BROWSE' 'Browse tab'
require "$MAIN" 'RadioTab.FAVORITES' 'Favorites tab'
require "$MAIN" 'isSystemInDarkTheme()' 'system theme detection'
require "$MAIN" 'background = Color(0xFF000000)' 'AMOLED black background'
require "$MAIN" 'horizontalScroll(rememberScrollState())' 'horizontal scrolling'
require "$MAIN" 'theme_mode' 'persisted theme mode'
require "$MAIN" 'private fun PageHero' 'mobile PageHero'
require "$MAIN" 'PageHero("radio cherry"' 'Now Playing PageHero'
require_count "$MAIN" 'SectionHeading("Genres"' 1 'Browse Genres section'
require_count "$MAIN" 'GenreGrid(genres, activeGenre, onGenre, palette)' 1 'Browse GenreGrid'
require "$MAIN" 'private fun RadioBottomNavigation' 'radio bottom navigation'
if grep -Fq 'Text("Radio Cherry"' "$MAIN"; then
    fail 'Duplicate Radio Cherry empty-state title remains below the hero.'
fi

# Media-session actions and supported Media3 button icons.
require "$PLAYBACK" 'ACTION_PREVIOUS' 'previous action'
require "$PLAYBACK" 'ACTION_NEXT' 'next action'
require "$PLAYBACK" 'CommandButton.ICON_PREVIOUS' 'previous media command icon'
require "$PLAYBACK" 'CommandButton.ICON_NEXT' 'next media command icon'
if grep -Eq 'ICON_SKIP_PREVIOUS|ICON_SKIP_NEXT' "$PLAYBACK"; then
    fail 'Unsupported Media3 CommandButton icon constant found.'
fi

# Android TV launcher and navigation.
require "$TV" 'class TvActivity' 'TV activity'
require "$MANIFEST" 'android.intent.category.LEANBACK_LAUNCHER' 'Leanback launcher category'
require "$MANIFEST" 'android:name="android.software.leanback" android:required="false"' 'optional Leanback feature'
require "$MANIFEST" 'android:banner="@drawable/tv_banner"' 'TV banner resource'
require "$TV" 'TvPage.BROWSE' 'TV Browse page'

# Mobile visualizer audio path. The current implementation deliberately uses
# a MobileAudioFrame holder plus callback coalescing; the former raw callback
# signature and a direct Handler.post() are obsolete implementation details.
require "$MAIN" 'private data class MobileAudioFrame' 'mobile audio-frame model'
require "$MAIN" 'waveform: FloatArray, level: Float' 'mobile waveform frame helper signature'
require "$MAIN" 'android.os.Handler(android.os.Looper.getMainLooper()).post' 'main-looper frame dispatch'
require "$MAIN" 'val audioFrame = remember { mutableStateOf(MobileAudioFrame()) }' 'stable mobile audio-frame holder'
require "$MAIN" 'Visualizer(sessionId)' 'Android Visualizer session'
require "$MAIN" 'onWaveFormDataCapture' 'waveform capture callback'
require "$MAIN" 'AtomicBoolean(false)' 'mobile frame publish coalescing flag'
require "$MAIN" 'AtomicReference<Pair<FloatArray, Float>?>(null)' 'latest mobile audio-frame reference'
require "$MAIN" 'mainHandler.postDelayed(publishFrame, 50L)' 'coalesced mobile frame publish'
require "$MAIN" 'val currentAudioFrame = audioFrame.value' 'Canvas-scoped audio-frame read'
require "$MAIN" 'val sampleIndex = (t * (waveform.size - 1))' 'waveform-to-hero mapping'

# TV audio path: coalesce waveform and FFT data into one frame, and consume it
# in the visual scene Canvas rather than from the root TV screen.
require "$TV" 'framePublishPending = AtomicBoolean(false)' 'TV frame publish coalescing flag'
require "$TV" 'mainHandler.postDelayed(publishFrame, 50L)' 'coalesced TV frame publish'
require "$TV" 'audioFrame: State<TvAudioFrame>' 'TV audio-frame state passed to scene'
require "$TV" 'val currentFrame = audioFrame.value' 'Canvas-scoped TV audio-frame read'
require "$TV" 'onFftDataCapture' 'FFT capture callback'

# Visualizer palette and scene identity.
require "$MAIN" 'contourCount = 13' 'hero contour count'
require "$MAIN" 'glowSpecs' 'hero glow specifications'
require "$MAIN" '0xFF17D9D0' 'teal accent'
require "$MAIN" '0xFF398CFB' 'electric-blue accent'
require "$MAIN" '0xFF9E49F0' 'violet accent'

# Android SDK, AGP, Kotlin and JVM compatibility.
require_regex "$APP_GRADLE" 'compileSdk[[:space:]]*=[[:space:]]*36' 'compileSdk 36'
require_regex "$APP_GRADLE" 'targetSdk[[:space:]]*=[[:space:]]*36' 'targetSdk 36'
require "$ROOT_GRADLE" 'id("com.android.application") version "8.13.2" apply false' 'Android Gradle Plugin 8.13.2'
require "$ROOT_GRADLE" 'id("org.jetbrains.kotlin.android") version "2.2.21" apply false' 'Kotlin Android plugin 2.2.21'
require "$ROOT_GRADLE" 'id("org.jetbrains.kotlin.plugin.compose") version "2.2.21" apply false' 'Kotlin Compose plugin 2.2.21'
require "$APP_GRADLE" 'jvmTarget = org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17' 'JVM 17 target'

echo 'Radio Cherry 3.1.5 source identity, mobile/TV navigation, media controls, audio-frame coalescing, visualizer palette, SDK and compiler versions verified.'
