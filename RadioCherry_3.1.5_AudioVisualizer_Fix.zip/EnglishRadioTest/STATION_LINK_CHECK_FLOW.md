# Radio Cherry — station link-check flow

## What changed

The station checker no longer keeps the full run's result set in Compose memory or waits until the end to create its report.

### During a run

1. A new run creates an internal append-only journal at `filesDir/station_link_check_session.jsonl` and, on Android 10+, creates a CSV in `Downloads/Radio Cherry` before the first station is checked.
2. Four muted Media3 probes continue to test actual audio playback.
3. When a station finishes, its complete result is appended to the JSONL journal and synchronously flushed to disk. The corresponding CSV row is appended and flushed to the Downloads report.
4. The dialog keeps only the latest 60 rows for display. Checked station IDs and the aggregate status counts are reconstructed from the journal when the dialog opens.
5. The display stays awake while the checker is running. Keep the device connected to power for a long scan.

The internal journal is the source of truth. If Android kills the process between writing the journal and the CSV, the next Resume operation rebuilds a fresh CSV from the journal before continuing. At successful completion, the report writer is finalized; if an incremental write failed, the CSV is rebuilt from the journal. This prevents a lost or incomplete CSV row from causing a station to be checked twice.

### Resume and pause

- **PAUSE** cancels active probes, closes the report writer, and leaves the session marked resumable.
- **RESUME** reloads station IDs already present in the journal, rebuilds the report, and checks only stations not yet recorded.
- **NEW RUN** intentionally starts over with a fresh journal and CSV. Earlier CSV files are left in Downloads.
- **SAVE LOG** rebuilds the Downloads CSV from the full journal. On Android 8/9, the existing storage-permission flow is used for the export.

A process crash or force-stop does not run the pause callback, but the journal and the active-session preference are already written. Opening the checker again offers Resume. If the process died after the final station but before final catalogue persistence, Resume detects that there are no remaining stations and completes the final persistence step.

### Final catalogue update

Station quality states are applied to the in-memory catalogue and compressed catalogue cache once, after all stations are checked. The update is built from a compact station-ID/status map rather than recreating and retaining all full result objects. The observable station list is replaced in one batch rather than issuing one Compose list mutation per station.

## Limits

- The scan remains an interactive in-app operation, not a background service. The screen is kept awake while the dialog is open, but Android can still terminate the app or the user can close it. In either case, Resume recovers saved results; it does not guarantee unattended execution while the app is closed.
- On Android 10 and later, the report is written to Downloads while the run progresses. If MediaStore cannot create the file, the internal journal remains intact and **SAVE LOG** retries report creation.
- A station is recorded as VERIFIED only after Media3 confirms selected supported audio is actively playing. HTTP 404/410 is DEAD; other failures remain UNVERIFIED.
- The checker still uses four concurrent probes and its existing per-station playback timeout. This change protects and resumes long scans; it does not promise a shorter total scan duration.

## Files changed

- `app/src/main/java/com/example/englishradio/StationLinkChecker.kt`
- `app/src/main/java/com/example/englishradio/RadioCatalogueRepository.kt`
