# Radio Cherry 3.1.5 — Visualizer and responsiveness fixes

## Visualizer presentation

- Replaced the text-based “BACK TO NORMAL MODE” treatment with the same vector back-arrow control across NEBULA, NEON, STARFIELD and AURORA.
- Moved the Radio Cherry LIVE label, station name, genre/broadcaster and ON AIR status below the orbital field with additional clearance; reduced their type sizes so none of the text sits on the orb or orbital rings.
- Removed the extra line work drawn across the orb face and softened the orb contour so it reads as a sphere rather than a broken waveform.
- Retuned the NEON orb to a teal, electric-blue, violet, magenta and pink gradient and retained a deep-space starfield for STARFIELD.
- Kept Aurora's existing particle/path renderer unchanged.

## Rendering and input responsiveness

- Moved TV audio-frame state observation into the Canvas draw pass. Audio samples no longer trigger recomposition of the TV root, remote controls, sidebar or Settings.
- Removed audio-driven per-frame recomposition from the TV visualizer transport controls and volume slider. The primary play control and metadata brightness react through layer properties instead.
- Applied the same stable audio-frame pattern to mobile Browse, Favorites and Now Playing headers; only the header Canvas observes audio samples.
- Limited mobile header scene updates to 25 fps and TV scene updates to 20 fps so audio-reactive motion remains fluid without needlessly refreshing at display refresh rate.
- Unified all four full-screen visualizers on one bottom-spectrum lane; limited spectrum-bar height so the bars remain below station metadata and above the transport row.
- Moved the orb/orbit field upward and the station metadata into a dedicated lane beneath the rings. The flowing waveform remains centered on the orb; the lower FFT spectrum and transport controls occupy separate, non-overlapping bands.
- Repositioned the compact Now Playing scene so its orbit field, preview spectrum, station metadata and transport row also have separate vertical space.
- Reduced non-Aurora cloud, particle, waveform-point and spectrum-bar workloads; moved the visualizer clock to a 20 fps invalidation cadence.
- Continued to coalesce waveform and FFT capture before publishing one stable audio frame.

## Now Playing transport

- Added explicit Previous, Play/Pause, Stop and Next controls to the mobile Now Playing screen, including its no-station-selected state.
- TV Now Playing now uses the same icon-only circular transport controls as the full-screen visualizer: Previous, Play/Pause, Stop, Next, Favourite and Sleep Timer, with the volume control aligned at the opposite edge.
- Made the TV Now Playing visualizer height responsive to the available viewport so its transport row remains visible on shorter TV layouts.
- Kept the corresponding controls on the full-screen TV visualizer.
- Play from an empty mobile player starts the first station instead of doing nothing.

## Build validation

- Kotlin parser scan: no syntax diagnostics found. The local compiler cannot resolve Android/Compose dependencies without the Android Gradle classpath, so this is not a full compile result.
- Full Android release build was not run here because this environment does not contain the Android SDK, Gradle executable or a Gradle wrapper. Run `gradle --no-daemon --stacktrace :app:assembleRelease` in the configured Android build runner before publishing.


## Station catalogue and link detection

- Compiled 95 additional unique stations from the supplied world-radio playlist and station CSV into the app's static station catalogue. The final catalogue contains 369 stations, including the app's original curated stations.
- Deduplicated by normalized stream URL and by station identity when the supplied files contained alternate URLs for a station already present.
- Retained the supplied M3U playlists, station CSV and world-radio `list.txt` under app assets; retained the Python radio playlist builder as a project utility.
- Added Station Link Detection to Android TV Settings and a link-check shortcut in the mobile app bar.
- The checker runs muted Media3 playback probes (four concurrent), so a simple HTTP response is not treated as proof that a radio stream works. It records actual playback status and ICY/current-track metadata when provided.
- A completed check automatically saves a CSV report to `Downloads/Radio Cherry/`; the report includes station name, URL, result, detected track metadata, details, elapsed time and timestamp. No stations are auto-deleted; results are for review.


## Station checker — explicit batch execution

- Added selectable station-check batch sizes: 50, 100, 250 and 500 stations. The default is 100.
- NEW RUN starts Batch 1 only; each RUN NEXT / RESUME BATCH action processes the current or next batch rather than launching every remaining station.
- Saved the batch size and next-batch index in the recovery session. A pause or process interruption resumes the current batch and skips station IDs already journaled.
- The batch size remains adjustable until Batch 1 completes, including for an existing pre-batch session; it is then locked to preserve stable batch boundaries.
- Batch number, total batches and per-batch progress are shown in the checker. At 48,748 stations, 100 per batch produces 488 batches; 500 per batch produces 98.
- Resume and SAVE LOG rebuild the existing Downloads CSV in place where possible, avoiding a new full-report CSV for each batch.
- Source validation and a standalone Kotlin parser scan found no syntax diagnostics. A full Android/Compose type-check and Release build were not available in this environment.
