# Radio Cherry 3.1.6 — Visualizer and responsiveness fixes

## Visualizer presentation

- Replaced the text-based “BACK TO NORMAL MODE” treatment with the same vector back-arrow control across NEBULA, NEON, STARFIELD and AURORA.
- Moved the Radio Cherry LIVE label, station name, genre/broadcaster and ON AIR status below the orbital field with additional clearance; reduced their type sizes so none of the text sits on the orb or orbital rings.
- Removed the extra line work drawn across the orb face and softened the orb contour so it reads as a sphere rather than a broken waveform.
- Retuned the NEON orb to a teal, electric-blue, violet, magenta and pink gradient and retained a deep-space starfield for STARFIELD.
- Kept Aurora's existing particle/path renderer unchanged.

## Rendering and input responsiveness

- Moved TV audio-frame state observation into the Canvas draw pass. Audio samples no longer trigger recomposition of the TV root, remote controls, sidebar or Settings.
- Removed audio-driven per-frame recomposition from the TV visualizer transport controls and volume slider. The primary play control and metadata brightness react through layer properties instead.
- Applied the same stable audio-frame pattern to mobile Browse, Favorites and Now Playing headers; only the header Canvas observes audio samples.
- Limited mobile header scene updates to 25 fps and TV scene updates to 20 fps so audio-reactive motion remains fluid without needlessly refreshing at display refresh rate.
- Lowered the non-Aurora full-screen spectrum rail and limited bar height, keeping the metadata band clear; Aurora’s existing spectrum geometry remains unchanged.
- Reduced non-Aurora cloud, particle, waveform-point and spectrum-bar workloads; moved the visualizer clock to a 20 fps invalidation cadence.
- Continued to coalesce waveform and FFT capture before publishing one stable audio frame.

## Now Playing transport

- Added explicit Previous, Play/Pause, Stop and Next controls to the mobile Now Playing screen, including its no-station-selected state.
- Kept the corresponding controls on TV Now Playing and the full-screen TV visualizer.
- Play from an empty mobile player starts the first station instead of doing nothing.

## Build validation

- Kotlin parser scan: no syntax diagnostics found. The local compiler cannot resolve Android/Compose dependencies without the Android Gradle classpath, so this is not a full compile result.
- Full Android release build was not run here because this environment does not contain the Android SDK, Gradle executable or a Gradle wrapper. Run `gradle --no-daemon --stacktrace :app:assembleRelease` in the configured Android build runner before publishing.
