# CI validation update for Radio Cherry 3.1.6

The uploaded project is already version **3.1.6** (`versionCode = 17`). The previous inline GitHub Actions validation block was written for the 3.1.5 baseline and checks implementation details that have since changed.

## What changed in the validation

- Version checks now expect `versionCode = 17` and `versionName = "3.1.6"`.
- The old `waveform: FloatArray, level: Float` assertion has been replaced with checks for the current `MobileAudioFrame` model, stable state holder, atomic latest-frame reference, coalesced delayed publish, and Canvas-scoped frame read.
- The old literal `android.os.Handler(android.os.Looper.getMainLooper()).post` assertion has been replaced with checks for `mainHandler.postDelayed(publishFrame, 50L)`, which is the current coalesced publication path.
- TV checks confirm the equivalent coalescing path and Canvas-scoped `TvAudioFrame` read.

## Use the checked-in validation script

Replace the long inline source-assertion block in the existing GitHub Actions workflow with:

```yaml
- name: Verify Radio Cherry source
  run: bash scripts/verify-source.sh
```

Keep the release build step immediately after it:

```yaml
- name: Assemble release
  run: gradle --no-daemon --stacktrace :app:assembleRelease
```

The original workflow file was not included in the uploaded ZIP, so this package cannot overwrite that external workflow. The checked-in script is the corrected, reproducible replacement for its outdated grep assertions.
