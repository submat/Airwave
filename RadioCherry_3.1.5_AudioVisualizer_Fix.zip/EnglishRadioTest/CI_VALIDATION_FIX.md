# Radio Cherry 3.1.5 CI compatibility repair

The project remains **Radio Cherry 3.1.5** (`versionCode = 16`) to match the existing GitHub Actions source-identity assertions. The earlier package revision incorrectly changed the application identity to 3.1.6, which caused the first two `grep` checks to fail immediately.

The mobile visualizer retains its coalesced audio-frame design. Two small, real helpers preserve the implementation contracts expected by the existing CI checks:

- `mobileAudioFrame(waveform: FloatArray, level: Float)` converts the published waveform/level pair into the Compose frame model.
- `postToMainThread(...)` marshals the delayed coalesced frame publication onto the Android main looper. The reusable session handler still owns the delayed runnable and its cancellation.

The source now matches the existing inline checks for version identity, audio-frame helper signature, sample-index mapping, and main-looper posting. No dummy assertion strings or comments were added to fake a passing grep.

Run the checked-in validation script from the repository root:

```bash
bash scripts/verify-source.sh
```

Then run the release build in the configured Android runner:

```bash
gradle --no-daemon --stacktrace :app:assembleRelease
```

The GitHub Actions workflow YAML was not present in the uploaded source archive, so it is not rewritten here. The app source is instead aligned with the exact 3.1.5 assertions in the workflow log supplied for this repair.
