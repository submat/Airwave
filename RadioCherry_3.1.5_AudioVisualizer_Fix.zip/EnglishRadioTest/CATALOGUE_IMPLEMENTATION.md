# Radio Cherry station catalogue

## What remains unchanged

The 24 built-in stations and the 345 entries in `ImportedStations.kt` remain in the catalogue. The runtime directory catalogue is additive and de-duplicates against the existing station and fallback URLs before insertion.

## International catalogue

Radio Cherry queries the Radio Browser station directory at runtime and targets up to 50,000 eligible, unique station URLs. Requests are paginated in batches of 1,000 and use the directory's `hidebroken=true` candidate filter. Directory reachability is only a candidate-selection hint; it does not mark a station as playable.

The app retains station name, country and country code, language, genre/tags, codec, bitrate, HLS indication, directory check timestamp and source vote count. HLS, AAC and MP3 entries are ordered ahead of other formats. The source codec and HLS information are both retained in the display label when applicable.

Non-English entries are placed in the Languages category, with language as the sub-filter. English entries are only added to the existing genre categories when their tags or name clearly map to an existing Radio Cherry music category. English talk/news and other entries that do not fit an existing music genre are not added to a new English catch-all category. Entries without language metadata are shown as Unspecified rather than being assigned a guessed language.

URLs are normalized and de-duplicated against both the original catalogue and other downloaded candidates. The curated built-in list, including SomaFM, is not overwritten.

## Quality states

Every directory-sourced entry starts as `UNVERIFIED`, even when Radio Browser currently reports it online. The in-app Station Link Detection action launches muted Media3 playback probes. `VERIFIED` requires a selected, supported audio track and sustained active playback. An explicit HTTP 404 or 410 is `DEAD`. Timeouts, 403/401, decoding failures, missing audio tracks and other inconclusive outcomes stay `UNVERIFIED` rather than being assumed dead.

The checker runs up to four concurrent probes, checks the full current catalogue, can be cancelled, and persists completed results for downloaded stations. It exports a CSV report to `Downloads/Radio Cherry` with station identity, stream URL, quality state, country, language, genre, codec, bitrate, directory check time, playback result, metadata, timing and diagnostic details. A full 50,000-entry verification run can take a long time; partial results are retained when cancelled.

## Caching and refresh

The downloaded catalogue is stored as a compressed JSON cache in the app's private files directory, not inside the APK. It refreshes automatically when older than seven days, can be refreshed manually from the Languages view, and falls back to the last saved catalogue when the directory cannot be reached. The APK remains compact and can receive catalogue updates independently of app releases.
