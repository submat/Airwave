# radio cherry · Android 3.1.5

Native Android internet-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Mobile experience

The existing phone interface remains in `MainActivity.kt`. It retains the Now Playing, Browse and Favourites experience, station catalogue, search, saved favourites and audio-session-driven waveform visualizer.

## Google TV experience

Google TV uses a dedicated landscape interface in `TvActivity.kt`, styled to match the supplied matte teal-to-pink reference screens:

- Now Playing artwork panel with a live circular visualizer, orbital rings, flowing audio-reactive wave strands, particles and FFT spectrum bars.
- Separate full-screen visualizer with a vector Back icon shared by all four styles.
- Browse with station search, genre filters and remote-friendly station rows; Favourites has its own uncluttered list.
- D-pad / OK focus states for navigation, playback, station selection, favourites, search, settings and visualizer controls.
- Sleep timer options (15, 30, 45, 60 or 90 minutes) that pause and clear the live stream when the timer expires. The “Turn Off TV” action also releases the screen-awake flag and blanks the app display; actual hardware standby is controlled by the TV firmware’s idle-power setting because ordinary apps do not have system shutdown / HDMI-CEC privileges.
- Settings for background audio playback, hiding volume controls, hiding previous/next controls, and keeping the TV display awake.
- An Exit App action that stops playback, closes the task and terminates the app process.

The four full-screen visualizers share a live Canvas renderer. The orb remains visually clear: waveform strands travel behind it rather than being drawn across its face. Station metadata sits below the orbital field and does not overlap the orb. Waveform and FFT callbacks are coalesced into a stable audio-frame holder observed only by the Canvas draw pass, so new audio frames do not recompose TV navigation, controls or settings. Non-Aurora particle, path and cloud workloads are reduced for TV hardware. FFT magnitudes are mapped logarithmically across the available frequency bins. Grant the RECORD_AUDIO permission when prompted to enable live visualizer capture.

The existing `SplashActivity` displays the supplied Cherry photograph and routes phones to the mobile activity and Google TV devices to the TV activity. The same Media3 `PlaybackService`, station catalogue and `radio_cherry_preferences` favourites are shared across both form factors.

## Playback behaviour

`PlaybackService` uses Media3 audio attributes with audio-focus handling enabled. The service supports continuing radio playback while the TV app is in the background when that setting is enabled. Disabling the setting pauses and clears the stream when the TV activity moves to the background. The Keep Screen Awake option applies `FLAG_KEEP_SCREEN_ON` while the TV activity is visible. The “Turn Off TV” sleep action clears that flag, blanks the display and restores brightness on resume or the next remote-key event. Android TV still controls the actual hardware standby transition through its configured idle-power timeout; a normal third-party app cannot force hardware power-off.

## Build requirements

- JDK 17
- Android SDK platform 36 and Build Tools 36.0.0
- Gradle 8.13

```bash
gradle --no-daemon :app:assembleDebug
gradle --no-daemon :app:assembleRelease
```

## CI / release validation

This source archive does not include the repository's `.github/workflows` files. It is aligned with the existing Radio Cherry 3.1.5 inline source checks supplied for this repair, so those checks can remain in the repository workflow without changing the app's version identity or reverting the coalesced visualizer update.

Keep signing credentials in GitHub Actions Secrets; do not commit keystores or passwords into the source archive.

## CI source verification (3.1.5)

Run `bash scripts/verify-source.sh` before `gradle --no-daemon --stacktrace :app:assembleRelease`.
The script validates the 3.1.5 version identity and the coalesced mobile/TV audio-frame implementation, including the waveform frame helper and main-looper posting contract used by the existing CI assertions. The existing inline GitHub Actions grep assertions are retained as compatibility checks; run the script for a single reproducible validation command.
