# radio cherry · Android 3.1.5

Native Android internet-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Mobile experience

The existing phone interface remains in `MainActivity.kt`. It retains the Now Playing, Browse and Favourites experience, station catalogue, search, saved favourites and audio-session-driven waveform visualizer.

## Google TV experience

Google TV uses a dedicated landscape interface in `TvActivity.kt`, styled to match the supplied matte teal-to-pink reference screens:

- Now Playing artwork panel with a live circular visualizer, orbital rings, flowing audio-reactive wave strands, particles and FFT spectrum bars.
- Separate full-screen visualizer with a Back to Normal Mode action.
- Browse with station search, genre filters and remote-friendly station rows; Favourites has its own uncluttered list.
- D-pad / OK focus states for navigation, playback, station selection, favourites, search, settings and visualizer controls.
- Sleep timer options (15, 30, 45, 60 or 90 minutes) that pause and clear the live stream when the timer expires.
- Settings for background audio playback, hiding volume controls, hiding previous/next controls, and keeping the TV display awake.
- An Exit App action that stops playback, closes the task and terminates the app process.

The waveform, circular rings, particle positions, spectrum arc, flowing strands and soft nebula fields use audio-session waveform and FFT capture. Grant the RECORD_AUDIO permission when prompted to enable live visualizer capture.

The existing `SplashActivity` displays the supplied Cherry photograph and routes phones to the mobile activity and Google TV devices to the TV activity. The same Media3 `PlaybackService`, station catalogue and `radio_cherry_preferences` favourites are shared across both form factors.

## Playback behaviour

`PlaybackService` uses Media3 audio attributes with audio-focus handling enabled. The service supports continuing radio playback while the TV app is in the background when that setting is enabled. Disabling the setting pauses and clears the stream when the TV activity moves to the background. The Keep Screen Awake option applies `FLAG_KEEP_SCREEN_ON` while the TV activity is visible; Android TV may still control its screensaver after the app is no longer foregrounded.

## Build requirements

- JDK 17
- Android SDK platform 36 and Build Tools 36.0.0
- Gradle 8.13

```bash
gradle --no-daemon :app:assembleDebug
gradle --no-daemon :app:assembleRelease
```

## GitHub Actions

The repository workflows expect `RadioCherry_3.1.5_AudioVisualizer_Fix.zip` at the repository root. The debug workflow produces `radio-cherry-debug-apk`. The signed release workflow produces `radio-cherry-3.1.5-signed-release-apk` and uses the four GitHub Actions secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` and `KEY_PASSWORD`.

Both workflows include the `google-tv` branch in their push triggers. The signing keystore and passwords must be kept in GitHub Actions Secrets; do not commit them or share them in chat.
