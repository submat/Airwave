# radio cherry · Android 3.0.0

Native Android internet-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Reference UI rebuild

The UI is rebuilt around the supplied Radio Cherry visual references. It provides three first-class screens: **Now Playing**, **Browse** and **Favorites**. Each screen uses the same animated colour-cloud and multi-line waveform header, with a typography-led layout, generous white space, soft rounded station cards and a flat three-item bottom navigation.

The app follows the device's system appearance and has matching light and dark palettes. The waveform is rendered at runtime with Compose Canvas; while a station is playing, Android audio-session capture contributes to its movement when RECORD_AUDIO permission is granted. The waveform has a subtle idle animation when playback is stopped or permission is unavailable.

## Radio functionality retained

- 223 curated station entries: 24 original stations plus the imported music catalogue.
- Station search and genre filtering. News and talk stations are excluded from the imported catalogue.
- Favorites are persisted locally and can be added or removed from Browse, Now Playing and Favorites.
- Media3 streaming playback with playlist URL resolution and fallback stream support.
- Background playback, notification controls, lock-screen media controls and session metadata remain in `PlaybackService.kt`.
- Previous/next controls move between radio stations; they do not seek within a live radio stream.

## Build requirements

- JDK 17
- Android SDK platform 36 and Build Tools 36.0.0
- Gradle 8.13

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

Place `RadioCherry_ReferenceUI_Build.zip` in the repository root and save the supplied workflow as `.github/workflows/build-apk.yml`. The workflow intentionally fails if that exact archive is missing; it never falls back to an older ZIP. The resulting artifact is named `radio-cherry-debug-apk`.

## System media artwork

The in-app waveform is live Compose drawing. Android owns the notification shade and lock-screen media surfaces, so those use static Media3 artwork rather than an animated Compose view.


## Google TV support

This build adds a dedicated landscape Leanback launcher and a TV-first Compose interface.
The TV activity shares the existing Media3 `PlaybackService`, station catalogue and
`radio_cherry_preferences` favourites with the phone/tablet interface. Use the TV remote's
D-pad and OK button to move between Now Playing, Browse and Favourites. The Android TV
launcher banner is `app/src/main/res/drawable-nodpi/tv_banner.png`.

The existing phone launcher and mobile UI remain in place. TV compatibility declarations
are optional so phones are not excluded from Google Play/device installation.
