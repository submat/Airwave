package com.example.englishradio

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/**
 * Expands Radio Cherry's unchanged curated catalogue with language-grouped stations.
 * Radio Browser's `hidebroken=true` is used only as a directory-level pre-filter;
 * every added entry remains UNVERIFIED until Media3 confirms active audio playback.
 */
internal object RadioCatalogueState {
    var loading by mutableStateOf(false)
    var status by mutableStateOf("Language catalogue will load when connected to the internet.")
    var scanned by mutableStateOf(0)
    var added by mutableStateOf(0)
}

internal object RadioCatalogueRepository {
    private const val TARGET_STATIONS = 50_000
    private const val PAGE_SIZE = 1_000
    private const val MAX_SCAN = 100_000
    private const val CACHE_NAME = "radio_cherry_language_catalogue_v1.json.gz"
    private const val CACHE_MAX_AGE_MS = 7L * 24L * 60L * 60L * 1000L
    private val mutex = Mutex()
    private var loadedOnce = false
    private data class CatalogueLoad(val stations: List<Station>, val usingStaleCache: Boolean = false)

    private val servers = listOf(
        "https://de1.api.radio-browser.info",
        "https://nl1.api.radio-browser.info",
        "https://at1.api.radio-browser.info",
        "https://all.api.radio-browser.info"
    )

    suspend fun load(context: Context, forceRefresh: Boolean = false) = mutex.withLock {
        if (loadedOnce && !forceRefresh) return@withLock
        RadioCatalogueState.loading = true
        RadioCatalogueState.status = if (forceRefresh) "Refreshing the international station directory…" else "Loading the international station directory…"
        try {
            val catalogueLoad = withContext(Dispatchers.IO) {
                val cache = File(context.filesDir, CACHE_NAME)
                val cached = if (cache.exists() && cache.length() > 100) {
                    runCatching { readCache(cache) }.getOrNull()?.takeIf { it.isNotEmpty() }
                } else null
                val cacheIsFresh = cached != null && System.currentTimeMillis() - cache.lastModified() < CACHE_MAX_AGE_MS
                if (!forceRefresh && cacheIsFresh) {
                    CatalogueLoad(cached!!)
                } else {
                    try {
                        val fetched = fetchCatalogue { count, accepted ->
                            RadioCatalogueState.scanned = count
                            RadioCatalogueState.added = accepted
                            RadioCatalogueState.status = "Scanning directory: $count records · $accepted language/genre candidates"
                        }
                        writeCache(cache, fetched)
                        CatalogueLoad(fetched)
                    } catch (error: Exception) {
                        if (cached != null) CatalogueLoad(cached, usingStaleCache = true) else throw error
                    }
                }
            }
            val newStations = catalogueLoad.stations
            withContext(Dispatchers.Main) {
                val existingUrls = stations.asSequence()
                    .flatMap { sequenceOf(normalizeUrl(it.stream), normalizeUrl(it.fallback.orEmpty())) }
                    .filter { it.isNotBlank() }.toHashSet()
                val existingIds = stations.mapTo(HashSet()) { it.id }
                val additions = newStations.filter { station ->
                    val key = normalizeUrl(station.stream)
                    val isNew = station.id !in existingIds && key.isNotBlank() && key !in existingUrls
                    if (isNew) {
                        existingIds.add(station.id)
                        existingUrls.add(key)
                    }
                    isNew
                }
                // One snapshot-list operation avoids 50,000 separate UI invalidations.
                stations.addAll(additions)
                val appended = additions.size
                RadioCatalogueState.added = appended
                RadioCatalogueState.status = when {
                    catalogueLoad.usingStaleCache -> "Offline · using saved language catalogue (${newStations.size} stations). Refresh when connected."
                    appended > 0 -> "Added $appended language stations · ${newStations.size} cached in the catalogue"
                    else -> "Language catalogue ready · ${newStations.size} cached stations already present"
                }
            }
            loadedOnce = true
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            withContext(Dispatchers.Main) {
                RadioCatalogueState.status = "International catalogue unavailable · existing stations remain available (${error.message?.take(120) ?: "network error"})"
            }
        } finally {
            RadioCatalogueState.loading = false
        }
    }

    /** Apply completed Media3 probes and persist the updated quality states once per run. */
    suspend fun persistVerificationResults(context: Context, results: List<StationLinkCheckResult>) {
        if (results.isEmpty()) return
        val updates = results.associateBy { it.stationId }
        withContext(Dispatchers.Main) {
            stations.indices.forEach { index ->
                val current = stations[index]
                val update = updates[current.id] ?: return@forEach
                stations[index] = current.copy(
                    qualityStatus = update.qualityStatus,
                    qualityCheckedAt = update.checkedAt
                )
            }
        }
        val snapshot = withContext(Dispatchers.Main) { stations.filter { it.id.startsWith("rb-") } }
        withContext(Dispatchers.IO) {
            val cache = File(context.filesDir, CACHE_NAME)
            val catalogueTimestamp = cache.lastModified()
            writeCache(cache, snapshot)
            if (catalogueTimestamp > 0L) cache.setLastModified(catalogueTimestamp)
        }
    }

    private fun fetchCatalogue(progress: (scanned: Int, accepted: Int) -> Unit): List<Station> {
        val accepted = LinkedHashMap<String, Station>()
        val seenUrls = HashSet<String>()
        var offset = 0
        while (offset < MAX_SCAN && accepted.size < TARGET_STATIONS) {
            val batch = try {
                fetchPage(offset)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                throw IllegalStateException(
                    "Station directory stopped after ${accepted.size} usable candidates at offset $offset",
                    error
                )
            }
            if (batch.length() == 0) break
            for (i in 0 until batch.length()) {
                val row = batch.optJSONObject(i) ?: continue
                val station = parseStation(row) ?: continue
                val normalizedUrl = normalizeUrl(station.stream)
                if (normalizedUrl.isBlank() || !seenUrls.add(normalizedUrl)) continue
                accepted[station.id] = station
                if (accepted.size >= TARGET_STATIONS) break
            }
            offset += batch.length()
            progress(offset, accepted.size)
            if (batch.length() < PAGE_SIZE) break
        }
        // AAC, MP3 and HLS are ordered first; all other codec-labelled stations remain
        // available after them as lower-priority candidates rather than being discarded.
        return accepted.values.sortedWith(
            compareBy<Station> { formatPriority(it.codec, it.stream) }
                .thenByDescending { it.votes }
                .thenBy { it.name.lowercase(Locale.ROOT) }
        )
    }

    private fun fetchPage(offset: Int): JSONArray {
        val path = "/json/stations?hidebroken=true&order=votes&reverse=true&offset=$offset&limit=$PAGE_SIZE"
        var lastError: Exception? = null
        servers.forEach { base ->
            var connection: HttpURLConnection? = null
            try {
                connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12_000
                    readTimeout = 25_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "RadioCherry/3.1.5 (Android Media3)")
                    setRequestProperty("Accept", "application/json")
                }
                if (connection.responseCode !in 200..299) throw IllegalStateException("Radio Browser HTTP ${connection.responseCode}")
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                return JSONArray(body)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                lastError = error
            } finally {
                connection?.disconnect()
            }
        }
        throw IllegalStateException("All Radio Browser mirrors failed: ${lastError?.message ?: "network error"}")
    }

    private fun parseStation(row: JSONObject): Station? {
        if (row.optInt("lastcheckok", 1) != 1) return null
        val url = row.optString("url_resolved").trim().ifBlank { row.optString("url").trim() }
        if (!url.startsWith("https://", true) && !url.startsWith("http://", true)) return null
        val name = cleanText(row.optString("name")).ifBlank { return null }
        val directoryLanguages = row.optString("language").split(',', ';').map(::cleanText).filter { it.isNotBlank() }
        val codeLanguages = row.optString("languagecodes").split(',', ';').map(::cleanText)
            .filter { it.isNotBlank() }.map(::displayLanguage)
        val rawLanguages = (directoryLanguages.ifEmpty { codeLanguages }).distinctBy { it.lowercase(Locale.ROOT) }
        val nonEnglish = rawLanguages.firstOrNull { !isEnglish(it) }
        val tags = row.optString("tags").split(',').map(::cleanText).filter { it.isNotBlank() }
        val editorial = (tags + name).joinToString(" ").lowercase(Locale.ROOT)
        val spokenWordOnly = listOf("quran", "koran", "sermon", "bible", "podcast", "audiobook", "traffic", "parliament")
            .any { it in editorial } || Regex("\\b(news|talk|sports?|politics|current affairs)\\b", RegexOption.IGNORE_CASE).containsMatchIn(editorial)
        val language = when {
            nonEnglish != null -> nonEnglish
            rawLanguages.any(::isEnglish) -> "English"
            rawLanguages.isNotEmpty() -> rawLanguages.first()
            else -> "Unspecified"
        }
        // Only English-only catalogue entries can join an existing music genre.
        // Every other language stays in Languages, even when its tags say rock, pop, etc.
        val mappedGenre = if (isEnglish(language) && !spokenWordOnly) mapEnglishGenre(tags, name) else null
        if (isEnglish(language) && mappedGenre == null) return null
        val codec = cleanText(row.optString("codec")).uppercase(Locale.ROOT)
        val hls = row.optInt("hls", 0) == 1 || url.substringBefore('?').endsWith(".m3u8", true)
        val bitrate = row.optInt("bitrate", 0).coerceAtLeast(0)
        val stationUuid = cleanText(row.optString("stationuuid"))
        val id = "rb-" + (stationUuid.ifBlank { url.hashCode().toUInt().toString(16) })
        val country = cleanText(row.optString("country"))
        val countryCode = cleanText(row.optString("countrycode")).uppercase(Locale.ROOT)
        val genre = when {
            mappedGenre != null -> mappedGenre.second
            tags.isEmpty() -> "Music"
            else -> tags.take(3).joinToString(" · ") { it.replaceFirstChar { ch -> ch.uppercase() } }
        }
        val category = mappedGenre?.first ?: "Languages"
        val sourceCheck = cleanText(row.optString("lastchecktime_iso8601")).ifBlank {
            cleanText(row.optString("lastchecktime"))
        }
        val host = runCatching { URL(url).host }.getOrDefault("")
        val votes = row.optInt("votes", 0).coerceAtLeast(0)
        val codecLabel = when {
            "AAC" in codec -> "AAC"
            "MP3" in codec || "MPEG" in codec -> "MP3"
            url.contains(".aac", true) -> "AAC"
            url.contains(".mp3", true) -> "MP3"
            else -> codec
        }
        val formatLabel = when {
            hls && codecLabel.isNotBlank() -> "$codecLabel / HLS"
            hls -> "HLS"
            codecLabel.isNotBlank() -> codecLabel
            else -> "Unknown"
        }
        return Station(
            id = id,
            name = name,
            genre = genre,
            broadcaster = country.ifBlank { host },
            stream = url,
            fallback = null,
            category = category,
            region = country.ifBlank { countryCode.ifBlank { "Worldwide" } },
            language = language,
            countryCode = countryCode,
            codec = formatLabel,
            bitrateKbps = bitrate,
            sourceCheckedAt = sourceCheck,
            qualityStatus = "UNVERIFIED",
            votes = votes
        )
    }

    private fun mapEnglishGenre(tags: List<String>, name: String): Pair<String, String>? {
        val text = (tags.joinToString(" ") + " " + name).lowercase(Locale.ROOT)
        val tests = listOf(
            "Pop" to listOf("pop", "hits", "top 40", "top40", "chart"),
            "Rock" to listOf("rock", "metal", "hard rock"),
            "Indie" to listOf("indie", "alternative", "independent"),
            "Electronic" to listOf("electronic", "dance", "house", "techno", "trance", "disco"),
            "Chill" to listOf("ambient", "chill", "downtempo", "lounge", "easy listening"),
            "Jazz" to listOf("jazz", "soul", "blues", "funk"),
            "Classical" to listOf("classical", "orchestral", "symphonic", "opera", "instrumental"),
            "Acoustic" to listOf("country", "folk", "americana", "acoustic"),
            "Lo-Fi" to listOf("lo-fi", "lofi", "study beats"),
            "Throwbacks" to listOf("oldies", "retro", "throwback", "70s", "80s", "90s", "classic hits"),
            "World" to listOf("world", "latin", "reggae", "global", "indian", "afrobeat"),
            "Nature & Sleep" to listOf("nature", "sleep", "soundscape", "rain", "drone"),
            "Seasonal" to listOf("christmas", "holiday", "seasonal")
        )
        val matched = tests.firstOrNull { (_, words) -> words.any { it in text } } ?: return null
        return matched.first to (tags.take(3).joinToString(" · ") { tag ->
            tag.replace('-', ' ').replaceFirstChar { it.uppercase() }
        }.ifBlank { matched.first })
    }

    private fun isEnglish(language: String): Boolean =
        language.contains("english", true) || language.equals("eng", true) || language.equals("en", true)

    private fun displayLanguage(value: String): String {
        if (isEnglish(value)) return "English"
        val normalized = value.trim()
        val display = Locale.forLanguageTag(normalized).getDisplayLanguage(Locale.ENGLISH)
        return if (display.isNotBlank() && !display.equals(normalized, true)) {
            display.replaceFirstChar { it.uppercase(Locale.ROOT) }
        } else normalized
    }

    private fun cleanText(value: String): String = value
        .takeUnless { it.equals("null", true) }
        .orEmpty()
        .replace(Regex("[\\r\\n\\t]+"), " ")
        .replace(Regex("\\s{2,}"), " ")
        .trim()
        .take(180)

    private fun formatPriority(codec: String, url: String): Int = when {
        codec.contains("HLS", true) || url.substringBefore('?').endsWith(".m3u8", true) -> 0
        codec.equals("AAC", true) || codec.contains("AAC", true) -> 1
        codec.equals("MP3", true) || codec.contains("MP3", true) || codec.contains("MPEG", true) -> 2
        else -> 3
    }

    private fun normalizeUrl(value: String): String {
        if (value.isBlank()) return ""
        return runCatching {
            val uri = java.net.URI(value.trim())
            val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return@runCatching value.trim()
            val host = uri.host?.lowercase(Locale.ROOT) ?: return@runCatching value.trim()
            val port = when { (scheme == "http" && uri.port == 80) || (scheme == "https" && uri.port == 443) -> -1; else -> uri.port }
            val path = (uri.rawPath ?: "").trimEnd('/').ifBlank { "/" }
            java.net.URI(scheme, uri.userInfo, host, port, path, uri.rawQuery, null).toASCIIString()
        }.getOrDefault(value.trim().substringBefore('#'))
    }

    private fun readCache(file: File): List<Station> {
        val text = GZIPInputStream(FileInputStream(file)).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val array = JSONArray(text)
        return buildList(array.length()) {
            for (i in 0 until array.length()) {
                val row = array.optJSONObject(i) ?: continue
                val stream = row.optString("stream")
                val name = row.optString("name")
                if (stream.isBlank() || name.isBlank()) continue
                add(
                    Station(
                        id = row.optString("id"), name = name, genre = row.optString("genre"),
                        broadcaster = row.optString("broadcaster"), stream = stream,
                        fallback = row.optString("fallback").takeIf { it.isNotBlank() },
                        category = row.optString("category"), region = row.optString("region"),
                        language = row.optString("language"), countryCode = row.optString("countryCode"),
                        codec = row.optString("codec"), bitrateKbps = row.optInt("bitrateKbps"),
                        sourceCheckedAt = row.optString("sourceCheckedAt"),
                        qualityStatus = row.optString("qualityStatus", "UNVERIFIED"),
                        qualityCheckedAt = row.optString("qualityCheckedAt"), votes = row.optInt("votes")
                    )
                )
            }
        }
    }

    private fun writeCache(file: File, data: List<Station>) {
        file.parentFile?.mkdirs()
        val temp = File(file.parentFile, file.name + ".tmp")
        GZIPOutputStream(FileOutputStream(temp)).bufferedWriter(Charsets.UTF_8).use { writer ->
            writer.write("[")
            data.forEachIndexed { index, station ->
                if (index > 0) writer.write(",")
                val obj = JSONObject().apply {
                    put("id", station.id); put("name", station.name); put("genre", station.genre)
                    put("broadcaster", station.broadcaster); put("stream", station.stream)
                    put("fallback", station.fallback ?: ""); put("category", station.category)
                    put("region", station.region); put("language", station.language)
                    put("countryCode", station.countryCode); put("codec", station.codec)
                    put("bitrateKbps", station.bitrateKbps); put("sourceCheckedAt", station.sourceCheckedAt)
                    put("qualityStatus", station.qualityStatus); put("qualityCheckedAt", station.qualityCheckedAt)
                    put("votes", station.votes)
                }
                writer.write(obj.toString())
            }
            writer.write("]")
        }
        if (temp.exists()) {
            if (file.exists()) file.delete()
            check(temp.renameTo(file)) { "Could not save the station catalogue cache" }
        }
    }
}
