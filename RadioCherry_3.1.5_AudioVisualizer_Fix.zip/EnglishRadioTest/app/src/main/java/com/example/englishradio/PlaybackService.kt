package com.example.englishradio

import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

import androidx.media3.common.util.UnstableApi

@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private var fallbackAttemptedFor: String? = null

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this)
            // Media3 manages Android audio focus for media playback (duck, pause, resume).
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        currentAudioSessionId = player.audioSessionId
        activeService = this

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                val item = player.currentMediaItem ?: return
                val stationId = item.mediaId
                if (fallbackAttemptedFor == stationId) return
                val fallback = item.mediaMetadata.extras?.getString(EXTRA_FALLBACK) ?: return
                fallbackAttemptedFor = stationId
                val fallbackItem = item.buildUpon().setUri(fallback).build()
                player.setMediaItem(fallbackItem)
                player.prepare()
                player.play()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (mediaItem?.mediaId != fallbackAttemptedFor) fallbackAttemptedFor = null
            }
        })

        val isTv = packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
        val launchIntent = Intent(this, if (isTv) TvActivity::class.java else MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val sessionActivity = PendingIntent.getActivity(
            this,
            SESSION_ACTIVITY_REQUEST_CODE,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val previousButton = CommandButton.Builder(CommandButton.ICON_PREVIOUS)
            .setDisplayName("Previous station")
            .setSessionCommand(PREVIOUS_COMMAND)
            .setSlots(CommandButton.SLOT_BACK)
            .build()
        val nextButton = CommandButton.Builder(CommandButton.ICON_NEXT)
            .setDisplayName("Next station")
            .setSessionCommand(NEXT_COMMAND)
            .setSlots(CommandButton.SLOT_FORWARD)
            .build()
        val stopButton = CommandButton.Builder(CommandButton.ICON_STOP)
            .setDisplayName("Stop")
            .setSessionCommand(STOP_COMMAND)
            .setSlots(CommandButton.SLOT_OVERFLOW)
            .build()

        mediaSession = MediaSession.Builder(this, player)
            .setId("radio-cherry-session")
            .setSessionActivity(sessionActivity)
            .setMediaButtonPreferences(listOf(previousButton, nextButton, stopButton))
            .setCallback(object : MediaSession.Callback {
                override fun onConnect(
                    session: MediaSession,
                    controller: MediaSession.ControllerInfo
                ): MediaSession.ConnectionResult {
                    val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS
                        .buildUpon()
                        .add(STOP_COMMAND)
                        .add(PREVIOUS_COMMAND)
                        .add(NEXT_COMMAND)
                        .build()
                    return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                        .setAvailableSessionCommands(commands)
                        .build()
                }

                override fun onCustomCommand(
                    session: MediaSession,
                    controller: MediaSession.ControllerInfo,
                    customCommand: SessionCommand,
                    args: Bundle
                ): ListenableFuture<SessionResult> {
                    when (customCommand.customAction) {
                        ACTION_STOP -> {
                            session.player.pause()
                            session.player.clearMediaItems()
                            fallbackAttemptedFor = null
                        }
                        ACTION_PREVIOUS -> changeStation(-1)
                        ACTION_NEXT -> changeStation(1)
                    }
                    return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
                }
            })
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        activeService = null
        super.onDestroy()
    }

    companion object {
        @Volatile var currentAudioSessionId: Int = 0
            private set

        private const val ACTION_STOP = "com.radiocherry.action.STOP"
        private const val ACTION_PREVIOUS = "com.radiocherry.action.PREVIOUS"
        private const val ACTION_NEXT = "com.radiocherry.action.NEXT"
        private const val SESSION_ACTIVITY_REQUEST_CODE = 7301
        private val STOP_COMMAND = SessionCommand(ACTION_STOP, Bundle.EMPTY)
        private val PREVIOUS_COMMAND = SessionCommand(ACTION_PREVIOUS, Bundle.EMPTY)
        private val NEXT_COMMAND = SessionCommand(ACTION_NEXT, Bundle.EMPTY)
        @Volatile private var stationQueue: List<Station> = emptyList()
        @Volatile private var artwork: ByteArray? = null

        fun configureStationQueue(stations: List<Station>, artworkData: ByteArray?) {
            stationQueue = stations.toList()
            artwork = artworkData?.clone()
        }

        private fun changeStation(direction: Int) {
            val service = activeService ?: return
            val queue = stationQueue
            if (queue.isEmpty()) return
            val current = queue.indexOfFirst { it.id == service.player.currentMediaItem?.mediaId }
            val next = if (current < 0) 0 else (current + direction + queue.size) % queue.size
            val station = queue[next]
            val stream = runCatching { PlaylistResolver.resolve(station.stream) }.getOrDefault(station.stream)
            service.player.setMediaItem(mediaItem(station.copy(stream = stream), artwork))
            service.player.prepare()
            service.player.play()
        }
        @Volatile private var activeService: PlaybackService? = null
        const val EXTRA_FALLBACK = "radio_cherry_fallback_stream"

        fun mediaItem(station: Station, artworkData: ByteArray?): MediaItem {
            val extras = Bundle().apply {
                station.fallback?.let { putString(EXTRA_FALLBACK, it) }
            }
            val metadataBuilder = MediaMetadata.Builder()
                .setTitle(station.name)
                .setArtist(station.genre)
                .setAlbumTitle("Radio Cherry · ${station.region}")
            if (artworkData != null) {
                metadataBuilder.setArtworkData(artworkData, MediaMetadata.PICTURE_TYPE_ILLUSTRATION)
            }
            val metadata = metadataBuilder.setExtras(extras).build()
            return MediaItem.Builder()
                .setMediaId(station.id)
                .setUri(station.stream)
                .setMediaMetadata(metadata)
                .build()
        }
    }
}
