package com.example.englishradio

import android.content.ComponentName
import android.media.audiofx.Visualizer
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.SystemBarStyle
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val stations = listOf(
    Station("groove-salad", "Groove Salad", "Ambient · Downtempo", "SomaFM", "https://ice5.somafm.com/groovesalad-128-mp3", "https://ice.somafm.com/groovesalad", "Chill"),
    Station("lush", "Lush", "Mellow · Electronic", "SomaFM", "https://ice5.somafm.com/lush-128-mp3", "https://ice.somafm.com/lush", "Chill"),
    Station("indie-pop", "Indie Pop Rocks!", "Indie · Alternative", "SomaFM", "https://ice5.somafm.com/indiepop-128-mp3", "https://ice.somafm.com/indiepop", "Indie"),
    Station("underground-80s", "Underground 80s", "80s · New Wave", "SomaFM", "https://ice5.somafm.com/u80s-128-mp3", "https://ice.somafm.com/u80s", "Throwbacks"),
    Station("left-coast-70s", "Left Coast 70s", "Classic · Album Rock", "SomaFM", "https://ice5.somafm.com/seventies-128-mp3", "https://ice.somafm.com/seventies", "Throwbacks"),
    Station("folk-forward", "Folk Forward", "Folk · Americana", "SomaFM", "https://ice5.somafm.com/folkfwd-128-mp3", "https://ice.somafm.com/folkfwd", "Acoustic"),
    Station("drone-zone", "Drone Zone", "Atmospheric · Ambient", "SomaFM", "https://ice5.somafm.com/dronezone-128-mp3", "https://ice.somafm.com/dronezone", "Chill"),
    Station("secret-agent", "Secret Agent", "Spy · Soundtracks", "SomaFM", "https://ice5.somafm.com/secretagent-128-mp3", "https://ice.somafm.com/secretagent", "Discovery"),
    Station("mission-control", "Mission Control", "Space · Ambient", "SomaFM", "https://ice5.somafm.com/missioncontrol-128-mp3", "https://ice.somafm.com/missioncontrol", "Chill"),
    Station("space-station", "Space Station Soma", "Space · Electronic", "SomaFM", "https://ice5.somafm.com/spacestation-128-mp3", "https://ice.somafm.com/spacestation", "Chill"),
    Station("beat-blender", "Beat Blender", "Deep · House", "SomaFM", "https://ice5.somafm.com/beatblender-128-mp3", "https://ice.somafm.com/beatblender", "Electronic"),
    Station("poptron", "PopTron", "Indie · Pop", "SomaFM", "https://ice5.somafm.com/poptron-128-mp3", "https://ice.somafm.com/poptron", "Indie"),
    Station("sonic-universe", "Sonic Universe", "Modern · Jazz", "SomaFM", "https://ice5.somafm.com/sonicuniverse-128-mp3", "https://ice.somafm.com/sonicuniverse", "Jazz"),
    Station("suburbs-of-goa", "Suburbs of Goa", "Psychedelic · Indian", "SomaFM", "https://ice5.somafm.com/suburbsofgoa-128-mp3", "https://ice.somafm.com/suburbsofgoa", "World"),
    Station("defcon", "DEF CON Radio", "Electronic · Hacker culture", "SomaFM", "https://ice5.somafm.com/defcon-128-mp3", "https://ice.somafm.com/defcon", "Electronic"),
    Station("radio-paradise-main", "Radio Paradise · Main Mix", "Eclectic · Alternative", "Radio Paradise", "https://stream.radioparadise.com/mp3-128", null, "Indie", region = "USA"),
    Station("radio-paradise-mellow", "Radio Paradise · Mellow Mix", "Mellow · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/mellow-128", null, "Chill", region = "USA"),
    Station("radio-paradise-rock", "Radio Paradise · Rock Mix", "Alternative · Rock", "Radio Paradise", "https://stream.radioparadise.com/rock-128", null, "Indie", region = "USA"),
    Station("radio-paradise-global", "Radio Paradise · Global Mix", "World · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/eclectic-128", null, "World", region = "USA"),
    Station("kexp", "KEXP 90.3", "Alternative · Discovery", "KEXP", "https://kexp.streamguys1.com/kexp160.aac", "https://kexp.streamguys1.com/kexp64.aac", "Indie", region = "Seattle"),
    Station("swiss-classic", "Radio Swiss Classic", "Western classical · Instrumental", "Switzerland", "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128", null, "Classical", region = "Switzerland"),
    Station("wcrb", "WCRB Classical", "Symphonic · Chamber · Opera", "CRB · Boston", "https://wgbh-live.streamguys1.com/classical-hi/", null, "Classical", region = "Boston"),
    Station("kusc", "Classical KUSC", "Orchestral · Classical favourites", "Classical California", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3", null, "Classical", region = "Los Angeles"),
    Station("air-raagam", "AIR Raagam", "Hindustani · Carnatic", "Akashvani · India", "https://airhlspush.pc.cdn.bitgravity.com/httppush/hlspbaudioragam/hlspbaudioragam64kbps.m3u8", null, "Indian Classical", region = "India")
) + importedStations

data class Station(
    val id: String,
    val name: String,
    val genre: String,
    val broadcaster: String,
    val stream: String,
    val fallback: String?,
    val category: String,
    val region: String = "USA"
)



private enum class RadioTab { NOW_PLAYING, BROWSE, FAVORITES }

private data class RadioPalette(
    val background: Color,
    val foreground: Color,
    val secondaryText: Color,
    val card: Color,
    val search: Color,
    val divider: Color,
    val accent: Color,
    val shadow: Color,
    val waveform: Color
)

@Composable
private fun radioPalette(dark: Boolean): RadioPalette = if (dark) {
    RadioPalette(
        background = Color(0xFF000000),
        foreground = Color(0xFFF4F4F6),
        secondaryText = Color(0xFFB8BBC2),
        card = Color(0xFF17191D),
        search = Color(0xFF111216),
        divider = Color(0xFF24262B),
        accent = Color(0xFFE6C8FF),
        shadow = Color(0xFF000000),
        waveform = Color(0xFFF7F4FA)
    )
} else {
    RadioPalette(
        background = Color(0xFFFAFAFA),
        foreground = Color(0xFF202126),
        secondaryText = Color(0xFF70737A),
        card = Color(0xFFFFFFFF),
        search = Color(0xFFF0F1F2),
        divider = Color(0xFFE2E3E5),
        accent = Color(0xFF9765D8),
        shadow = Color(0xFFB8BEC8),
        waveform = Color(0xFF25242C)
    )
}

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
        )
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                runCatching { future.get() }.onSuccess { controller = it }
            }, ContextCompat.getMainExecutor(this))
        }
        setContent { RadioCherryApp(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun RadioCherryApp(player: MediaController?) {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()
    val preferences = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", android.content.Context.MODE_PRIVATE)
    }
    var themeMode by remember { mutableStateOf(preferences.getString("theme_mode", "system") ?: "system") }
    val dark = when (themeMode) { "dark" -> true; "light" -> false; else -> systemDark }
    val palette = radioPalette(dark)
    var audioPermissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val audioPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        audioPermissionGranted = granted
    }
    var audioWaveform by remember { mutableStateOf(FloatArray(96) { 0.05f }) }
    var audioLevel by remember { mutableFloatStateOf(0.08f) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackStatus by remember { mutableStateOf("Choose a station to begin") }
    var search by remember { mutableStateOf("") }
    var activeGenre by remember { mutableStateOf("All genres") }
    var activeTab by remember { mutableStateOf(RadioTab.BROWSE) }
    var favorites by remember {
        mutableStateOf(preferences.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    val animationEnabled = true
    val playbackScope = rememberCoroutineScope()
    var playlistResolveJob by remember { mutableStateOf<Job?>(null) }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }
    SideEffect { PlaybackService.configureStationQueue(stations, orbArtwork) }

    LaunchedEffect(selectedId, isPlaying, audioPermissionGranted) {
        audioWaveform = FloatArray(96) { 0.035f }
        audioLevel = 0.06f
        if (!audioPermissionGranted || !isPlaying) return@LaunchedEffect
        var sessionId = PlaybackService.currentAudioSessionId
        repeat(12) {
            if (sessionId > 0) return@repeat
            delay(100)
            sessionId = PlaybackService.currentAudioSessionId
        }
        if (sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    val values = FloatArray(96) { i ->
                        val index = (i * (bytes.size - 1) / 95).coerceIn(0, bytes.lastIndex)
                        kotlin.math.abs((bytes[index].toInt() and 0xFF) - 128) / 128f
                    }
                    val levelNow = (values.sum() / values.size).coerceIn(0.03f, 0.95f)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        audioWaveform = values
                        audioLevel = levelNow
                    }
                }
                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) = Unit
            }, Visualizer.getMaxCaptureRate() / 2, true, false)
            visualizer.enabled = true
        } catch (_: Throwable) {
            runCatching { visualizer.release() }
            return@LaunchedEffect
        }
        try { awaitCancellation() } finally {
            runCatching { visualizer.enabled = false }
            runCatching { visualizer.release() }
        }
    }

    LaunchedEffect(favorites) {
        preferences.edit().putStringSet("favorite_station_ids", favorites).apply()
    }
    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                playbackStatus = if (playing) "Playing live" else if (player.mediaItemCount > 0) "Paused" else "Choose a station"
            }
            override fun onPlaybackStateChanged(state: Int) {
                playbackStatus = when (state) {
                    Player.STATE_BUFFERING -> "Connecting to station…"
                    Player.STATE_READY -> if (player.isPlaying) "Playing live" else "Ready to play"
                    Player.STATE_ENDED -> "Stream ended"
                    Player.STATE_IDLE -> if (player.mediaItemCount == 0) "Choose a station" else "Stopped"
                    else -> playbackStatus
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isPlaying = false
                playbackStatus = "Stream unavailable · ${error.errorCodeName}"
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
                if (mediaItem == null) isPlaying = false
            }
        }
        player.addListener(listener)
        isPlaying = player.isPlaying
        selectedId = player.currentMediaItem?.mediaId
        onDispose { player.removeListener(listener) }
    }

    val selected = stations.firstOrNull { it.id == selectedId }
    val genreFilters = listOf(
        "All genres", "Pop", "Rock", "Indie & Alternative", "Electronic & Dance",
        "Ambient & Chill", "Jazz & Soul", "Classical", "Country & Folk",
        "Lo-Fi", "Throwbacks", "World & Culture", "Nature & Sleep", "Seasonal"
    )
    fun matchesGenre(station: Station, genre: String): Boolean {
        if (genre == "All genres") return true
        val metadata = "${station.genre} ${station.category} ${station.name}".lowercase()
        return when (genre) {
            "Pop" -> "pop" in metadata || "hits" in metadata
            "Rock" -> "rock" in metadata || "metal" in metadata
            "Indie & Alternative" -> listOf("indie", "alternative", "independent").any { it in metadata }
            "Electronic & Dance" -> listOf("electronic", "dance", "house", "techno", "trance", "disco").any { it in metadata }
            "Ambient & Chill" -> listOf("ambient", "chill", "downtempo", "mellow", "easy listening", "space").any { it in metadata }
            "Jazz & Soul" -> listOf("jazz", "soul", "blues", "funk").any { it in metadata }
            "Classical" -> listOf("classical", "orchestral", "symphonic", "opera", "instrumental").any { it in metadata }
            "Country & Folk" -> listOf("country", "folk", "americana", "acoustic").any { it in metadata }
            "Lo-Fi" -> listOf("lo-fi", "lofi", "downtempo", "study beats").any { it in metadata }
            "Throwbacks" -> listOf("throwback", "classic hits", "80s", "70s", "oldies", "retro").any { it in metadata }
            "World & Culture" -> listOf("world", "indian", "goa", "global", "culture", "reggae", "latin").any { it in metadata }
            "Nature & Sleep" -> listOf("nature", "sleep", "soundscape", "rain", "drone").any { it in metadata }
            "Seasonal" -> listOf("christmas", "holiday", "seasonal").any { it in metadata }
            else -> false
        }
    }
    val visibleStations = stations.filter { station ->
        (search.isBlank() || (station.name + station.genre + station.category + station.broadcaster).contains(search, true)) &&
            matchesGenre(station, activeGenre)
    }
    val favoriteStations = stations.filter { it.id in favorites }

    fun playStation(station: Station) {
        if (!audioPermissionGranted) audioPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        val activePlayer = player ?: run { playbackStatus = "Player service is starting. Tap again."; return }
        playlistResolveJob?.cancel()
        selectedId = station.id
        activeTab = RadioTab.NOW_PLAYING
        val requiresPlaylistResolution = PlaylistResolver.isPlaylistUrl(station.stream)
        playbackStatus = if (requiresPlaylistResolution) "Opening station playlist…" else "Connecting to station…"
        playlistResolveJob = playbackScope.launch {
            val resolvedUrl = runCatching {
                withContext(Dispatchers.IO) { PlaylistResolver.resolve(station.stream) }
            }.getOrElse { station.stream }
            if (selectedId != station.id) return@launch
            val resolvedStation = station.copy(stream = resolvedUrl, fallback = station.fallback)
            activePlayer.setMediaItem(PlaybackService.mediaItem(resolvedStation, orbArtwork))
            activePlayer.prepare()
            activePlayer.play()
        }
    }
    fun togglePlayback() {
        if (player == null) return
        if (player.isPlaying) player.pause() else if (player.mediaItemCount > 0) player.play()
        else selected?.let { playStation(it) }
    }
    fun changeStation(direction: Int) {
        val currentIndex = stations.indexOfFirst { it.id == selectedId }
        val nextIndex = when {
            stations.isEmpty() -> -1
            currentIndex < 0 -> if (direction >= 0) 0 else stations.lastIndex
            else -> (currentIndex + direction + stations.size) % stations.size
        }
        if (nextIndex >= 0) playStation(stations[nextIndex])
    }
    fun toggleFavorite(station: Station) {
        favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
    }

    MaterialTheme {
        Column(
            Modifier.fillMaxSize()
                .background(palette.background)
                .windowInsetsPadding(WindowInsets.safeDrawing)
        ) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (activeTab) {
                    RadioTab.BROWSE -> BrowseScreen(
                        palette = palette, dark = dark, stations = visibleStations, search = search,
                        onSearch = { search = it }, genres = genreFilters, activeGenre = activeGenre,
                        onGenre = { activeGenre = it }, favorites = favorites,
                        onFavorite = ::toggleFavorite, onPlay = ::playStation,
                        waveform = audioWaveform, level = audioLevel, playing = isPlaying, animationEnabled = animationEnabled
                    )
                    RadioTab.FAVORITES -> FavoritesScreen(
                        palette = palette, dark = dark, stations = favoriteStations,
                        onFavorite = ::toggleFavorite, onPlay = ::playStation,
                        waveform = audioWaveform, level = audioLevel, playing = isPlaying, animationEnabled = animationEnabled,
                        onBrowse = { activeTab = RadioTab.BROWSE }
                    )
                    RadioTab.NOW_PLAYING -> NowPlayingScreen(
                        palette = palette, dark = dark, station = selected, isPlaying = isPlaying, status = playbackStatus,
                        upcoming = upcomingStations(selectedId), waveform = audioWaveform, level = audioLevel,
                        animationEnabled = animationEnabled, favorite = selected?.id?.let { it in favorites } == true,
                        onFavorite = { selected?.let(::toggleFavorite) }, onPlayPause = ::togglePlayback,
                        onPrevious = { changeStation(-1) }, onNext = { changeStation(1) }, onPlayStation = ::playStation,
                        onBrowse = { activeTab = RadioTab.BROWSE }
                    )
                }
                Row(
                    Modifier.align(Alignment.TopEnd).padding(top = 7.dp, end = 18.dp)
                        .clip(CircleShape).background(palette.card.copy(alpha = 0.92f))
                        .clickable {
                            themeMode = when (themeMode) { "dark" -> "light"; "light" -> "system"; else -> "dark" }
                            preferences.edit().putString("theme_mode", themeMode).apply()
                        }.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(when (themeMode) { "dark" -> "AMOLED"; "light" -> "LIGHT"; else -> "SYSTEM" }, color = palette.foreground, fontSize = 10.sp, letterSpacing = 1.sp)
                }
            }
            RadioBottomNavigation(activeTab = activeTab, palette = palette, onSelect = { activeTab = it })
        }
    }
}

private fun upcomingStations(currentId: String?): List<Station> {
    if (stations.isEmpty()) return emptyList()
    val index = stations.indexOfFirst { it.id == currentId }
    val start = if (index < 0) 0 else (index + 1) % stations.size
    return (0 until minOf(3, stations.size)).map { stations[(start + it) % stations.size] }
}

@Composable
private fun BrowseScreen(
    palette: RadioPalette, dark: Boolean, stations: List<Station>, search: String, onSearch: (String) -> Unit,
    genres: List<String>, activeGenre: String, onGenre: (String) -> Unit, favorites: Set<String>,
    onFavorite: (Station) -> Unit, onPlay: (Station) -> Unit, waveform: FloatArray, level: Float, playing: Boolean,
    animationEnabled: Boolean
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHero("browse", palette, dark, waveform, level, playing, animationEnabled) }
        item { SearchStationsField(search, onSearch, palette) }
        item { SectionHeading("Stations", "${stations.size} available", palette) }
        items(stations.take(3), key = { it.id }) { station ->
            StationTile(
                station = station, palette = palette, favorite = station.id in favorites,
                onFavorite = { onFavorite(station) }, onClick = { onPlay(station) }, showFavorite = false
            )
        }
        if (stations.isEmpty()) {
            item { EmptyState("No stations found", "Try another search or genre.", palette) }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                SectionHeading("Genres", "Explore by sound", palette)
                Spacer(Modifier.height(12.dp))
                GenreGrid(genres, activeGenre, onGenre, palette)
            }
        }
        if (stations.size > 3) {
            item { SectionHeading("All frequencies", "${stations.size} stations", palette) }
            items(stations.drop(3), key = { it.id }) { station ->
                StationTile(
                    station = station, palette = palette, favorite = station.id in favorites,
                    onFavorite = { onFavorite(station) }, onClick = { onPlay(station) }, showFavorite = false
                )
            }
        }
    }
}

@Composable
private fun FavoritesScreen(
    palette: RadioPalette, dark: Boolean, stations: List<Station>, onFavorite: (Station) -> Unit,
    onPlay: (Station) -> Unit, waveform: FloatArray, level: Float, playing: Boolean,
    animationEnabled: Boolean, onBrowse: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { PageHero("favorites", palette, dark, waveform, level, playing, animationEnabled) }
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                Text("Favorites", color = palette.foreground, fontSize = 25.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(3.dp))
                Text("Saved stations · ${stations.size}", color = palette.secondaryText, fontSize = 14.sp)
            }
        }
        if (stations.isEmpty()) {
            item { EmptyState("Your favorites are waiting", "Save stations from Browse and they will appear here.", palette, onBrowse) }
        } else {
            items(stations, key = { it.id }) { station ->
                StationTile(
                    station = station, palette = palette, favorite = true,
                    onFavorite = { onFavorite(station) }, onClick = { onPlay(station) }, showFavorite = true
                )
            }
        }
    }
}

@Composable
private fun NowPlayingScreen(
    palette: RadioPalette, dark: Boolean, station: Station?, isPlaying: Boolean, status: String,
    upcoming: List<Station>, waveform: FloatArray, level: Float, animationEnabled: Boolean, favorite: Boolean,
    onFavorite: () -> Unit, onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onPlayStation: (Station) -> Unit, onBrowse: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        PageHero("radio cherry", palette, dark, waveform, level, isPlaying, animationEnabled)
        Spacer(Modifier.height(8.dp))
        if (station == null) {
            Text("Choose a station to start listening", color = palette.secondaryText, fontSize = 14.sp)
            Spacer(Modifier.height(25.dp))
            PrimaryAction("Browse stations", palette, onBrowse)
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
                Spacer(Modifier.weight(1f))
                Text(station.name.uppercase(), color = palette.foreground, fontSize = 21.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(8f))
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onFavorite) {
                    Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = if (favorite) "Remove from favorites" else "Add to favorites", tint = if (favorite) palette.accent else palette.secondaryText)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text("${station.genre}  ·  ${station.broadcaster}", color = palette.secondaryText, fontSize = 13.sp, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 20.dp))
            Spacer(Modifier.height(24.dp))
            LiveStreamLine(palette, isPlaying)
            Spacer(Modifier.height(23.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(30.dp)) {
                RoundPlayerButton(Icons.Default.SkipPrevious, "Previous station", palette, 52.dp, false, onPrevious)
                RoundPlayerButton(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pause" else "Play", palette, 70.dp, true, onPlayPause)
                RoundPlayerButton(Icons.Default.SkipNext, "Next station", palette, 52.dp, false, onNext)
            }
            Spacer(Modifier.height(23.dp))
            Text(status, color = palette.secondaryText, fontSize = 12.sp)
            Spacer(Modifier.height(36.dp))
            Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
                SectionHeading("Up next", "Radio stations", palette)
                Spacer(Modifier.height(12.dp))
                upcoming.forEach { next ->
                    UpcomingStationRow(next, palette) { onPlayStation(next) }
                }
            }
        }
    }
}

@Composable
private fun PageHero(
    title: String, palette: RadioPalette, dark: Boolean, waveform: FloatArray, level: Float, playing: Boolean,
    animationEnabled: Boolean
) {
    Box(Modifier.fillMaxWidth().height(244.dp)) {
        val transition = rememberInfiniteTransition(label = "radio-header-motion")
        val phase by transition.animateFloat(
            initialValue = 0f,
            targetValue = (2f * PI).toFloat(),
            animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing)),
            label = "header-phase"
        )
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val pulse = if (animationEnabled) (0.5f + 0.5f * sin(phase * 0.72f)).coerceIn(0f, 1f) else 0.5f
            val breath = 0.86f + pulse * 0.14f
            val drift = if (animationEnabled) sin(phase * 0.55f) * 0.008f else 0f

            // Soft, independently breathing colour blooms behind the wave, as in the reference artwork.
            val glowBaseAlpha = if (dark) 0.39f else 0.30f
            val glowSpecs = listOf(
                Triple(0.23f, 0.60f, Color(0xFF17D9D0)),
                Triple(0.48f, 0.49f, Color(0xFF398CFB)),
                Triple(0.70f, 0.51f, Color(0xFF9E49F0)),
                Triple(0.83f, 0.63f, Color(0xFFE45BCB))
            )
            glowSpecs.forEachIndexed { index, spec ->
                val color = spec.third
                val wobble = if (animationEnabled) sin(phase * 0.82f + index * 1.35f) else 0f
                val center = Offset(
                    w * (spec.first + drift * (if (index % 2 == 0) 1f else -1f)),
                    h * (spec.second + wobble * 0.025f)
                )
                val radius = w * (0.205f + pulse * 0.018f)
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0.0f to color.copy(alpha = glowBaseAlpha * breath),
                            0.48f to color.copy(alpha = glowBaseAlpha * 0.52f * breath),
                            1.0f to Color.Transparent
                        ),
                        center = center,
                        radius = radius
                    ),
                    radius = radius,
                    center = center
                )
            }

            // Five broad lobes form the smooth, interlaced signal ribbon. Each contour is
            // a scaled version of the same curve so the lines stay parallel and meet cleanly.
            fun gaussian(t: Float, center: Float, spread: Float): Float {
                val d = (t - center) / spread
                return exp((-d * d).toDouble()).toFloat()
            }

            val midY = h * 0.555f
            val audioLift = if (playing && animationEnabled) 0.94f + level.coerceIn(0f, 1f) * 0.18f else 0.96f + pulse * 0.04f
            val amplitude = h * 0.285f * audioLift
            val contourCount = 13
            for (layer in 0 until contourCount) {
                val path = Path()
                val contourScale = 0.34f + (layer.toFloat() / (contourCount - 1)) * 0.70f
                for (step in 0..240) {
                    val t = step / 240f
                    val movingT = (t + drift).coerceIn(0f, 1f)
                    val shape =
                        0.88f * gaussian(movingT, 0.205f, 0.070f) -
                        0.76f * gaussian(movingT, 0.315f, 0.048f) +
                        0.70f * gaussian(movingT, 0.445f, 0.073f) -
                        0.86f * gaussian(movingT, 0.585f, 0.055f) +
                        1.00f * gaussian(movingT, 0.780f, 0.105f)
                    // Use live Visualizer samples to deform the ribbon itself, not just its glow.
                    // Keep the reference's broad three-crest silhouette while adding audio-reactive detail.
                    val sampleIndex = (t * (waveform.size - 1)).toInt().coerceIn(0, waveform.lastIndex)
                    val sample = waveform.getOrElse(sampleIndex) { 0.04f }.coerceIn(0f, 1f)
                    val audioMotion = if (playing) (sample - 0.22f) * 0.24f else 0f
                    val ripple = if (playing && animationEnabled) sin((t * 34f) + phase * 2.1f) * level.coerceIn(0f, 1f) * 0.012f else 0f
                    val y = midY - shape * amplitude * contourScale * (1f + audioMotion) + ripple * h
                    val x = w * t
                    if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val contourAlpha = 0.54f + contourScale * 0.36f
                drawPath(
                    path = path,
                    color = palette.waveform.copy(alpha = contourAlpha),
                    style = Stroke(width = if (layer == contourCount - 1) 1.05.dp.toPx() else 0.82.dp.toPx())
                )
            }
        }
        Text(
            title,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 42.dp),
            color = palette.foreground,
            fontSize = if (title == "radio cherry") 27.sp else 30.sp,
            fontWeight = FontWeight.ExtraLight,
            letterSpacing = if (title == "radio cherry") 5.5.sp else 7.sp
        )
        Box(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp).size(42.dp)
                .border(1.dp, palette.foreground.copy(alpha = 0.65f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            SignalMark(palette.foreground, 27.dp)
        }
    }
}

@Composable
private fun SignalMark(color: Color, iconSize: Dp) {
    Canvas(Modifier.size(iconSize)) {
        val canvasSize = this.size
        val center = Offset(canvasSize.width / 2f, canvasSize.height / 2f)
        val maxRadius = canvasSize.minDimension * 0.42f
        for (factor in listOf(0.30f, 0.57f, 0.84f)) {
            drawCircle(color.copy(alpha = 0.9f), radius = maxRadius * factor, center = center, style = Stroke(width = 1.dp.toPx()))
        }
        drawCircle(color, radius = canvasSize.minDimension * 0.045f, center = center)
    }
}

@Composable
private fun SearchStationsField(value: String, onValueChange: (String) -> Unit, palette: RadioPalette) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp).height(52.dp).clip(CircleShape).background(palette.search).padding(horizontal = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, contentDescription = null, tint = palette.secondaryText, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        BasicTextField(
            value = value, onValueChange = onValueChange, modifier = Modifier.weight(1f), singleLine = true,
            textStyle = TextStyle(color = palette.foreground, fontSize = 14.sp), cursorBrush = SolidColor(palette.accent),
            decorationBox = { inner -> Box {
                if (value.isEmpty()) Text("Search stations, genres or moods", color = palette.secondaryText, fontSize = 14.sp)
                inner()
            } }
        )
        if (value.isNotEmpty()) {
            Text("×", color = palette.secondaryText, fontSize = 22.sp, modifier = Modifier.clickable { onValueChange("") }.padding(horizontal = 4.dp))
        }
    }
}

@Composable
private fun SectionHeading(title: String, detail: String, palette: RadioPalette) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = palette.foreground, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.weight(1f))
        Text(detail, color = palette.secondaryText, fontSize = 11.sp)
    }
}

@Composable
private fun StationTile(
    station: Station, palette: RadioPalette, favorite: Boolean, onFavorite: () -> Unit, onClick: () -> Unit, showFavorite: Boolean
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp).shadow(11.dp, RoundedCornerShape(23.dp), ambientColor = palette.shadow.copy(alpha = 0.18f), spotColor = palette.shadow.copy(alpha = 0.14f))
            .clip(RoundedCornerShape(23.dp)).background(palette.card).clickable(onClick = onClick)
            .padding(start = 18.dp, end = 12.dp, top = 15.dp, bottom = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SignalMark(palette.foreground.copy(alpha = 0.86f), 34.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(station.name, color = palette.foreground, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${station.genre}  ·  ${station.broadcaster}", color = palette.secondaryText, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (showFavorite) {
            IconButton(onClick = onFavorite) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = if (favorite) "Remove favorite" else "Add favorite", tint = if (favorite) palette.accent else palette.secondaryText, modifier = Modifier.size(25.dp))
            }
        }
    }
}

@Composable
private fun GenreGrid(genres: List<String>, activeGenre: String, onGenre: (String) -> Unit, palette: RadioPalette) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        genres.forEachIndexed { index, genre ->
            Column(
                Modifier.width(104.dp).clip(RoundedCornerShape(18.dp))
                    .background(if (activeGenre == genre) palette.search else Color.Transparent)
                    .clickable { onGenre(genre) }.padding(vertical = 13.dp, horizontal = 5.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    when (index % 4) { 0 -> Icons.Default.MusicNote; 1 -> Icons.Default.GraphicEq; 2 -> Icons.Default.Radio; else -> Icons.Default.Explore },
                    contentDescription = null, tint = palette.foreground.copy(alpha = 0.82f), modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.height(6.dp))
                Text(genre, color = palette.foreground, fontSize = 11.sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun LiveStreamLine(palette: RadioPalette, playing: Boolean) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.weight(1f).height(5.dp)) {
            drawLine(palette.divider, Offset(0f, size.height / 2f), Offset(size.width, size.height / 2f), strokeWidth = 2.dp.toPx())
            val progress = if (playing) 0.72f else 0.16f
            drawLine(palette.accent.copy(alpha = 0.85f), Offset(0f, size.height / 2f), Offset(size.width * progress, size.height / 2f), strokeWidth = 2.dp.toPx())
        }
        Spacer(Modifier.width(10.dp))
        Text(if (playing) "LIVE" else "READY", color = palette.secondaryText, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun RoundPlayerButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, palette: RadioPalette, size: Dp, primary: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(if (primary) palette.foreground else palette.card)
            .border(1.dp, palette.divider, CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = description, tint = if (primary) palette.background else palette.foreground, modifier = Modifier.size(if (primary) 30.dp else 23.dp))
    }
}

@Composable
private fun UpcomingStationRow(station: Station, palette: RadioPalette, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(station.name.uppercase(), color = palette.foreground, fontSize = 13.sp, letterSpacing = 1.5.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${station.genre} · ${station.broadcaster}", color = palette.secondaryText, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(palette.divider))
}

@Composable
private fun EmptyState(title: String, message: String, palette: RadioPalette, action: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = palette.foreground, fontSize = 18.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(7.dp))
        Text(message, color = palette.secondaryText, fontSize = 13.sp, textAlign = TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(16.dp))
            PrimaryAction("Browse stations", palette, action)
        }
    }
}

@Composable
private fun PrimaryAction(label: String, palette: RadioPalette, onClick: () -> Unit) {
    Text(label, color = palette.background, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.clip(CircleShape).background(palette.foreground).clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp))
}

@Composable
private fun RadioBottomNavigation(activeTab: RadioTab, palette: RadioPalette, onSelect: (RadioTab) -> Unit) {
    Column(Modifier.fillMaxWidth().background(palette.background)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(palette.divider))
        Row(Modifier.fillMaxWidth().height(74.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            BottomNavItem("now playing", Icons.Default.GraphicEq, activeTab == RadioTab.NOW_PLAYING, palette, Modifier.weight(1f)) { onSelect(RadioTab.NOW_PLAYING) }
            BottomNavItem("browse", Icons.Default.Explore, activeTab == RadioTab.BROWSE, palette, Modifier.weight(1f)) { onSelect(RadioTab.BROWSE) }
            BottomNavItem("favorites", Icons.Default.Favorite, activeTab == RadioTab.FAVORITES, palette, Modifier.weight(1f)) { onSelect(RadioTab.FAVORITES) }
        }
    }
}

@Composable
private fun BottomNavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, palette: RadioPalette, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.fillMaxHeight().clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, contentDescription = label, tint = if (selected) palette.foreground else palette.secondaryText.copy(alpha = 0.72f), modifier = Modifier.size(23.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (selected) palette.foreground else palette.secondaryText, fontSize = 10.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        Spacer(Modifier.height(3.dp))
        Box(Modifier.width(if (selected) 46.dp else 0.dp).height(2.dp).background(palette.foreground, CircleShape))
    }
}

