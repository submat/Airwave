package com.example.englishradio

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer

class SplashActivity : ComponentActivity() {
    private val handler = Handler(Looper.getMainLooper())
    private val launchApp = Runnable {
        val isTv = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
        startActivity(Intent(this, if (isTv) TvActivity::class.java else MainActivity::class.java))
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = 5894 or 1024 or 512
        setContent { CherrySplash() }
        handler.postDelayed(launchApp, 2100L)
    }
    override fun onDestroy() {
        handler.removeCallbacks(launchApp)
        super.onDestroy()
    }
}

@Composable
private fun CherrySplash() {
    val painter = painterResource(R.drawable.cherry_splash)
    Box(Modifier.fillMaxSize().background(Color(0xFF08070A))) {
        // Soft full-bleed backdrop fills wide TV panels without cropping the portrait itself.
        Image(
            painter = painter, contentDescription = null,
            modifier = Modifier.fillMaxSize().graphicsLayer(alpha = 0.28f),
            contentScale = ContentScale.Crop
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000000), Color(0x66000000)))))
        Image(
            painter = painter, contentDescription = "Cherry",
            modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 4.dp),
            contentScale = ContentScale.Fit
        )
    }
}
