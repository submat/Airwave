package com.example.englishradio

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Metadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.extractor.metadata.icy.IcyInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import java.util.concurrent.atomic.AtomicInteger

internal data class StationLinkCheckResult(
    val stationId: String,
    val stationName: String,
    val streamUrl: String,
    val status: String,
    val currentTrack: String,
    val details: String,
    val elapsedMs: Long,
    val checkedAt: String,
    val language: String,
    val country: String,
    val countryCode: String,
    val genre: String,
    val codec: String,
    val bitrateKbps: Int,
    val sourceCheckedAt: String
) {
    val isPlaying: Boolean get() = status == "PLAYING"
    // A stream is DEAD only for an explicit permanent HTTP response. Timeouts,
    // decoder errors and transient network failures remain UNVERIFIED, not dead.
    val qualityStatus: String get() = when {
        isPlaying -> "VERIFIED"
        Regex("\\bHTTP\\s+(404|410)\\b", RegexOption.IGNORE_CASE).containsMatchIn(details) -> "DEAD"
        else -> "UNVERIFIED"
    }
}

@OptIn(UnstableApi::class)
internal object StationLinkChecker {
    private const val CHECK_TIMEOUT_MS = 9_000L
    private const val PLAY_CONFIRM_MS = 1_600L

    suspend fun check(context: Context, station: Station): StationLinkCheckResult {
        val startedAt = SystemClock.elapsedRealtime()
        val checkedAt = timestamp()
        val parsed = Uri.parse(station.stream)
        if (parsed.scheme !in setOf("http", "https") || parsed.host.isNullOrBlank()) {
            return result(station, "INVALID_URL", "", "Stream URL is not a valid HTTP(S) URL",
                SystemClock.elapsedRealtime() - startedAt, checkedAt)
        }

        val resolvedUrl = try {
            withContext(Dispatchers.IO) { PlaylistResolver.resolve(station.stream) }
        } catch (error: Exception) {
            return result(station, "PLAYLIST_ERROR", "", concise(error.message ?: error.javaClass.simpleName),
                SystemClock.elapsedRealtime() - startedAt, checkedAt)
        }

        return withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { continuation ->
                val player = try {
                    ExoPlayer.Builder(context.applicationContext).build()
                } catch (error: Exception) {
                    continuation.resume(
                        result(station, "PLAYER_ERROR", "", concise(error.message ?: "Could not create playback probe"),
                            SystemClock.elapsedRealtime() - startedAt, checkedAt)
                    )
                    return@suspendCancellableCoroutine
                }
                player.volume = 0f

                val handler = Handler(Looper.getMainLooper())
                var completed = false
                var released = false
                var audioTrackAvailable = false
                var playingSince = 0L
                var latestTrack = ""
                var listener: Player.Listener? = null
                var watchdog: Runnable? = null

                fun release() {
                    if (released) return
                    released = true
                    watchdog?.let { handler.removeCallbacks(it) }
                    listener?.let { player.removeListener(it) }
                    runCatching { player.release() }
                }

                fun finish(status: String, details: String) {
                    if (completed) return
                    completed = true
                    release()
                    if (continuation.isActive) {
                        continuation.resume(
                            result(
                                station, status,
                                latestTrack.ifBlank { "No song metadata supplied by station" },
                                details,
                                SystemClock.elapsedRealtime() - startedAt,
                                checkedAt
                            )
                        )
                    }
                }

                val probeListener = object : Player.Listener {
                    override fun onTracksChanged(tracks: Tracks) {
                        audioTrackAvailable = tracks.groups.any { group ->
                            group.type == C.TRACK_TYPE_AUDIO &&
                                (0 until group.length).any { index ->
                                    group.isTrackSelected(index) && group.isTrackSupported(index)
                                }
                        }
                    }

                    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                        val title = mediaMetadata.title?.toString()?.trim().orEmpty()
                        val artist = mediaMetadata.artist?.toString()?.trim().orEmpty()
                        val candidate = listOf(artist, title).filter { it.isNotBlank() }.joinToString(" — ")
                        if (candidate.isNotBlank()) latestTrack = candidate
                    }

                    override fun onMetadata(metadata: Metadata) {
                        for (index in 0 until metadata.length()) {
                            val icy = metadata[index] as? IcyInfo ?: continue
                            val title = icy.title?.trim().orEmpty()
                            if (title.isNotBlank()) latestTrack = title
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        val http = generateSequence(error as Throwable?) { it.cause }
                            .filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
                            .firstOrNull()
                        val detail = if (http != null) {
                            "HTTP ${http.responseCode}"
                        } else {
                            "${error.errorCodeName}: ${concise(error.message ?: "Playback failed")}"
                        }
                        finish("FAILED", detail)
                    }
                }
                listener = probeListener
                player.addListener(probeListener)

                watchdog = object : Runnable {
                    override fun run() {
                        if (completed) return
                        val now = SystemClock.elapsedRealtime()
                        val elapsed = now - startedAt
                        if (player.isPlaying && audioTrackAvailable) {
                            if (playingSince == 0L) playingSince = now
                            if (now - playingSince >= PLAY_CONFIRM_MS) {
                                finish("PLAYING", "Selected supported audio track is actively playing")
                                return
                            }
                        } else {
                            playingSince = 0L
                        }

                        if (elapsed >= 6_500L && player.playbackState == Player.STATE_READY && !player.isPlaying) {
                            finish(
                                if (audioTrackAvailable) "READY_NOT_PLAYING" else "NO_AUDIO_TRACK",
                                if (audioTrackAvailable) "Stream prepared but playback did not start" else "Stream prepared without a supported audio track"
                            )
                            return
                        }
                        if (elapsed >= CHECK_TIMEOUT_MS) {
                            finish(
                                if (player.isPlaying && !audioTrackAvailable) "NO_AUDIO_TRACK" else "TIMEOUT",
                                if (player.isPlaying && !audioTrackAvailable) {
                                    "Player became active, but no selected supported audio track was confirmed"
                                } else {
                                    "No confirmed audio playback within ${CHECK_TIMEOUT_MS / 1000}s"
                                }
                            )
                            return
                        }
                        handler.postDelayed(this, 250L)
                    }
                }

                continuation.invokeOnCancellation {
                    handler.post { release() }
                }

                try {
                    player.setMediaItem(MediaItem.fromUri(resolvedUrl))
                    player.prepare()
                    player.play()
                    watchdog?.let { handler.postDelayed(it, 250L) }
                } catch (error: Exception) {
                    finish("FAILED", concise(error.message ?: error.javaClass.simpleName))
                }
            }
        }
    }

    private fun result(
        station: Station,
        status: String,
        track: String,
        details: String,
        elapsed: Long,
        checkedAt: String
    ) = StationLinkCheckResult(
        stationId = station.id,
        stationName = station.name,
        streamUrl = station.stream,
        status = status,
        currentTrack = track,
        details = details,
        elapsedMs = elapsed,
        checkedAt = checkedAt,
        language = station.language,
        country = station.region,
        countryCode = station.countryCode,
        genre = station.genre,
        codec = station.codec,
        bitrateKbps = station.bitrateKbps,
        sourceCheckedAt = station.sourceCheckedAt
    )

    private fun timestamp(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(Date())

    private fun concise(value: String): String =
        value.replace(Regex("\\s+"), " ").take(180)
}

internal fun exportStationLinkReport(context: Context, results: List<StationLinkCheckResult>): String {
    require(results.isNotEmpty()) { "There are no station-check results to export." }
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val fileName = "RadioCherry_Station_Link_Check_$stamp.csv"
    val csv = buildString {
        appendLine("station_id,station_name,stream_url,quality_status,probe_status,country,country_code,language,genre,codec,bitrate_kbps,directory_last_checked,current_track,details,response_ms,checked_at")
        results.forEach { row ->
            appendLine(
                listOf(
                    row.stationId, row.stationName, row.streamUrl, row.qualityStatus, row.status,
                    row.country, row.countryCode, row.language, row.genre, row.codec, row.bitrateKbps.toString(),
                    row.sourceCheckedAt, row.currentTrack, row.details, row.elapsedMs.toString(), row.checkedAt
                ).joinToString(",") { csvEscape(it) }
            )
        }
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Radio Cherry")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: error("Android could not create the report in Downloads.")
        try {
            resolver.openOutputStream(uri, "w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(csv) }
                ?: error("Could not write the station report.")
            val ready = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(uri, ready, null, null)
        } catch (error: Exception) {
            resolver.delete(uri, null, null)
            throw error
        }
        return "Downloads/Radio Cherry/$fileName"
    }

    val permission = ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    check(permission == android.content.pm.PackageManager.PERMISSION_GRANTED) {
        "Storage permission is required to save into Downloads on Android 8/9."
    }
    val directory = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Radio Cherry"
    )
    check(directory.exists() || directory.mkdirs()) { "Could not create the Downloads/Radio Cherry folder." }
    File(directory, fileName).writeText(csv, Charsets.UTF_8)
    return "Downloads/Radio Cherry/$fileName"
}

private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

@Composable
internal fun StationLinkCheckDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val results = remember { mutableStateListOf<StationLinkCheckResult>() }
    var running by remember { mutableStateOf(false) }
    var completed by remember { mutableIntStateOf(0) }
    var currentStation by remember { mutableStateOf("") }
    var reportLocation by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Tests real audio playback silently; it does not interrupt the station currently playing.") }
    var runJob by remember { mutableStateOf<Job?>(null) }
    val permissionAction = remember { mutableStateOf<(() -> Unit)?>(null) }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) permissionAction.value?.invoke()
        else message = "Storage permission was denied. The check results remain available in this screen."
        permissionAction.value = null
    }

    fun exportLog() {
        val snapshot = results.toList()
        if (snapshot.isEmpty()) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            permissionAction.value = { exportLog() }
            storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        scope.launch {
            runCatching {
                withContext(Dispatchers.IO) { exportStationLinkReport(context, snapshot) }
            }.onSuccess {
                reportLocation = it
                message = "Report saved successfully."
            }.onFailure {
                message = "Could not save report: ${it.message ?: "unknown error"}"
            }
        }
    }

    fun startCheck() {
        if (running) return
        results.clear()
        completed = 0
        currentStation = ""
        reportLocation = ""
        message = "Checking ${stations.size} stations with four muted Media3 playback probes. A full 50,000-station scan can take hours; cancel any time."
        running = true
        runJob = scope.launch {
            try {
                val snapshot = stations.toList()
                val nextIndex = AtomicInteger(0)
                coroutineScope {
                    repeat(4) {
                        launch {
                            while (true) {
                                val index = nextIndex.getAndIncrement()
                                if (index >= snapshot.size) break
                                val station = snapshot[index]
                                currentStation = station.name
                                val checked = StationLinkChecker.check(context.applicationContext, station)
                                results.add(checked)
                                completed += 1
                            }
                        }
                    }
                }
                RadioCatalogueRepository.persistVerificationResults(context.applicationContext, results.toList())
                val verified = results.count { it.qualityStatus == "VERIFIED" }
                val unverified = results.count { it.qualityStatus == "UNVERIFIED" }
                val dead = results.count { it.qualityStatus == "DEAD" }
                message = "Check complete: $verified verified · $unverified unverified · $dead dead (HTTP 404/410)."
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                    android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    exportLog()
                } else {
                    message += " Tap SAVE LOG to grant Downloads access."
                }
            } catch (_: CancellationException) {
                withContext(NonCancellable) {
                    RadioCatalogueRepository.persistVerificationResults(context.applicationContext, results.toList())
                }
                message = "Check cancelled. ${results.size} results retained; quality states were saved."
                if (results.isNotEmpty()) message += " Save the partial report with SAVE LOG."
            } finally {
                running = false
                currentStation = ""
            }
        }
    }

    Dialog(
        onDismissRequest = {
            runJob?.cancel()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).widthIn(max = 760.dp).heightIn(max = 580.dp),
            shape = RoundedCornerShape(22.dp),
            color = Color(0xFF171B22),
            tonalElevation = 0.dp
        ) {
            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Station link detection", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Each link is opened in a muted player. PLAYING confirms active audio playback; a server response alone is not counted as success.",
                    color = Color(0xFFB9C0CB), fontSize = 12.sp, lineHeight = 16.sp
                )
                if (running) {
                    LinearProgressIndicator(
                        progress = if (stations.isEmpty()) 0f else completed.toFloat() / stations.size.toFloat(),
                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(6.dp))
                    )
                    Text(
                        "$completed / ${stations.size} checked${if (currentStation.isNotBlank()) " · $currentStation" else ""}",
                        color = Color(0xFF6FE7D7), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                } else if (completed > 0) {
                    val verified = results.count { it.qualityStatus == "VERIFIED" }
                    val unverified = results.count { it.qualityStatus == "UNVERIFIED" }
                    val dead = results.count { it.qualityStatus == "DEAD" }
                    Text(
                        "$verified verified · $unverified unverified · $dead dead",
                        color = Color(0xFF6FE7D7), fontSize = 12.sp, fontWeight = FontWeight.Medium
                    )
                }

                Text(message, color = Color(0xFFD0D5DC), fontSize = 10.sp, lineHeight = 13.sp)
                if (reportLocation.isNotBlank()) {
                    Text(reportLocation, color = Color(0xFF8FE9DC), fontSize = 10.sp)
                }
                if (results.isNotEmpty()) {
                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false).heightIn(max = 235.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(results.takeLast(60), key = { it.stationId }) { row ->
                            Row(
                                Modifier.fillMaxWidth().background(Color(0xFF222832), RoundedCornerShape(8.dp)).padding(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    row.qualityStatus,
                                    color = when (row.qualityStatus) {
                                        "VERIFIED" -> Color(0xFF70E2C9)
                                        "DEAD" -> Color(0xFFFF8585)
                                        else -> Color(0xFFFFD28A)
                                    },
                                    fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(112.dp)
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(row.stationName, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        if (row.currentTrack.isBlank()) "${row.status} · ${row.details}" else row.currentTrack,
                                        color = Color(0xFFABB4C0), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Spacer(Modifier.height(8.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = ::startCheck, enabled = !running) { Text(if (completed > 0) "RUN AGAIN" else "RUN CHECK") }
                    OutlinedButton(onClick = { runJob?.cancel() }, enabled = running) { Text("CANCEL") }
                    OutlinedButton(onClick = ::exportLog, enabled = results.isNotEmpty() && !running) { Text("SAVE LOG") }
                    Spacer(Modifier.weight(1f))
                    OutlinedButton(onClick = {
                        runJob?.cancel()
                        onDismiss()
                    }) { Text("DONE") }
                }
            }
        }
    }
}
