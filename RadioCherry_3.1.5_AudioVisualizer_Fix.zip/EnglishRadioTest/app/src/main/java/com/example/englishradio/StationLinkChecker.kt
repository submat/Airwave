package com.example.englishradio

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Metadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.extractor.metadata.icy.IcyInfo
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.ArrayDeque
import java.util.LinkedHashSet
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import java.util.concurrent.atomic.AtomicInteger

internal data class StationLinkCheckResult(
    val stationId: String,
    val stationName: String,
    val streamUrl: String,
    val status: String,
    val currentTrack: String,
    val details: String,
    val elapsedMs: Long,
    val checkedAt: String,
    val language: String,
    val country: String,
    val countryCode: String,
    val genre: String,
    val codec: String,
    val bitrateKbps: Int,
    val sourceCheckedAt: String
) {
    val isPlaying: Boolean get() = status == "PLAYING"
    // A stream is DEAD only for an explicit permanent HTTP response. Timeouts,
    // decoder errors and transient network failures remain UNVERIFIED, not dead.
    val qualityStatus: String get() = when {
        isPlaying -> "VERIFIED"
        Regex("\\bHTTP\\s+(404|410)\\b", RegexOption.IGNORE_CASE).containsMatchIn(details) -> "DEAD"
        else -> "UNVERIFIED"
    }
}

@OptIn(UnstableApi::class)
internal object StationLinkChecker {
    private const val CHECK_TIMEOUT_MS = 9_000L
    private const val PLAY_CONFIRM_MS = 1_600L

    suspend fun check(context: Context, station: Station): StationLinkCheckResult {
        val startedAt = SystemClock.elapsedRealtime()
        val checkedAt = timestamp()
        val parsed = Uri.parse(station.stream)
        if (parsed.scheme !in setOf("http", "https") || parsed.host.isNullOrBlank()) {
            return result(station, "INVALID_URL", "", "Stream URL is not a valid HTTP(S) URL",
                SystemClock.elapsedRealtime() - startedAt, checkedAt)
        }

        val resolvedUrl = try {
            withContext(Dispatchers.IO) { PlaylistResolver.resolve(station.stream) }
        } catch (error: Exception) {
            return result(station, "PLAYLIST_ERROR", "", concise(error.message ?: error.javaClass.simpleName),
                SystemClock.elapsedRealtime() - startedAt, checkedAt)
        }

        return withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine { continuation ->
                val player = try {
                    ExoPlayer.Builder(context.applicationContext).build()
                } catch (error: Exception) {
                    continuation.resume(
                        result(station, "PLAYER_ERROR", "", concise(error.message ?: "Could not create playback probe"),
                            SystemClock.elapsedRealtime() - startedAt, checkedAt)
                    )
                    return@suspendCancellableCoroutine
                }
                player.volume = 0f

                val handler = Handler(Looper.getMainLooper())
                var completed = false
                var released = false
                var audioTrackAvailable = false
                var playingSince = 0L
                var latestTrack = ""
                var listener: Player.Listener? = null
                var watchdog: Runnable? = null

                fun release() {
                    if (released) return
                    released = true
                    watchdog?.let { handler.removeCallbacks(it) }
                    listener?.let { player.removeListener(it) }
                    runCatching { player.release() }
                }

                fun finish(status: String, details: String) {
                    if (completed) return
                    completed = true
                    release()
                    if (continuation.isActive) {
                        continuation.resume(
                            result(
                                station, status,
                                latestTrack.ifBlank { "No song metadata supplied by station" },
                                details,
                                SystemClock.elapsedRealtime() - startedAt,
                                checkedAt
                            )
                        )
                    }
                }

                val probeListener = object : Player.Listener {
                    override fun onTracksChanged(tracks: Tracks) {
                        audioTrackAvailable = tracks.groups.any { group ->
                            group.type == C.TRACK_TYPE_AUDIO &&
                                (0 until group.length).any { index ->
                                    group.isTrackSelected(index) && group.isTrackSupported(index)
                                }
                        }
                    }

                    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) {
                        val title = mediaMetadata.title?.toString()?.trim().orEmpty()
                        val artist = mediaMetadata.artist?.toString()?.trim().orEmpty()
                        val candidate = listOf(artist, title).filter { it.isNotBlank() }.joinToString(" — ")
                        if (candidate.isNotBlank()) latestTrack = candidate
                    }

                    override fun onMetadata(metadata: Metadata) {
                        for (index in 0 until metadata.length()) {
                            val icy = metadata[index] as? IcyInfo ?: continue
                            val title = icy.title?.trim().orEmpty()
                            if (title.isNotBlank()) latestTrack = title
                        }
                    }

                    override fun onPlayerError(error: PlaybackException) {
                        val http = generateSequence(error as Throwable?) { it.cause }
                            .filterIsInstance<HttpDataSource.InvalidResponseCodeException>()
                            .firstOrNull()
                        val detail = if (http != null) {
                            "HTTP ${http.responseCode}"
                        } else {
                            "${error.errorCodeName}: ${concise(error.message ?: "Playback failed")}"
                        }
                        finish("FAILED", detail)
                    }
                }
                listener = probeListener
                player.addListener(probeListener)

                watchdog = object : Runnable {
                    override fun run() {
                        if (completed) return
                        val now = SystemClock.elapsedRealtime()
                        val elapsed = now - startedAt
                        if (player.isPlaying && audioTrackAvailable) {
                            if (playingSince == 0L) playingSince = now
                            if (now - playingSince >= PLAY_CONFIRM_MS) {
                                finish("PLAYING", "Selected supported audio track is actively playing")
                                return
                            }
                        } else {
                            playingSince = 0L
                        }

                        if (elapsed >= 6_500L && player.playbackState == Player.STATE_READY && !player.isPlaying) {
                            finish(
                                if (audioTrackAvailable) "READY_NOT_PLAYING" else "NO_AUDIO_TRACK",
                                if (audioTrackAvailable) "Stream prepared but playback did not start" else "Stream prepared without a supported audio track"
                            )
                            return
                        }
                        if (elapsed >= CHECK_TIMEOUT_MS) {
                            finish(
                                if (player.isPlaying && !audioTrackAvailable) "NO_AUDIO_TRACK" else "TIMEOUT",
                                if (player.isPlaying && !audioTrackAvailable) {
                                    "Player became active, but no selected supported audio track was confirmed"
                                } else {
                                    "No confirmed audio playback within ${CHECK_TIMEOUT_MS / 1000}s"
                                }
                            )
                            return
                        }
                        handler.postDelayed(this, 250L)
                    }
                }

                continuation.invokeOnCancellation {
                    handler.post { release() }
                }

                try {
                    player.setMediaItem(MediaItem.fromUri(resolvedUrl))
                    player.prepare()
                    player.play()
                    watchdog?.let { handler.postDelayed(it, 250L) }
                } catch (error: Exception) {
                    finish("FAILED", concise(error.message ?: error.javaClass.simpleName))
                }
            }
        }
    }

    private fun result(
        station: Station,
        status: String,
        track: String,
        details: String,
        elapsed: Long,
        checkedAt: String
    ) = StationLinkCheckResult(
        stationId = station.id,
        stationName = station.name,
        streamUrl = station.stream,
        status = status,
        currentTrack = track,
        details = details,
        elapsedMs = elapsed,
        checkedAt = checkedAt,
        language = station.language,
        country = station.region,
        countryCode = station.countryCode,
        genre = station.genre,
        codec = station.codec,
        bitrateKbps = station.bitrateKbps,
        sourceCheckedAt = station.sourceCheckedAt
    )

    private fun timestamp(): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(Date())

    private fun concise(value: String): String =
        value.replace(Regex("\\s+"), " ").take(180)
}

internal fun exportStationLinkReport(context: Context, results: List<StationLinkCheckResult>): String {
    require(results.isNotEmpty()) { "There are no station-check results to export." }
    val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    val fileName = "RadioCherry_Station_Link_Check_$stamp.csv"
    val directory = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
        "Radio Cherry"
    )
    check(directory.exists() || directory.mkdirs()) { "Could not create the Downloads/Radio Cherry folder." }
    File(directory, fileName).bufferedWriter(Charsets.UTF_8).use { writer ->
        writer.appendLine(stationReportHeader())
        results.forEach { writer.appendLine(it.toCsvLine()) }
    }
    return "Downloads/Radio Cherry/$fileName"
}

private fun stationReportHeader() =
    "station_id,station_name,stream_url,quality_status,probe_status,country,country_code,language,genre,codec,bitrate_kbps,directory_last_checked,current_track,details,response_ms,checked_at"

private fun StationLinkCheckResult.toCsvLine(): String = listOf(
    stationId, stationName, streamUrl, qualityStatus, status, country, countryCode,
    language, genre, codec, bitrateKbps.toString(), sourceCheckedAt, currentTrack,
    details, elapsedMs.toString(), checkedAt
).joinToString(",") { csvEscape(it) }

private fun csvEscape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

/**
 * Crash-safe station-check session storage. The JSONL journal is the source of truth;
 * the user-visible CSV is an incrementally-written mirror in Downloads.
 */
internal data class StationQualityUpdate(
    val stationId: String,
    val qualityStatus: String,
    val checkedAt: String
)

internal data class StationCheckSessionSnapshot(
    val checkedIds: Set<String>,
    val recentResults: List<StationLinkCheckResult>,
    val verified: Int,
    val unverified: Int,
    val dead: Int,
    val active: Boolean,
    val reportLocation: String
) {
    val completed: Int get() = checkedIds.size
}

internal object StationLinkCheckSessionStore {
    private const val JOURNAL_NAME = "station_link_check_session.jsonl"
    private const val PREFS_NAME = "station_link_check_session"
    private const val KEY_ACTIVE = "active"
    private const val KEY_REPORT_URI = "report_uri"
    private const val KEY_REPORT_NAME = "report_name"
    private val mutex = kotlinx.coroutines.sync.Mutex()
    private var reportWriter: java.io.BufferedWriter? = null
    private var reportUri: Uri? = null
    private var reportWriteFailed = false
    private val knownIds = LinkedHashSet<String>()

    suspend fun beginNew(context: Context): StationCheckSessionSnapshot = withContext(Dispatchers.IO) {
        mutex.withLock {
            closeReportWriter()
            val journal = File(context.filesDir, JOURNAL_NAME)
            if (journal.exists()) check(journal.delete()) { "Could not reset the previous station-check journal." }
            knownIds.clear()
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            check(prefs.edit().clear().putBoolean(KEY_ACTIVE, true).commit()) { "Could not initialise the recovery session." }
            createReport(context, replayJournal = false)
            snapshotLocked(context)
        }
    }

    suspend fun resume(context: Context): StationCheckSessionSnapshot = withContext(Dispatchers.IO) {
        mutex.withLock {
            closeReportWriter()
            // Recreate the CSV from the journal. This repairs the small window where the
            // process could stop after a journal write but before its CSV mirror was flushed.
            createReport(context, replayJournal = true)
            check(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ACTIVE, true).commit()) { "Could not mark the session resumable." }
            snapshotLocked(context)
        }
    }

    suspend fun inspect(context: Context): StationCheckSessionSnapshot = withContext(Dispatchers.IO) {
        mutex.withLock { snapshotLocked(context) }
    }

    suspend fun rebuildReport(context: Context): String = withContext(Dispatchers.IO) {
        mutex.withLock {
            createReport(context, replayJournal = true)
            closeReportWriter()
            snapshotLocked(context).reportLocation
        }
    }

    suspend fun finalizeReport(context: Context): String = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && (reportWriteFailed || reportWriter == null)) {
                createReport(context, replayJournal = true)
            }
            closeReportWriter()
            snapshotLocked(context).reportLocation
        }
    }

    suspend fun append(context: Context, row: StationLinkCheckResult): Boolean = withContext(Dispatchers.IO) {
        mutex.withLock {
            val journal = File(context.filesDir, JOURNAL_NAME)
            if (!knownIds.add(row.stationId)) return@withLock false

            val jsonLine = row.toJournalJson().toString() + "\n"
            try {
                java.io.FileOutputStream(journal, true).use { stream ->
                    stream.write(jsonLine.toByteArray(Charsets.UTF_8))
                    stream.flush()
                    stream.fd.sync()
                }
            } catch (error: Exception) {
                knownIds.remove(row.stationId)
                throw error
            }
            try {
                reportWriter?.apply {
                    appendLine(row.toCsvLine())
                    flush()
                }
            } catch (_: Exception) {
                reportWriteFailed = true
                closeReportWriter()
            }
            true
        }
    }

    suspend fun finish(context: Context, complete: Boolean) = withContext(Dispatchers.IO) {
        mutex.withLock {
            closeReportWriter()
            check(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ACTIVE, !complete).commit()) { "Could not save the session state." }
        }
    }

    suspend fun loadAllResults(context: Context): List<StationLinkCheckResult> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val output = ArrayList<StationLinkCheckResult>()
            val journal = File(context.filesDir, JOURNAL_NAME)
            if (journal.exists()) journal.useLines(Charsets.UTF_8) { lines ->
                lines.forEach { line -> runCatching { org.json.JSONObject(line).toStationResult() }.getOrNull()?.let(output::add) }
            }
            output
        }
    }

    suspend fun loadQualityUpdates(context: Context): Map<String, StationQualityUpdate> = withContext(Dispatchers.IO) {
        mutex.withLock {
            val updates = LinkedHashMap<String, StationQualityUpdate>()
            val journal = File(context.filesDir, JOURNAL_NAME)
            if (journal.exists()) journal.useLines(Charsets.UTF_8) { lines ->
                lines.forEach { line ->
                    runCatching {
                        val row = org.json.JSONObject(line)
                        val id = row.optString("stationId")
                        if (id.isNotBlank()) updates[id] = StationQualityUpdate(
                            stationId = id,
                            qualityStatus = when {
                                row.optString("status") == "PLAYING" -> "VERIFIED"
                                Regex("\\bHTTP\\s+(404|410)\\b", RegexOption.IGNORE_CASE)
                                    .containsMatchIn(row.optString("details")) -> "DEAD"
                                else -> "UNVERIFIED"
                            },
                            checkedAt = row.optString("checkedAt")
                        )
                    }
                }
            }
            updates
        }
    }

    private fun snapshotLocked(context: Context): StationCheckSessionSnapshot {
        val checked = LinkedHashSet<String>()
        val recent = ArrayDeque<StationLinkCheckResult>(60)
        var verified = 0
        var unverified = 0
        var dead = 0
        val journal = File(context.filesDir, JOURNAL_NAME)
        if (journal.exists()) journal.useLines(Charsets.UTF_8) { lines ->
            lines.forEach { line ->
                val row = runCatching { org.json.JSONObject(line).toStationResult() }.getOrNull() ?: return@forEach
                if (!checked.add(row.stationId)) return@forEach
                when (row.qualityStatus) {
                    "VERIFIED" -> verified++
                    "DEAD" -> dead++
                    else -> unverified++
                }
                if (recent.size == 60) recent.removeFirst()
                recent.addLast(row)
            }
        }
        knownIds.clear()
        knownIds.addAll(checked)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val name = prefs.getString(KEY_REPORT_NAME, "").orEmpty()
        return StationCheckSessionSnapshot(
            checkedIds = checked,
            recentResults = recent.toList(),
            verified = verified,
            unverified = unverified,
            dead = dead,
            active = prefs.getBoolean(KEY_ACTIVE, false) && checked.isNotEmpty(),
            reportLocation = if (name.isBlank()) "" else "Downloads/Radio Cherry/$name"
        )
    }

    private fun createReport(context: Context, replayJournal: Boolean) {
        closeReportWriter()
        reportWriteFailed = false
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
            .remove(KEY_REPORT_URI).remove(KEY_REPORT_NAME).commit()
        runCatching {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val fileName = "RadioCherry_Station_Link_Check_$stamp.csv"
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/Radio Cherry")
                // Make the file visible immediately. If Android kills the process, the partial CSV remains.
                put(MediaStore.MediaColumns.IS_PENDING, 0)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: error("Could not create the incremental CSV in Downloads.")
            reportUri = uri
            val output = context.contentResolver.openOutputStream(uri, "w")
                ?: error("Could not open the incremental CSV in Downloads.")
            reportWriter = output.bufferedWriter(Charsets.UTF_8)
            reportWriter?.apply {
                appendLine(stationReportHeader())
                flush()
            }
            check(context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit()
                .putString(KEY_REPORT_URI, uri.toString())
                .putString(KEY_REPORT_NAME, fileName)
                .commit()) { "Could not save the report location." }
            if (replayJournal) {
                val journal = File(context.filesDir, JOURNAL_NAME)
                if (journal.exists()) journal.useLines(Charsets.UTF_8) { lines ->
                    lines.forEach { line ->
                        val csv = runCatching { org.json.JSONObject(line).toStationResult().toCsvLine() }.getOrNull()
                        if (csv != null) reportWriter?.appendLine(csv)
                    }
                }
                reportWriter?.flush()
            }
        }.onFailure {
            reportWriteFailed = true
            closeReportWriter()
            // The internal JSONL journal remains usable when Downloads is unavailable.
        }
    }

    private fun closeReportWriter() {
        runCatching { reportWriter?.flush() }
        runCatching { reportWriter?.close() }
        reportWriter = null
        reportUri = null
    }

    private fun StationLinkCheckResult.toJournalJson() = org.json.JSONObject().apply {
        put("stationId", stationId); put("stationName", stationName); put("streamUrl", streamUrl)
        put("status", status); put("currentTrack", currentTrack); put("details", details)
        put("elapsedMs", elapsedMs); put("checkedAt", checkedAt); put("language", language)
        put("country", country); put("countryCode", countryCode); put("genre", genre)
        put("codec", codec); put("bitrateKbps", bitrateKbps); put("sourceCheckedAt", sourceCheckedAt)
    }

    private fun org.json.JSONObject.toStationResult() = StationLinkCheckResult(
        stationId = optString("stationId"), stationName = optString("stationName"),
        streamUrl = optString("streamUrl"), status = optString("status"),
        currentTrack = optString("currentTrack"), details = optString("details"),
        elapsedMs = optLong("elapsedMs"), checkedAt = optString("checkedAt"),
        language = optString("language"), country = optString("country"),
        countryCode = optString("countryCode"), genre = optString("genre"),
        codec = optString("codec"), bitrateKbps = optInt("bitrateKbps"),
        sourceCheckedAt = optString("sourceCheckedAt")
    )
}

@Composable
internal fun StationLinkCheckDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val results = remember { mutableStateListOf<StationLinkCheckResult>() }
    var running by remember { mutableStateOf(false) }
    var resumable by remember { mutableStateOf(false) }
    var completed by remember { mutableIntStateOf(0) }
    var totalStations by remember { mutableIntStateOf(stations.size) }
    var verified by remember { mutableIntStateOf(0) }
    var unverified by remember { mutableIntStateOf(0) }
    var dead by remember { mutableIntStateOf(0) }
    var currentStation by remember { mutableStateOf("") }
    var reportLocation by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("Checks real audio playback silently. Results are saved as each station finishes.") }
    var runJob by remember { mutableStateOf<Job?>(null) }
    val permissionAction = remember { mutableStateOf<(() -> Unit)?>(null) }

    // Keep the display awake during long-running probes. The on-disk journal still
    // allows recovery if Android or the user closes the app.
    DisposableEffect(running) {
        view.keepScreenOn = running
        onDispose { view.keepScreenOn = false }
    }

    val storagePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) permissionAction.value?.invoke()
        else message = "Storage permission denied. The internal recovery journal is still being retained."
        permissionAction.value = null
    }

    fun exportLog() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            scope.launch {
                val rebuilt = runCatching { StationLinkCheckSessionStore.rebuildReport(context.applicationContext) }
                rebuilt.onSuccess {
                    reportLocation = it
                    message = if (it.isNotBlank()) "Full report saved at $it." else
                        "Downloads could not create the CSV. The complete recovery journal is still retained by Radio Cherry."
                }.onFailure {
                    message = "Could not rebuild the CSV: ${it.message ?: "unknown error"}. The recovery journal is retained."
                }
            }
            return
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            permissionAction.value = { exportLog() }
            storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        scope.launch {
            runCatching {
                val all = StationLinkCheckSessionStore.loadAllResults(context)
                withContext(Dispatchers.IO) { exportStationLinkReport(context, all) }
            }.onSuccess {
                reportLocation = it
                message = "Full report saved successfully at $it."
            }.onFailure {
                message = "Could not save report: ${it.message ?: "unknown error"}"
            }
        }
    }

    fun startCheck(resume: Boolean) {
        if (running) return
        running = true
        currentStation = ""
        message = if (resume) "Recovering the saved run and resuming unchecked stations…" else
            "Starting a new run. Each result is journaled and appended to Downloads as it completes."
        runJob = scope.launch {
            try {
                val session = if (resume) StationLinkCheckSessionStore.resume(context.applicationContext)
                    else StationLinkCheckSessionStore.beginNew(context.applicationContext)
                results.clear()
                results.addAll(session.recentResults)
                completed = session.completed
                verified = session.verified
                unverified = session.unverified
                dead = session.dead
                reportLocation = session.reportLocation
                resumable = true

                val snapshot = stations.toList()
                totalStations = snapshot.size
                val pending = snapshot.filterNot { it.id in session.checkedIds }
                if (pending.isEmpty()) {
                    val qualityUpdates = StationLinkCheckSessionStore.loadQualityUpdates(context.applicationContext)
                    RadioCatalogueRepository.persistVerificationResults(context.applicationContext, qualityUpdates)
                    reportLocation = StationLinkCheckSessionStore.finalizeReport(context.applicationContext)
                    StationLinkCheckSessionStore.finish(context.applicationContext, complete = true)
                    resumable = false
                    message = "All ${snapshot.size} stations already have saved results. ${if (reportLocation.isNotBlank()) "Report: $reportLocation." else "Use SAVE LOG to rebuild the Downloads CSV from the recovery journal."}"
                } else {
                    message = "Checking ${pending.size} remaining stations with four muted Media3 probes. Completed results are saved continuously; you can cancel and resume later."
                    val nextIndex = AtomicInteger(0)
                    coroutineScope {
                        repeat(4) {
                            launch {
                                while (true) {
                                    val index = nextIndex.getAndIncrement()
                                    if (index >= pending.size) break
                                    val station = pending[index]
                                    withContext(Dispatchers.Main.immediate) { currentStation = station.name }
                                    val checked = StationLinkChecker.check(context.applicationContext, station)
                                    val stored = StationLinkCheckSessionStore.append(context.applicationContext, checked)
                                    if (stored) {
                                        withContext(Dispatchers.Main.immediate) {
                                            if (results.size >= 60) results.removeAt(0)
                                            results.add(checked)
                                            completed++
                                            when (checked.qualityStatus) {
                                                "VERIFIED" -> verified++
                                                "DEAD" -> dead++
                                                else -> unverified++
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    val allChecked = completed >= snapshot.map { it.id }.toSet().size
                    if (allChecked) {
                        val qualityUpdates = StationLinkCheckSessionStore.loadQualityUpdates(context.applicationContext)
                        RadioCatalogueRepository.persistVerificationResults(context.applicationContext, qualityUpdates)
                        reportLocation = StationLinkCheckSessionStore.finalizeReport(context.applicationContext)
                    }
                    StationLinkCheckSessionStore.finish(context.applicationContext, complete = allChecked)
                    resumable = !allChecked
                    message = if (allChecked) {
                        if (reportLocation.isNotBlank()) {
                            "Check complete: $verified verified · $unverified unverified · $dead dead. CSV saved at $reportLocation."
                        } else {
                            "Check complete: $verified verified · $unverified unverified · $dead dead. The recovery journal is saved; use SAVE LOG to rebuild the Downloads CSV."
                        }
                    } else {
                        "Run paused with $completed of ${snapshot.size} stations saved. Tap RESUME to continue."
                    }
                }
            } catch (_: CancellationException) {
                withContext(NonCancellable) {
                    StationLinkCheckSessionStore.finish(context.applicationContext, complete = false)
                }
                resumable = true
                message = "Run paused. $completed results are saved to the recovery journal and the incremental report. Tap RESUME to continue."
            } catch (error: Exception) {
                withContext(NonCancellable) {
                    runCatching { StationLinkCheckSessionStore.finish(context.applicationContext, complete = false) }
                }
                resumable = true
                message = "Run stopped safely: ${error.message?.take(160) ?: error.javaClass.simpleName}. $completed results remain saved; tap RESUME."
            } finally {
                running = false
                currentStation = ""
            }
        }
    }

    LaunchedEffect(context) {
        runCatching { StationLinkCheckSessionStore.inspect(context.applicationContext) }
            .onSuccess { session ->
                results.clear()
                results.addAll(session.recentResults)
                completed = session.completed
                verified = session.verified
                unverified = session.unverified
                dead = session.dead
                resumable = session.active
                reportLocation = session.reportLocation
                if (session.completed > 0) {
                    message = if (session.active) {
                        "Recovered an interrupted run: ${session.completed} stations have saved results. Tap RESUME to continue without repeating them."
                    } else {
                        "Previous run: ${session.completed} stations checked. The report remains available in Downloads."
                    }
                }
            }
    }

    Dialog(
        onDismissRequest = {
            runJob?.cancel()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.94f).widthIn(max = 760.dp).heightIn(max = 580.dp),
            shape = RoundedCornerShape(22.dp),
            color = Color(0xFF171B22),
            tonalElevation = 0.dp
        ) {
            Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Station link detection", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Muted Media3 playback confirms actual audio. Results are checkpointed to disk and mirrored to Downloads while the scan runs. The display stays awake during checks; keep the device plugged in. An interrupted run can be resumed.",
                    color = Color(0xFFB9C0CB), fontSize = 12.sp, lineHeight = 16.sp
                )
                if (running) {
                    LinearProgressIndicator(
                        progress = if (totalStations == 0) 0f else (completed.toFloat() / totalStations.toFloat()).coerceIn(0f, 1f),
                        modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(6.dp))
                    )
                }
                Text(
                    "$completed / $totalStations checked${if (currentStation.isNotBlank()) " · $currentStation" else ""}",
                    color = Color(0xFF6FE7D7), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text("$verified verified · $unverified unverified · $dead dead", color = Color(0xFF6FE7D7), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                Text(message, color = Color(0xFFD0D5DC), fontSize = 10.sp, lineHeight = 13.sp)
                if (reportLocation.isNotBlank()) {
                    Text(reportLocation, color = Color(0xFF8FE9DC), fontSize = 10.sp)
                }
                if (results.isNotEmpty()) {
                    LazyColumn(
                        modifier = Modifier.weight(1f, fill = false).heightIn(max = 235.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(results, key = { it.stationId }) { row ->
                            Row(
                                Modifier.fillMaxWidth().background(Color(0xFF222832), RoundedCornerShape(8.dp)).padding(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    row.qualityStatus,
                                    color = when (row.qualityStatus) {
                                        "VERIFIED" -> Color(0xFF70E2C9)
                                        "DEAD" -> Color(0xFFFF8585)
                                        else -> Color(0xFFFFD28A)
                                    },
                                    fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(112.dp)
                                )
                                Column(Modifier.weight(1f)) {
                                    Text(row.stationName, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        if (row.currentTrack.isBlank()) "${row.status} · ${row.details}" else row.currentTrack,
                                        color = Color(0xFFABB4C0), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Spacer(Modifier.height(8.dp))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { startCheck(false) }, enabled = !running) { Text("NEW RUN") }
                    OutlinedButton(onClick = { startCheck(true) }, enabled = !running && resumable) { Text("RESUME") }
                    OutlinedButton(onClick = { runJob?.cancel() }, enabled = running) { Text("PAUSE") }
                    OutlinedButton(onClick = ::exportLog, enabled = !running && completed > 0) { Text("SAVE LOG") }
                    Spacer(Modifier.weight(1f))
                    OutlinedButton(onClick = {
                        runJob?.cancel()
                        onDismiss()
                    }) { Text("DONE") }
                }
            }
        }
    }
}
