package com.example.englishradio

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private enum class TvPage { NOW_PLAYING, BROWSE, FAVORITES }

private val MatteInk = Color(0xFF11141B)
private val MatteCard = Color(0xFF20242D)
private val MatteLine = Color(0xFF484E59)
private val MatteText = Color(0xFFF4F3F2)
private val MatteMuted = Color(0xFFB6BAC2)
private val MatteTeal = Color(0xFF9BCFC6)
private val MattePink = Color(0xFFE7B9C9)
private val MatteMint = Color(0xFFB8DED4)

class TvActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val preferences by lazy {
        getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        applyKeepScreenAwake(preferences.getBoolean("tv_keep_screen_awake", true))
        val artwork = runCatching { assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
        PlaybackService.configureStationQueue(stations, artwork)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({ runCatching { future.get() }.onSuccess { controller = it } }, ContextCompat.getMainExecutor(this))
        }
        setContent {
            TvRadioCherry(
                player = controller,
                onKeepScreenAwake = ::applyKeepScreenAwake,
                onExit = ::exitApplication
            )
        }
    }

    private fun applyKeepScreenAwake(enabled: Boolean) {
        if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onStop() {
        if (!preferences.getBoolean("tv_background_playback", true)) {
            controller?.let { active ->
                active.pause()
                active.clearMediaItems()
            }
        }
        super.onStop()
    }

    private fun exitApplication() {
        runCatching {
            controller?.pause()
            controller?.clearMediaItems()
            stopService(Intent(this, PlaybackService::class.java))
        }
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        finishAndRemoveTask()
        Handler(Looper.getMainLooper()).postDelayed({ Process.killProcess(Process.myPid()) }, 180L)
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun TvRadioCherry(
    player: MediaController?,
    onKeepScreenAwake: (Boolean) -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }
    var audioPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioPermission = it }
    var waveform by remember { mutableStateOf(FloatArray(96) { 0.012f }) }
    var spectrum by remember { mutableStateOf(FloatArray(48) { 0.008f }) }
    var audioEnergy by remember { mutableFloatStateOf(0.012f) }
    var page by remember { mutableStateOf(TvPage.NOW_PLAYING) }
    var fullScreen by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf(player?.currentMediaItem?.mediaId) }
    var playing by remember { mutableStateOf(player?.isPlaying == true) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet()) }
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("All") }
    var settingsOpen by remember { mutableStateOf(false) }
    var sleepDialogOpen by remember { mutableStateOf(false) }
    var sleepUntil by remember { mutableStateOf<Long?>(null) }
    var sleepRemaining by remember { mutableIntStateOf(0) }
    var volume by remember { mutableFloatStateOf(prefs.getFloat("tv_volume", 0.72f).coerceIn(0f, 1f)) }
    var backgroundPlayback by remember { mutableStateOf(prefs.getBoolean("tv_background_playback", true)) }
    var hideVolume by remember { mutableStateOf(prefs.getBoolean("tv_hide_volume", false)) }
    var hideSkip by remember { mutableStateOf(prefs.getBoolean("tv_hide_previous_next", false)) }
    var keepScreenAwake by remember { mutableStateOf(prefs.getBoolean("tv_keep_screen_awake", true)) }
    var status by remember { mutableStateOf("CHOOSE A STATION TO BEGIN") }
    val scope = rememberCoroutineScope()
    val selected = stations.firstOrNull { it.id == selectedId }
    val visibleStations = remember(page, search, selectedGenre, favorites) {
        val base = if (page == TvPage.FAVORITES) stations.filter { it.id in favorites } else stations
        base.filter { station ->
            val matchesSearch = search.isBlank() ||
                station.name.contains(search, true) || station.genre.contains(search, true) ||
                station.broadcaster.contains(search, true) || station.category.contains(search, true)
            val text = "${station.category} ${station.genre} ${station.name}".lowercase()
            val matchesGenre = selectedGenre == "All" || when (selectedGenre) {
                "Ambient" -> text.contains("ambient") || text.contains("chill") || text.contains("downtempo")
                "Electronic" -> text.contains("electronic") || text.contains("dance") || text.contains("house")
                "Indie" -> text.contains("indie") || text.contains("alternative") || text.contains("rock")
                "80s" -> text.contains("80") || text.contains("new wave") || text.contains("throwback")
                "Classical" -> text.contains("classical") || text.contains("instrumental") || text.contains("orchestra")
                "Sleep" -> text.contains("sleep") || text.contains("nature") || text.contains("soundscape")
                "Nature" -> text.contains("nature") || text.contains("field recording") || text.contains("bird")
                "Jazz" -> text.contains("jazz")
                else -> true
            }
            matchesSearch && matchesGenre
        }
    }

    LaunchedEffect(Unit) {
        if (!audioPermission) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(keepScreenAwake) {
        prefs.edit().putBoolean("tv_keep_screen_awake", keepScreenAwake).apply()
        onKeepScreenAwake(keepScreenAwake)
    }

    LaunchedEffect(backgroundPlayback, hideVolume, hideSkip) {
        prefs.edit()
            .putBoolean("tv_background_playback", backgroundPlayback)
            .putBoolean("tv_hide_volume", hideVolume)
            .putBoolean("tv_hide_previous_next", hideSkip)
            .apply()
    }

    LaunchedEffect(player, playing, audioPermission) {
        waveform = FloatArray(96) { 0.012f }
        spectrum = FloatArray(48) { 0.008f }
        audioEnergy = 0.012f
        if (!audioPermission || player == null || !playing) return@LaunchedEffect
        var sessionId = PlaybackService.currentAudioSessionId
        repeat(20) {
            if (sessionId <= 0) {
                delay(120)
                sessionId = PlaybackService.currentAudioSessionId
            }
        }
        if (sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    if (bytes.isEmpty()) return
                    val samples = FloatArray(96) { i ->
                        val index = (i * (bytes.size - 1) / 95).coerceIn(0, bytes.lastIndex)
                        abs((bytes[index].toInt() and 0xFF) - 128) / 128f
                    }
                    val level = (samples.average().toFloat() * 2.15f).coerceIn(0.012f, 1f)
                    Handler(Looper.getMainLooper()).post {
                        waveform = samples
                        audioEnergy = level
                    }
                }

                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) {
                    if (fft.size < 4) return
                    val bands = FloatArray(48) { index ->
                        val bin = (index + 1).coerceAtMost((fft.size / 2) - 1)
                        val real = fft[2 * bin].toInt().toFloat()
                        val imaginary = fft[2 * bin + 1].toInt().toFloat()
                        (sqrt(real * real + imaginary * imaginary) / 92f).coerceIn(0f, 1f)
                    }
                    Handler(Looper.getMainLooper()).post { spectrum = bands }
                }
            }, Visualizer.getMaxCaptureRate() / 2, true, true)
            visualizer.enabled = true
            kotlinx.coroutines.awaitCancellation()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
        } finally {
            runCatching { visualizer.enabled = false; visualizer.release() }
        }
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isNowPlaying: Boolean) {
                playing = isNowPlaying
                status = if (isNowPlaying) "ON AIR  ·  LIVE STREAM" else "PAUSED"
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
            }
            override fun onPlaybackStateChanged(state: Int) {
                status = when (state) {
                    Player.STATE_BUFFERING -> "CONNECTING TO STATION…"
                    Player.STATE_READY -> if (player.isPlaying) "ON AIR  ·  LIVE STREAM" else "READY TO PLAY"
                    Player.STATE_IDLE -> "CHOOSE A STATION TO BEGIN"
                    Player.STATE_ENDED -> "STREAM ENDED"
                    else -> status
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status = "STREAM UNAVAILABLE"
            }
        }
        player.addListener(listener)
        selectedId = player.currentMediaItem?.mediaId
        playing = player.isPlaying
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(favorites) {
        prefs.edit().putStringSet("favorite_station_ids", favorites).apply()
    }

    LaunchedEffect(player, volume) {
        player?.volume = volume
        prefs.edit().putFloat("tv_volume", volume).apply()
    }

    LaunchedEffect(sleepUntil) {
        val deadline = sleepUntil ?: return@LaunchedEffect
        while (true) {
            val remaining = ((deadline - System.currentTimeMillis()) / 1000L).toInt()
            if (remaining <= 0) {
                player?.pause()
                player?.clearMediaItems()
                sleepUntil = null
                sleepRemaining = 0
                status = "SLEEP TIMER ENDED · PLAYBACK STOPPED"
                break
            }
            sleepRemaining = remaining
            delay(1000)
        }
    }

    fun toggleFavorite(station: Station) {
        favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
    }

    suspend fun playStation(station: Station) {
        val active = player ?: return
        status = "CONNECTING TO STATION…"
        val resolved = withContext(Dispatchers.IO) {
            runCatching { PlaylistResolver.resolve(station.stream) }.getOrDefault(station.stream)
        }
        selectedId = station.id
        active.setMediaItem(PlaybackService.mediaItem(station.copy(stream = resolved), orbArtwork))
        active.prepare()
        active.play()
        page = TvPage.NOW_PLAYING
        fullScreen = false
    }

    fun stepStation(direction: Int) {
        val index = stations.indexOfFirst { it.id == selectedId }
        val next = if (index < 0) 0 else (index + direction + stations.size) % stations.size
        stations.getOrNull(next)?.let { station -> scope.launch { playStation(station) } }
    }

    fun togglePlayback() {
        val active = player ?: return
        if (active.isPlaying) active.pause()
        else if (active.mediaItemCount > 0) active.play()
        else selected?.let { scope.launch { playStation(it) } } ?: stepStation(0)
    }

    BackHandler(enabled = fullScreen || settingsOpen || sleepDialogOpen || page != TvPage.NOW_PLAYING) {
        when {
            sleepDialogOpen -> sleepDialogOpen = false
            settingsOpen -> settingsOpen = false
            fullScreen -> fullScreen = false
            page != TvPage.NOW_PLAYING -> page = TvPage.NOW_PLAYING
        }
    }

    MaterialTheme {
        Box(Modifier.fillMaxSize().background(MatteInk)) {
            if (fullScreen) {
                TvFullScreenVisualizer(
                    selected = selected, playing = playing, status = status,
                    waveform = waveform, spectrum = spectrum, audioEnergy = audioEnergy,
                    hideSkip = hideSkip, hideVolume = hideVolume, volume = volume,
                    favorite = selected?.id?.let { it in favorites } == true,
                    sleepRemaining = sleepRemaining,
                    onBack = { fullScreen = false }, onPlayPause = ::togglePlayback,
                    onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                    onFavorite = { selected?.let(::toggleFavorite) },
                    onVolume = { volume = it }, onSleep = { sleepDialogOpen = true },
                    onSettings = { settingsOpen = true }, onExit = onExit
                )
            } else {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 27.dp),
                    horizontalArrangement = Arrangement.spacedBy(34.dp)
                ) {
                    TvSidebar(
                        page = page,
                        onPage = { page = it; if (it != TvPage.BROWSE) { search = ""; selectedGenre = "All" } },
                        onSettings = { settingsOpen = true }, onExit = onExit
                    )
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        when (page) {
                            TvPage.NOW_PLAYING -> TvNowPlaying(
                                selected = selected, playing = playing, status = status,
                                waveform = waveform, spectrum = spectrum, audioEnergy = audioEnergy,
                                hideSkip = hideSkip, hideVolume = hideVolume,
                                volume = volume, favorite = selected?.id?.let { it in favorites } == true,
                                sleepRemaining = sleepRemaining,
                                onPlayPause = ::togglePlayback,
                                onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                                onFavorite = { selected?.let(::toggleFavorite) },
                                onVolume = { volume = it },
                                onBrowse = { page = TvPage.BROWSE },
                                onFullscreen = { fullScreen = true },
                                onSleep = { sleepDialogOpen = true },
                                onSettings = { settingsOpen = true }
                            )
                            TvPage.BROWSE, TvPage.FAVORITES -> TvBrowsePage(
                                isFavorites = page == TvPage.FAVORITES,
                                stations = visibleStations, totalCount = if (page == TvPage.BROWSE) stations.size else visibleStations.size,
                                selectedId = selectedId, favorites = favorites,
                                search = search, onSearch = { search = it },
                                selectedGenre = selectedGenre, onGenre = { selectedGenre = it },
                                onSelect = { station -> scope.launch { playStation(station) } },
                                onFavorite = ::toggleFavorite
                            )
                        }
                    }
                }
            }

            if (settingsOpen) {
                TvSettingsDialog(
                    backgroundPlayback = backgroundPlayback, onBackgroundPlayback = { backgroundPlayback = it },
                    hideVolume = hideVolume, onHideVolume = { hideVolume = it },
                    hideSkip = hideSkip, onHideSkip = { hideSkip = it },
                    keepScreenAwake = keepScreenAwake, onKeepScreenAwake = { keepScreenAwake = it },
                    onDismiss = { settingsOpen = false }
                )
            }

            if (sleepDialogOpen) {
                TvSleepDialog(
                    remaining = sleepRemaining,
                    onSet = { minutes -> sleepUntil = System.currentTimeMillis() + minutes * 60_000L; sleepDialogOpen = false },
                    onCancelTimer = { sleepUntil = null; sleepRemaining = 0; sleepDialogOpen = false },
                    onDismiss = { sleepDialogOpen = false }
                )
            }
        }
    }
}

@Composable
private fun TvSidebar(
    page: TvPage, onPage: (TvPage) -> Unit, onSettings: () -> Unit, onExit: () -> Unit
) {
    val initialFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { initialFocus.requestFocus() }
    Column(Modifier.width(205.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("radio", color = MatteText, fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 1.7.sp)
                Text("cherry", color = MattePink, fontSize = 27.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
            }
            Spacer(Modifier.height(10.dp))
            TvNavItem("NOW PLAYING", page == TvPage.NOW_PLAYING, { onPage(TvPage.NOW_PLAYING) }, Icons.Default.Radio, Modifier.focusRequester(initialFocus))
            TvNavItem("BROWSE", page == TvPage.BROWSE, { onPage(TvPage.BROWSE) }, Icons.Default.Explore)
            TvNavItem("FAVOURITES", page == TvPage.FAVORITES, { onPage(TvPage.FAVORITES) }, Icons.Default.Favorite)
        }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("INTERNET RADIO", color = Color(0xFF858B95), fontSize = 10.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 5.dp, bottom = 5.dp))
            TvUtilityButton("SETTINGS", onSettings, Icons.Default.Settings)
            TvUtilityButton("EXIT APP", onExit, Icons.Default.Close, accent = false)
        }
    }
}

@Composable
private fun TvNavItem(
    label: String, selected: Boolean, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    val selectedBrush = Brush.horizontalGradient(listOf(MatteTeal, MattePink))
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(brush = if (selected) selectedBrush else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else if (selected) Color.Transparent else MatteLine, RoundedCornerShape(14.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (selected) MatteInk else MatteMuted, modifier = Modifier.size(19.dp))
        Text(label, color = if (selected) MatteInk else MatteText, fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvUtilityButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Boolean = true
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (focused) Color(0xFF2A3038) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (accent) MatteTeal else MatteMuted, modifier = Modifier.size(17.dp))
        Text(label, color = MatteMuted, fontSize = 10.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvNowPlaying(
    selected: Station?, playing: Boolean, status: String,
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float,
    hideSkip: Boolean, hideVolume: Boolean, volume: Float, favorite: Boolean, sleepRemaining: Int,
    onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit,
    onBrowse: () -> Unit, onFullscreen: () -> Unit, onSleep: () -> Unit, onSettings: () -> Unit
) {
    val phase by rememberVisualizerPhase()
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("NOW PLAYING", color = MatteTeal, fontSize = 10.sp, letterSpacing = 2.5.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TvSmallTextButton("FULL SCREEN VISUALIZER", onFullscreen, Icons.Default.Fullscreen)
                TvSmallTextButton("SETTINGS", onSettings, Icons.Default.Settings)
            }
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(278.dp).clip(RoundedCornerShape(20.dp))) {
            ReactiveVisualScene(waveform, spectrum, audioEnergy, phase, Modifier.fillMaxSize(), fullScreen = false)
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("radio cherry", color = Color(0xFFF7F4F2), fontSize = 22.sp, fontWeight = FontWeight.Light, letterSpacing = 2.4.sp)
                Spacer(Modifier.height(5.dp))
                Text("LIVE", color = Color(0xFF39444A), fontSize = 10.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(17.dp))
        Text(selected?.name ?: "Choose a station to begin",
            color = MatteText, fontSize = 29.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(5.dp))
        Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Discover more than 200 stations from around the world",
            color = MatteMuted, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Text(status, color = MatteTeal, fontSize = 10.sp, letterSpacing = 1.9.sp, fontWeight = FontWeight.SemiBold)
        if (sleepRemaining > 0) {
            Text("SLEEP TIMER  ·  ${formatTime(sleepRemaining)}", color = MattePink, fontSize = 10.sp,
                letterSpacing = 1.3.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(17.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            if (!hideSkip) TvRoundControl(Icons.Default.SkipPrevious, "PREVIOUS", onPrevious)
            TvRoundControl(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "PAUSE" else "PLAY", onPlayPause, primary = true)
            if (!hideSkip) TvRoundControl(Icons.Default.SkipNext, "NEXT", onNext)
            TvRoundControl(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "FAVOURITE", onFavorite)
            Spacer(Modifier.width(4.dp))
            TvPillButton(if (sleepRemaining > 0) "SLEEP ${formatTime(sleepRemaining)}" else "SLEEP TIMER", onSleep, Icons.Default.Timer)
            TvPillButton("BROWSE", onBrowse, Icons.Default.Explore)
            Spacer(Modifier.weight(1f))
            if (!hideVolume) TvVolumeControl(volume = volume, onValue = onVolume, compact = true)
        }
    }
}

@Composable
private fun TvBrowsePage(
    isFavorites: Boolean, stations: List<Station>, totalCount: Int,
    selectedId: String?, favorites: Set<String>, search: String, onSearch: (String) -> Unit,
    selectedGenre: String, onGenre: (String) -> Unit,
    onSelect: (Station) -> Unit, onFavorite: (Station) -> Unit
) {
    val genres = listOf("All", "Ambient", "Electronic", "Indie", "80s", "Classical", "Sleep", "Nature", "Jazz")
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
            Column(horizontalAlignment = Alignment.End) {
                Text(if (isFavorites) "Your favourites" else "Explore stations", color = MatteText, fontSize = 30.sp, fontWeight = FontWeight.Light)
                Text("$totalCount STATIONS", color = MatteMuted, fontSize = 10.sp, letterSpacing = 2.sp,
                    modifier = Modifier.padding(top = 5.dp))
            }
        }
        Spacer(Modifier.height(17.dp))
        if (!isFavorites) {
            OutlinedTextField(
                value = search, onValueChange = onSearch,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                singleLine = true, shape = RoundedCornerShape(15.dp),
                placeholder = { Text("Search stations...", color = MatteMuted, fontSize = 14.sp) },
                leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Search, null, tint = MatteTeal) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MatteText, unfocusedTextColor = MatteText,
                    focusedBorderColor = MatteTeal, unfocusedBorderColor = MatteLine,
                    cursorColor = MatteTeal, focusedContainerColor = Color(0xFF1B2027),
                    unfocusedContainerColor = Color(0xFF1B2027)
                )
            )
            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                genres.forEach { genre -> TvGenreChip(genre, selectedGenre == genre, { onGenre(genre) }) }
            }
            Spacer(Modifier.height(13.dp))
        }
        if (stations.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (isFavorites) "No favourites yet. Save stations with the heart." else "No stations match your search.",
                    color = MatteMuted, fontSize = 16.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(stations, key = { it.id }) { station ->
                    TvStationRow(
                        station = station, active = station.id == selectedId,
                        favorite = station.id in favorites,
                        onClick = { onSelect(station) }, onFavorite = { onFavorite(station) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TvGenreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.clip(RoundedCornerShape(30.dp))
            .background(if (selected) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(Color(0xFF282D35), Color(0xFF282D35))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color.Transparent, RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) MatteInk else MatteText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvStationRow(
    station: Station, active: Boolean, favorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(15.dp))
            .background(if (active) Brush.horizontalGradient(listOf(Color(0xFF293A3B), Color(0xFF38313A))) else Brush.horizontalGradient(listOf(MatteCard, MatteCard)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(15.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(station.name, color = MatteText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${station.genre}  ·  ${station.broadcaster}", color = MatteMuted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        }
        if (active) Text("ON AIR", color = MatteTeal, fontSize = 9.sp, letterSpacing = 1.4.sp,
            modifier = Modifier.padding(end = 18.dp))
        TvFavoriteButton(
            selected = favorite, onClick = onFavorite
        )
    }
}

@Composable
private fun TvFavoriteButton(selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(if (focused) Color(0xFF3B3940) else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(if (selected) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favourite", tint = if (selected) MattePink else MatteMuted, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun TvFullScreenVisualizer(
    selected: Station?, playing: Boolean, status: String,
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float,
    hideSkip: Boolean, hideVolume: Boolean, volume: Float, favorite: Boolean, sleepRemaining: Int,
    onBack: () -> Unit, onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit, onSleep: () -> Unit,
    onSettings: () -> Unit, onExit: () -> Unit
) {
    val phase by rememberVisualizerPhase()
    val backFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { backFocus.requestFocus() }
    Box(Modifier.fillMaxSize()) {
        ReactiveVisualScene(waveform, spectrum, audioEnergy, phase, Modifier.fillMaxSize(), fullScreen = true)
        TvSmallTextButton("BACK TO NORMAL MODE", onBack, Icons.Default.Close,
            Modifier.align(Alignment.TopEnd).focusRequester(backFocus).padding(end = 40.dp, top = 24.dp))
        TvSmallTextButton("SETTINGS", onSettings, Icons.Default.Settings,
            Modifier.align(Alignment.TopStart).padding(start = 40.dp, top = 24.dp))
        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 142.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("radio cherry LIVE", color = MatteText, fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 0.8.sp)
            Spacer(Modifier.height(8.dp))
            Text(selected?.name ?: "Choose a station", color = MatteText, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Internet radio", color = Color(0xFF5D6A70), fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp))
            Text(status, color = Color(0xFF536A6A), fontSize = 9.sp, letterSpacing = 1.7.sp,
                modifier = Modifier.padding(top = 7.dp))
            if (sleepRemaining > 0) Text("SLEEP TIMER  ·  ${formatTime(sleepRemaining)}", color = Color(0xFF6B555F), fontSize = 9.sp,
                letterSpacing = 1.4.sp, modifier = Modifier.padding(top = 5.dp))
        }
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(17.dp)
        ) {
            if (!hideSkip) TvControlText("PREV", Icons.Default.SkipPrevious, onPrevious)
            TvControlText(if (playing) "PAUSE" else "PLAY", if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, onPlayPause, primary = true)
            if (!hideSkip) TvControlText("NEXT", Icons.Default.SkipNext, onNext)
            TvControlText("FAV", if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, onFavorite)
            TvControlText("SLEEP", Icons.Default.Timer, onSleep)
            if (!hideVolume) TvVolumeControl(volume = volume, onValue = onVolume, compact = false)
            TvControlText("EXIT", Icons.Default.Close, onExit)
        }
    }
}

@Composable
private fun rememberVisualizerPhase(): State<Float> {
    val transition = rememberInfiniteTransition(label = "matte-audio-visualizer")
    return transition.animateFloat(
        initialValue = 0f, targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(42000, easing = LinearEasing)),
        label = "visualizer-phase"
    )
}

@Composable
private fun ReactiveVisualScene(
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float,
    phase: Float, modifier: Modifier, fullScreen: Boolean
) {
    val level = audioEnergy.coerceIn(0.01f, 1f)
    val blend = (0.16f + level * 0.25f).coerceIn(0.16f, 0.40f)
    val start = androidx.compose.ui.graphics.lerp(Color(0xFF85BDB8), Color(0xFF9CC9C1), (0.5f + sin(phase) * 0.5f) * blend)
    val end = androidx.compose.ui.graphics.lerp(Color(0xFFD8AEBB), Color(0xFFF0C9D2), (0.5f + cos(phase * 0.73f) * 0.5f) * blend)
    Box(modifier.background(Brush.linearGradient(listOf(start, Color(0xFFB9C4C1), end), start = Offset(0f, 0f), end = Offset(1600f, 900f)))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val minDim = size.minDimension
            val center = Offset(w * 0.5f, if (fullScreen) h * 0.43f else h * 0.47f)
            val localLevel = level
            val bass = spectrum.take(7).average().toFloat().coerceIn(0f, 1f)
            val mids = spectrum.drop(7).take(18).average().toFloat().coerceIn(0f, 1f)
            val highs = spectrum.drop(25).average().toFloat().coerceIn(0f, 1f)

            // The soft nebula fields move and breathe with the captured audio bands.
            val nebulaShift = sin(phase * 0.55f) * minDim * (0.025f + bass * 0.055f)
            drawCircle(Color(0xFF78BDB4).copy(alpha = 0.08f + bass * 0.12f), minDim * (0.36f + bass * 0.08f),
                Offset(w * 0.12f + nebulaShift, h * 0.60f + mids * 12f))
            drawCircle(Color(0xFFE8AFC2).copy(alpha = 0.08f + highs * 0.12f), minDim * (0.38f + highs * 0.07f),
                Offset(w * 0.88f - nebulaShift, h * 0.37f - bass * 14f))
            drawCircle(Color(0xFFB7B6C7).copy(alpha = 0.05f + localLevel * 0.08f), minDim * (0.31f + mids * 0.05f),
                Offset(w * 0.51f, h * 0.86f + sin(phase) * 11f))

            // Flowing ribbon strands: every curve is deformed by the same live waveform and FFT bands.
            val lineCount = if (fullScreen) 15 else 10
            for (line in 0 until lineCount) {
                val path = Path()
                val baseY = h * (if (fullScreen) 0.48f else 0.56f) + (line - lineCount / 2) * (if (fullScreen) 5.8f else 4.2f)
                for (step in 0..100) {
                    val x = w * step / 100f
                    val index = (step * (waveform.size - 1) / 100).coerceIn(0, waveform.lastIndex)
                    val wave = waveform[index]
                    val band = spectrum[index % spectrum.size]
                    val envelope = sin((step / 100f) * PI).toFloat()
                    val bend = sin((step / 100f * PI * 2.3f) + phase + line * 0.24f).toFloat()
                    val y = baseY + bend * (h * 0.075f) + (wave - 0.03f) * h * (0.12f + localLevel * 0.10f) * envelope +
                        band * h * 0.025f * sin(phase + line).toFloat()
                    if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val tint = if (line % 2 == 0) Color(0xFF5C9692) else Color(0xFFBD899B)
                drawPath(path, tint.copy(alpha = 0.17f + localLevel * 0.24f), style = Stroke(width = if (fullScreen) 1.2f else 1.0f))
            }

            // Thin orbital rings around the central orb; their radius changes with the audio envelope.
            val orbRadius = minDim * (if (fullScreen) 0.105f else 0.145f) + bass * minDim * 0.018f
            val ringCount = if (fullScreen) 4 else 7
            for (ring in 0 until ringCount) {
                val sample = waveform[(ring * 13) % waveform.size]
                val radius = orbRadius * (1.30f + ring * 0.21f) + sample * minDim * 0.018f + mids * ring * 1.1f
                drawCircle(Color(0xFF6C9691).copy(alpha = 0.31f + sample * 0.18f), radius, center,
                    style = Stroke(width = if (fullScreen) 1.1f else 1.2f))
            }

            // Matte orb responds to bass and midrange rather than behaving as a static illustration.
            drawCircle(
                Brush.linearGradient(listOf(Color(0xFFB2DAD0).copy(alpha = 0.96f), Color(0xFFE7C2CC).copy(alpha = 0.94f)),
                    start = Offset(center.x - orbRadius, center.y - orbRadius), end = Offset(center.x + orbRadius, center.y + orbRadius)),
                radius = orbRadius * (1f + bass * 0.055f), center = center
            )
            drawCircle(Color(0xFF668F89).copy(alpha = 0.32f + localLevel * 0.12f), orbRadius * (1.05f + mids * 0.025f), center,
                style = Stroke(width = 1.1f))

            // Orbiting dots have audio-driven radius, opacity and orbital wobble.
            val particleCount = if (fullScreen) 34 else 22
            for (i in 0 until particleCount) {
                val sample = waveform[(i * 7) % waveform.size]
                val band = spectrum[(i * 3) % spectrum.size]
                val orbit = orbRadius * (1.62f + (i % 5) * 0.43f) + sample * minDim * 0.035f
                val angle = phase * (0.16f + (i % 4) * 0.035f) + i * 2.399f + band * 0.38f
                val x = center.x + cos(angle) * orbit
                val y = center.y + sin(angle * 1.07f) * orbit * 0.72f
                val r = 1.5f + sample * 4.2f + band * 2.2f
                drawCircle(if (i % 2 == 0) MatteTeal.copy(alpha = 0.35f + sample * 0.42f) else MattePink.copy(alpha = 0.35f + band * 0.42f), r, Offset(x, y))
            }

            // A soft spectrum arc anchors the composition; bar heights follow the FFT magnitudes.
            val bars = 64
            val arcY = if (fullScreen) h * 0.78f else h * 0.86f
            val arcWidth = w * (if (fullScreen) 0.30f else 0.25f)
            for (i in 0 until bars) {
                val normalized = i / (bars - 1f)
                val x = center.x - arcWidth + normalized * arcWidth * 2f
                val envelope = sin(normalized * PI).toFloat()
                val band = spectrum[(i * spectrum.size / bars).coerceIn(0, spectrum.lastIndex)]
                val wave = waveform[(i * waveform.size / bars).coerceIn(0, waveform.lastIndex)]
                val barHeight = 3f + envelope * (4f + band * 28f + wave * 14f) * (0.35f + localLevel)
                drawLine(if (i % 2 == 0) Color(0xFF6B9E97).copy(alpha = 0.30f + band * 0.38f) else Color(0xFFC08F9E).copy(alpha = 0.30f + wave * 0.38f),
                    Offset(x, arcY), Offset(x, arcY - barHeight), strokeWidth = if (fullScreen) 1.7f else 1.5f)
            }
        }
    }
}

@Composable
private fun TvRoundControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.size(if (primary) 58.dp else 48.dp).clip(CircleShape)
                .background(if (primary) Brush.linearGradient(listOf(MatteTeal, MattePink)) else Brush.linearGradient(listOf(Color(0xFF272C34), Color(0xFF272C34))))
                .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, CircleShape)
                .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Icon(icon, null, tint = if (primary) MatteInk else MatteText,
                modifier = Modifier.size(if (primary) 26.dp else 21.dp))
        }
        Text(label, color = MatteMuted, fontSize = 8.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvControlText(
    label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (primary) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(Color(0x22494F57), Color(0x22494F57))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0x556B7479), RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 15.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (primary) MatteInk else MatteText, modifier = Modifier.size(17.dp))
        Text(label, color = if (primary) MatteInk else MatteText, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvPillButton(label: String, onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF272C34))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 11.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = MatteTeal, modifier = Modifier.size(16.dp))
        Text(label, color = MatteText, fontSize = 9.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvSmallTextButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier.clip(RoundedCornerShape(30.dp))
            .background(if (focused) Color(0x334D5958) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0x557A8584), RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) androidx.compose.material3.Icon(icon, null, tint = MatteText, modifier = Modifier.size(14.dp))
        Text(label, color = MatteText, fontSize = 8.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvVolumeControl(volume: Float, onValue: (Float) -> Unit, compact: Boolean) {
    var focused by remember { mutableStateOf(false) }
    Column(Modifier.width(if (compact) 178.dp else 245.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            androidx.compose.material3.Icon(Icons.Default.VolumeUp, null, tint = MatteMuted, modifier = Modifier.size(17.dp))
            Slider(
                value = volume, onValueChange = onValue,
                colors = SliderDefaults.colors(
                    thumbColor = MatteTeal, activeTrackColor = MatteTeal,
                    inactiveTrackColor = Color(0xFF626B70)
                ),
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused }
                    .onPreviewKeyEvent { event ->
                        if (event.type == KeyEventType.KeyDown) {
                            when (event.key) {
                                Key.DirectionLeft -> { onValue((volume - 0.04f).coerceAtLeast(0f)); true }
                                Key.DirectionRight -> { onValue((volume + 0.04f).coerceAtMost(1f)); true }
                                else -> false
                            }
                        } else false
                    }.focusable(),
            )
            Text("${(volume * 100).toInt()}%", color = MatteMuted, fontSize = 10.sp)
        }
        if (focused) Text("VOLUME", color = MatteTeal, fontSize = 8.sp, letterSpacing = 1.1.sp)
    }
}

@Composable
private fun TvSettingsDialog(
    backgroundPlayback: Boolean, onBackgroundPlayback: (Boolean) -> Unit,
    hideVolume: Boolean, onHideVolume: (Boolean) -> Unit,
    hideSkip: Boolean, onHideSkip: (Boolean) -> Unit,
    keepScreenAwake: Boolean, onKeepScreenAwake: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF20252C),
        title = { Text("Settings", color = MatteText, fontSize = 23.sp, fontWeight = FontWeight.Light) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                TvSettingRow("Allow audio playback in background", "Continue playing when radio cherry is not on screen", backgroundPlayback, onBackgroundPlayback)
                TvSettingRow("Hide volume control", "Hide the volume slider on both visualizer screens", hideVolume, onHideVolume)
                TvSettingRow("Hide previous / next", "Hide station skip buttons on both visualizer screens", hideSkip, onHideSkip)
                TvSettingRow("Keep screen awake", "Prevent the TV screensaver from interrupting listening", keepScreenAwake, onKeepScreenAwake)
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("DONE", color = MatteTeal, letterSpacing = 1.sp) } }
    )
}

@Composable
private fun TvSettingRow(title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MatteText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(description, color = MatteMuted, fontSize = 10.sp, lineHeight = 14.sp,
                modifier = Modifier.padding(top = 3.dp))
        }
        Switch(
            checked = checked, onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MatteInk, checkedTrackColor = MatteTeal,
                uncheckedThumbColor = MatteMuted, uncheckedTrackColor = MatteLine
            )
        )
    }
}

@Composable
private fun TvSleepDialog(
    remaining: Int, onSet: (Int) -> Unit, onCancelTimer: () -> Unit, onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF20252C),
        title = { Text("Sleep timer", color = MatteText, fontSize = 22.sp, fontWeight = FontWeight.Light) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (remaining > 0) "Current timer: ${formatTime(remaining)}" else "Stop playback automatically after:",
                    color = MatteMuted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(15, 30, 45).forEach { minutes ->
                        TextButton(onClick = { onSet(minutes) }) { Text("${minutes}m", color = MatteTeal) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(60, 90).forEach { minutes ->
                        TextButton(onClick = { onSet(minutes) }) { Text("${minutes}m", color = MatteTeal) }
                    }
                    if (remaining > 0) TextButton(onClick = onCancelTimer) { Text("CANCEL", color = MattePink) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("CLOSE", color = MatteMuted) } }
    )
}

private fun formatTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    return "%02d:%02d".format(safe / 60, safe % 60)
}
