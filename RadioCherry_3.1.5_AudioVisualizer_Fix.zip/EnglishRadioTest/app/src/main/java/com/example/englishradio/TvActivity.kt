package com.example.englishradio

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import java.util.concurrent.atomic.AtomicLong

private enum class TvPage { NOW_PLAYING, BROWSE, FAVORITES }

private val MatteInk = Color(0xFF11141B)
private val MatteCard = Color(0xFF20242D)
private val MatteLine = Color(0xFF484E59)
private val MatteText = Color(0xFFF4F3F2)
private val MatteMuted = Color(0xFFB6BAC2)
private val MatteTeal = Color(0xFF9BCFC6)
private val MattePink = Color(0xFFE7B9C9)
private val MatteMint = Color(0xFFB8DED4)
private val LocalTvAmoledTheme = compositionLocalOf { false }
private const val VISUALIZER_STARFIELD = "STARFIELD"

private data class StarfieldStar(
    val x: Float,
    val y: Float,
    val radius: Float,
    val color: Color,
    val twinklePhase: Float
)

private data class StarfieldBokeh(
    val x: Float,
    val y: Float,
    val radius: Float,
    val color: Color,
    val phase: Float
)

class TvActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val preferences by lazy {
        getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        applyKeepScreenAwake(preferences.getBoolean("tv_keep_screen_awake", true))
        val artwork = runCatching { assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
        PlaybackService.configureStationQueue(stations, artwork)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({ runCatching { future.get() }.onSuccess { controller = it } }, ContextCompat.getMainExecutor(this))
        }
        setContent {
            TvRadioCherry(
                player = controller,
                onKeepScreenAwake = ::applyKeepScreenAwake,
                onAppBrightness = ::applyAppBrightness,
                onTurnOffTv = ::requestTvPowerOff,
                onExit = ::exitApplication
            )
        }
    }

    private fun applyKeepScreenAwake(enabled: Boolean) {
        if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun applyAppBrightness(value: Float) {
        val attributes = window.attributes
        attributes.screenBrightness = value.coerceIn(0.05f, 1f)
        window.attributes = attributes
    }

    private fun requestTvPowerOff() {
        // Android TV normally reserves hardware power-off for system UI / the remote.
        // Request the system shutdown screen where the firmware exposes it.
        val intent = Intent("android.intent.action.ACTION_REQUEST_SHUTDOWN")
            .putExtra("android.intent.extra.KEY_CONFIRM", false)
        try {
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(
                this,
                "This TV does not allow apps to power it off. Use the TV remote.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onStop() {
        if (!preferences.getBoolean("tv_background_playback", true)) {
            controller?.let { active ->
                active.pause()
                active.clearMediaItems()
            }
        }
        super.onStop()
    }

    private fun exitApplication() {
        runCatching {
            controller?.pause()
            controller?.clearMediaItems()
            stopService(Intent(this, PlaybackService::class.java))
        }
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        finishAndRemoveTask()
        Handler(Looper.getMainLooper()).postDelayed({ Process.killProcess(Process.myPid()) }, 180L)
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun TvRadioCherry(
    player: MediaController?,
    onKeepScreenAwake: (Boolean) -> Unit,
    onAppBrightness: (Float) -> Unit,
    onTurnOffTv: () -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }
    var audioPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioPermission = it }
    var waveform by remember { mutableStateOf(FloatArray(64) { 0.012f }) }
    var spectrum by remember { mutableStateOf(FloatArray(32) { 0.008f }) }
    var audioEnergy by remember { mutableFloatStateOf(0.012f) }
    var page by remember { mutableStateOf(TvPage.NOW_PLAYING) }
    var fullScreen by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf(player?.currentMediaItem?.mediaId) }
    var playing by remember { mutableStateOf(player?.isPlaying == true) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet()) }
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("All") }
    var settingsOpen by remember { mutableStateOf(false) }
    var sleepDialogOpen by remember { mutableStateOf(false) }
    var sleepUntil by remember { mutableStateOf<Long?>(null) }
    var sleepRemaining by remember { mutableIntStateOf(0) }
    var sleepAction by remember { mutableStateOf(prefs.getString("tv_sleep_action", "STOP_PLAYING") ?: "STOP_PLAYING") }
    var shuffleEnabled by remember { mutableStateOf(prefs.getBoolean("tv_shuffle_enabled", false)) }
    var appBrightness by remember { mutableFloatStateOf(prefs.getFloat("tv_app_brightness", 1f).coerceIn(0.05f, 1f)) }
    var volume by remember { mutableFloatStateOf(prefs.getFloat("tv_volume", 0.72f).coerceIn(0f, 1f)) }
    val failedStationIds = remember { mutableSetOf<String>() }
    var fallbackInProgress by remember { mutableStateOf(false) }
    var connectionAttempt by remember { mutableIntStateOf(0) }
    var backgroundPlayback by remember { mutableStateOf(prefs.getBoolean("tv_background_playback", true)) }
    var hideVolume by remember { mutableStateOf(prefs.getBoolean("tv_hide_volume", false)) }
    var hideSkip by remember { mutableStateOf(prefs.getBoolean("tv_hide_previous_next", false)) }
    var keepScreenAwake by remember { mutableStateOf(prefs.getBoolean("tv_keep_screen_awake", true)) }
    val storedAppTheme = remember(prefs) {
        prefs.getString(
            "tv_app_theme",
            if (prefs.getBoolean("tv_theme_amoled", false)) "AMOLED" else "DEFAULT"
        ) ?: "DEFAULT"
    }
    // Theme is intentionally limited to the two application-wide palettes.
    // Migrate the earlier experimental NEON app theme into the visualizer style.
    var appTheme by remember {
        mutableStateOf(if (storedAppTheme == "AMOLED") "AMOLED" else "DEFAULT")
    }
    var visualizerStyle by remember {
        mutableStateOf(
            prefs.getString("tv_visualizer_style", null) ?: when {
                storedAppTheme == "NEON" || prefs.getBoolean("tv_theme_neon", false) -> "NEON"
                prefs.contains("tv_visualizer_darker") && prefs.getBoolean("tv_visualizer_darker", false) -> "NEBULA"
                prefs.contains("tv_visualizer_darker") -> "AURORA"
                else -> "NEBULA"
            }
        )
    }
    val amoledTheme = appTheme == "AMOLED"
    var visualizerChromeVisible by remember { mutableStateOf(true) }
    var visualizerActivityRevision by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("CHOOSE A STATION TO BEGIN") }
    val scope = rememberCoroutineScope()
    val selected = stations.firstOrNull { it.id == selectedId }
    val visibleStations = remember(page, search, selectedGenre, favorites) {
        val base = if (page == TvPage.FAVORITES) stations.filter { it.id in favorites } else stations
        base.filter { station ->
            val matchesSearch = search.isBlank() ||
                station.name.contains(search, true) || station.genre.contains(search, true) ||
                station.broadcaster.contains(search, true) || station.category.contains(search, true)
            val text = "${station.category} ${station.genre} ${station.name}".lowercase()
            val matchesGenre = selectedGenre == "All" || when (selectedGenre) {
                "Ambient" -> text.contains("ambient") || text.contains("chill") || text.contains("downtempo")
                "Electronic" -> text.contains("electronic") || text.contains("dance") || text.contains("house")
                "Indie" -> text.contains("indie") || text.contains("alternative") || text.contains("rock")
                "80s" -> text.contains("80") || text.contains("new wave") || text.contains("throwback")
                "Classical" -> text.contains("classical") || text.contains("instrumental") || text.contains("orchestra")
                "Sleep" -> text.contains("sleep") || text.contains("nature") || text.contains("soundscape")
                "Nature" -> text.contains("nature") || text.contains("field recording") || text.contains("bird")
                "Jazz" -> text.contains("jazz")
                else -> true
            }
            matchesSearch && matchesGenre
        }
    }

    LaunchedEffect(Unit) {
        if (!audioPermission) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(keepScreenAwake) {
        prefs.edit().putBoolean("tv_keep_screen_awake", keepScreenAwake).apply()
        onKeepScreenAwake(keepScreenAwake)
    }

    LaunchedEffect(visualizerStyle) {
        prefs.edit()
            .putString("tv_visualizer_style", visualizerStyle)
            // Retain the legacy value for downgrade compatibility.
            .putBoolean("tv_visualizer_darker", visualizerStyle == "NEBULA")
            .apply()
    }

    LaunchedEffect(appTheme) {
        prefs.edit()
            .putString("tv_app_theme", appTheme)
            .putBoolean("tv_theme_amoled", appTheme == "AMOLED")
            .remove("tv_theme_neon")
            .apply()
    }

    LaunchedEffect(fullScreen, visualizerActivityRevision) {
        if (!fullScreen) {
            visualizerChromeVisible = true
        } else {
            delay(60_000L)
            visualizerChromeVisible = false
        }
    }

    LaunchedEffect(backgroundPlayback, hideVolume, hideSkip) {
        prefs.edit()
            .putBoolean("tv_background_playback", backgroundPlayback)
            .putBoolean("tv_hide_volume", hideVolume)
            .putBoolean("tv_hide_previous_next", hideSkip)
            .apply()
    }

    LaunchedEffect(player, playing, audioPermission) {
        waveform = FloatArray(64) { 0.012f }
        spectrum = FloatArray(32) { 0.008f }
        audioEnergy = 0.012f
        if (!audioPermission || player == null || !playing) return@LaunchedEffect
        var sessionId = PlaybackService.currentAudioSessionId
        repeat(20) {
            if (sessionId <= 0) {
                delay(120)
                sessionId = PlaybackService.currentAudioSessionId
            }
        }
        if (sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        val mainHandler = Handler(Looper.getMainLooper())
        val frameLock = Any()
        var latestWaveform = FloatArray(64) { 0.012f }
        var latestSpectrum = FloatArray(32) { 0.008f }
        var latestEnergy = 0.012f
        val lastUiPublish = AtomicLong(0L)

        // Collapse the two native capture callbacks into one latest-value UI update.
        // This prevents a backlog of old frames on the main thread, which is the
        // primary source of visualizer lag after long playback sessions.
        fun publishLatestAudioFrame() {
            val now = SystemClock.elapsedRealtime()
            val previous = lastUiPublish.get()
            if (now - previous < 32L || !lastUiPublish.compareAndSet(previous, now)) return

            val snapshot = synchronized(frameLock) {
                Triple(latestWaveform, latestSpectrum, latestEnergy)
            }
            mainHandler.post {
                waveform = snapshot.first
                spectrum = snapshot.second
                audioEnergy = snapshot.third
            }
        }

        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(512)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    if (bytes.isEmpty()) return
                    val samples = FloatArray(64) { i ->
                        val index = (i * (bytes.size - 1) / 63).coerceIn(0, bytes.lastIndex)
                        abs((bytes[index].toInt() and 0xFF) - 128) / 128f
                    }
                    val level = (samples.average().toFloat() * 2.15f).coerceIn(0.012f, 1f)
                    synchronized(frameLock) {
                        latestWaveform = samples
                        latestEnergy = level
                    }
                    publishLatestAudioFrame()
                }

                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) {
                    if (fft.size < 4) return
                    val bands = FloatArray(32) { index ->
                        val bin = (index + 1).coerceAtMost((fft.size / 2) - 1)
                        val real = fft[2 * bin].toInt().toFloat()
                        val imaginary = fft[2 * bin + 1].toInt().toFloat()
                        (sqrt(real * real + imaginary * imaginary) / 92f).coerceIn(0f, 1f)
                    }
                    synchronized(frameLock) { latestSpectrum = bands }
                    publishLatestAudioFrame()
                }
            }, Visualizer.getMaxCaptureRate() / 2, true, true)
            visualizer.enabled = true
            kotlinx.coroutines.awaitCancellation()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
        } finally {
            runCatching { visualizer.enabled = false; visualizer.release() }
        }
    }

    suspend fun playStation(
        station: Station,
        keepVisualizerOpen: Boolean = false,
        automaticFallback: Boolean = false
    ) {
        val active = player ?: return
        if (!automaticFallback) failedStationIds.clear()
        failedStationIds.add(station.id)
        fallbackInProgress = false
        connectionAttempt++
        selectedId = station.id
        status = "CONNECTING TO STATION…"
        val resolved = withContext(Dispatchers.IO) {
            runCatching { PlaylistResolver.resolve(station.stream) }.getOrDefault(station.stream)
        }
        active.setMediaItem(PlaybackService.mediaItem(station.copy(stream = resolved), orbArtwork))
        active.prepare()
        active.play()
        if (!keepVisualizerOpen) {
            page = TvPage.NOW_PLAYING
            fullScreen = false
        }
    }

    fun stopPlayback() {
        val active = player ?: return
        active.pause()
        active.stop()
        playing = false
        status = "STOPPED"
    }

    fun startAutomaticFallback() {
        if (fallbackInProgress) return
        val failedId = selectedId ?: player?.currentMediaItem?.mediaId
        if (failedId != null) failedStationIds.add(failedId)

        val candidate = if (shuffleEnabled) {
            stations.filterNot { it.id in failedStationIds }.randomOrNull()
        } else {
            val currentIndex = stations.indexOfFirst { it.id == failedId }.let { if (it < 0) 0 else it }
            (1..stations.size)
                .asSequence()
                .map { offset -> stations[(currentIndex + offset) % stations.size] }
                .firstOrNull { it.id !in failedStationIds }
        }

        if (candidate == null) {
            status = "NO WORKING STATIONS FOUND"
            playing = false
            fallbackInProgress = false
            return
        }

        fallbackInProgress = true
        status = "STATION UNAVAILABLE · TRYING ${candidate.name.uppercase()}…"
        scope.launch {
            delay(180L)
            try {
                playStation(candidate, keepVisualizerOpen = fullScreen, automaticFallback = true)
            } finally {
                fallbackInProgress = false
            }
        }
    }

    fun stepStation(direction: Int) {
        val current = selected
        val next = if (shuffleEnabled) {
            stations.filter { current == null || it.id != current.id }.randomOrNull()
        } else {
            if (current == null) {
                stations.firstOrNull()
            } else {
                // Normal previous/next stays within the current station's primary genre.
                val activeGenre = current.genre.substringBefore("·").trim()
                val sameGenreStations = stations.filter { station ->
                    station.genre.substringBefore("·").trim().equals(activeGenre, ignoreCase = true)
                }
                val group = sameGenreStations.ifEmpty { listOf(current) }
                val index = group.indexOfFirst { it.id == selectedId }
                val nextIndex = if (index < 0) 0 else (index + direction + group.size) % group.size
                group.getOrNull(nextIndex)
            }
        } ?: return
        scope.launch { playStation(next, keepVisualizerOpen = fullScreen) }
    }

    fun togglePlayback() {
        val active = player ?: return
        if (active.isPlaying) {
            active.pause()
        } else if (active.mediaItemCount > 0) {
            if (active.playbackState == Player.STATE_IDLE || active.playbackState == Player.STATE_ENDED) {
                active.prepare()
            }
            active.play()
        } else {
            val start = selected ?: if (shuffleEnabled) stations.random() else stations.first()
            scope.launch { playStation(start, keepVisualizerOpen = fullScreen) }
        }
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isNowPlaying: Boolean) {
                playing = isNowPlaying
                status = if (isNowPlaying) "ON AIR  ·  LIVE STREAM" else if (status == "STOPPED") "STOPPED" else "PAUSED"
                if (isNowPlaying) fallbackInProgress = false
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
            }

            override fun onPlaybackStateChanged(state: Int) {
                status = when (state) {
                    Player.STATE_BUFFERING -> "CONNECTING TO STATION…"
                    Player.STATE_READY -> if (player.isPlaying) "ON AIR  ·  LIVE STREAM" else if (status == "STOPPED") "STOPPED" else "READY TO PLAY"
                    Player.STATE_IDLE -> if (player.mediaItemCount > 0) "STOPPED" else "CHOOSE A STATION TO BEGIN"
                    Player.STATE_ENDED -> "STREAM ENDED · FINDING ANOTHER STATION…"
                    else -> status
                }
                if (state == Player.STATE_ENDED) startAutomaticFallback()
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                val erroredId = player.currentMediaItem?.mediaId
                if (erroredId != null && selectedId != null && erroredId != selectedId) return
                status = "STREAM UNAVAILABLE · TRYING ANOTHER STATION…"
                startAutomaticFallback()
            }
        }
        player.addListener(listener)
        selectedId = player.currentMediaItem?.mediaId
        playing = player.isPlaying
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(connectionAttempt, player, playing, status) {
        val attempt = connectionAttempt
        if (selectedId == null || playing ||
            !(status.startsWith("CONNECTING") || status == "READY TO PLAY")
        ) return@LaunchedEffect

        delay(18_000L)
        if (attempt == connectionAttempt && !playing &&
            (status.startsWith("CONNECTING") || status == "READY TO PLAY")
        ) {
            status = "CONNECTION TIMEOUT · TRYING ANOTHER STATION…"
            startAutomaticFallback()
        }
    }

    LaunchedEffect(favorites) {
        prefs.edit().putStringSet("favorite_station_ids", favorites).apply()
    }

    LaunchedEffect(player, volume) {
        player?.volume = volume
        prefs.edit().putFloat("tv_volume", volume).apply()
    }

    LaunchedEffect(shuffleEnabled) {
        prefs.edit().putBoolean("tv_shuffle_enabled", shuffleEnabled).apply()
    }

    LaunchedEffect(sleepAction) {
        prefs.edit().putString("tv_sleep_action", sleepAction).apply()
    }

    LaunchedEffect(appBrightness) {
        prefs.edit().putFloat("tv_app_brightness", appBrightness).apply()
        onAppBrightness(appBrightness)
    }

    LaunchedEffect(sleepUntil, sleepAction) {
        val deadline = sleepUntil ?: return@LaunchedEffect
        while (true) {
            val remaining = ((deadline - System.currentTimeMillis()) / 1000L).toInt()
            if (remaining <= 0) {
                sleepUntil = null
                sleepRemaining = 0
                when (sleepAction) {
                    "EXIT_APP" -> {
                        player?.pause()
                        player?.clearMediaItems()
                        status = "SLEEP TIMER · EXITING APP"
                        onExit()
                    }
                    "TURN_OFF_TV" -> {
                        player?.pause()
                        player?.clearMediaItems()
                        status = "SLEEP TIMER · REQUESTING TV POWER OFF"
                        onTurnOffTv()
                    }
                    else -> {
                        stopPlayback()
                        status = "SLEEP TIMER · PLAYBACK STOPPED"
                    }
                }
                break
            }
            sleepRemaining = remaining
            delay(1000)
        }
    }

    fun toggleFavorite(station: Station) {
        favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
    }

    // Keep fullscreen controls visible after any remote-key or visualizer interaction.
    // Incrementing the revision restarts the inactivity timer in the effect above.
    fun registerVisualizerActivity() {
        visualizerChromeVisible = true
        visualizerActivityRevision++
    }

    BackHandler(enabled = fullScreen || settingsOpen || sleepDialogOpen || page != TvPage.NOW_PLAYING) {
        when {
            sleepDialogOpen -> sleepDialogOpen = false
            settingsOpen -> settingsOpen = false
            fullScreen -> fullScreen = false
            page != TvPage.NOW_PLAYING -> page = TvPage.NOW_PLAYING
        }
    }

    CompositionLocalProvider(LocalTvAmoledTheme provides amoledTheme) {
      MaterialTheme {
        Box(
            Modifier.fillMaxSize()
                .background(if (amoledTheme) Color.Black else MatteInk)
                .onPreviewKeyEvent { event ->
                    if (fullScreen && event.type == KeyEventType.KeyDown) registerVisualizerActivity()
                    false
                }
        ) {
            if (fullScreen) {
                TvFullScreenVisualizer(
                    selected = selected, playing = playing, status = status,
                    waveform = waveform, spectrum = spectrum, audioEnergy = audioEnergy,
                    visualizerStyle = visualizerStyle,
                    chromeVisible = visualizerChromeVisible,
                    onUserActivity = ::registerVisualizerActivity,
                    hideSkip = hideSkip, hideVolume = hideVolume, volume = volume,
                    favorite = selected?.id?.let { it in favorites } == true,
                    sleepRemaining = sleepRemaining,
                    appBrightness = appBrightness, onAppBrightness = { appBrightness = it },
                    onBack = { fullScreen = false }, onPlayPause = ::togglePlayback,
                    onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                    onFavorite = { selected?.let(::toggleFavorite) },
                    onVolume = { volume = it }, onSleep = { sleepDialogOpen = true },
                    onSettings = { settingsOpen = true }, onExit = onExit
                )
            } else {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 27.dp),
                    horizontalArrangement = Arrangement.spacedBy(34.dp)
                ) {
                    TvSidebar(
                        page = page,
                        onPage = { page = it; if (it != TvPage.BROWSE) { search = ""; selectedGenre = "All" } },
                        onSettings = { settingsOpen = true }, onExit = onExit
                    )
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        when (page) {
                            TvPage.NOW_PLAYING -> TvNowPlaying(
                                selected = selected, playing = playing, status = status,
                                waveform = waveform, spectrum = spectrum, audioEnergy = audioEnergy,
                                visualizerStyle = visualizerStyle,
                                volume = volume, favorite = selected?.id?.let { it in favorites } == true,
                                sleepRemaining = sleepRemaining,
                                onPlayPause = ::togglePlayback, onStopPlayback = ::stopPlayback,
                                onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                                onFavorite = { selected?.let(::toggleFavorite) },
                                onVolume = { volume = it },
                                onBrowse = { page = TvPage.BROWSE },
                                onFullscreen = { fullScreen = true },
                                onSleep = { sleepDialogOpen = true }
                            )
                            TvPage.BROWSE, TvPage.FAVORITES -> TvBrowsePage(
                                isFavorites = page == TvPage.FAVORITES,
                                stations = visibleStations, totalCount = if (page == TvPage.BROWSE) stations.size else visibleStations.size,
                                selectedId = selectedId, favorites = favorites,
                                search = search, onSearch = { search = it },
                                selectedGenre = selectedGenre, onGenre = { selectedGenre = it },
                                onSelect = { station -> scope.launch { playStation(station) } },
                                onFavorite = ::toggleFavorite
                            )
                        }
                    }
                }
            }

            if (settingsOpen) {
                TvSettingsDialog(
                    backgroundPlayback = backgroundPlayback, onBackgroundPlayback = { backgroundPlayback = it },
                    hideVolume = hideVolume, onHideVolume = { hideVolume = it },
                    hideSkip = hideSkip, onHideSkip = { hideSkip = it },
                    keepScreenAwake = keepScreenAwake, onKeepScreenAwake = { keepScreenAwake = it },
                    shuffleEnabled = shuffleEnabled, onShuffleEnabled = { shuffleEnabled = it },
                    visualizerStyle = visualizerStyle, onVisualizerStyle = { visualizerStyle = it },
                    appTheme = appTheme, onAppTheme = { appTheme = it },
                    onDismiss = { settingsOpen = false }
                )
            }

            if (sleepDialogOpen) {
                TvSleepDialog(
                    remaining = sleepRemaining,
                    selectedAction = sleepAction,
                    onActionChange = { sleepAction = it },
                    onSet = { minutes -> sleepUntil = System.currentTimeMillis() + minutes * 60_000L; sleepDialogOpen = false },
                    onCancelTimer = { sleepUntil = null; sleepRemaining = 0; sleepDialogOpen = false },
                    onDismiss = { sleepDialogOpen = false }
                )
            }
        }
      }
    }
}

@Composable
private fun TvSidebar(
    page: TvPage, onPage: (TvPage) -> Unit, onSettings: () -> Unit, onExit: () -> Unit
) {
    val initialFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { initialFocus.requestFocus() }
    Column(Modifier.width(205.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("radio", color = MatteText, fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 1.7.sp)
                Text("cherry", color = MattePink, fontSize = 27.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
            }
            Spacer(Modifier.height(10.dp))
            TvNavItem("NOW PLAYING", page == TvPage.NOW_PLAYING, { onPage(TvPage.NOW_PLAYING) }, Icons.Default.Radio, Modifier.focusRequester(initialFocus))
            TvNavItem("BROWSE", page == TvPage.BROWSE, { onPage(TvPage.BROWSE) }, Icons.Default.Explore)
            TvNavItem("FAVOURITES", page == TvPage.FAVORITES, { onPage(TvPage.FAVORITES) }, Icons.Default.Favorite)
        }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("INTERNET RADIO", color = Color(0xFF858B95), fontSize = 10.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 5.dp, bottom = 5.dp))
            TvUtilityButton("SETTINGS", onSettings, Icons.Default.Settings)
            TvUtilityButton("EXIT APP", onExit, Icons.Default.Close, accent = false)
        }
    }
}

@Composable
private fun TvNavItem(
    label: String, selected: Boolean, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    val selectedBrush = Brush.horizontalGradient(listOf(MatteTeal, MattePink))
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(brush = if (selected) selectedBrush else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else if (selected) Color.Transparent else MatteLine, RoundedCornerShape(14.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (selected) MatteInk else MatteMuted, modifier = Modifier.size(19.dp))
        Text(label, color = if (selected) MatteInk else MatteText, fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvUtilityButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Boolean = true
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (focused) if (amoled) Color(0xFF141414) else Color(0xFF2A3038) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (accent) MatteTeal else MatteMuted, modifier = Modifier.size(17.dp))
        Text(label, color = MatteMuted, fontSize = 10.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvNowPlaying(
    selected: Station?, playing: Boolean, status: String,
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float, visualizerStyle: String,
    volume: Float, favorite: Boolean, sleepRemaining: Int,
    onPlayPause: () -> Unit, onStopPlayback: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit,
    onBrowse: () -> Unit, onFullscreen: () -> Unit, onSleep: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("NOW PLAYING", color = MatteTeal, fontSize = 10.sp, letterSpacing = 2.5.sp, fontWeight = FontWeight.SemiBold)
            TvSmallTextButton("FULL SCREEN VISUALIZER", onFullscreen, Icons.Default.Fullscreen)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(278.dp).clip(RoundedCornerShape(20.dp))) {
            ReactiveVisualScene(waveform, spectrum, audioEnergy, Modifier.fillMaxSize(), fullScreen = false, style = visualizerStyle)
        }
        Spacer(Modifier.height(17.dp))
        Text("radio cherry LIVE", color = Color(0xFFE9EEF0), fontSize = 13.sp,
            fontWeight = FontWeight.Medium, letterSpacing = 1.1.sp)
        Spacer(Modifier.height(4.dp))
        Text(selected?.name ?: "Choose a station to begin",
            color = MatteText, fontSize = 29.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(5.dp))
        Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Discover more than 200 stations from around the world",
            color = Color(0xFFD7DCE0), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Text(status, color = Color(0xFFC4E6DD), fontSize = 11.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.SemiBold)
        if (sleepRemaining > 0) {
            Text("SLEEP TIMER  ·  ${formatTime(sleepRemaining)}", color = MattePink, fontSize = 10.sp,
                letterSpacing = 1.3.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(17.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            TvRoundControl(Icons.Default.SkipPrevious, "PREVIOUS", onPrevious)
            TvRoundControl(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "PAUSE" else "PLAY", onPlayPause, primary = true)
            TvRoundControl(Icons.Default.Stop, "STOP", onStopPlayback)
            TvRoundControl(Icons.Default.SkipNext, "NEXT", onNext)
            TvRoundControl(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "FAVOURITE", onFavorite)
            Spacer(Modifier.width(4.dp))
            TvPillButton(if (sleepRemaining > 0) "SLEEP ${formatTime(sleepRemaining)}" else "SLEEP TIMER", onSleep, Icons.Default.Timer)
            TvPillButton("BROWSE", onBrowse, Icons.Default.Explore)
            Spacer(Modifier.weight(1f))
            TvVolumeControl(volume = volume, onValue = onVolume, compact = true)
        }
    }
}

@Composable
private fun TvBrowsePage(
    isFavorites: Boolean, stations: List<Station>, totalCount: Int,
    selectedId: String?, favorites: Set<String>, search: String, onSearch: (String) -> Unit,
    selectedGenre: String, onGenre: (String) -> Unit,
    onSelect: (Station) -> Unit, onFavorite: (Station) -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    val genres = listOf("All", "Ambient", "Electronic", "Indie", "80s", "Classical", "Sleep", "Nature", "Jazz")
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
            Column(horizontalAlignment = Alignment.End) {
                Text(if (isFavorites) "Your favourites" else "Explore stations", color = MatteText, fontSize = 30.sp, fontWeight = FontWeight.Light)
                Text("$totalCount STATIONS", color = MatteMuted, fontSize = 10.sp, letterSpacing = 2.sp,
                    modifier = Modifier.padding(top = 5.dp))
            }
        }
        Spacer(Modifier.height(17.dp))
        if (!isFavorites) {
            OutlinedTextField(
                value = search, onValueChange = onSearch,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                singleLine = true, shape = RoundedCornerShape(15.dp),
                placeholder = { Text("Search stations...", color = MatteMuted, fontSize = 14.sp) },
                leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Search, null, tint = MatteTeal) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MatteText, unfocusedTextColor = MatteText,
                    focusedBorderColor = MatteTeal, unfocusedBorderColor = MatteLine,
                    cursorColor = MatteTeal, focusedContainerColor = if (amoled) Color.Black else Color(0xFF1B2027),
                    unfocusedContainerColor = if (amoled) Color.Black else Color(0xFF1B2027)
                )
            )
            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                genres.forEach { genre -> TvGenreChip(genre, selectedGenre == genre, { onGenre(genre) }) }
            }
            Spacer(Modifier.height(13.dp))
        }
        if (stations.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (isFavorites) "No favourites yet. Save stations with the heart." else "No stations match your search.",
                    color = MatteMuted, fontSize = 16.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(stations, key = { it.id }) { station ->
                    TvStationRow(
                        station = station, active = station.id == selectedId,
                        favorite = station.id in favorites,
                        onClick = { onSelect(station) }, onFavorite = { onFavorite(station) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TvGenreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Box(
        Modifier.clip(RoundedCornerShape(30.dp))
            .background(if (selected) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(if (amoled) Color(0xFF050505) else Color(0xFF282D35), if (amoled) Color(0xFF050505) else Color(0xFF282D35))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color.Transparent, RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) MatteInk else MatteText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvStationRow(
    station: Station, active: Boolean, favorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(15.dp))
            .background(if (active) Brush.horizontalGradient(listOf(Color(0xFF293A3B), Color(0xFF38313A))) else Brush.horizontalGradient(listOf(if (amoled) Color(0xFF050505) else MatteCard, if (amoled) Color(0xFF050505) else MatteCard)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(15.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(station.name, color = MatteText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${station.genre}  ·  ${station.broadcaster}", color = MatteMuted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        }
        if (active) Text("ON AIR", color = MatteTeal, fontSize = 9.sp, letterSpacing = 1.4.sp,
            modifier = Modifier.padding(end = 18.dp))
        TvFavoriteButton(
            selected = favorite, onClick = onFavorite
        )
    }
}

@Composable
private fun TvFavoriteButton(selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(if (focused) Color(0xFF3B3940) else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(if (selected) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favourite", tint = if (selected) MattePink else MatteMuted, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun TvFullScreenVisualizer(
    selected: Station?, playing: Boolean, status: String,
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float, visualizerStyle: String,
    chromeVisible: Boolean, onUserActivity: () -> Unit,
    hideSkip: Boolean, hideVolume: Boolean,
    volume: Float, favorite: Boolean, sleepRemaining: Int,
    appBrightness: Float, onAppBrightness: (Float) -> Unit,
    onBack: () -> Unit, onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit, onSleep: () -> Unit,
    onSettings: () -> Unit, onExit: () -> Unit
) {
    val controlAlpha by animateFloatAsState(
        targetValue = if (chromeVisible) 0.88f else 0.0f,
        animationSpec = tween(750), label = "visualizer-control-idle-alpha"
    )
    var brightnessPanelOpen by remember { mutableStateOf(false) }
    // Only interactive chrome fades after inactivity. Station identity and the
    // entire audio-reactive scene remain fully visible at all times.
    val backFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { backFocus.requestFocus() }
    Box(Modifier.fillMaxSize()) {
        ReactiveVisualScene(waveform, spectrum, audioEnergy, Modifier.fillMaxSize(), fullScreen = true, style = visualizerStyle)

        TvIconButton(
            icon = Icons.Default.ArrowBack,
            description = "Back to normal mode",
            onClick = { onUserActivity(); onBack() },
            modifier = Modifier.align(Alignment.TopEnd).focusRequester(backFocus)
                .padding(end = 22.dp, top = 16.dp).graphicsLayer(alpha = controlAlpha),
            buttonSize = 25.dp, iconSize = 12.dp, onFocusActivity = onUserActivity,
            neon = visualizerStyle == "NEON"
        )
        TvIconButton(
            icon = Icons.Default.Settings,
            description = "Settings",
            onClick = { onUserActivity(); onSettings() },
            modifier = Modifier.align(Alignment.TopStart)
                .padding(start = 22.dp, top = 16.dp).graphicsLayer(alpha = controlAlpha),
            buttonSize = 25.dp, iconSize = 12.dp, onFocusActivity = onUserActivity,
            neon = visualizerStyle == "NEON"
        )

        if (brightnessPanelOpen) {
            Row(
                Modifier.align(Alignment.BottomCenter)
                    .padding(bottom = 66.dp)
                    .graphicsLayer(alpha = controlAlpha)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xB8121720))
                    .border(0.8.dp, Color(0x667E9AA0), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 5.dp)
                    .width(250.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.Icon(
                    Icons.Default.Brightness6, null,
                    tint = MatteText, modifier = Modifier.size(14.dp)
                )
                Text("APP LIGHT", color = MatteMuted, fontSize = 8.sp, letterSpacing = 0.7.sp)
                Slider(
                    value = appBrightness,
                    onValueChange = { onUserActivity(); onAppBrightness(it) },
                    valueRange = 0.05f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = MatteTeal,
                        activeTrackColor = MatteTeal,
                        inactiveTrackColor = Color(0x667C858B)
                    ),
                    modifier = Modifier.weight(1f).height(24.dp)
                        .onPreviewKeyEvent { event ->
                            if (event.type == KeyEventType.KeyDown) {
                                when (event.key) {
                                    Key.DirectionLeft -> {
                                        onUserActivity()
                                        onAppBrightness((appBrightness - 0.05f).coerceAtLeast(0.05f))
                                        true
                                    }
                                    Key.DirectionRight -> {
                                        onUserActivity()
                                        onAppBrightness((appBrightness + 0.05f).coerceAtMost(1f))
                                        true
                                    }
                                    else -> false
                                }
                            } else false
                        }.focusable()
                )
                Text("${(appBrightness * 100).toInt()}%", color = MatteText, fontSize = 8.sp)
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 104.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("radio cherry LIVE", color = Color(0xFFF4F6F7), fontSize = 23.sp,
                fontWeight = FontWeight.Medium, letterSpacing = 0.35.sp)
            Spacer(Modifier.height(5.dp))
            Text(selected?.name ?: "Choose a station", color = Color(0xFFF4F6F7),
                fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Internet radio",
                color = Color(0xFFE0E5E8), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Text(status, color = Color(0xFFD0EEE5), fontSize = 9.sp, letterSpacing = 1.25.sp,
                modifier = Modifier.padding(top = 5.dp))
            if (sleepRemaining > 0) Text("SLEEP TIMER  ·  ${formatTime(sleepRemaining)}",
                color = Color(0xFFF0CBD8), fontSize = 9.sp, letterSpacing = 1.1.sp,
                modifier = Modifier.padding(top = 4.dp))
        }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 17.dp)
                .graphicsLayer(alpha = controlAlpha),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!hideSkip) TvMiniVisualizerButton(Icons.Default.SkipPrevious, "Previous station", { onUserActivity(); onPrevious() }, onUserActivity, neon = visualizerStyle == "NEON")
            TvMiniVisualizerButton(
                if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                if (playing) "Pause" else "Play",
                { onUserActivity(); brightnessPanelOpen = false; onPlayPause() }, onUserActivity, primary = true, neon = visualizerStyle == "NEON"
            )
            if (!hideSkip) TvMiniVisualizerButton(Icons.Default.SkipNext, "Next station", { onUserActivity(); onNext() }, onUserActivity, neon = visualizerStyle == "NEON")
            TvMiniVisualizerButton(
                if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "Favourite", { onUserActivity(); onFavorite() }, onUserActivity, neon = visualizerStyle == "NEON"
            )
            TvMiniVisualizerButton(Icons.Default.Timer, "Sleep timer", { onUserActivity(); onSleep() }, onUserActivity, neon = visualizerStyle == "NEON")
            TvMiniVisualizerButton(
                Icons.Default.Brightness6,
                "App brightness",
                { onUserActivity(); brightnessPanelOpen = !brightnessPanelOpen },
                onUserActivity,
                neon = visualizerStyle == "NEON"
            )
            if (!hideVolume) {
                TvVolumeControl(volume = volume, onValue = { onUserActivity(); onVolume(it) }, compact = true, miniVisualizer = true)
            }
            TvMiniVisualizerButton(Icons.Default.Close, "Exit app", { onUserActivity(); onExit() }, onUserActivity, neon = visualizerStyle == "NEON")
        }
    }
}

@Composable
private fun TvMiniVisualizerButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    onFocusActivity: () -> Unit,
    primary: Boolean = false,
    neon: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(27.dp).clip(CircleShape)
            .background(
                if (primary && neon) Brush.linearGradient(listOf(Color(0xFF00EFFF), Color(0xFF8A36FF), Color(0xFFFF31B8)))
                else if (primary) Brush.linearGradient(listOf(MatteTeal.copy(alpha = 0.82f), MattePink.copy(alpha = 0.82f)))
                else Brush.linearGradient(listOf(Color(0x77333D49), Color(0x77333D49)))
            )
            .border(if (focused) 1.3.dp else 0.7.dp,
                if (focused) Color.White else if (neon) Color(0xBB8F63FF) else Color(0x667A8990), CircleShape)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocusActivity() }
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            imageVector = icon, contentDescription = description,
            tint = if (primary) MatteInk else Color(0xFFE8EEF0),
            modifier = Modifier.size(13.dp)
        )
    }
}

@Composable
private fun rememberVisualizerPhase(): State<Float> {
    // Keep a steady 30fps phase clock aligned with the coalesced audio frame rate.
    // Audio samples remain the source of waveform motion; this clock supplies slow drift.
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val started = System.nanoTime()
        while (true) {
            val elapsed = (System.nanoTime() - started) / 1_000_000_000f
            phase.floatValue = (elapsed * 0.23f) % (2f * PI.toFloat())
            delay(33L)
        }
    }
    return phase
}

@Composable
private fun ReactiveVisualScene(
    waveform: FloatArray,
    spectrum: FloatArray,
    audioEnergy: Float,
    modifier: Modifier,
    fullScreen: Boolean,
    style: String
) {
    val phase by rememberVisualizerPhase()
    val level = audioEnergy.coerceIn(0.01f, 1f)
    val aurora = style == "AURORA"
    val neon = style == "NEON"
    val starfield = style == VISUALIZER_STARFIELD
    val starfieldStars = remember {
        val colors = listOf(
            Color(0xFFE8E7EF), Color(0xFFCFC9D8), Color(0xFF7DB8B8),
            Color(0xFFCB8AA5), Color(0xFF8297BD)
        )
        List(720) { i ->
            StarfieldStar(
                x = ((i * 97 + 31) % 1009) / 1008f,
                y = ((i * 173 + 53) % 1013) / 1012f,
                radius = 0.42f + ((i * 7) % 9) * 0.12f,
                color = colors[i % colors.size],
                twinklePhase = i * 0.618f
            )
        }
    }
    val starfieldBokeh = remember {
        val colors = listOf(Color(0xFF147E86), Color(0xFFCB819D), Color(0xFF6A6F8D), Color(0xFF3E8991))
        List(24) { i ->
            val leftSide = i % 2 == 0
            val x = if (leftSide) 0.025f + ((i * 13) % 23) / 100f
                    else 0.75f + ((i * 17) % 22) / 100f
            val y = ((i * 37 + 11) % 97) / 96f
            StarfieldBokeh(
                x = x,
                y = y,
                radius = 0.010f + (i % 4) * 0.0055f,
                color = colors[i % colors.size],
                phase = i * 0.81f
            )
        }
    }

    fun averageBand(from: Int, until: Int): Float {
        val end = until.coerceAtMost(spectrum.size)
        val start = from.coerceAtMost(end)
        if (end <= start) return 0f
        var total = 0f
        for (index in start until end) total += spectrum[index]
        return (total / (end - start)).coerceIn(0f, 1f)
    }

    val bass = averageBand(0, 7)
    val mids = averageBand(7, 25)
    val highs = averageBand(25, spectrum.size)
    val audioTint = (bass * 0.42f + mids * 0.34f + highs * 0.24f).coerceIn(0f, 1f)
    val slowA = (0.5f + 0.5f * sin(phase * 0.22f)).coerceIn(0f, 1f)
    val slowB = (0.5f + 0.5f * cos(phase * 0.17f + 1.4f)).coerceIn(0f, 1f)

    // Each visualizer is an independent composition:
    // NEBULA is the dark cinematic matte look; AURORA is the pale pastel look;
    // NEON is the electric treatment; STARFIELD is the black cosmic starfield.
    val backgroundColors = when {
        neon -> listOf(
            androidx.compose.ui.graphics.lerp(Color(0xFF020614), Color(0xFF07122D), slowA * 0.34f),
            androidx.compose.ui.graphics.lerp(Color(0xFF080B22), Color(0xFF170A32), slowB * 0.55f),
            androidx.compose.ui.graphics.lerp(Color(0xFF1B0828), Color(0xFF330A3B), slowA * 0.58f)
        )
        starfield -> listOf(Color.Black, Color.Black, Color.Black)
        aurora -> listOf(
            androidx.compose.ui.graphics.lerp(Color(0xFF6EA7A8), Color(0xFF82B8B4), slowA * 0.28f),
            androidx.compose.ui.graphics.lerp(Color(0xFFB8B4BD), Color(0xFFD0C1C9), slowB * 0.30f),
            androidx.compose.ui.graphics.lerp(Color(0xFFDDB1C0), Color(0xFFEBC6CC), slowA * 0.26f)
        )
        else -> listOf(
            androidx.compose.ui.graphics.lerp(Color(0xFF071522), Color(0xFF0C2030), slowA * 0.34f),
            androidx.compose.ui.graphics.lerp(Color(0xFF17192D), Color(0xFF28203A), slowB * 0.34f),
            androidx.compose.ui.graphics.lerp(Color(0xFF2B1835), Color(0xFF3B2144), slowA * 0.38f)
        )
    }

    Box(
        modifier.background(
            Brush.linearGradient(
                colorStops = arrayOf(
                    0f to backgroundColors[0],
                    0.52f to backgroundColors[1],
                    1f to backgroundColors[2]
                ),
                start = Offset(0f, 0f),
                end = Offset(1800f, 980f)
            )
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val minDim = size.minDimension
            val center = Offset(w * 0.5f, if (fullScreen) h * 0.425f else h * 0.47f)
            val nebulaMotion = minDim * (0.014f + bass * 0.055f + mids * 0.035f)
            val cloudScale = if (fullScreen) 1f else 0.82f
            val cloudAlpha = when {
                neon -> 0.78f
                starfield -> 0.20f
                aurora -> 0.25f
                else -> 0.52f
            }

            fun cloud(
                color: Color,
                point: Offset,
                radius: Float,
                bandEnergy: Float,
                phaseOffset: Float,
                alphaScale: Float = 1f
            ) {
                val motionShimmer = (0.72f + 0.28f * sin(phase * 0.72f + phaseOffset)).coerceIn(0.25f, 1f)
                val audioLift = (bandEnergy.coerceIn(0f, 1f) * 0.20f + level * 0.07f)
                val alpha = ((cloudAlpha + audioLift) * motionShimmer * alphaScale).coerceIn(0.06f, 0.88f)
                if (neon) {
                    // Two translucent shells create a glow without an expensive blur effect.
                    drawCircle(
                        Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to color.copy(alpha = alpha * 0.38f),
                                0.42f to color.copy(alpha = alpha * 0.20f),
                                1f to Color.Transparent
                            ),
                            center = point,
                            radius = radius * 1.55f
                        ),
                        radius = radius * 1.55f,
                        center = point
                    )
                }
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to color.copy(alpha = alpha),
                            0.25f to color.copy(alpha = alpha * 0.72f),
                            0.63f to color.copy(alpha = alpha * 0.22f),
                            1f to Color.Transparent
                        ),
                        center = point,
                        radius = radius
                    ),
                    radius = radius,
                    center = point
                )
            }

            val driftA = sin(phase * 0.37f) * nebulaMotion
            val driftB = cos(phase * 0.31f) * nebulaMotion
            val driftC = sin(phase * 0.23f + 1.2f) * nebulaMotion * 0.76f

            val teal = when {
                neon -> Color(0xFF00F5D4)
                starfield -> Color(0xFF147E83)
                aurora -> Color(0xFF75CFC4)
                else -> Color(0xFF267C86)
            }
            val cyan = when {
                neon -> Color(0xFF00BFFF)
                starfield -> Color(0xFF174D6B)
                aurora -> Color(0xFF86CADC)
                else -> Color(0xFF276B91)
            }
            val blue = when {
                neon -> Color(0xFF315BFF)
                starfield -> Color(0xFF1C2B57)
                aurora -> Color(0xFF9BAFD4)
                else -> Color(0xFF344F85)
            }
            val violet = when {
                neon -> Color(0xFF8738FF)
                starfield -> Color(0xFF382448)
                aurora -> Color(0xFFC6A9D0)
                else -> Color(0xFF65517D)
            }
            val plum = when {
                neon -> Color(0xFFFF2CBF)
                starfield -> Color(0xFF60334F)
                aurora -> Color(0xFFE1A7BC)
                else -> Color(0xFF9A547C)
            }
            val rose = when {
                neon -> Color(0xFFFF4FB8)
                starfield -> Color(0xFF96516E)
                aurora -> Color(0xFFE8B8C5)
                else -> Color(0xFFB36D8B)
            }

            if (!starfield) {
                // Nebula and Aurora retain the animated gas clouds. Starfield is a
                // true black space scene and must not inherit a painted nebula layer.
                cloud(teal, Offset(w * 0.08f + driftA, h * 0.59f + mids * minDim * 0.045f),
                    minDim * (0.60f + bass * 0.08f) * cloudScale, bass + mids * 0.45f, 0.1f)
                cloud(cyan, Offset(w * 0.18f - driftB, h * 0.82f + driftC),
                    minDim * (0.48f + mids * 0.06f) * cloudScale, mids + bass * 0.25f, 1.0f, 0.88f)
                cloud(blue, Offset(w * 0.31f + driftC, h * 0.17f - driftA * 0.25f),
                    minDim * (0.43f + highs * 0.05f) * cloudScale, highs + mids * 0.30f, 1.9f, 0.82f)
                cloud(violet, Offset(w * 0.78f + driftB, h * 0.18f + highs * minDim * 0.045f),
                    minDim * (0.56f + highs * 0.06f) * cloudScale, highs + mids * 0.42f, 2.8f)
                cloud(plum, Offset(w * 0.94f - driftA, h * 0.60f - bass * minDim * 0.035f),
                    minDim * (0.60f + highs * 0.05f) * cloudScale, highs + bass * 0.35f, 3.7f)
                cloud(rose, Offset(w * 0.72f + driftC, h * 0.90f),
                    minDim * 0.36f * cloudScale, highs + mids * 0.25f, 4.6f, 0.82f)
                cloud(teal, Offset(w * 0.29f + driftB * 0.7f, h * 0.40f + driftA * 0.2f),
                    minDim * 0.31f * cloudScale, highs + mids, 5.3f, 0.72f)
                cloud(plum, Offset(w * 0.64f - driftA * 0.6f, h * 0.68f - driftC),
                    minDim * 0.33f * cloudScale, bass + highs, 6.1f, 0.78f)

                // Turbulent audio-reactive translucent wisps enrich the matte scenes.
                for (i in 0 until 8) {
                    val sample = waveform[(i * 9) % waveform.size]
                    val band = spectrum[(i * 5) % spectrum.size]
                    val baseX = ((i * 37 + 11) % 97) / 96f
                    val baseY = ((i * 53 + 7) % 89) / 88f
                    val x = baseX * w + sin(phase * (0.16f + (i % 3) * 0.04f) + i) * nebulaMotion * (0.5f + sample)
                    val y = baseY * h + cos(phase * (0.13f + (i % 4) * 0.03f) + i * 0.73f) * nebulaMotion * 0.62f
                    val radius = minDim * (0.10f + band * 0.11f + sample * 0.05f) * cloudScale
                    cloud(if (i % 2 == 0) teal else plum, Offset(x, y), radius, sample + band, i * 0.37f, 0.54f)
                }
            } else {
                // The supplied reference uses a black field, hundreds of pin-stars,
                // and soft teal / rose bokeh planets around the outside of the frame.
                for ((bokehIndex, bokeh) in starfieldBokeh.withIndex()) {
                    val bandEnergy = spectrum[(bokehIndex * 3) % spectrum.size]
                    val pulse = 0.88f + 0.08f * sin(phase * 0.17f + bokeh.phase) + bandEnergy * 0.12f
                    val drift = sin(phase * 0.09f + bokeh.phase) * nebulaMotion * (0.035f + bandEnergy * 0.06f)
                    val point = Offset(bokeh.x * w + drift, bokeh.y * h - drift * 0.35f)
                    val radius = minDim * bokeh.radius * pulse
                    drawCircle(
                        Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to bokeh.color.copy(alpha = 0.24f),
                                0.35f to bokeh.color.copy(alpha = 0.15f),
                                0.72f to bokeh.color.copy(alpha = 0.045f),
                                1f to Color.Transparent
                            ),
                            center = point,
                            radius = radius * 3.2f
                        ),
                        radius = radius * 3.2f,
                        center = point
                    )
                    drawCircle(bokeh.color.copy(alpha = 0.16f), radius * 0.58f, point)
                }
                for (index in starfieldStars.indices) {
                    val star = starfieldStars[index]
                    val twinkle = (0.48f + 0.52f * sin(phase * 0.58f + star.twinklePhase)).coerceIn(0.08f, 1f)
                    val x = star.x * w
                    val y = star.y * h
                    val audioFlicker = if (index % 7 == 0) 0.08f + highs * 0.12f else 0f
                    drawCircle(
                        star.color.copy(alpha = (0.16f + twinkle * 0.58f + audioFlicker).coerceIn(0.12f, 0.9f)),
                        star.radius,
                        Offset(x, y)
                    )
                    if (index % 97 == 0) {
                        val glint = star.radius * (4.2f + highs * 1.5f)
                        drawLine(Color.White.copy(alpha = 0.58f * twinkle), Offset(x - glint, y), Offset(x + glint, y), 0.9f)
                        drawLine(Color.White.copy(alpha = 0.58f * twinkle), Offset(x, y - glint), Offset(x, y + glint), 0.9f)
                    }
                }
            }

            // Particle density and character vary by visualizer: Aurora is airy,
            // Nebula is restrained, Neon is luminous, and Starfield is densely star-filled.
            val particleCount = when {
                aurora -> 80
                neon -> 60
                starfield -> 0
                else -> 48
            }
            for (i in 0 until particleCount) {
                val baseX = ((i * 47 + 13) % 997) / 996f
                val baseY = ((i * 71 + 19) % 991) / 990f
                val sample = waveform[(i * 11) % waveform.size]
                val band = spectrum[(i * 5) % spectrum.size]
                val twinkle = (0.48f + 0.52f * sin(phase * (0.36f + (i % 5) * 0.055f) + i)).coerceIn(0.04f, 1f)
                val x = baseX * w + sin(phase * 0.095f + i * 0.7f) * nebulaMotion * 0.34f
                val y = baseY * h + cos(phase * 0.11f + i * 0.47f) * nebulaMotion * 0.25f
                val baseRadius = when {
                    starfield -> 0.42f + (i % 5) * 0.20f
                    aurora -> 1.0f + (i % 5) * 0.52f
                    neon -> 0.9f + (i % 4) * 0.48f
                    else -> 0.7f + (i % 3) * 0.40f
                }
                val radius = baseRadius + band * (if (aurora) 2.8f else 2.0f) + sample * 1.0f
                val particleColor = when {
                    neon -> when (i % 4) {
                        0 -> Color(0xFF00F5FF)
                        1 -> Color(0xFF5A72FF)
                        2 -> Color(0xFFD344FF)
                        else -> Color(0xFFFF48C9)
                    }
                    starfield -> when (i % 5) {
                        0 -> Color(0xFFE7E9F0)
                        1 -> Color(0xFF40BFC0)
                        2 -> Color(0xFFD17A98)
                        3 -> Color(0xFF8A9FCB)
                        else -> Color(0xFFB8A6C7)
                    }
                    aurora -> when (i % 4) {
                        0 -> Color(0xFF63D6CC)
                        1 -> Color(0xFFFFC4D7)
                        2 -> Color(0xFFE9E8EF)
                        else -> Color(0xFF82B6CE)
                    }
                    else -> when (i % 4) {
                        0 -> Color(0xFF72DAD2)
                        1 -> Color(0xFFE7A9CF)
                        2 -> Color(0xFF99BDEB)
                        else -> Color(0xFFE3DDF0)
                    }
                }
                val alpha = when {
                    neon -> (0.62f + twinkle * 0.34f + band * 0.12f).coerceIn(0f, 1f)
                    starfield -> (0.38f + twinkle * 0.46f + band * 0.12f).coerceIn(0f, 1f)
                    aurora -> (0.40f + twinkle * 0.48f + band * 0.12f).coerceIn(0f, 1f)
                    else -> (0.28f + twinkle * 0.42f + band * 0.16f).coerceIn(0f, 1f)
                }
                if (starfield && i % 13 == 0) {
                    val hazeRadius = radius * 5.5f
                    drawCircle(
                        Brush.radialGradient(
                            listOf(particleColor.copy(alpha = 0.15f + band * 0.08f), Color.Transparent),
                            center = Offset(x, y), radius = hazeRadius
                        ), hazeRadius, Offset(x, y)
                    )
                }
                drawCircle(particleColor.copy(alpha = alpha), radius, Offset(x, y))
                if ((aurora && i % 11 == 0) || (starfield && i % 23 == 0)) {
                    // Tiny four-point star glints from the lighter visual reference.
                    drawLine(Color.White.copy(alpha = 0.55f * twinkle),
                        Offset(x - radius * 2.4f, y), Offset(x + radius * 2.4f, y), 0.8f)
                    drawLine(Color.White.copy(alpha = 0.55f * twinkle),
                        Offset(x, y - radius * 2.4f), Offset(x, y + radius * 2.4f), 0.8f)
                }
            }

            // Wave ribbons span almost the full width and remain clearly readable.
            val lineCount = when {
                starfield -> 18
                neon -> 14
                else -> 15
            }
            val waveCenterY = h * if (fullScreen) 0.46f else 0.555f
            for (line in 0 until lineCount) {
                val path = Path()
                val lineOffset = (line - (lineCount - 1) / 2f) * (if (fullScreen) 5.3f else 4.1f)
                val linePhase = line * 0.18f
                for (step in 0..64) {
                    val t = step / 64f
                    val x = w * t
                    val index = (t * (waveform.size - 1)).toInt().coerceIn(0, waveform.lastIndex)
                    val previous = waveform[(index - 1).coerceAtLeast(0)]
                    val sample = waveform[index]
                    val next = waveform[(index + 1).coerceAtMost(waveform.lastIndex)]
                    val wave = (previous + sample * 2f + next) * 0.25f
                    val band = spectrum[(index * 3) % spectrum.size]
                    val envelope = (0.18f + 0.82f * sin(t * PI).toFloat()).coerceIn(0f, 1f)
                    val broad = sin(t * PI * 2.25f + phase * 0.68f + linePhase).toFloat()
                    val fine = sin(t * PI * 7.8f - phase * 0.46f + linePhase * 1.6f).toFloat()
                    val audioWave = (wave - 0.10f) * h * (0.14f + level * 0.055f) * envelope
                    val y = waveCenterY + lineOffset +
                        broad * h * (0.043f + mids * 0.027f) +
                        fine * h * (0.011f + highs * 0.018f) +
                        audioWave + (band - 0.02f) * h * 0.032f
                    if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }

                val tint = when {
                    neon -> when (line % 4) {
                        0 -> Color(0xFF00F5FF)
                        1 -> Color(0xFF388BFF)
                        2 -> Color(0xFFB845FF)
                        else -> Color(0xFFFF3EBB)
                    }
                    starfield -> when (line % 3) {
                        0 -> Color(0xFF78BDB7)
                        1 -> Color(0xFFB7B6C5)
                        else -> Color(0xFFD19DB5)
                    }
                    aurora -> if (line % 2 == 0) Color(0xFFBCE4DE) else Color(0xFFE8C5D2)
                    else -> if (line % 2 == 0) Color(0xFF86BDB7) else Color(0xFFC193AE)
                }
                if (neon) {
                    drawPath(path, tint.copy(alpha = 0.18f + level * 0.14f),
                        style = Stroke(width = if (fullScreen) 5.2f else 4.4f))
                }
                val alpha = when {
                    neon -> 0.82f + level * 0.12f
                    starfield -> 0.34f + level * 0.10f
                    aurora -> 0.40f + level * 0.12f
                    else -> 0.50f + level * 0.16f
                }
                drawPath(path, tint.copy(alpha = alpha), style = Stroke(width = if (starfield) 0.82f else if (fullScreen) 1.25f else 1.0f))
            }

            // A fine secondary wire layer restores the braided ribbon detail.
            val fineLineCount = when { starfield -> 10; aurora -> 8; neon -> 7; else -> 6 }
            for (line in 0 until fineLineCount) {
                val path = Path()
                for (step in 0..44) {
                    val t = step / 44f
                    val x = w * t
                    val index = (t * (spectrum.size - 1)).toInt().coerceIn(0, spectrum.lastIndex)
                    val band = spectrum[index]
                    val sample = waveform[(index * 2).coerceIn(0, waveform.lastIndex)]
                    val envelope = sin(t * PI).toFloat()
                    val offset = (line - (fineLineCount - 1) / 2f) * 2.1f
                    val y = waveCenterY + offset +
                        sin(t * PI * 3.0f + phase * 0.62f + line * 0.27f) * h * 0.044f +
                        (sample - 0.08f) * h * 0.095f * envelope +
                        band * h * 0.036f * sin(phase + line * 0.21f)
                    if (step == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
                }
                val color = when {
                    neon -> if (line % 2 == 0) Color(0xFF00DFFF) else Color(0xFFE948FF)
                    starfield -> if (line % 2 == 0) Color(0xFF54C4BE) else Color(0xFFC78DA9)
                    aurora -> if (line % 2 == 0) Color(0xFFD5F0EA) else Color(0xFFF1D6DF)
                    else -> if (line % 2 == 0) Color(0xFF9BC8C0) else Color(0xFFD6A7BD)
                }
                drawPath(path, color.copy(alpha = if (neon) 0.72f else if (starfield) 0.46f else if (aurora) 0.31f else 0.35f),
                    style = Stroke(width = 0.75f))
            }

            // Thin orbital rings around the sphere, not a flat disc.
            val orbRadius = minDim * (
                if (starfield && fullScreen) 0.092f
                else if (fullScreen) 0.112f else 0.132f
            ) + bass * minDim * 0.016f
            val ringCount = when { neon -> 5; starfield -> 3; else -> 4 }
            for (ring in 0 until ringCount) {
                val sample = waveform[(ring * 13) % waveform.size]
                val ringMultiplier = if (starfield) 1.52f + ring * 0.34f else 1.38f + ring * 0.25f
                val radius = orbRadius * ringMultiplier + sample * minDim * 0.020f + mids * ring * 1.15f
                val ringColor = when {
                    neon -> if (ring % 2 == 0) Color(0xFF00EFFF) else Color(0xFFFF4AD8)
                    starfield -> if (ring % 2 == 0) Color(0xFF8DBCB8) else Color(0xFFC69AAF)
                    aurora -> if (ring % 2 == 0) Color(0xFFE0F0EB) else Color(0xFFF6DCE5)
                    else -> if (ring % 2 == 0) Color(0xFF9BCBC2) else Color(0xFFD8B0C5)
                }
                if (neon) {
                    drawCircle(ringColor.copy(alpha = 0.18f), radius, center, style = Stroke(width = 6f))
                }
                drawCircle(
                    ringColor.copy(alpha = when {
                        neon -> 0.88f + sample * 0.10f
                        aurora -> 0.52f + sample * 0.14f
                        else -> 0.46f + sample * 0.18f
                    }),
                    radius,
                    center,
                    style = Stroke(width = if (fullScreen) 1.05f else 0.95f)
                )
            }

            // Dimensional orb with a shaded terminator, specular highlight and
            // an offset shadow. This restores the sphere-like centre of the refs.
            val pulseRadius = orbRadius * (1f + bass * 0.045f + mids * 0.016f)
            val shadowCenter = Offset(center.x + pulseRadius * 0.16f, center.y + pulseRadius * 0.19f)
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to Color(0xFF02030B).copy(alpha = if (aurora) 0.30f else 0.54f),
                        0.58f to Color(0xFF050817).copy(alpha = 0.24f),
                        1f to Color.Transparent
                    ),
                    center = shadowCenter,
                    radius = pulseRadius * 1.55f
                ),
                radius = pulseRadius * 1.55f,
                center = shadowCenter
            )
            if (neon) {
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color(0xFF00EFFF).copy(alpha = 0.35f + bass * 0.16f),
                            0.48f to Color(0xFF9C38FF).copy(alpha = 0.21f),
                            1f to Color.Transparent
                        ),
                        center = center,
                        radius = pulseRadius * 1.9f
                    ),
                    radius = pulseRadius * 1.9f,
                    center = center
                )
            }

            val orbStops = when {
                neon -> arrayOf(
                    0f to Color(0xFFFFFFFF),
                    0.20f to Color(0xFFDFFFFF),
                    0.48f to Color(0xFF9DCBFF),
                    0.72f to Color(0xFF9B6DDB),
                    0.91f to Color(0xFFE35DC7),
                    1f to Color(0xFF34154F)
                )
                aurora -> arrayOf(
                    0f to Color(0xFFFFFFFF),
                    0.22f to Color(0xFFE9FFF8),
                    0.48f to Color(0xFFB7E2DE),
                    0.72f to Color(0xFFD6C2D9),
                    0.92f to Color(0xFFEAB7C9),
                    1f to Color(0xFF876C90)
                )
                starfield -> arrayOf(
                    0f to Color(0xFFFFFFFF),
                    0.22f to Color(0xFFD9F7F1),
                    0.48f to Color(0xFF9BC9C8),
                    0.72f to Color(0xFFB7A3C0),
                    0.92f to Color(0xFFD19DB5),
                    1f to Color(0xFF30243B)
                )
                else -> arrayOf(
                    0f to Color(0xFFFFFFFF),
                    0.22f to Color(0xFFDDFBF1),
                    0.48f to Color(0xFFAED4D4),
                    0.72f to Color(0xFFC4B3D1),
                    0.92f to Color(0xFFDDAFC4),
                    1f to Color(0xFF51405F)
                )
            }
            drawCircle(
                Brush.radialGradient(
                    colorStops = orbStops,
                    center = Offset(center.x - pulseRadius * 0.34f, center.y - pulseRadius * 0.40f),
                    radius = pulseRadius * 1.36f
                ),
                radius = pulseRadius,
                center = center
            )
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to Color.White.copy(alpha = if (aurora) 0.60f else 0.52f),
                        0.38f to Color(0xFFDFFFF9).copy(alpha = 0.22f),
                        1f to Color.Transparent
                    ),
                    center = Offset(center.x - pulseRadius * 0.36f, center.y - pulseRadius * 0.43f),
                    radius = pulseRadius * 0.63f
                ),
                radius = pulseRadius * 0.63f,
                center = Offset(center.x - pulseRadius * 0.36f, center.y - pulseRadius * 0.43f)
            )
            drawCircle(
                (if (neon) Color(0xFF69F6FF) else if (aurora) Color(0xFFE6F4EE) else Color(0xFFB9D9D0))
                    .copy(alpha = if (neon) 0.92f else 0.58f + level * 0.10f),
                pulseRadius * 1.02f,
                center,
                style = Stroke(width = if (neon) 1.8f else 1.0f)
            )

            // Tiny orbiting planet dots move independently with frequency bands.
            val orbitCount = when { starfield -> 8; aurora -> 12; else -> 10 }
            for (i in 0 until orbitCount) {
                val sample = waveform[(i * 7) % waveform.size]
                val band = spectrum[(i * 3) % spectrum.size]
                val orbit = pulseRadius * (1.68f + (i % 5) * 0.48f) + sample * minDim * 0.034f
                val angle = phase * (0.15f + (i % 4) * 0.032f) + i * 2.399f + band * 0.40f
                val x = center.x + cos(angle) * orbit
                val y = center.y + sin(angle * 1.07f) * orbit * 0.72f
                val radius = 1.8f + sample * 4.0f + band * 2.4f
                val color = when {
                    neon -> if (i % 2 == 0) Color(0xFF00F5FF) else Color(0xFFFF43CC)
                    starfield -> when (i % 3) { 0 -> Color(0xFF8CCBC5); 1 -> Color(0xFFE0A7BC); else -> Color(0xFFA8B5D0) }
                    aurora -> if (i % 2 == 0) Color(0xFF9BE5DC) else Color(0xFFEFBBCF)
                    else -> if (i % 2 == 0) Color(0xFF8FDAD0) else Color(0xFFE8B2CE)
                }
                drawCircle(color.copy(alpha = if (neon) 0.94f else 0.65f + sample * 0.22f),
                    radius, Offset(x, y))
                drawCircle(Color.White.copy(alpha = 0.34f), radius * 0.25f,
                    Offset(x - radius * 0.25f, y - radius * 0.25f))
            }

            // Stronger spectrum arc, with each bar tied to both FFT and waveform data.
            val bars = 64
            val arcY = h * if (starfield && fullScreen) 0.895f else if (fullScreen) 0.855f else 0.86f
            val arcWidth = w * (if (starfield && fullScreen) 0.145f else if (fullScreen) 0.36f else 0.29f)
            for (i in 0 until bars) {
                val normalized = i / (bars - 1f)
                val x = center.x - arcWidth + normalized * arcWidth * 2f
                val envelope = sin(normalized * PI).toFloat()
                val band = spectrum[(i * spectrum.size / bars).coerceIn(0, spectrum.lastIndex)]
                val wave = waveform[(i * waveform.size / bars).coerceIn(0, waveform.lastIndex)]
                val barHeight = 4f + envelope * (7f + band * 58f + wave * 28f) * (0.52f + level)
                val color = when {
                    neon -> androidx.compose.ui.graphics.lerp(Color(0xFF00F5FF), Color(0xFFFF36C9), normalized)
                    starfield -> androidx.compose.ui.graphics.lerp(Color(0xFF4EAAA7), Color(0xFFD094B0), normalized)
                    aurora -> androidx.compose.ui.graphics.lerp(Color(0xFFA8DCD2), Color(0xFFE6B7C9), normalized)
                    else -> androidx.compose.ui.graphics.lerp(Color(0xFF75B7AD), Color(0xFFD69BB7), normalized)
                }
                drawLine(
                    color.copy(alpha = if (neon) 0.96f else if (aurora) 0.70f else 0.66f),
                    Offset(x, arcY),
                    Offset(x, arcY - barHeight),
                    strokeWidth = if (fullScreen) 1.9f else 1.55f
                )
            }
        }
    }
}

@Composable
private fun TvRoundControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.size(if (primary) 58.dp else 48.dp).clip(CircleShape)
                .background(if (primary) Brush.linearGradient(listOf(MatteTeal, MattePink)) else Brush.linearGradient(listOf(if (amoled) Color(0xFF080808) else Color(0xFF272C34), if (amoled) Color(0xFF080808) else Color(0xFF272C34))))
                .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, CircleShape)
                .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Icon(icon, null, tint = if (primary) MatteInk else MatteText,
                modifier = Modifier.size(if (primary) 26.dp else 21.dp))
        }
        Text(label, color = MatteMuted, fontSize = 8.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvControlText(
    label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (primary) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(if (amoled) Color(0xCC080808) else Color(0xCC27323B), if (amoled) Color(0xCC080808) else Color(0xCC27323B))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0xAA9BA9AD), RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 15.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (primary) MatteInk else MatteText, modifier = Modifier.size(17.dp))
        Text(label, color = if (primary) MatteInk else MatteText, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvPillButton(label: String, onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (amoled) Color(0xFF050505) else Color(0xFF272C34))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 11.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = MatteTeal, modifier = Modifier.size(16.dp))
        Text(label, color = MatteText, fontSize = 9.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: androidx.compose.ui.unit.Dp = 50.dp,
    iconSize: androidx.compose.ui.unit.Dp = 23.dp,
    onFocusActivity: () -> Unit = {},
    neon: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier.size(buttonSize).clip(CircleShape)
            .background(if (focused) Color(0xFFE0EEE9) else if (neon) Color(0xAA15132A) else Color(0x88202B35))
            .border(if (focused) 1.5.dp else 0.7.dp, if (focused) MatteText else if (neon) Color(0xCC9B58FF) else Color(0x667A8990), CircleShape)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocusActivity() }
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            icon, description,
            tint = if (focused) MatteInk else Color(0xFFF4F6F7),
            modifier = Modifier.size(iconSize)
        )
    }
}

@Composable
private fun TvVisualizerStyleChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    buttonWidth: androidx.compose.ui.unit.Dp = 104.dp,
    buttonHeight: androidx.compose.ui.unit.Dp = 36.dp
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    val neon = label == "NEON"
    val selectedBrush = when {
        selected && neon -> Brush.horizontalGradient(listOf(Color(0xFF4931A6), Color(0xFF9A2D92)))
        selected -> Brush.horizontalGradient(listOf(MatteTeal, MattePink))
        else -> Brush.horizontalGradient(
            listOf(if (amoled) Color(0xFF080808) else Color(0xFF303640),
                   if (amoled) Color(0xFF080808) else Color(0xFF303640))
        )
    }
    Box(
        Modifier.width(buttonWidth).height(buttonHeight)
            .clip(RoundedCornerShape(8.dp))
            .background(selectedBrush)
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) Color.White else MatteLine,
                shape = RoundedCornerShape(8.dp)
            )
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) if (neon) Color.White else MatteInk else MatteText,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.25.sp,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip
        )
    }
}

@Composable
private fun TvSmallTextButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier.clip(RoundedCornerShape(30.dp))
            .background(if (focused) Color(0x334D5958) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0x557A8584), RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) androidx.compose.material3.Icon(icon, null, tint = MatteText, modifier = Modifier.size(14.dp))
        Text(label, color = MatteText, fontSize = 8.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvVolumeControl(
    volume: Float, onValue: (Float) -> Unit, compact: Boolean, miniVisualizer: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Column(
        Modifier.width(when { miniVisualizer -> 108.dp; compact -> 178.dp; else -> 245.dp }),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            androidx.compose.material3.Icon(
                Icons.Default.VolumeUp, null, tint = MatteMuted,
                modifier = Modifier.size(if (miniVisualizer) 9.dp else 17.dp)
            )
            Slider(
                value = volume, onValueChange = onValue,
                colors = SliderDefaults.colors(
                    thumbColor = MatteTeal, activeTrackColor = MatteTeal,
                    inactiveTrackColor = if (amoled) Color(0xFF303030) else Color(0xFF626B70)
                ),
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused }
                    .onPreviewKeyEvent { event ->
                        if (event.type == KeyEventType.KeyDown) {
                            when (event.key) {
                                Key.DirectionLeft -> { onValue((volume - 0.04f).coerceAtLeast(0f)); true }
                                Key.DirectionRight -> { onValue((volume + 0.04f).coerceAtMost(1f)); true }
                                else -> false
                            }
                        } else false
                    }.focusable(),
            )
            if (!miniVisualizer) Text("${(volume * 100).toInt()}%", color = MatteMuted, fontSize = 10.sp)
        }
        if (focused && !miniVisualizer) Text("VOLUME", color = MatteTeal, fontSize = 8.sp, letterSpacing = 1.1.sp)
    }
}

@Composable
private fun TvSettingsDialog(
    backgroundPlayback: Boolean, onBackgroundPlayback: (Boolean) -> Unit,
    hideVolume: Boolean, onHideVolume: (Boolean) -> Unit,
    hideSkip: Boolean, onHideSkip: (Boolean) -> Unit,
    keepScreenAwake: Boolean, onKeepScreenAwake: (Boolean) -> Unit,
    shuffleEnabled: Boolean, onShuffleEnabled: (Boolean) -> Unit,
    visualizerStyle: String, onVisualizerStyle: (String) -> Unit,
    appTheme: String, onAppTheme: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.width(370.dp),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        shape = RoundedCornerShape(20.dp),
        containerColor = if (amoled) Color(0x80000000) else Color(0x8020252C),
        tonalElevation = 0.dp,
        title = {
            Text("Settings", color = MatteText, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        },
        text = {
            Column(Modifier.width(326.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                TvSettingRow("Background playback", "Keep radio playing when the app is in the background", backgroundPlayback, onBackgroundPlayback)
                TvSettingRow("Hide volume in full screen", "Only affects the full-screen visualizer", hideVolume, onHideVolume)
                TvSettingRow("Hide previous / next in full screen", "Only affects the full-screen visualizer", hideSkip, onHideSkip)
                TvSettingRow("Keep screen awake", "Prevent the TV screensaver while visible", keepScreenAwake, onKeepScreenAwake)
                TvSettingRow("Shuffle stations", "Play a random station; failed streams are skipped", shuffleEnabled, onShuffleEnabled)

                Spacer(Modifier.height(3.dp))
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Visualizer style", color = MatteText, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("Four audio-reactive looks. App theme remains independent.", color = MatteMuted, fontSize = 7.5.sp, maxLines = 1)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        TvVisualizerStyleChoice("NEBULA", visualizerStyle == "NEBULA", { onVisualizerStyle("NEBULA") }, 75.dp, 28.dp)
                        TvVisualizerStyleChoice("AURORA", visualizerStyle == "AURORA", { onVisualizerStyle("AURORA") }, 75.dp, 28.dp)
                        TvVisualizerStyleChoice("NEON", visualizerStyle == "NEON", { onVisualizerStyle("NEON") }, 75.dp, 28.dp)
                        TvVisualizerStyleChoice("STARFIELD", visualizerStyle == VISUALIZER_STARFIELD, { onVisualizerStyle(VISUALIZER_STARFIELD) }, 82.dp, 28.dp)
                    }
                }

                Spacer(Modifier.height(2.dp))
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("App theme", color = MatteText, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("Default or true-black AMOLED. Does not change the visualizer.", color = MatteMuted, fontSize = 7.5.sp, maxLines = 1)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TvVisualizerStyleChoice("DEFAULT", appTheme == "DEFAULT", { onAppTheme("DEFAULT") }, 92.dp, 28.dp)
                        TvVisualizerStyleChoice("AMOLED", appTheme == "AMOLED", { onAppTheme("AMOLED") }, 92.dp, 28.dp)
                    }
                }
            }
        },
        confirmButton = {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                TvVisualizerStyleChoice("DONE", true, onDismiss, 70.dp, 27.dp)
            }
        }
    )
}

@Composable
private fun TvSettingRow(
    title: String,
    description: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.height(31.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                title, color = MatteText, fontSize = 9.5.sp, lineHeight = 10.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false,
                overflow = TextOverflow.Clip
            )
            Text(
                description, color = MatteMuted, fontSize = 7.sp, lineHeight = 8.sp,
                maxLines = 1, softWrap = false, overflow = TextOverflow.Clip
            )
        }
        Box(
            Modifier.width(38.dp).height(21.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(if (checked) MatteTeal else Color(0xFF4A505A))
                .border(if (focused) 1.5.dp else 0.6.dp,
                    if (focused) Color.White else MatteLine, RoundedCornerShape(20.dp))
                .onFocusChanged { focused = it.isFocused }
                .clickable { onChecked(!checked) }
                .focusable(),
            contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                Modifier.padding(horizontal = 3.dp).size(15.dp)
                    .background(if (checked) Color(0xFF19353A) else Color(0xFFE5E7EA), CircleShape)
            )
        }
    }
}

@Composable
private fun TvSleepDialog(
    remaining: Int,
    selectedAction: String,
    onActionChange: (String) -> Unit,
    onSet: (Int) -> Unit,
    onCancelTimer: () -> Unit,
    onDismiss: () -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.width(350.dp),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        containerColor = if (amoled) Color.Black else Color(0xFF20252C),
        title = { Text("Sleep timer", color = MatteText, fontSize = 18.sp, fontWeight = FontWeight.Medium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (remaining > 0) "Current timer: ${formatTime(remaining)}" else "Choose what happens when the timer ends",
                    color = MatteMuted, fontSize = 10.sp
                )
                Text("AFTER TIMER", color = MatteTeal, fontSize = 8.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    TvVisualizerStyleChoice(
                        "STOP PLAYING", selectedAction == "STOP_PLAYING",
                        { onActionChange("STOP_PLAYING") }, 104.dp, 29.dp
                    )
                    TvVisualizerStyleChoice(
                        "EXIT APP", selectedAction == "EXIT_APP",
                        { onActionChange("EXIT_APP") }, 82.dp, 29.dp
                    )
                    TvVisualizerStyleChoice(
                        "TURN OFF TV", selectedAction == "TURN_OFF_TV",
                        { onActionChange("TURN_OFF_TV") }, 94.dp, 29.dp
                    )
                }
                Text(
                    "TV power-off depends on support from the TV firmware. Some models require the remote.",
                    color = MatteMuted, fontSize = 7.5.sp, lineHeight = 9.sp
                )
                Text("TIMER DURATION", color = MatteTeal, fontSize = 8.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(15, 30, 45, 60, 90).forEach { minutes ->
                        TextButton(
                            onClick = { onSet(minutes) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("${minutes}m", color = MatteTeal, fontSize = 11.sp)
                        }
                    }
                }
                if (remaining > 0) {
                    TextButton(onClick = onCancelTimer) {
                        Text("CANCEL TIMER", color = MattePink, fontSize = 9.sp, letterSpacing = 0.8.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("DONE", color = MatteMuted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
    )
}

private fun formatTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    return "%02d:%02d".format(safe / 60, safe % 60)
}
