package com.example.englishradio

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.view.KeyEvent
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.exp
import kotlin.math.ln
import java.util.concurrent.atomic.AtomicBoolean

private enum class TvPage { NOW_PLAYING, BROWSE, FAVORITES }

private val MatteInk = Color(0xFF11141B)
private val MatteCard = Color(0xFF20242D)
private val MatteLine = Color(0xFF484E59)
private val MatteText = Color(0xFFF4F3F2)
private val MatteMuted = Color(0xFFB6BAC2)
private val MatteTeal = Color(0xFF9BCFC6)
private val MattePink = Color(0xFFE7B9C9)
private val MatteMint = Color(0xFFB8DED4)
private val LocalTvAmoledTheme = compositionLocalOf { false }
private const val VISUALIZER_STARFIELD = "STARFIELD"

private data class StarfieldStar(
    val x: Float,
    val y: Float,
    val radius: Float,
    val color: Color,
    val twinklePhase: Float
)

private data class StarfieldBokeh(
    val x: Float,
    val y: Float,
    val radius: Float,
    val color: Color,
    val phase: Float
)

class TvActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var tvSleepScreenDimmed by mutableStateOf(false)
    private val preferences by lazy {
        getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        applyKeepScreenAwake(preferences.getBoolean("tv_keep_screen_awake", true))
        val artwork = runCatching { assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
        PlaybackService.configureStationQueue(stations, artwork)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({ runCatching { future.get() }.onSuccess { controller = it } }, ContextCompat.getMainExecutor(this))
        }
        setContent {
            Box(Modifier.fillMaxSize()) {
                TvRadioCherry(
                    player = controller,
                    onKeepScreenAwake = ::applyKeepScreenAwake,
                    onAppBrightness = ::applyAppBrightness,
                    onTurnOffTv = ::requestTvPowerOff,
                    onExit = ::exitApplication
                )
                if (tvSleepScreenDimmed) {
                    // Use a Compose overlay as well as a window brightness override:
                    // this still gives a true black app screen on TVs that ignore the
                    // per-window panel-brightness request.
                    Box(Modifier.fillMaxSize().background(Color.Black))
                }
            }
        }
    }

    private fun applyKeepScreenAwake(enabled: Boolean) {
        if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun applyAppBrightness(value: Float) {
        val attributes = window.attributes
        attributes.screenBrightness = value.coerceIn(0.05f, 1f)
        window.attributes = attributes
    }

    private fun requestTvPowerOff() {
        // A normally installed Android TV app cannot invoke system shutdown or HDMI-CEC
        // standby. Stop playback in the timer handler, release KEEP_SCREEN_ON, and blank
        // this activity. The TV firmware can then enter standby on its configured idle
        // timeout. A remote key or the next resume restores the app brightness.
        tvSleepScreenDimmed = true
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply {
            screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_OFF
        }
        window.decorView.setBackgroundColor(android.graphics.Color.BLACK)
    }

    private fun restoreAfterTvWake() {
        if (!tvSleepScreenDimmed) return
        tvSleepScreenDimmed = false
        window.attributes = window.attributes.apply {
            screenBrightness = preferences.getFloat("tv_app_brightness", 1f).coerceIn(0.05f, 1f)
        }
        applyKeepScreenAwake(preferences.getBoolean("tv_keep_screen_awake", true))
    }

    override fun onResume() {
        super.onResume()
        restoreAfterTvWake()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Some TV firmwares leave the activity resumed when the panel wakes. Restore
        // brightness on the first remote-key event as well as in onResume().
        if (tvSleepScreenDimmed && event.action == KeyEvent.ACTION_DOWN) {
            restoreAfterTvWake()
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onStop() {
        if (!preferences.getBoolean("tv_background_playback", true)) {
            controller?.let { active ->
                active.pause()
                active.clearMediaItems()
            }
        }
        super.onStop()
    }

    private fun exitApplication() {
        runCatching {
            controller?.pause()
            controller?.clearMediaItems()
            stopService(Intent(this, PlaybackService::class.java))
        }
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        finishAndRemoveTask()
        Handler(Looper.getMainLooper()).postDelayed({ Process.killProcess(Process.myPid()) }, 180L)
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

private data class TvAudioFrame(
    val waveform: FloatArray = FloatArray(64) { 0.012f },
    val spectrum: FloatArray = FloatArray(32) { 0.008f },
    val energy: Float = 0.012f
)

@Composable
private fun TvRadioCherry(
    player: MediaController?,
    onKeepScreenAwake: (Boolean) -> Unit,
    onAppBrightness: (Float) -> Unit,
    onTurnOffTv: () -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }
    var audioPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioPermission = it }
    // Stable holder: the root screen never reads .value. Only ReactiveVisualScene's
    // Canvas observes each frame, keeping controls/settings out of the audio redraw loop.
    val audioFrame = remember { mutableStateOf(TvAudioFrame()) }
    var page by remember { mutableStateOf(TvPage.NOW_PLAYING) }
    var fullScreen by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf(player?.currentMediaItem?.mediaId) }
    var playing by remember { mutableStateOf(player?.isPlaying == true) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet()) }
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("All") }
    var settingsOpen by remember { mutableStateOf(false) }
    var sleepDialogOpen by remember { mutableStateOf(false) }
    var sleepUntil by remember { mutableStateOf<Long?>(null) }
    var sleepRemaining by remember { mutableIntStateOf(0) }
    var sleepAction by remember { mutableStateOf(prefs.getString("tv_sleep_action", "STOP_PLAYING") ?: "STOP_PLAYING") }
    var shuffleEnabled by remember { mutableStateOf(prefs.getBoolean("tv_shuffle_enabled", false)) }
    var appBrightness by remember { mutableFloatStateOf(prefs.getFloat("tv_app_brightness", 1f).coerceIn(0.05f, 1f)) }
    var volume by remember { mutableFloatStateOf(prefs.getFloat("tv_volume", 0.72f).coerceIn(0f, 1f)) }
    val failedStationIds = remember { mutableSetOf<String>() }
    var fallbackInProgress by remember { mutableStateOf(false) }
    var connectionAttempt by remember { mutableIntStateOf(0) }
    var backgroundPlayback by remember { mutableStateOf(prefs.getBoolean("tv_background_playback", true)) }
    var hideVolume by remember { mutableStateOf(prefs.getBoolean("tv_hide_volume", false)) }
    var hideSkip by remember { mutableStateOf(prefs.getBoolean("tv_hide_previous_next", false)) }
    var keepScreenAwake by remember { mutableStateOf(prefs.getBoolean("tv_keep_screen_awake", true)) }
    val storedAppTheme = remember(prefs) {
        prefs.getString(
            "tv_app_theme",
            if (prefs.getBoolean("tv_theme_amoled", false)) "AMOLED" else "DEFAULT"
        ) ?: "DEFAULT"
    }
    // Theme is intentionally limited to the two application-wide palettes.
    // Migrate the earlier experimental NEON app theme into the visualizer style.
    var appTheme by remember {
        mutableStateOf(if (storedAppTheme == "AMOLED") "AMOLED" else "DEFAULT")
    }
    var visualizerStyle by remember {
        mutableStateOf(
            prefs.getString("tv_visualizer_style", null) ?: when {
                storedAppTheme == "NEON" || prefs.getBoolean("tv_theme_neon", false) -> "NEON"
                prefs.contains("tv_visualizer_darker") && prefs.getBoolean("tv_visualizer_darker", false) -> "NEBULA"
                prefs.contains("tv_visualizer_darker") -> "AURORA"
                else -> "NEBULA"
            }
        )
    }
    val amoledTheme = appTheme == "AMOLED"
    var visualizerChromeVisible by remember { mutableStateOf(true) }
    var visualizerActivityRevision by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("CHOOSE A STATION TO BEGIN") }
    val scope = rememberCoroutineScope()
    val selected = stations.firstOrNull { it.id == selectedId }
    val visibleStations = remember(page, search, selectedGenre, favorites) {
        val base = if (page == TvPage.FAVORITES) stations.filter { it.id in favorites } else stations
        base.filter { station ->
            val matchesSearch = search.isBlank() ||
                station.name.contains(search, true) || station.genre.contains(search, true) ||
                station.broadcaster.contains(search, true) || station.category.contains(search, true)
            val text = "${station.category} ${station.genre} ${station.name}".lowercase()
            val matchesGenre = selectedGenre == "All" || when (selectedGenre) {
                "Ambient" -> text.contains("ambient") || text.contains("chill") || text.contains("downtempo")
                "Electronic" -> text.contains("electronic") || text.contains("dance") || text.contains("house")
                "Indie" -> text.contains("indie") || text.contains("alternative") || text.contains("rock")
                "80s" -> text.contains("80") || text.contains("new wave") || text.contains("throwback")
                "Classical" -> text.contains("classical") || text.contains("instrumental") || text.contains("orchestra")
                "Sleep" -> text.contains("sleep") || text.contains("nature") || text.contains("soundscape")
                "Nature" -> text.contains("nature") || text.contains("field recording") || text.contains("bird")
                "Jazz" -> text.contains("jazz")
                else -> true
            }
            matchesSearch && matchesGenre
        }
    }

    LaunchedEffect(Unit) {
        if (!audioPermission) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(keepScreenAwake) {
        prefs.edit().putBoolean("tv_keep_screen_awake", keepScreenAwake).apply()
        onKeepScreenAwake(keepScreenAwake)
    }

    LaunchedEffect(visualizerStyle) {
        prefs.edit()
            .putString("tv_visualizer_style", visualizerStyle)
            // Retain the legacy value for downgrade compatibility.
            .putBoolean("tv_visualizer_darker", visualizerStyle == "NEBULA")
            .apply()
    }

    LaunchedEffect(appTheme) {
        prefs.edit()
            .putString("tv_app_theme", appTheme)
            .putBoolean("tv_theme_amoled", appTheme == "AMOLED")
            .remove("tv_theme_neon")
            .apply()
    }

    LaunchedEffect(fullScreen, visualizerActivityRevision) {
        if (!fullScreen) {
            visualizerChromeVisible = true
        } else {
            delay(60_000L)
            visualizerChromeVisible = false
        }
    }

    LaunchedEffect(backgroundPlayback, hideVolume, hideSkip) {
        prefs.edit()
            .putBoolean("tv_background_playback", backgroundPlayback)
            .putBoolean("tv_hide_volume", hideVolume)
            .putBoolean("tv_hide_previous_next", hideSkip)
            .apply()
    }

    LaunchedEffect(player, playing, audioPermission) {
        audioFrame.value = TvAudioFrame()
        if (!audioPermission || player == null || !playing) return@LaunchedEffect
        var sessionId = PlaybackService.currentAudioSessionId
        repeat(20) {
            if (sessionId <= 0) {
                delay(120)
                sessionId = PlaybackService.currentAudioSessionId
            }
        }
        if (sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        val mainHandler = Handler(Looper.getMainLooper())
        val frameLock = Any()
        var latestWaveform = FloatArray(64) { 0.012f }
        var latestSpectrum = FloatArray(32) { 0.008f }
        var latestEnergy = 0.012f
        val framePublishPending = AtomicBoolean(false)
        lateinit var publishFrame: Runnable

        // The waveform and FFT callbacks are delivered as a pair. Do not throttle
        // them independently: the old shared timestamp often discarded every FFT
        // callback, leaving all frequency bands at their startup values. Coalesce
        // both into one short delayed UI publish instead.
        publishFrame = Runnable {
            framePublishPending.set(false)
            val snapshot = synchronized(frameLock) {
                Triple(latestWaveform.clone(), latestSpectrum.clone(), latestEnergy)
            }
            audioFrame.value = TvAudioFrame(snapshot.first, snapshot.second, snapshot.third)
        }
        fun publishLatestAudioFrame() {
            if (framePublishPending.compareAndSet(false, true)) {
                mainHandler.postDelayed(publishFrame, 50L)
            }
        }

        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    if (bytes.isEmpty()) return
                    val samples = FloatArray(64) { i ->
                        val index = (i * (bytes.size - 1) / 63).coerceIn(0, bytes.lastIndex)
                        abs((bytes[index].toInt() and 0xFF) - 128) / 128f
                    }
                    var squareTotal = 0f
                    for (sample in bytes) {
                        val centered = ((sample.toInt() and 0xFF) - 128) / 128f
                        squareTotal += centered * centered
                    }
                    val rawLevel = (sqrt(squareTotal / bytes.size) * 2.65f).coerceIn(0.012f, 1f)
                    synchronized(frameLock) {
                        for (i in samples.indices) {
                            samples[i] = samples[i] * 0.72f + latestWaveform[i] * 0.28f
                        }
                        latestWaveform = samples
                        latestEnergy = latestEnergy * 0.56f + rawLevel * 0.44f
                    }
                    publishLatestAudioFrame()
                }

                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) {
                    val maxBin = (fft.size / 2 - 1).coerceAtLeast(1)
                    if (maxBin < 2) return
                    val bands = FloatArray(32) { index ->
                        val startFraction = index / 32f
                        val endFraction = (index + 1) / 32f
                        val startBin = exp(ln(maxBin.toFloat()) * startFraction).toInt().coerceAtLeast(1)
                        val endBin = exp(ln(maxBin.toFloat()) * endFraction).toInt()
                            .coerceAtLeast(startBin).coerceAtMost(maxBin)
                        var magnitudeTotal = 0f
                        var count = 0
                        for (bin in startBin..endBin) {
                            val real = fft[2 * bin].toInt().toFloat()
                            val imaginary = fft[2 * bin + 1].toInt().toFloat()
                            magnitudeTotal += sqrt(real * real + imaginary * imaginary)
                            count++
                        }
                        (magnitudeTotal / count.coerceAtLeast(1) / 78f).coerceIn(0f, 1f)
                    }
                    synchronized(frameLock) {
                        for (i in bands.indices) {
                            bands[i] = latestSpectrum[i] * 0.42f + bands[i] * 0.58f
                        }
                        latestSpectrum = bands
                    }
                    publishLatestAudioFrame()
                }
            }, Visualizer.getMaxCaptureRate().coerceAtMost(20_000), true, true)
            visualizer.enabled = true
            kotlinx.coroutines.awaitCancellation()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
        } finally {
            mainHandler.removeCallbacks(publishFrame)
            framePublishPending.set(false)
            runCatching { visualizer.enabled = false; visualizer.release() }
        }
    }

    suspend fun playStation(
        station: Station,
        keepVisualizerOpen: Boolean = false,
        automaticFallback: Boolean = false
    ) {
        val active = player ?: return
        if (!automaticFallback) failedStationIds.clear()
        failedStationIds.add(station.id)
        fallbackInProgress = false
        connectionAttempt++
        selectedId = station.id
        status = "CONNECTING TO STATION…"
        val resolved = withContext(Dispatchers.IO) {
            runCatching { PlaylistResolver.resolve(station.stream) }.getOrDefault(station.stream)
        }
        active.setMediaItem(PlaybackService.mediaItem(station.copy(stream = resolved), orbArtwork))
        active.prepare()
        active.play()
        if (!keepVisualizerOpen) {
            page = TvPage.NOW_PLAYING
            fullScreen = false
        }
    }

    fun stopPlayback() {
        val active = player ?: return
        active.pause()
        active.stop()
        playing = false
        status = "STOPPED"
    }

    fun startAutomaticFallback() {
        if (fallbackInProgress) return
        val failedId = selectedId ?: player?.currentMediaItem?.mediaId
        if (failedId != null) failedStationIds.add(failedId)

        val candidate = if (shuffleEnabled) {
            stations.filterNot { it.id in failedStationIds }.randomOrNull()
        } else {
            val currentIndex = stations.indexOfFirst { it.id == failedId }.let { if (it < 0) 0 else it }
            (1..stations.size)
                .asSequence()
                .map { offset -> stations[(currentIndex + offset) % stations.size] }
                .firstOrNull { it.id !in failedStationIds }
        }

        if (candidate == null) {
            status = "NO WORKING STATIONS FOUND"
            playing = false
            fallbackInProgress = false
            return
        }

        fallbackInProgress = true
        status = "STATION UNAVAILABLE · TRYING ${candidate.name.uppercase()}…"
        scope.launch {
            delay(180L)
            try {
                playStation(candidate, keepVisualizerOpen = fullScreen, automaticFallback = true)
            } finally {
                fallbackInProgress = false
            }
        }
    }

    fun stepStation(direction: Int) {
        val current = selected
        val next = if (shuffleEnabled) {
            stations.filter { current == null || it.id != current.id }.randomOrNull()
        } else {
            if (current == null) {
                stations.firstOrNull()
            } else {
                // Normal previous/next stays within the current station's primary genre.
                val activeGenre = current.genre.substringBefore("·").trim()
                val sameGenreStations = stations.filter { station ->
                    station.genre.substringBefore("·").trim().equals(activeGenre, ignoreCase = true)
                }
                val group = sameGenreStations.ifEmpty { listOf(current) }
                val index = group.indexOfFirst { it.id == selectedId }
                val nextIndex = if (index < 0) 0 else (index + direction + group.size) % group.size
                group.getOrNull(nextIndex)
            }
        } ?: return
        scope.launch { playStation(next, keepVisualizerOpen = fullScreen) }
    }

    fun togglePlayback() {
        val active = player ?: return
        if (active.isPlaying) {
            active.pause()
        } else if (active.mediaItemCount > 0) {
            if (active.playbackState == Player.STATE_IDLE || active.playbackState == Player.STATE_ENDED) {
                active.prepare()
            }
            active.play()
        } else {
            val start = selected ?: if (shuffleEnabled) stations.random() else stations.first()
            scope.launch { playStation(start, keepVisualizerOpen = fullScreen) }
        }
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isNowPlaying: Boolean) {
                playing = isNowPlaying
                status = if (isNowPlaying) "ON AIR  ·  LIVE STREAM" else if (status == "STOPPED") "STOPPED" else "PAUSED"
                if (isNowPlaying) fallbackInProgress = false
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
            }

            override fun onPlaybackStateChanged(state: Int) {
                status = when (state) {
                    Player.STATE_BUFFERING -> "CONNECTING TO STATION…"
                    Player.STATE_READY -> if (player.isPlaying) "ON AIR  ·  LIVE STREAM" else if (status == "STOPPED") "STOPPED" else "READY TO PLAY"
                    Player.STATE_IDLE -> if (player.mediaItemCount > 0) "STOPPED" else "CHOOSE A STATION TO BEGIN"
                    Player.STATE_ENDED -> "STREAM ENDED · FINDING ANOTHER STATION…"
                    else -> status
                }
                if (state == Player.STATE_ENDED) startAutomaticFallback()
            }

            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                val erroredId = player.currentMediaItem?.mediaId
                if (erroredId != null && selectedId != null && erroredId != selectedId) return
                status = "STREAM UNAVAILABLE · TRYING ANOTHER STATION…"
                startAutomaticFallback()
            }
        }
        player.addListener(listener)
        selectedId = player.currentMediaItem?.mediaId
        playing = player.isPlaying
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(connectionAttempt, player, playing, status) {
        val attempt = connectionAttempt
        if (selectedId == null || playing ||
            !(status.startsWith("CONNECTING") || status == "READY TO PLAY")
        ) return@LaunchedEffect

        delay(18_000L)
        if (attempt == connectionAttempt && !playing &&
            (status.startsWith("CONNECTING") || status == "READY TO PLAY")
        ) {
            status = "CONNECTION TIMEOUT · TRYING ANOTHER STATION…"
            startAutomaticFallback()
        }
    }

    LaunchedEffect(favorites) {
        prefs.edit().putStringSet("favorite_station_ids", favorites).apply()
    }

    LaunchedEffect(player, volume) {
        player?.volume = volume
        prefs.edit().putFloat("tv_volume", volume).apply()
    }

    LaunchedEffect(shuffleEnabled) {
        prefs.edit().putBoolean("tv_shuffle_enabled", shuffleEnabled).apply()
    }

    LaunchedEffect(sleepAction) {
        prefs.edit().putString("tv_sleep_action", sleepAction).apply()
    }

    LaunchedEffect(appBrightness) {
        prefs.edit().putFloat("tv_app_brightness", appBrightness).apply()
        onAppBrightness(appBrightness)
    }

    LaunchedEffect(sleepUntil, sleepAction) {
        val deadline = sleepUntil ?: return@LaunchedEffect
        while (true) {
            val remaining = ((deadline - System.currentTimeMillis()) / 1000L).toInt()
            if (remaining <= 0) {
                sleepUntil = null
                sleepRemaining = 0
                when (sleepAction) {
                    "EXIT_APP" -> {
                        player?.pause()
                        player?.clearMediaItems()
                        status = "SLEEP TIMER · EXITING APP"
                        onExit()
                    }
                    "TURN_OFF_TV" -> {
                        player?.pause()
                        player?.clearMediaItems()
                        status = "SLEEP TIMER · TV DISPLAY SLEEP REQUESTED"
                        onTurnOffTv()
                    }
                    else -> {
                        stopPlayback()
                        status = "SLEEP TIMER · PLAYBACK STOPPED"
                    }
                }
                break
            }
            sleepRemaining = remaining
            delay(1000)
        }
    }

    fun toggleFavorite(station: Station) {
        favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
    }

    // Keep fullscreen controls visible after any remote-key or visualizer interaction.
    // Incrementing the revision restarts the inactivity timer in the effect above.
    fun registerVisualizerActivity() {
        visualizerChromeVisible = true
        visualizerActivityRevision++
    }

    BackHandler(enabled = fullScreen || settingsOpen || sleepDialogOpen || page != TvPage.NOW_PLAYING) {
        when {
            sleepDialogOpen -> sleepDialogOpen = false
            settingsOpen -> settingsOpen = false
            fullScreen -> fullScreen = false
            page != TvPage.NOW_PLAYING -> page = TvPage.NOW_PLAYING
        }
    }

    CompositionLocalProvider(LocalTvAmoledTheme provides amoledTheme) {
      MaterialTheme {
        Box(
            Modifier.fillMaxSize()
                .background(if (amoledTheme) Color.Black else MatteInk)
                .onPreviewKeyEvent { event ->
                    if (fullScreen && event.type == KeyEventType.KeyDown) registerVisualizerActivity()
                    false
                }
        ) {
            if (fullScreen) {
                TvFullScreenVisualizer(
                    selected = selected, playing = playing, status = status,
                    audioFrame = audioFrame,
                    visualizerStyle = visualizerStyle,
                    chromeVisible = visualizerChromeVisible,
                    onUserActivity = ::registerVisualizerActivity,
                    hideSkip = hideSkip, hideVolume = hideVolume, volume = volume,
                    favorite = selected?.id?.let { it in favorites } == true,
                    sleepRemaining = sleepRemaining,
                    appBrightness = appBrightness, onAppBrightness = { appBrightness = it },
                    onBack = { fullScreen = false }, onPlayPause = ::togglePlayback, onStopPlayback = ::stopPlayback,
                    onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                    onFavorite = { selected?.let(::toggleFavorite) },
                    onVolume = { volume = it }, onSleep = { sleepDialogOpen = true },
                    onSettings = { settingsOpen = true }, onExit = onExit
                )
            } else {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 27.dp),
                    horizontalArrangement = Arrangement.spacedBy(34.dp)
                ) {
                    TvSidebar(
                        page = page,
                        onPage = { page = it; if (it != TvPage.BROWSE) { search = ""; selectedGenre = "All" } },
                        onSettings = { settingsOpen = true }, onExit = onExit
                    )
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        when (page) {
                            TvPage.NOW_PLAYING -> TvNowPlaying(
                                selected = selected, playing = playing, status = status,
                                audioFrame = audioFrame,
                                visualizerStyle = visualizerStyle,
                                volume = volume, favorite = selected?.id?.let { it in favorites } == true,
                                sleepRemaining = sleepRemaining,
                                onPlayPause = ::togglePlayback, onStopPlayback = ::stopPlayback,
                                onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                                onFavorite = { selected?.let(::toggleFavorite) },
                                onVolume = { volume = it },
                                onBrowse = { page = TvPage.BROWSE },
                                onFullscreen = { fullScreen = true },
                                onSleep = { sleepDialogOpen = true }
                            )
                            TvPage.BROWSE, TvPage.FAVORITES -> TvBrowsePage(
                                isFavorites = page == TvPage.FAVORITES,
                                stations = visibleStations, totalCount = if (page == TvPage.BROWSE) stations.size else visibleStations.size,
                                selectedId = selectedId, favorites = favorites,
                                search = search, onSearch = { search = it },
                                selectedGenre = selectedGenre, onGenre = { selectedGenre = it },
                                onSelect = { station -> scope.launch { playStation(station) } },
                                onFavorite = ::toggleFavorite
                            )
                        }
                    }
                }
            }

            if (settingsOpen) {
                TvSettingsDialog(
                    backgroundPlayback = backgroundPlayback, onBackgroundPlayback = { backgroundPlayback = it },
                    hideVolume = hideVolume, onHideVolume = { hideVolume = it },
                    hideSkip = hideSkip, onHideSkip = { hideSkip = it },
                    keepScreenAwake = keepScreenAwake, onKeepScreenAwake = { keepScreenAwake = it },
                    shuffleEnabled = shuffleEnabled, onShuffleEnabled = { shuffleEnabled = it },
                    visualizerStyle = visualizerStyle, onVisualizerStyle = { visualizerStyle = it },
                    appTheme = appTheme, onAppTheme = { appTheme = it },
                    onDismiss = { settingsOpen = false }
                )
            }

            if (sleepDialogOpen) {
                TvSleepDialog(
                    remaining = sleepRemaining,
                    selectedAction = sleepAction,
                    onActionChange = { sleepAction = it },
                    onSet = { minutes -> sleepUntil = System.currentTimeMillis() + minutes * 60_000L; sleepDialogOpen = false },
                    onCancelTimer = { sleepUntil = null; sleepRemaining = 0; sleepDialogOpen = false },
                    onDismiss = { sleepDialogOpen = false }
                )
            }
        }
      }
    }
}

@Composable
private fun TvSidebar(
    page: TvPage, onPage: (TvPage) -> Unit, onSettings: () -> Unit, onExit: () -> Unit
) {
    val initialFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { initialFocus.requestFocus() }
    Column(Modifier.width(205.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("radio", color = MatteText, fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 1.7.sp)
                Text("cherry", color = MattePink, fontSize = 27.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
            }
            Spacer(Modifier.height(10.dp))
            TvNavItem("NOW PLAYING", page == TvPage.NOW_PLAYING, { onPage(TvPage.NOW_PLAYING) }, Icons.Default.Radio, Modifier.focusRequester(initialFocus))
            TvNavItem("BROWSE", page == TvPage.BROWSE, { onPage(TvPage.BROWSE) }, Icons.Default.Explore)
            TvNavItem("FAVOURITES", page == TvPage.FAVORITES, { onPage(TvPage.FAVORITES) }, Icons.Default.Favorite)
        }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("INTERNET RADIO", color = Color(0xFF858B95), fontSize = 10.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 5.dp, bottom = 5.dp))
            TvUtilityButton("SETTINGS", onSettings, Icons.Default.Settings)
            TvUtilityButton("EXIT APP", onExit, Icons.Default.Close, accent = false)
        }
    }
}

@Composable
private fun TvNavItem(
    label: String, selected: Boolean, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    val selectedBrush = Brush.horizontalGradient(listOf(MatteTeal, MattePink))
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(brush = if (selected) selectedBrush else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else if (selected) Color.Transparent else MatteLine, RoundedCornerShape(14.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (selected) MatteInk else MatteMuted, modifier = Modifier.size(19.dp))
        Text(label, color = if (selected) MatteInk else MatteText, fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvUtilityButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Boolean = true
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (focused) if (amoled) Color(0xFF141414) else Color(0xFF2A3038) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (accent) MatteTeal else MatteMuted, modifier = Modifier.size(17.dp))
        Text(label, color = MatteMuted, fontSize = 10.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvNowPlaying(
    selected: Station?, playing: Boolean, status: String,
    audioFrame: State<TvAudioFrame>, visualizerStyle: String,
    volume: Float, favorite: Boolean, sleepRemaining: Int,
    onPlayPause: () -> Unit, onStopPlayback: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit,
    onBrowse: () -> Unit, onFullscreen: () -> Unit, onSleep: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("NOW PLAYING", color = MatteTeal, fontSize = 10.sp, letterSpacing = 2.5.sp, fontWeight = FontWeight.SemiBold)
            TvSmallTextButton("FULL SCREEN VISUALIZER", onFullscreen, Icons.Default.Fullscreen)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(278.dp).clip(RoundedCornerShape(20.dp))) {
            ReactiveVisualScene(audioFrame, Modifier.fillMaxSize(), fullScreen = false, style = visualizerStyle)
        }
        Spacer(Modifier.height(17.dp))
        Text("radio cherry LIVE", color = Color(0xFFE9EEF0), fontSize = 13.sp,
            fontWeight = FontWeight.Medium, letterSpacing = 1.1.sp)
        Spacer(Modifier.height(4.dp))
        Text(selected?.name ?: "Choose a station to begin",
            color = MatteText, fontSize = 29.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(5.dp))
        Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Discover more than 200 stations from around the world",
            color = Color(0xFFD7DCE0), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Text(status, color = Color(0xFFC4E6DD), fontSize = 11.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.SemiBold)
        if (sleepRemaining > 0) {
            Text("SLEEP TIMER  ·  ${formatTime(sleepRemaining)}", color = MattePink, fontSize = 10.sp,
                letterSpacing = 1.3.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(17.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            TvRoundControl(Icons.Default.SkipPrevious, "PREVIOUS", onPrevious)
            TvRoundControl(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "PAUSE" else "PLAY", onPlayPause, primary = true)
            TvRoundControl(Icons.Default.Stop, "STOP", onStopPlayback)
            TvRoundControl(Icons.Default.SkipNext, "NEXT", onNext)
            TvRoundControl(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "FAVOURITE", onFavorite)
            Spacer(Modifier.width(4.dp))
            TvPillButton(if (sleepRemaining > 0) "SLEEP ${formatTime(sleepRemaining)}" else "SLEEP TIMER", onSleep, Icons.Default.Timer)
            TvPillButton("BROWSE", onBrowse, Icons.Default.Explore)
            Spacer(Modifier.weight(1f))
            TvVolumeControl(volume = volume, onValue = onVolume, compact = true, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA")
        }
    }
}

@Composable
private fun TvBrowsePage(
    isFavorites: Boolean, stations: List<Station>, totalCount: Int,
    selectedId: String?, favorites: Set<String>, search: String, onSearch: (String) -> Unit,
    selectedGenre: String, onGenre: (String) -> Unit,
    onSelect: (Station) -> Unit, onFavorite: (Station) -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    val genres = listOf("All", "Ambient", "Electronic", "Indie", "80s", "Classical", "Sleep", "Nature", "Jazz")
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
            Column(horizontalAlignment = Alignment.End) {
                Text(if (isFavorites) "Your favourites" else "Explore stations", color = MatteText, fontSize = 30.sp, fontWeight = FontWeight.Light)
                Text("$totalCount STATIONS", color = MatteMuted, fontSize = 10.sp, letterSpacing = 2.sp,
                    modifier = Modifier.padding(top = 5.dp))
            }
        }
        Spacer(Modifier.height(17.dp))
        if (!isFavorites) {
            OutlinedTextField(
                value = search, onValueChange = onSearch,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                singleLine = true, shape = RoundedCornerShape(15.dp),
                placeholder = { Text("Search stations...", color = MatteMuted, fontSize = 14.sp) },
                leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Search, null, tint = MatteTeal) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MatteText, unfocusedTextColor = MatteText,
                    focusedBorderColor = MatteTeal, unfocusedBorderColor = MatteLine,
                    cursorColor = MatteTeal, focusedContainerColor = if (amoled) Color.Black else Color(0xFF1B2027),
                    unfocusedContainerColor = if (amoled) Color.Black else Color(0xFF1B2027)
                )
            )
            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                genres.forEach { genre -> TvGenreChip(genre, selectedGenre == genre, { onGenre(genre) }) }
            }
            Spacer(Modifier.height(13.dp))
        }
        if (stations.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (isFavorites) "No favourites yet. Save stations with the heart." else "No stations match your search.",
                    color = MatteMuted, fontSize = 16.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(stations, key = { it.id }) { station ->
                    TvStationRow(
                        station = station, active = station.id == selectedId,
                        favorite = station.id in favorites,
                        onClick = { onSelect(station) }, onFavorite = { onFavorite(station) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TvGenreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Box(
        Modifier.clip(RoundedCornerShape(30.dp))
            .background(if (selected) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(if (amoled) Color(0xFF050505) else Color(0xFF282D35), if (amoled) Color(0xFF050505) else Color(0xFF282D35))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color.Transparent, RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) MatteInk else MatteText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvStationRow(
    station: Station, active: Boolean, favorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(15.dp))
            .background(if (active) Brush.horizontalGradient(listOf(Color(0xFF293A3B), Color(0xFF38313A))) else Brush.horizontalGradient(listOf(if (amoled) Color(0xFF050505) else MatteCard, if (amoled) Color(0xFF050505) else MatteCard)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(15.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(station.name, color = MatteText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${station.genre}  ·  ${station.broadcaster}", color = MatteMuted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        }
        if (active) Text("ON AIR", color = MatteTeal, fontSize = 9.sp, letterSpacing = 1.4.sp,
            modifier = Modifier.padding(end = 18.dp))
        TvFavoriteButton(
            selected = favorite, onClick = onFavorite
        )
    }
}

@Composable
private fun TvFavoriteButton(selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(if (focused) Color(0xFF3B3940) else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(if (selected) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favourite", tint = if (selected) MattePink else MatteMuted, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun TvFullScreenVisualizer(
    selected: Station?, playing: Boolean, status: String,
    audioFrame: State<TvAudioFrame>, visualizerStyle: String,
    chromeVisible: Boolean, onUserActivity: () -> Unit,
    hideSkip: Boolean, hideVolume: Boolean,
    volume: Float, favorite: Boolean, sleepRemaining: Int,
    appBrightness: Float, onAppBrightness: (Float) -> Unit,
    onBack: () -> Unit, onPlayPause: () -> Unit, onStopPlayback: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit, onSleep: () -> Unit,
    onSettings: () -> Unit, onExit: () -> Unit
) {
    val controlAlpha by animateFloatAsState(
        targetValue = if (chromeVisible) 0.88f else 0.0f,
        animationSpec = tween(750), label = "visualizer-control-idle-alpha"
    )
    var brightnessPanelOpen by remember { mutableStateOf(false) }
    // Only interactive chrome fades after inactivity. Station identity and the
    // entire audio-reactive scene remain fully visible at all times.
    val backFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { backFocus.requestFocus() }
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val metadataTop = maxHeight * 0.815f
        ReactiveVisualScene(audioFrame, Modifier.fillMaxSize(), fullScreen = true, style = visualizerStyle)

        TvIconButton(
            icon = Icons.Default.ArrowBack,
            description = "Back to normal mode",
            onClick = { onUserActivity(); onBack() },
            modifier = Modifier.align(Alignment.TopEnd)
                .padding(end = 22.dp, top = 16.dp).graphicsLayer(alpha = controlAlpha),
            buttonSize = 30.dp, iconSize = 16.dp, onFocusActivity = onUserActivity,
            neon = visualizerStyle == "NEON"
        )
        TvIconButton(
            icon = Icons.Default.Settings,
            description = "Settings",
            onClick = { onUserActivity(); onSettings() },
            modifier = Modifier.align(Alignment.TopStart)
                .padding(start = 22.dp, top = 16.dp).graphicsLayer(alpha = controlAlpha),
            buttonSize = 25.dp, iconSize = 12.dp, onFocusActivity = onUserActivity,
            neon = visualizerStyle == "NEON"
        )

        if (brightnessPanelOpen) {
            Row(
                Modifier.align(Alignment.BottomCenter)
                    .padding(bottom = 66.dp)
                    .graphicsLayer(alpha = controlAlpha)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (visualizerStyle == "NEON") Color(0xE5080A1F) else Color(0xB8121720))
                    .border(0.8.dp, if (visualizerStyle == "NEON") Color(0xAA8B5CF6) else Color(0x667E9AA0), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 5.dp)
                    .width(250.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                androidx.compose.material3.Icon(
                    Icons.Default.Brightness6, null,
                    tint = if (visualizerStyle == "NEON") Color(0xFFC4B5FD) else MatteText,
                    modifier = Modifier.size(14.dp)
                )
                Text("APP LIGHT", color = if (visualizerStyle == "NEON") Color(0xFF93C5FD) else MatteMuted, fontSize = 8.sp, letterSpacing = 0.7.sp)
                Slider(
                    value = appBrightness,
                    onValueChange = { onUserActivity(); onAppBrightness(it) },
                    valueRange = 0.05f..1f,
                    colors = SliderDefaults.colors(
                        thumbColor = if (visualizerStyle == "NEON") Color(0xFF8B5CF6) else MatteTeal,
                        activeTrackColor = if (visualizerStyle == "NEON") Color(0xFF3B82F6) else MatteTeal,
                        inactiveTrackColor = if (visualizerStyle == "NEON") Color(0x665A55A6) else Color(0x667C858B)
                    ),
                    modifier = Modifier.weight(1f).height(24.dp)
                        .onPreviewKeyEvent { event ->
                            if (event.type == KeyEventType.KeyDown) {
                                when (event.key) {
                                    Key.DirectionLeft -> {
                                        onUserActivity()
                                        onAppBrightness((appBrightness - 0.05f).coerceAtLeast(0.05f))
                                        true
                                    }
                                    Key.DirectionRight -> {
                                        onUserActivity()
                                        onAppBrightness((appBrightness + 0.05f).coerceAtMost(1f))
                                        true
                                    }
                                    else -> false
                                }
                            } else false
                        }.focusable()
                )
                Text("${(appBrightness * 100).toInt()}%", color = if (visualizerStyle == "NEON") Color(0xFFC4B5FD) else MatteText, fontSize = 8.sp)
            }
        }

        Column(
            Modifier.align(Alignment.TopCenter)
                .fillMaxWidth(0.76f)
                .offset(y = metadataTop)
                .graphicsLayer {
                    val energy = audioFrame.value.energy.coerceIn(0f, 1f)
                    alpha = 0.88f + energy * 0.12f
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // BoxWithConstraints is used below to place this stack beyond the ring field.
            Text(
                "radio cherry LIVE",
                color = when {
                    visualizerStyle == "NEON" -> Color(0xFFE9D5FF)
                    visualizerStyle == VISUALIZER_STARFIELD -> Color(0xFFE7E5EF)
                    visualizerStyle == "NEBULA" -> Color(0xFFFFE5F5)
                    else -> Color(0xFFF4F6F7)
                },
                fontSize = 8.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.8.sp
            )
            Text(
                selected?.name ?: "Choose a station",
                color = Color(0xFFFFEAF7), fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Internet radio",
                color = Color(0xFFE9C9F0), fontSize = 8.5.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (playing) "ON AIR · LIVE STREAM" else status,
                color = Color(0xFFD0EEE5), fontSize = 7.5.sp, letterSpacing = 1.1.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (sleepRemaining > 0) Text(
                "SLEEP TIMER · ${formatTime(sleepRemaining)}",
                color = Color(0xFFF0BFE8), fontSize = 7.sp, letterSpacing = 0.8.sp
            )
        }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 17.dp)
                .graphicsLayer(alpha = controlAlpha),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!hideSkip) TvMiniVisualizerButton(Icons.Default.SkipPrevious, "Previous station", { onUserActivity(); onPrevious() }, onUserActivity, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA")
            TvMiniVisualizerButton(
                if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                if (playing) "Pause" else "Play",
                { onUserActivity(); brightnessPanelOpen = false; onPlayPause() }, onUserActivity,
                primary = true, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA", audioFrame = audioFrame
            )
            TvMiniVisualizerButton(Icons.Default.Stop, "Stop playback", { onUserActivity(); onStopPlayback() }, onUserActivity, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA")
            if (!hideSkip) TvMiniVisualizerButton(Icons.Default.SkipNext, "Next station", { onUserActivity(); onNext() }, onUserActivity, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA")
            TvMiniVisualizerButton(
                if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "Favourite", { onUserActivity(); onFavorite() }, onUserActivity, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA"
            )
            TvMiniVisualizerButton(Icons.Default.Timer, "Sleep timer", { onUserActivity(); onSleep() }, onUserActivity, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA")
            TvMiniVisualizerButton(
                Icons.Default.Brightness6,
                "App brightness",
                { onUserActivity(); brightnessPanelOpen = !brightnessPanelOpen },
                onUserActivity,
                neon = visualizerStyle == "NEON",
                starfield = visualizerStyle == VISUALIZER_STARFIELD,
                nebula = visualizerStyle == "NEBULA",
            )
            if (!hideVolume) {
                TvVolumeControl(volume = volume, onValue = { onUserActivity(); onVolume(it) }, compact = true, miniVisualizer = true, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA")
            }
            TvMiniVisualizerButton(Icons.Default.Close, "Exit app", { onUserActivity(); onExit() }, onUserActivity, neon = visualizerStyle == "NEON", starfield = visualizerStyle == VISUALIZER_STARFIELD, nebula = visualizerStyle == "NEBULA")
        }
    }
}

@Composable
private fun TvMiniVisualizerButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    onFocusActivity: () -> Unit,
    primary: Boolean = false,
    neon: Boolean = false,
    starfield: Boolean = false,
    nebula: Boolean = false,
    audioFrame: State<TvAudioFrame>? = null
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(27.dp)
            .graphicsLayer {
                val energy = audioFrame?.value?.energy?.coerceIn(0f, 1f) ?: 0f
                val pulse = 1f + energy * 0.016f
                scaleX = pulse
                scaleY = pulse
            }
            .clip(CircleShape)
            .background(
                if (primary && neon) Brush.linearGradient(listOf(Color(0xFF4338CA), Color(0xFF7C3AED), Color(0xFF3B82F6)))
                else if (primary && starfield) Brush.linearGradient(listOf(Color(0xFF2DD4BF).copy(alpha = 0.78f), Color(0xFFA78BFA).copy(alpha = 0.76f), Color(0xFFF472B6).copy(alpha = 0.78f)))
                else if (primary && nebula) Brush.linearGradient(listOf(Color(0xFF6D28D9).copy(alpha = 0.82f), Color(0xFFD946EF).copy(alpha = 0.78f), Color(0xFFF472B6).copy(alpha = 0.82f)))
                else if (primary) Brush.linearGradient(listOf(MatteTeal.copy(alpha = 0.82f), MattePink.copy(alpha = 0.82f)))
                else if (starfield) Brush.linearGradient(listOf(Color(0xAA061010), Color(0xAA120A12)))
                else if (nebula) Brush.linearGradient(listOf(Color(0xAA160D24), Color(0xAA210D29)))
                else Brush.linearGradient(listOf(Color(0x77333D49), Color(0x77333D49)))
            )
            .border(if (focused) 1.3.dp else 0.7.dp,
                if (focused) Color.White else if (neon) Color(0xCC8B5CF6) else if (starfield) Color(0x665D9D94) else if (nebula) Color(0x887C3AED) else Color(0x667A8990), CircleShape)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocusActivity() }
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            imageVector = icon, contentDescription = description,
            tint = if (neon) Color(0xFFE0E7FF) else if (starfield) Color(0xFFF0E7EC) else if (nebula) Color(0xFFFFE8F8) else if (primary) MatteInk else Color(0xFFE8EEF0),
            modifier = Modifier.size(13.dp)
        )
    }
}

@Composable
private fun rememberVisualizerPhase(): State<Float> {
    // The clock is observed inside Canvas drawing, not at the composable root.
    // This invalidates only the visual layer and keeps focusable TV chrome responsive.
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val started = System.nanoTime()
        while (true) {
            val elapsed = (System.nanoTime() - started) / 1_000_000_000f
            phase.floatValue = (elapsed * 0.23f) % (2f * PI.toFloat())
            delay(50L)
        }
    }
    return phase
}

@Composable
private fun ReactiveVisualScene(
    audioFrame: State<TvAudioFrame>,
    modifier: Modifier,
    fullScreen: Boolean,
    style: String
) {
    val phaseState = rememberVisualizerPhase()
    val aurora = style == "AURORA"
    val neon = style == "NEON"
    val starfield = style == VISUALIZER_STARFIELD
    val nebula = !aurora && !neon && !starfield
    val starfieldStars = remember {
        val colors = listOf(
            Color(0xFFE9E5E9), Color(0xFFC9C3D0), Color(0xFF2DD4BF),
            Color(0xFFF472B6), Color(0xFFA78BFA), Color(0xFFFB7185)
        )
        // Pre-computed positions avoid allocations on every frame. Positions drift
        // in Canvas using the phase clock and current audio levels.
        List(140) { i ->
            StarfieldStar(
                x = ((i * 97 + 31) % 1009) / 1008f,
                y = ((i * 173 + 53) % 1013) / 1012f,
                radius = 0.38f + ((i * 7) % 8) * 0.105f,
                color = colors[i % colors.size],
                twinklePhase = i * 0.618f
            )
        }
    }
    val neonParticles = remember {
        val colors = listOf(
            Color(0xFF7C3AED), Color(0xFF8B5CF6), Color(0xFF3B82F6),
            Color(0xFF60A5FA), Color(0xFF4338CA), Color(0xFFA78BFA)
        )
        List(110) { i ->
            StarfieldStar(
                x = ((i * 97 + 31) % 1009) / 1008f,
                y = ((i * 173 + 53) % 1013) / 1012f,
                radius = 0.45f + ((i * 7) % 8) * 0.15f,
                color = colors[i % colors.size],
                twinklePhase = i * 0.618f
            )
        }
    }
    val starfieldBokeh = remember {
        val colors = listOf(Color(0xFF2DD4BF), Color(0xFFF472B6), Color(0xFFA78BFA), Color(0xFFFB7185))
        List(8) { i ->
            val leftSide = i % 2 == 0
            val x = if (leftSide) 0.018f + ((i * 13) % 25) / 100f
                    else 0.755f + ((i * 17) % 22) / 100f
            val y = ((i * 37 + 11) % 97) / 96f
            StarfieldBokeh(
                x = x,
                y = y,
                radius = 0.008f + (i % 4) * 0.0047f,
                color = colors[i % colors.size],
                phase = i * 0.81f
            )
        }
    }

    // Each visualizer is an independent composition:
    // NEBULA is the dark cinematic matte look; AURORA is the pale pastel look;
    // NEON is the electric treatment; STARFIELD is the black cosmic starfield.
    val backgroundColors = when {
        neon -> listOf(Color(0xFF050510), Color(0xFF0B0A20), Color(0xFF120A22))
        starfield -> listOf(Color.Black, Color.Black, Color.Black)
        aurora -> listOf(Color(0xFF6EA7A8), Color(0xFFB8B4BD), Color(0xFFDDB1C0))
        else -> listOf(Color(0xFF050510), Color(0xFF10091F), Color(0xFF160B25))
    }

    Box(
        modifier.background(
            Brush.linearGradient(
                colorStops = arrayOf(
                    0f to backgroundColors[0],
                    0.52f to backgroundColors[1],
                    1f to backgroundColors[2]
                ),
                start = Offset(0f, 0f),
                end = Offset(1800f, 980f)
            )
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            // State is read only while drawing: the parent composable and TV chrome
            // do not recompose for every 50 ms audio sample.
            val currentFrame = audioFrame.value
            val waveform = currentFrame.waveform
            val spectrum = currentFrame.spectrum
            val audioEnergy = currentFrame.energy
            val level = audioEnergy.coerceIn(0.01f, 1f)
            fun averageBand(from: Int, until: Int): Float {
                val end = until.coerceAtMost(spectrum.size)
                val start = from.coerceAtMost(end)
                if (end <= start) return 0f
                var total = 0f
                for (index in start until end) total += spectrum[index]
                return (total / (end - start)).coerceIn(0f, 1f)
            }
            val bass = averageBand(0, 7)
            val mids = averageBand(7, 25)
            val highs = averageBand(25, spectrum.size)
            val audioTint = (bass * 0.42f + mids * 0.34f + highs * 0.24f).coerceIn(0f, 1f)
            val phase = phaseState.value
            val slowA = (0.5f + 0.5f * sin(phase * 0.22f)).coerceIn(0f, 1f)
            val slowB = (0.5f + 0.5f * cos(phase * 0.17f + 1.4f)).coerceIn(0f, 1f)
            val w = size.width
            val h = size.height
            val minDim = size.minDimension
            val center = Offset(w * 0.5f, if (fullScreen) h * 0.425f else h * 0.47f)
            val nebulaMotion = minDim * (if (nebula) 0.022f + bass * 0.065f + mids * 0.045f else 0.014f + bass * 0.055f + mids * 0.035f)
            val cloudScale = if (fullScreen) 1f else 0.82f
            val cloudAlpha = when {
                neon -> 0.48f
                starfield -> 0.20f
                aurora -> 0.25f
                else -> 0.76f
            }

            fun cloud(
                color: Color,
                point: Offset,
                radius: Float,
                bandEnergy: Float,
                phaseOffset: Float,
                alphaScale: Float = 1f
            ) {
                val motionShimmer = if (nebula) {
                    (0.56f + 0.44f * sin(phase * (0.76f + mids * 0.74f + highs * 0.42f) + phaseOffset)).coerceIn(0.16f, 1f)
                } else {
                    (0.72f + 0.28f * sin(phase * 0.72f + phaseOffset)).coerceIn(0.25f, 1f)
                }
                val audioLift = if (nebula) {
                    bandEnergy.coerceIn(0f, 1f) * 0.34f + level * 0.12f + highs * 0.10f
                } else {
                    bandEnergy.coerceIn(0f, 1f) * 0.20f + level * 0.07f
                }
                val alpha = ((cloudAlpha + audioLift) * motionShimmer * alphaScale).coerceIn(0.06f, 0.92f)
                val quietPlum = Color(0xFF35113F)
                val cloudColor = if (nebula) androidx.compose.ui.graphics.lerp(
                    quietPlum, color, (0.58f + bandEnergy.coerceIn(0f, 1f) * 0.42f)
                ) else color
                val cloudBreath = if (nebula) 0.93f + 0.07f * sin(phase * (0.30f + mids * 0.22f) + phaseOffset) else 1f
                val cloudPoint = if (nebula) Offset(
                    point.x + sin(phase * 0.22f + phaseOffset) * radius * 0.045f,
                    point.y + cos(phase * 0.19f + phaseOffset) * radius * 0.035f
                ) else point
                val cloudRadius = radius * cloudBreath
                if (nebula) {
                    // One translucent, rotating gas wisp per cloud. The main radial
                    // volume is drawn once below; avoid stacking several full-screen
                    // radial shaders for every cloud on lower-powered TV hardware.
                    val wispLength = cloudRadius * (2.20f + 0.24f * sin(phase * 0.34f + phaseOffset))
                    val wispThickness = cloudRadius * (0.30f + mids * 0.08f)
                    val wispAngle = (phase * (0.48f + mids * 0.24f) + phaseOffset * 1.7f) * 57.2958f
                    val wispCenter = Offset(
                        cloudPoint.x + sin(phase * 0.24f + phaseOffset) * cloudRadius * 0.24f,
                        cloudPoint.y + cos(phase * 0.20f + phaseOffset) * cloudRadius * 0.15f
                    )
                    rotate(wispAngle, wispCenter) {
                        drawOval(
                            Brush.radialGradient(
                                colorStops = arrayOf(
                                    0f to cloudColor.copy(alpha = alpha * 0.15f),
                                    0.48f to cloudColor.copy(alpha = alpha * 0.07f),
                                    1f to Color.Transparent
                                ), center = wispCenter, radius = wispLength
                            ),
                            topLeft = Offset(wispCenter.x - wispLength, wispCenter.y - wispThickness),
                            size = Size(wispLength * 2f, wispThickness * 2f)
                        )
                    }
                }
                if (neon) {
                    // Two translucent shells create a glow without an expensive blur effect.
                    drawCircle(
                        Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to cloudColor.copy(alpha = alpha * 0.38f),
                                0.42f to cloudColor.copy(alpha = alpha * 0.20f),
                                1f to Color.Transparent
                            ),
                            center = cloudPoint,
                            radius = radius * 1.55f
                        ),
                        radius = radius * 1.55f,
                        center = point
                    )
                }
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to cloudColor.copy(alpha = alpha),
                            0.25f to cloudColor.copy(alpha = alpha * 0.72f),
                            0.63f to cloudColor.copy(alpha = alpha * 0.22f),
                            1f to Color.Transparent
                        ),
                        center = cloudPoint,
                        radius = cloudRadius
                    ),
                    radius = cloudRadius,
                    center = cloudPoint
                )
            }

            val driftA = sin(phase * 0.37f) * nebulaMotion
            val driftB = cos(phase * 0.31f) * nebulaMotion
            val driftC = sin(phase * 0.23f + 1.2f) * nebulaMotion * 0.76f

            val teal = when {
                neon -> Color(0xFF8B5CF6)
                starfield -> Color(0xFF147E83)
                aurora -> Color(0xFF75CFC4)
                else -> Color(0xFF267C86)
            }
            val cyan = when {
                neon -> Color(0xFF3B82F6)
                starfield -> Color(0xFF174D6B)
                aurora -> Color(0xFF86CADC)
                else -> Color(0xFF276B91)
            }
            val blue = when {
                neon -> Color(0xFF60A5FA)
                starfield -> Color(0xFF1C2B57)
                aurora -> Color(0xFF9BAFD4)
                else -> Color(0xFF344F85)
            }
            val violet = when {
                neon -> Color(0xFF8B5CF6)
                starfield -> Color(0xFF382448)
                aurora -> Color(0xFFC6A9D0)
                else -> Color(0xFF65517D)
            }
            val plum = when {
                neon -> Color(0xFF7C3AED)
                starfield -> Color(0xFF60334F)
                aurora -> Color(0xFFE1A7BC)
                else -> Color(0xFF9A547C)
            }
            val rose = when {
                neon -> Color(0xFF4338CA)
                starfield -> Color(0xFF96516E)
                aurora -> Color(0xFFE8B8C5)
                else -> Color(0xFFB36D8B)
            }

            val nebulaBassColor = androidx.compose.ui.graphics.lerp(
                Color(0xFF6D28D9), Color(0xFF4338CA), (bass * 0.72f + slowB * 0.12f).coerceIn(0f, 0.82f)
            )
            val nebulaMidColor = androidx.compose.ui.graphics.lerp(
                Color(0xFF8B5CF6), Color(0xFFD946EF), (mids * 0.78f + slowA * 0.12f).coerceIn(0f, 0.88f)
            )
            val nebulaHighColor = androidx.compose.ui.graphics.lerp(
                Color(0xFFF472B6), Color(0xFF60A5FA), (highs * 0.54f + mids * 0.12f).coerceIn(0f, 0.72f)
            )
            val nebulaTealColor = Color(0xFF2DD4BF)
            val nebulaBloom = (bass * 0.36f + mids * 0.32f + highs * 0.22f + level * 0.18f).coerceIn(0f, 1f)
            val nebulaSwirl = 0.72f + mids * 1.15f + level * 0.36f

            if (neon) {
                // Neon nebula: black-navy space with layered, slowly evolving
                // violet / indigo / electric-blue gas clouds. Each cloud breathes
                // with its related FFT bands and drifts continuously.
                cloud(Color(0xFF6D28D9), Offset(w * 0.08f + driftA * 1.35f, h * 0.24f + bass * minDim * 0.04f),
                    minDim * (0.48f + bass * 0.09f) * cloudScale, bass + mids * 0.36f, 0.2f, 0.86f)
                cloud(Color(0xFF3B82F6), Offset(w * 0.19f - driftB, h * 0.74f + driftC),
                    minDim * (0.56f + mids * 0.08f) * cloudScale, mids + bass * 0.26f, 1.3f, 0.80f)
                cloud(Color(0xFFD946EF), Offset(w * 0.47f + driftC, h * 0.08f - driftA * 0.42f),
                    minDim * (0.40f + highs * 0.06f) * cloudScale, highs + mids * 0.34f, 2.1f, 0.72f)
                cloud(Color(0xFF8B5CF6), Offset(w * 0.79f + driftB * 1.2f, h * 0.30f + highs * minDim * 0.035f),
                    minDim * (0.56f + highs * 0.08f) * cloudScale, highs + mids * 0.48f, 3.2f, 0.88f)
                cloud(Color(0xFFF472B6), Offset(w * 0.94f - driftA, h * 0.72f - bass * minDim * 0.04f),
                    minDim * (0.52f + bass * 0.06f) * cloudScale, bass + highs * 0.28f, 4.0f, 0.80f)
                cloud(Color(0xFF2DD4BF), Offset(w * 0.61f - driftC, h * 0.91f),
                    minDim * (0.36f + mids * 0.06f) * cloudScale, mids + highs * 0.35f, 5.1f, 0.70f)
                cloud(Color(0xFF7C3AED), Offset(w * 0.30f + driftB * 0.7f, h * 0.46f + driftA * 0.24f),
                    minDim * 0.30f * cloudScale, highs + mids, 5.8f, 0.64f)
                cloud(Color(0xFF3B82F6), Offset(w * 0.68f - driftA * 0.55f, h * 0.62f - driftC),
                    minDim * 0.31f * cloudScale, bass + highs, 6.5f, 0.72f)
            } else if (nebula) {
                // NEBULA HERO: layered smoke fields fill the full 16:9 canvas.
                // Far clouds move slowly, mid clouds fold and swirl with mids, and
                // near wisps move faster with treble. Bass deepens and expands the
                // indigo-violet masses; highs add pink / blue edge energy.
                val farDriftX = sin(phase * 0.18f + 0.4f) * nebulaMotion * 0.86f
                val farDriftY = cos(phase * 0.16f + 1.1f) * nebulaMotion * 0.56f
                val midDriftX = sin(phase * (0.38f + mids * 0.16f) + 2.0f) * nebulaMotion * (1.0f + mids * 0.28f)
                val midDriftY = cos(phase * (0.32f + mids * 0.14f) + 0.7f) * nebulaMotion * 0.86f
                val nearDriftX = sin(phase * (0.62f + highs * 0.26f) + 4.1f) * nebulaMotion * (1.35f + level * 0.22f)
                val nearDriftY = cos(phase * (0.50f + highs * 0.22f) + 2.4f) * nebulaMotion * 1.12f
                val bassRadius = minDim * (0.66f + bass * 0.15f + nebulaBloom * 0.06f) * cloudScale
                val midRadius = minDim * (0.48f + mids * 0.13f + nebulaBloom * 0.08f) * cloudScale
                val nearRadius = minDim * (0.30f + highs * 0.10f + nebulaBloom * 0.05f) * cloudScale

                // FAR LAYER - deep, broad gas clouds, low parallax.
                cloud(nebulaBassColor, Offset(w * 0.08f + farDriftX, h * 0.25f + farDriftY),
                    bassRadius * 1.08f, bass + 0.12f, 0.15f, 0.72f)
                cloud(androidx.compose.ui.graphics.lerp(nebulaBassColor, Color(0xFF6D28D9), 0.38f), Offset(w * 0.48f - farDriftX * 0.62f, h * 0.02f + farDriftY),
                    bassRadius * 0.88f, bass + mids * 0.22f, 1.05f, 0.60f)
                cloud(Color(0xFF3B2B82), Offset(w * 0.92f - farDriftX, h * 0.74f - farDriftY),
                    bassRadius * 1.14f, bass + 0.10f, 2.05f, 0.74f)
                cloud(Color(0xFF31266F), Offset(w * 0.34f + farDriftX * 0.42f, h * 0.96f - farDriftY * 0.60f),
                    bassRadius * 0.92f, bass + 0.08f, 2.85f, 0.58f)

                // MID LAYER - violet and magenta folds driven by the midrange.
                cloud(nebulaMidColor, Offset(w * 0.18f - midDriftX, h * 0.54f + midDriftY),
                    midRadius * 1.10f, mids + bass * 0.24f, 0.55f, 0.88f)
                cloud(nebulaMidColor, Offset(w * 0.43f + midDriftX * 0.82f, h * 0.23f - midDriftY),
                    midRadius * 0.94f, mids + highs * 0.22f, 1.45f, 0.72f)
                cloud(androidx.compose.ui.graphics.lerp(nebulaMidColor, Color(0xFF8B5CF6), 0.32f), Offset(w * 0.73f - midDriftX * 0.72f, h * 0.47f + midDriftY * 0.72f),
                    midRadius * 1.14f, mids + bass * 0.18f, 2.55f, 0.84f)
                cloud(Color(0xFFA12BCB), Offset(w * 0.90f + midDriftX * 0.55f, h * 0.12f + midDriftY),
                    midRadius * 0.82f, mids + highs * 0.20f, 3.45f, 0.72f)
                cloud(Color(0xFF6D28D9), Offset(w * 0.54f + midDriftX * 0.34f, h * 0.88f - midDriftY * 0.70f),
                    midRadius * 0.98f, mids + bass * 0.26f, 4.35f, 0.70f)

                // NEAR LAYER - fast translucent plumes and luminous cool accents.
                cloud(nebulaHighColor, Offset(w * 0.06f + nearDriftX, h * 0.70f - nearDriftY),
                    nearRadius * 1.18f, highs + mids * 0.30f, 0.85f, 0.76f)
                cloud(nebulaHighColor, Offset(w * 0.31f - nearDriftX * 0.72f, h * 0.34f + nearDriftY),
                    nearRadius * 0.92f, highs + mids * 0.34f, 1.85f, 0.78f)
                cloud(Color(0xFF60A5FA), Offset(w * 0.82f + nearDriftX * 0.64f, h * 0.78f - nearDriftY * 0.76f),
                    nearRadius * 1.02f, highs + bass * 0.18f, 2.75f, 0.66f)
                cloud(nebulaTealColor, Offset(w * 0.66f - nearDriftX, h * 0.17f + nearDriftY * 0.82f),
                    nearRadius * 0.76f, highs + mids * 0.24f, 3.65f, 0.58f)
                cloud(Color(0xFFD946EF), Offset(w * 0.98f + nearDriftX * 0.48f, h * 0.43f + nearDriftY),
                    nearRadius * 0.88f, mids + highs * 0.34f, 4.55f, 0.74f)

                // Soft gas plumes continually circulate around the central orb.
                // Their paths are offset and counter-rotating so the cloud field
                // feels like one connected, folding nebula rather than fixed blobs.
                for (plume in 0 until 3) {
                    val direction = if (plume % 2 == 0) 1f else -1f
                    val angle = phase * direction * (0.16f + mids * 0.12f) + plume * (2f * PI.toFloat() / 3f)
                    val orbitX = minDim * (0.30f + bass * 0.045f)
                    val orbitY = minDim * (0.22f + mids * 0.045f)
                    val wobble = sin(phase * 0.42f + plume * 1.7f) * minDim * 0.025f
                    val plumePoint = Offset(
                        center.x + cos(angle) * orbitX + wobble,
                        center.y + sin(angle * 0.91f) * orbitY
                    )
                    val plumeBand = spectrum[(plume * 4 + 3) % spectrum.size]
                    val plumeWave = waveform[(plume * 7 + 5) % waveform.size]
                    val plumeColor = when (plume % 4) {
                        0 -> nebulaMidColor
                        1 -> nebulaHighColor
                        2 -> nebulaBassColor
                        else -> nebulaTealColor
                    }
                    cloud(
                        plumeColor, plumePoint,
                        minDim * (0.145f + plumeBand * 0.065f + nebulaBloom * 0.025f) * cloudScale,
                        plumeBand + plumeWave, 0.72f + plume * 0.83f, 0.38f
                    )
                }

                // Star-forming knots bloom from the nebula on the strongest bands.
                for (knot in 0 until 2) {
                    val sample = waveform[(knot * 5 + 3) % waveform.size]
                    val band = spectrum[(knot * 3 + 2) % spectrum.size]
                    val t = ((knot * 79 + 17) % 97) / 96f
                    val x = w * (0.05f + t * 0.90f) + sin(phase * (0.20f + knot * 0.012f) + knot) * nebulaMotion * 0.72f
                    val y = h * (((knot * 37 + 9) % 91) / 90f) + cos(phase * (0.16f + knot * 0.009f) + knot * 0.7f) * nebulaMotion * 0.56f
                    val knotRadius = minDim * (0.035f + band * 0.055f + sample * 0.025f) * (0.80f + nebulaBloom * 0.45f)
                    val knotColor = when (knot % 4) {
                        0 -> nebulaMidColor
                        1 -> nebulaHighColor
                        2 -> nebulaTealColor
                        else -> nebulaBassColor
                    }
                    cloud(knotColor, Offset(x, y), knotRadius, band + sample, knot * 0.48f, 0.72f)
                }

                // Curled luminous filaments connect cloud masses and wrap around the orb.
                // They use live waveform shape plus independent phase layers.
                for (layer in 0 until 2) {
                    val strands = 2
                    for (strand in 0 until strands) {
                        val path = Path()
                        val strandIndex = layer * 7 + strand
                        val motion = when (layer) { 0 -> 0.12f; 1 -> 0.25f; else -> 0.43f }
                        val strandColor = when (strandIndex % 5) {
                            0 -> nebulaBassColor
                            1 -> nebulaMidColor
                            2 -> nebulaHighColor
                            3 -> nebulaTealColor
                            else -> Color(0xFF60A5FA)
                        }
                        for (point in 0..24) {
                            val t = point / 24f
                            val x = w * t
                            val sample = waveform[(point * 3 + strandIndex * 5) % waveform.size]
                            val band = spectrum[(point * 2 + strandIndex * 3) % spectrum.size]
                            val envelope = (0.24f + 0.76f * sin(t * PI).toFloat())
                            val curl = sin(t * PI * (1.55f + strand * 0.17f) + phase * (motion * nebulaSwirl) + strandIndex * 0.64f).toFloat()
                            val fold = cos(t * PI * (3.1f + layer * 0.45f) - phase * (motion * 0.68f) + strandIndex).toFloat()
                            val y = h * (0.48f + (strand - (strands - 1) / 2f) * (0.033f + layer * 0.009f)) +
                                curl * h * (0.055f + layer * 0.018f + mids * 0.028f) +
                                fold * h * (0.012f + highs * 0.016f) +
                                (sample - 0.08f) * h * (0.075f + bass * 0.075f) * envelope +
                                band * h * 0.032f * envelope
                            if (point == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        val alpha = (0.10f + mids * 0.10f + highs * 0.10f + nebulaBloom * 0.06f) * (if (layer == 0) 0.55f else 1f)
                        drawPath(path, strandColor.copy(alpha = alpha * 0.30f), style = Stroke(width = if (layer == 2) 4.2f else 3.0f))
                        drawPath(path, strandColor.copy(alpha = alpha), style = Stroke(width = if (layer == 2) 0.88f else 0.72f))
                    }
                }
            } else if (aurora) {
                // Aurora keeps its own airy pastel cloud arrangement.
                cloud(teal, Offset(w * 0.08f + driftA, h * 0.59f + mids * minDim * 0.045f),
                    minDim * (0.60f + bass * 0.08f) * cloudScale, bass + mids * 0.45f, 0.1f)
                cloud(cyan, Offset(w * 0.18f - driftB, h * 0.82f + driftC),
                    minDim * (0.48f + mids * 0.06f) * cloudScale, mids + bass * 0.25f, 1.0f, 0.88f)
                cloud(blue, Offset(w * 0.31f + driftC, h * 0.17f - driftA * 0.25f),
                    minDim * (0.43f + highs * 0.05f) * cloudScale, highs + mids * 0.30f, 1.9f, 0.82f)
                cloud(violet, Offset(w * 0.78f + driftB, h * 0.18f + highs * minDim * 0.045f),
                    minDim * (0.56f + highs * 0.06f) * cloudScale, highs + mids * 0.42f, 2.8f)
                cloud(plum, Offset(w * 0.94f - driftA, h * 0.60f - bass * minDim * 0.035f),
                    minDim * (0.60f + highs * 0.05f) * cloudScale, highs + bass * 0.35f, 3.7f)
                cloud(rose, Offset(w * 0.72f + driftC, h * 0.90f),
                    minDim * 0.36f * cloudScale, highs + mids * 0.25f, 4.6f, 0.82f)
                cloud(teal, Offset(w * 0.29f + driftB * 0.7f, h * 0.40f + driftA * 0.2f),
                    minDim * 0.31f * cloudScale, highs + mids, 5.3f, 0.72f)
                cloud(plum, Offset(w * 0.64f - driftA * 0.6f, h * 0.68f - driftC),
                    minDim * 0.33f * cloudScale, bass + highs, 6.1f, 0.78f)

                // Delicate audio-reactive wisps enrich the pastel atmosphere.
                for (i in 0 until 8) {
                    val sample = waveform[(i * 9) % waveform.size]
                    val band = spectrum[(i * 5) % spectrum.size]
                    val baseX = ((i * 37 + 11) % 97) / 96f
                    val baseY = ((i * 53 + 7) % 89) / 88f
                    val x = baseX * w + sin(phase * (0.16f + (i % 3) * 0.04f) + i) * nebulaMotion * (0.5f + sample)
                    val y = baseY * h + cos(phase * (0.13f + (i % 4) * 0.03f) + i * 0.73f) * nebulaMotion * 0.62f
                    val radius = minDim * (0.10f + band * 0.11f + sample * 0.05f) * cloudScale
                    cloud(if (i % 2 == 0) teal else plum, Offset(x, y), radius, sample + band, i * 0.37f, 0.54f)
                }
            } else {
                // The black remains genuinely black. Only very low-opacity, drifting
                // wisps are painted over it; they breathe with bass and midrange.
                val hazePulse = (0.55f + level * 0.45f + 0.10f * sin(phase * 0.34f)).coerceIn(0.35f, 1f)
                val haze1 = Offset(w * (0.17f + 0.012f * sin(phase * 0.19f)), h * (0.55f + 0.025f * cos(phase * 0.16f)))
                val haze2 = Offset(w * (0.84f + 0.015f * cos(phase * 0.17f)), h * (0.44f + 0.025f * sin(phase * 0.14f)))
                val hazeRadius = minDim * (0.40f + bass * 0.06f)
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color(0xFF2DD4BF).copy(alpha = 0.055f * hazePulse),
                            0.42f to Color(0xFF2DD4BF).copy(alpha = 0.025f * hazePulse),
                            1f to Color.Transparent
                        ), center = haze1, radius = hazeRadius
                    ), hazeRadius, haze1
                )
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color(0xFFF472B6).copy(alpha = 0.050f * hazePulse),
                            0.45f to Color(0xFFA78BFA).copy(alpha = 0.022f * hazePulse),
                            1f to Color.Transparent
                        ), center = haze2, radius = hazeRadius * 1.08f
                    ), hazeRadius * 1.08f, haze2
                )

                // Bokeh planets drift rather than sit at fixed screen coordinates.
                for ((bokehIndex, bokeh) in starfieldBokeh.withIndex()) {
                    val bandEnergy = spectrum[(bokehIndex * 3) % spectrum.size]
                    val sample = waveform[(bokehIndex * 5) % waveform.size]
                    val pulse = 0.82f + 0.10f * sin(phase * 0.28f + bokeh.phase) + bandEnergy * 0.16f + sample * 0.05f
                    val driftX = sin(phase * (0.11f + (bokehIndex % 4) * 0.025f) + bokeh.phase) * w * 0.012f
                    val driftY = cos(phase * (0.10f + (bokehIndex % 3) * 0.02f) + bokeh.phase) * h * 0.010f
                    val point = Offset(bokeh.x * w + driftX, bokeh.y * h + driftY)
                    val radius = minDim * bokeh.radius * pulse
                    val haloRadius = radius * (2.7f + bandEnergy * 1.2f)
                    drawCircle(
                        Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to bokeh.color.copy(alpha = 0.18f + bandEnergy * 0.08f),
                                0.36f to bokeh.color.copy(alpha = 0.09f),
                                0.72f to bokeh.color.copy(alpha = 0.025f),
                                1f to Color.Transparent
                            ), center = point, radius = haloRadius
                        ), haloRadius, point
                    )
                    drawCircle(bokeh.color.copy(alpha = 0.20f + bandEnergy * 0.18f), radius * 0.62f, point)
                }

                // Hundreds of independently drifting pin-stars. Loud passages pull
                // the field slightly toward the orb; quieter passages let it scatter.
                val visibleStars = (82 + level * 35f + highs * 8f).toInt().coerceIn(75, starfieldStars.size)
                val cluster = ((level - 0.28f) / 0.72f).coerceIn(0f, 1f) * 0.055f
                for (index in 0 until visibleStars) {
                    val star = starfieldStars[index]
                    val speed = 0.035f + (index % 7) * 0.012f + mids * 0.035f
                    val driftX = sin(phase * speed + star.twinklePhase) * (0.004f + level * 0.006f)
                    val driftY = cos(phase * (speed * 0.82f) + star.twinklePhase * 0.71f) * (0.004f + bass * 0.006f)
                    val verticalFlow = phase * (bass * 0.0025f - highs * 0.0035f) * (1f + (index % 4) * 0.25f)
                    val dispersedX = (star.x + driftX).let { (it % 1f + 1f) % 1f }
                    val dispersedY = (star.y + driftY + verticalFlow).let { (it % 1f + 1f) % 1f }
                    val x = (dispersedX + (0.5f - dispersedX) * cluster) * w
                    val y = (dispersedY + (0.425f - dispersedY) * cluster) * h
                    val twinkle = (0.42f + 0.58f * sin(phase * (0.62f + highs * 0.35f) + star.twinklePhase)).coerceIn(0.07f, 1f)
                    val audioFlicker = if (index % 5 == 0) highs * 0.16f + level * 0.05f else 0f
                    val radius = star.radius * (0.80f + twinkle * 0.28f + spectrum[(index * 3) % spectrum.size] * 0.18f)
                    val alpha = (0.20f + twinkle * 0.56f + audioFlicker).coerceIn(0.10f, 0.90f)
                    drawCircle(star.color.copy(alpha = alpha), radius, Offset(x, y))
                    if (index % 61 == 0) {
                        val glint = radius * (3.1f + highs * 1.4f)
                        val glintColor = if (index % 2 == 0) Color(0xFFA78BFA) else Color(0xFFF472B6)
                        drawLine(glintColor.copy(alpha = 0.38f * twinkle), Offset(x - glint, y), Offset(x + glint, y), 0.65f)
                        drawLine(glintColor.copy(alpha = 0.38f * twinkle), Offset(x, y - glint), Offset(x, y + glint), 0.65f)
                    }
                }
            }

            // Particle density and character vary by visualizer: Nebula is a rich dust field,
            // Aurora is airy, Neon is luminous, and Starfield is densely star-filled.
            if (neon) {
                val visibleStars = (62 + level * 35f).toInt().coerceIn(62, neonParticles.size)
                for (index in 0 until visibleStars) {
                    val particle = neonParticles[index]
                    val sample = waveform[(index * 7) % waveform.size]
                    val band = spectrum[(index * 5) % spectrum.size]
                    val twinkle = (0.46f + 0.54f * sin(phase * (1.2f + highs * 0.9f) + particle.twinklePhase)).coerceIn(0.08f, 1f)
                    val driftSpeed = 0.16f + (index % 7) * 0.045f + level * 0.20f
                    val x = particle.x * w + sin(phase * driftSpeed + particle.twinklePhase) * nebulaMotion * 0.48f
                    val rawY = particle.y * h - phase * (0.8f + mids * 1.4f) * (index % 5 + 1) * 0.8f
                    val y = ((rawY % h) + h) % h
                    val radius = particle.radius + band * 1.25f + sample * 0.55f
                    val alpha = (0.28f + twinkle * 0.62f + band * 0.16f).coerceIn(0.12f, 0.98f)
                    if (index % 19 == 0) {
                        val halo = radius * (5.0f + bass * 2.2f)
                        drawCircle(
                            Brush.radialGradient(
                                colorStops = arrayOf(
                                    0f to particle.color.copy(alpha = 0.22f + band * 0.14f),
                                    0.38f to particle.color.copy(alpha = 0.10f + band * 0.06f),
                                    1f to Color.Transparent
                                ), center = Offset(x, y), radius = halo
                            ), halo, Offset(x, y)
                        )
                    }
                    drawCircle(particle.color.copy(alpha = alpha), radius, Offset(x, y))
                    if (index % 47 == 0) {
                        val glint = radius * (3.5f + highs * 2.4f)
                        drawLine(Color(0xFFC4B5FD).copy(alpha = 0.72f * twinkle), Offset(x - glint, y), Offset(x + glint, y), 0.9f)
                        drawLine(Color(0xFF93C5FD).copy(alpha = 0.72f * twinkle), Offset(x, y - glint), Offset(x, y + glint), 0.9f)
                    }
                }
            }

            val particleCount = when {
                neon -> 0
                aurora -> 80
                starfield -> 0
                else -> 96
            }
            val visibleNebulaDust = (72 + nebulaBloom * 18f + highs * 6f).toInt().coerceIn(72, 96)
            for (i in 0 until particleCount) {
                if (nebula && i >= visibleNebulaDust) continue
                val baseX = ((i * 47 + 13) % 997) / 996f
                val baseY = ((i * 71 + 19) % 991) / 990f
                val sample = waveform[(i * 11) % waveform.size]
                val band = spectrum[(i * 5) % spectrum.size]
                val twinkle = (0.48f + 0.52f * sin(phase * (0.36f + (i % 5) * 0.055f) + i)).coerceIn(0.04f, 1f)
                val driftX = sin(phase * (if (nebula) 0.20f else 0.095f) + i * 0.7f) * nebulaMotion * (if (nebula) 0.62f else 0.34f)
                // Melody lifts dust upward; bass drops let it fall. During strong
                // drops the same particles gather toward the centre orb, then spread
                // back into the cloud field as the mix calms.
                val verticalFlow = if (nebula) phase * (bass * 0.0034f - mids * 0.0020f) * (1f + (i % 5) * 0.18f) else 0f
                val rawX = (baseX + driftX / w).coerceIn(-0.05f, 1.05f)
                val driftY = cos(phase * (if (nebula) 0.19f else 0.11f) + i * 0.47f) * nebulaMotion * (if (nebula) 0.44f else 0.25f)
                val rawY = (baseY + (driftY + verticalFlow) / h).coerceIn(-0.05f, 1.05f)
                val particleCluster = if (nebula) (nebulaBloom * 0.16f + bass * 0.07f).coerceIn(0f, 0.22f) else 0f
                val x = (rawX + (0.5f - rawX) * particleCluster) * w
                val y = (rawY + (center.y / h - rawY) * particleCluster) * h
                val baseRadius = when {
                    starfield -> 0.42f + (i % 5) * 0.20f
                    aurora -> 1.0f + (i % 5) * 0.52f
                    neon -> 0.9f + (i % 4) * 0.48f
                    nebula -> 0.62f + (i % 4) * 0.34f
                    else -> 0.7f + (i % 3) * 0.40f
                }
                val radius = baseRadius + band * (if (aurora) 2.8f else 2.0f) + sample * 1.0f
                val particleColor = when {
                    neon -> when (i % 4) {
                        0 -> Color(0xFF3B82F6)
                        1 -> Color(0xFF8B5CF6)
                        2 -> Color(0xFF4338CA)
                        else -> Color(0xFF60A5FA)
                    }
                    starfield -> when (i % 5) {
                        0 -> Color(0xFFE7E9F0)
                        1 -> Color(0xFF40BFC0)
                        2 -> Color(0xFFD17A98)
                        3 -> Color(0xFF8A9FCB)
                        else -> Color(0xFFB8A6C7)
                    }
                    aurora -> when (i % 4) {
                        0 -> Color(0xFF63D6CC)
                        1 -> Color(0xFFFFC4D7)
                        2 -> Color(0xFFE9E8EF)
                        else -> Color(0xFF82B6CE)
                    }
                    else -> when (i % 6) {
                        0 -> Color(0xFF6D28D9)
                        1 -> Color(0xFF8B5CF6)
                        2 -> Color(0xFFD946EF)
                        3 -> Color(0xFFF472B6)
                        4 -> Color(0xFF2DD4BF)
                        else -> Color(0xFF60A5FA)
                    }
                }
                val alpha = when {
                    neon -> (0.62f + twinkle * 0.34f + band * 0.12f).coerceIn(0f, 1f)
                    starfield -> (0.38f + twinkle * 0.46f + band * 0.12f).coerceIn(0f, 1f)
                    aurora -> (0.40f + twinkle * 0.48f + band * 0.12f).coerceIn(0f, 1f)
                    else -> (0.34f + twinkle * 0.48f + band * 0.18f + nebulaBloom * 0.06f).coerceIn(0f, 1f)
                }
                if (nebula && i % 24 == 0) {
                    val halo = radius * (4.0f + band * 2.5f + nebulaBloom * 1.2f)
                    drawCircle(
                        Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to particleColor.copy(alpha = 0.18f + band * 0.12f),
                                0.40f to particleColor.copy(alpha = 0.075f + highs * 0.035f),
                                1f to Color.Transparent
                            ), center = Offset(x, y), radius = halo
                        ), halo, Offset(x, y)
                    )
                }
                if (starfield && i % 13 == 0) {
                    val hazeRadius = radius * 5.5f
                    drawCircle(
                        Brush.radialGradient(
                            listOf(particleColor.copy(alpha = 0.15f + band * 0.08f), Color.Transparent),
                            center = Offset(x, y), radius = hazeRadius
                        ), hazeRadius, Offset(x, y)
                    )
                }
                drawCircle(particleColor.copy(alpha = alpha), radius, Offset(x, y))
                if ((aurora && i % 11 == 0) || (starfield && i % 23 == 0) || (nebula && i % 17 == 0)) {
                    // Tiny four-point star glints from the lighter visual reference.
                    val glintColor = if (nebula) Color(0xFFFFC8F0) else Color.White
                    drawLine(glintColor.copy(alpha = (if (nebula) 0.42f else 0.55f) * twinkle),
                        Offset(x - radius * 2.4f, y), Offset(x + radius * 2.4f, y), 0.8f)
                    drawLine(glintColor.copy(alpha = (if (nebula) 0.42f else 0.55f) * twinkle),
                        Offset(x, y - radius * 2.4f), Offset(x, y + radius * 2.4f), 0.8f)
                }
            }

            // Wave ribbons span almost the full width and remain clearly readable.
            val lineCount = when {
                neon -> 8
                starfield -> 6
                nebula -> 7
                else -> 15
            }
            val waveSteps = if (aurora) 64 else 28
            val waveCenterY = h * if (fullScreen) 0.455f else 0.555f
            for (line in 0 until lineCount) {
                val path = Path()
                val lineOffset = (line - (lineCount - 1) / 2f) * (if (starfield) 2.8f else if (fullScreen) 5.3f else 4.1f)
                val linePhase = line * 0.18f
                for (step in 0..waveSteps) {
                    val t = step / waveSteps.toFloat()
                    val x = w * t
                    val index = (t * (waveform.size - 1)).toInt().coerceIn(0, waveform.lastIndex)
                    val previous = waveform[(index - 1).coerceAtLeast(0)]
                    val sample = waveform[index]
                    val next = waveform[(index + 1).coerceAtMost(waveform.lastIndex)]
                    val wave = (previous + sample * 2f + next) * 0.25f
                    val band = spectrum[(index * 3) % spectrum.size]
                    val envelope = (0.18f + 0.82f * sin(t * PI).toFloat()).coerceIn(0f, 1f)
                    val motionRate = when { neon -> 2.8f; starfield -> 1.35f; nebula -> 1.12f + mids * 0.42f; else -> 0.68f }
                    val broad = sin(t * PI * (if (neon) 2.9f else if (starfield) 2.55f else if (nebula) 2.55f else 2.25f) + phase * motionRate + linePhase).toFloat()
                    val fine = sin(t * PI * (if (neon) 9.5f else if (starfield) 8.6f else if (nebula) 8.7f else 7.8f) - phase * (if (neon) 2.1f else if (starfield) 1.08f else if (nebula) 0.84f + highs * 0.42f else 0.46f) + linePhase * 1.6f).toFloat()
                    val audioWave = (wave - 0.10f) * h * (if (neon) 0.22f + level * 0.11f else if (starfield) 0.17f + level * 0.075f else if (nebula) 0.17f + level * 0.09f else 0.14f + level * 0.055f) * envelope
                    val y = waveCenterY + lineOffset +
                        broad * h * (if (neon) 0.052f + mids * 0.045f else if (starfield) 0.058f + mids * 0.030f else if (nebula) 0.052f + mids * 0.046f else 0.043f + mids * 0.027f) +
                        fine * h * (if (neon) 0.018f + highs * 0.028f else if (starfield) 0.016f + highs * 0.024f else if (nebula) 0.016f + highs * 0.030f else 0.011f + highs * 0.018f) +
                        audioWave + (band - 0.02f) * h * (if (neon) 0.052f else if (starfield) 0.042f else if (nebula) 0.045f else 0.032f)
                    if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }

                val tint = when {
                    neon -> when (line % 4) {
                        0 -> Color(0xFF7C3AED)
                        1 -> Color(0xFF8B5CF6)
                        2 -> Color(0xFF3B82F6)
                        else -> Color(0xFF60A5FA)
                    }
                    starfield -> androidx.compose.ui.graphics.lerp(
                        Color(0xFF2DD4BF),
                        Color(0xFFF472B6),
                        (0.18f + (line / (lineCount - 1f)) * 0.48f + mids * 0.24f + highs * 0.10f).coerceIn(0f, 1f)
                    )
                    nebula -> {
                        val pitchBlend = (line / (lineCount - 1f) * 0.66f + highs * 0.24f + mids * 0.10f).coerceIn(0f, 1f)
                        val purplePink = androidx.compose.ui.graphics.lerp(nebulaBassColor, nebulaHighColor, pitchBlend)
                        androidx.compose.ui.graphics.lerp(purplePink, Color(0xFF60A5FA), (highs * 0.22f + line / (lineCount - 1f) * 0.10f).coerceIn(0f, 0.26f))
                    }
                    aurora -> if (line % 2 == 0) Color(0xFFBCE4DE) else Color(0xFFE8C5D2)
                    else -> if (line % 2 == 0) Color(0xFF86BDB7) else Color(0xFFC193AE)
                }
                if (neon) {
                    // Two low-cost glow passes beneath the crisp ribbon core.
                    drawPath(path, tint.copy(alpha = 0.10f + level * 0.10f),
                        style = Stroke(width = if (fullScreen) 8.0f else 6.5f))
                    drawPath(path, tint.copy(alpha = 0.28f + level * 0.18f),
                        style = Stroke(width = if (fullScreen) 3.2f else 2.6f))
                } else if (nebula) {
                    drawPath(path, tint.copy(alpha = 0.075f + mids * 0.075f + nebulaBloom * 0.035f),
                        style = Stroke(width = if (fullScreen) 6.2f else 4.8f))
                    drawPath(path, tint.copy(alpha = 0.17f + highs * 0.10f),
                        style = Stroke(width = if (fullScreen) 2.2f else 1.7f))
                }
                val alpha = when {
                    neon -> 0.76f + level * 0.20f
                    starfield -> 0.48f + level * 0.12f
                    aurora -> 0.40f + level * 0.12f
                    else -> 0.56f + level * 0.20f + nebulaBloom * 0.08f
                }
                drawPath(path, tint.copy(alpha = alpha), style = Stroke(width = if (neon) 1.15f else if (starfield) 0.95f else if (nebula) 1.15f else if (fullScreen) 1.25f else 1.0f))
            }

            // A fine secondary wire layer restores the braided ribbon detail.
            val fineLineCount = when { neon -> 3; starfield -> 3; nebula -> 3; aurora -> 8; else -> 4 }
            val fineSteps = if (aurora) 44 else 20
            for (line in 0 until fineLineCount) {
                val path = Path()
                for (step in 0..fineSteps) {
                    val t = step / fineSteps.toFloat()
                    val x = w * t
                    val index = (t * (spectrum.size - 1)).toInt().coerceIn(0, spectrum.lastIndex)
                    val band = spectrum[index]
                    val sample = waveform[(index * 2).coerceIn(0, waveform.lastIndex)]
                    val envelope = sin(t * PI).toFloat()
                    val offset = (line - (fineLineCount - 1) / 2f) * 2.1f
                    val y = waveCenterY + offset +
                        sin(t * PI * (if (neon) 4.4f else if (nebula) 3.7f else 3.0f) + phase * (if (neon) 2.2f else if (nebula) 0.92f + mids * 0.35f else 0.62f) + line * 0.27f) * h * (if (neon) 0.057f else if (nebula) 0.052f else 0.044f) +
                        (sample - 0.08f) * h * (if (neon) 0.15f else if (nebula) 0.13f else 0.095f) * envelope +
                        band * h * (if (neon) 0.062f else if (nebula) 0.048f else 0.036f) * sin(phase * (if (neon) 1.8f else if (nebula) 1.35f else 1f) + line * 0.21f)
                    if (step == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
                }
                val color = when {
                    neon -> if (line % 2 == 0) Color(0xFF60A5FA) else Color(0xFF8B5CF6)
                    starfield -> androidx.compose.ui.graphics.lerp(
                        Color(0xFF2DD4BF), Color(0xFFF472B6),
                        (line / (fineLineCount - 1f) * 0.62f + mids * 0.24f).coerceIn(0f, 1f)
                    )
                    nebula -> androidx.compose.ui.graphics.lerp(
                        nebulaMidColor, nebulaHighColor, (line / (fineLineCount - 1f) * 0.54f + highs * 0.22f).coerceIn(0f, 1f)
                    )
                    aurora -> if (line % 2 == 0) Color(0xFFD5F0EA) else Color(0xFFF1D6DF)
                    else -> if (line % 2 == 0) Color(0xFF9BC8C0) else Color(0xFFD6A7BD)
                }
                if (neon) drawPath(path, color.copy(alpha = 0.16f + highs * 0.12f), style = Stroke(width = 3.0f))
                else if (nebula) drawPath(path, color.copy(alpha = 0.10f + highs * 0.08f), style = Stroke(width = 3.6f))
                drawPath(path, color.copy(alpha = if (neon) 0.78f else if (starfield) 0.42f else if (nebula) 0.44f + mids * 0.08f else if (aurora) 0.31f else 0.35f),
                    style = Stroke(width = if (neon) 0.85f else if (nebula) 0.82f else 0.75f))
            }

            // Frequency rings: for Neon, use independent segmented orbits. Their
            // rotation speeds, gaps, radius and stroke weight all respond to FFT bands.
            val orbRadius = minDim * (
                if (starfield && fullScreen) 0.092f
                else if (neon && fullScreen) 0.116f
                else if (fullScreen) 0.112f else 0.132f
            ) + bass * minDim * 0.016f
            val ringCount = when { neon -> 4; starfield -> 3; nebula -> 3; else -> 4 }
            for (ring in 0 until ringCount) {
                val sample = waveform[(ring * 13) % waveform.size]
                val bandValue = when (ring) {
                    0 -> bass
                    1 -> mids
                    2 -> highs
                    else -> (bass + highs) * 0.5f
                }
                val ringMultiplier = if (starfield) 1.52f + ring * 0.34f else if (neon) 1.50f + ring * 0.31f else if (nebula) 1.46f + ring * 0.32f else 1.38f + ring * 0.25f
                val radius = orbRadius * ringMultiplier + sample * minDim * (if (neon) 0.030f else 0.020f) + bandValue * ring * 2.0f
                val ringColor = when {
                    neon -> when (ring % 4) {
                        0 -> Color(0xFF8B5CF6)
                        1 -> Color(0xFF3B82F6)
                        2 -> Color(0xFF7C3AED)
                        else -> Color(0xFF60A5FA)
                    }
                    starfield -> if (ring % 2 == 0) Color(0xFF8DBCB8) else Color(0xFFC69AAF)
                    nebula -> when (ring) { 0 -> nebulaBassColor; 1 -> nebulaMidColor; else -> nebulaHighColor }
                    aurora -> if (ring % 2 == 0) Color(0xFFE0F0EB) else Color(0xFFF6DCE5)
                    else -> if (ring % 2 == 0) Color(0xFF9BCBC2) else Color(0xFFD8B0C5)
                }
                if (neon) {
                    val speed = when (ring) { 0 -> 1.65f; 1 -> -1.08f; 2 -> 0.76f; else -> -0.48f }
                    val startAngle = (phase * speed * 57.2958f + ring * 79f + bandValue * 54f) % 360f
                    val sweep = (210f + bandValue * 92f + level * 30f).coerceIn(190f, 330f)
                    val ringSize = Size(radius * 2f, radius * 2f)
                    val topLeft = Offset(center.x - radius, center.y - radius)
                    // Soft halo pass.
                    drawArc(
                        color = ringColor.copy(alpha = 0.13f + bandValue * 0.13f),
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = ringSize,
                        style = Stroke(width = 7f + bandValue * 4f)
                    )
                    // Bright frequency arc with a gap that opens and closes with the signal.
                    drawArc(
                        color = ringColor.copy(alpha = 0.76f + bandValue * 0.22f),
                        startAngle = startAngle,
                        sweepAngle = sweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = ringSize,
                        style = Stroke(width = 1.15f + bandValue * 1.55f + sample * 0.8f)
                    )
                    drawArc(
                        color = Color(0xFFC4B5FD).copy(alpha = 0.40f + highs * 0.28f),
                        startAngle = startAngle + 188f + highs * 24f,
                        sweepAngle = 35f + sample * 42f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = ringSize,
                        style = Stroke(width = 0.75f + highs * 0.8f)
                    )
                } else if (starfield) {
                    val rotationSpeed = when (ring) {
                        0 -> 0.92f
                        1 -> -0.62f
                        else -> 0.38f
                    }
                    val rotation = (phase * rotationSpeed * 57.2958f + ring * 83f + bandValue * 32f) % 360f
                    val gapSweep = (42f - bandValue * 24f - level * 8f).coerceIn(12f, 42f)
                    val mainSweep = 360f - gapSweep
                    val ringSize = Size(radius * 2f, radius * 2f)
                    val topLeft = Offset(center.x - radius, center.y - radius)
                    val starRingColor = when (ring) {
                        0 -> Color(0xFF2DD4BF)
                        1 -> Color(0xFFA78BFA)
                        else -> Color(0xFFF472B6)
                    }
                    drawArc(
                        color = starRingColor.copy(alpha = 0.48f + bandValue * 0.18f),
                        startAngle = rotation,
                        sweepAngle = mainSweep,
                        useCenter = false,
                        topLeft = topLeft,
                        size = ringSize,
                        style = Stroke(width = 0.75f + bandValue * 0.55f + sample * 0.25f)
                    )
                    drawArc(
                        color = Color(0xFFFB7185).copy(alpha = 0.24f + highs * 0.16f),
                        startAngle = rotation + mainSweep + 5f,
                        sweepAngle = 12f + highs * 18f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = ringSize,
                        style = Stroke(width = 0.65f + highs * 0.45f)
                    )
                } else if (nebula) {
                    val ringSpeed = when (ring) { 0 -> 0.54f; 1 -> -0.38f; else -> 0.24f }
                    val rotation = (phase * ringSpeed * 57.2958f + ring * 91f + bandValue * 38f) % 360f
                    val gap = (56f - bandValue * 30f - level * 12f).coerceIn(15f, 56f)
                    val sweep = 360f - gap
                    val ringSize = Size(radius * 2f, radius * 2f)
                    val ringTopLeft = Offset(center.x - radius, center.y - radius)
                    drawArc(
                        color = ringColor.copy(alpha = 0.095f + bandValue * 0.07f),
                        startAngle = rotation, sweepAngle = sweep, useCenter = false,
                        topLeft = ringTopLeft, size = ringSize,
                        style = Stroke(width = 4.4f + bandValue * 1.5f)
                    )
                    drawArc(
                        color = ringColor.copy(alpha = 0.48f + bandValue * 0.22f),
                        startAngle = rotation, sweepAngle = sweep, useCenter = false,
                        topLeft = ringTopLeft, size = ringSize,
                        style = Stroke(width = 0.78f + bandValue * 0.62f + sample * 0.18f)
                    )
                    drawArc(
                        color = nebulaHighColor.copy(alpha = 0.20f + highs * 0.18f),
                        startAngle = rotation + sweep + 6f,
                        sweepAngle = 11f + highs * 22f, useCenter = false,
                        topLeft = ringTopLeft, size = ringSize,
                        style = Stroke(width = 0.70f + highs * 0.46f)
                    )
                } else {
                    drawCircle(
                        ringColor.copy(alpha = when {
                            aurora -> 0.52f + sample * 0.14f
                            else -> 0.46f + sample * 0.18f
                        }),
                        radius,
                        center,
                        style = Stroke(width = if (fullScreen) 1.05f else 0.95f)
                    )
                }
            }

            // Dimensional orb with a shaded terminator, specular highlight and
            // an offset shadow. This restores the sphere-like centre of the refs.
            val pulseRadius = orbRadius * (1f + bass * (if (nebula) 0.068f else 0.045f) + mids * (if (nebula) 0.026f else 0.016f) + highs * (if (nebula) 0.012f else 0f))
            val shadowCenter = Offset(center.x + pulseRadius * 0.16f, center.y + pulseRadius * 0.19f)
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to Color(0xFF02030B).copy(alpha = if (aurora) 0.30f else 0.54f),
                        0.58f to Color(0xFF050817).copy(alpha = 0.24f),
                        1f to Color.Transparent
                    ),
                    center = shadowCenter,
                    radius = pulseRadius * 1.55f
                ),
                radius = pulseRadius * 1.55f,
                center = shadowCenter
            )
            if (nebula) {
                val haloRadius = pulseRadius * (2.28f + bass * 0.30f + nebulaBloom * 0.14f)
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to nebulaMidColor.copy(alpha = 0.24f + mids * 0.12f),
                            0.30f to nebulaBassColor.copy(alpha = 0.18f + bass * 0.10f),
                            0.58f to nebulaHighColor.copy(alpha = 0.12f + highs * 0.09f),
                            0.82f to nebulaTealColor.copy(alpha = 0.045f + highs * 0.025f),
                            1f to Color.Transparent
                        ), center = center, radius = haloRadius
                    ), haloRadius, center
                )
            }
            if (starfield) {
                val haloRadius = pulseRadius * (1.72f + bass * 0.18f)
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color(0xFF2DD4BF).copy(alpha = 0.095f + bass * 0.035f),
                            0.48f to Color(0xFFA78BFA).copy(alpha = 0.045f + mids * 0.025f),
                            0.78f to Color(0xFFF472B6).copy(alpha = 0.030f + highs * 0.020f),
                            1f to Color.Transparent
                        ), center = center, radius = haloRadius
                    ), haloRadius, center
                )
            }
            if (neon) {
                val haloRadius = pulseRadius * (2.25f + bass * 0.24f)
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color(0xFF7C3AED).copy(alpha = 0.30f + bass * 0.22f),
                            0.32f to Color(0xFF4338CA).copy(alpha = 0.24f + mids * 0.12f),
                            0.68f to Color(0xFF3B82F6).copy(alpha = 0.11f + highs * 0.08f),
                            1f to Color.Transparent
                        ),
                        center = center,
                        radius = haloRadius
                    ),
                    radius = haloRadius,
                    center = center
                )
                drawCircle(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF8B5CF6).copy(alpha = 0.10f + highs * 0.08f), Color.Transparent),
                        center = Offset(center.x - pulseRadius * 0.18f, center.y - pulseRadius * 0.22f),
                        radius = pulseRadius * 2.7f
                    ),
                    radius = pulseRadius * 2.7f,
                    center = center
                )
            }

            val orbStops = when {
                neon -> arrayOf(
                    0f to Color(0xFFF7F2FF),
                    0.13f to Color(0xFFBDF7EA),
                    0.30f to Color(0xFF60A5FA),
                    0.48f to Color(0xFF8B5CF6),
                    0.66f to Color(0xFFD946EF),
                    0.84f to Color(0xFFF472B6),
                    1f to Color(0xFF24102F)
                )
                aurora -> arrayOf(
                    0f to Color(0xFFFFFFFF),
                    0.22f to Color(0xFFE9FFF8),
                    0.48f to Color(0xFFB7E2DE),
                    0.72f to Color(0xFFD6C2D9),
                    0.92f to Color(0xFFEAB7C9),
                    1f to Color(0xFF876C90)
                )
                nebula -> arrayOf(
                    0f to Color(0xFFFFF3FA),
                    0.16f to androidx.compose.ui.graphics.lerp(Color(0xFFBDF7EA), Color(0xFFFFC6E7), (nebulaBloom * 0.56f + slowA * 0.10f).coerceIn(0f, 0.72f)),
                    0.38f to androidx.compose.ui.graphics.lerp(nebulaTealColor, nebulaMidColor, (mids * 0.58f + bass * 0.18f).coerceIn(0f, 0.78f)),
                    0.62f to nebulaBassColor,
                    0.82f to nebulaHighColor,
                    0.94f to Color(0xFF53245F),
                    1f to Color(0xFF1B102C)
                )
                starfield -> arrayOf(
                    0f to androidx.compose.ui.graphics.lerp(Color(0xFFE8F8F4), Color(0xFFFFE4EE), (audioTint * 0.38f + slowA * 0.12f).coerceIn(0f, 0.5f)),
                    0.18f to androidx.compose.ui.graphics.lerp(Color(0xFFB8F0E8), Color(0xFFF4B7D1), (audioTint * 0.58f).coerceIn(0f, 0.7f)),
                    0.40f to androidx.compose.ui.graphics.lerp(Color(0xFF63BDB4), Color(0xFFA78BFA), (bass * 0.34f + mids * 0.22f).coerceIn(0f, 0.7f)),
                    0.62f to Color(0xFFA78BFA),
                    0.83f to Color(0xFFF472B6),
                    0.96f to Color(0xFF8F526F),
                    1f to Color(0xFF241B2B)
                )
                else -> arrayOf(
                    0f to Color(0xFFFFFFFF),
                    0.22f to Color(0xFFDDFBF1),
                    0.48f to Color(0xFFAED4D4),
                    0.72f to Color(0xFFC4B3D1),
                    0.92f to Color(0xFFDDAFC4),
                    1f to Color(0xFF51405F)
                )
            }
            val orbShape = Path()
            val orbSteps = if (neon || nebula) 96 else 64
            for (step in 0..orbSteps) {
                val angle = step / orbSteps.toFloat() * (2f * PI.toFloat())
                val sample = waveform[(step * waveform.size / (orbSteps + 1)).coerceIn(0, waveform.lastIndex)]
                val band = spectrum[(step * spectrum.size / (orbSteps + 1)).coerceIn(0, spectrum.lastIndex)]
                val ripple = when {
                    neon ->
                        1f + sin(angle * 3f + phase * 1.8f) * (0.004f + bass * 0.006f) +
                            cos(angle * 5f - phase * 1.35f) * (0.002f + highs * 0.003f) +
                            (sample - 0.08f) * (0.003f + level * 0.004f) + band * 0.002f
                    starfield ->
                        1f + sin(angle * 3f + phase * 1.12f) * (0.003f + bass * 0.006f) +
                            cos(angle * 5f - phase * 0.82f) * (0.002f + highs * 0.003f) +
                            sin(angle * 7f + phase * 0.54f) * (0.001f + mids * 0.003f) +
                            (sample - 0.08f) * (0.003f + level * 0.004f) + band * 0.002f
                    nebula ->
                        1f + sin(angle * 3f + phase * 0.92f) * (0.004f + bass * 0.007f) +
                            cos(angle * 5f - phase * 0.74f) * (0.002f + highs * 0.004f) +
                            sin(angle * 8f + phase * 0.52f) * (0.001f + mids * 0.003f) +
                            (sample - 0.08f) * (0.004f + level * 0.004f) + band * 0.002f
                    else -> 1f + sin(angle * 3f + phase * 0.6f) * 0.006f + sample * 0.008f
                }
                val x = center.x + cos(angle) * pulseRadius * ripple
                val y = center.y + sin(angle) * pulseRadius * ripple * (if (neon) 0.985f else if (nebula) 0.975f + mids * 0.012f else 1f)
                if (step == 0) orbShape.moveTo(x, y) else orbShape.lineTo(x, y)
            }
            orbShape.close()
            val orbBrush = Brush.radialGradient(
                colorStops = orbStops,
                center = Offset(center.x - pulseRadius * (0.34f + highs * 0.06f), center.y - pulseRadius * 0.40f),
                radius = pulseRadius * 1.36f
            )
            drawPath(orbShape, orbBrush)
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to Color.White.copy(alpha = if (starfield) 0.40f else if (aurora) 0.60f else if (nebula) 0.62f else 0.52f),
                        0.38f to (if (neon) Color(0xFFC4B5FD) else if (starfield) Color(0xFFE7C7DA) else if (nebula) Color(0xFFFFD5F0) else Color(0xFFDFFFF9)).copy(alpha = if (starfield) 0.15f else if (nebula) 0.28f else 0.22f),
                        1f to Color.Transparent
                    ),
                    center = Offset(center.x - pulseRadius * 0.36f, center.y - pulseRadius * 0.43f),
                    radius = pulseRadius * 0.63f
                ),
                radius = pulseRadius * 0.63f,
                center = Offset(center.x - pulseRadius * 0.36f, center.y - pulseRadius * 0.43f)
            )
            val orbEdge = when {
                nebula -> nebulaHighColor
                neon -> Color(0xFF8B5CF6)
                starfield -> Color(0xFF2DD4BF)
                else -> Color(0xFFD5F0EA)
            }
            drawPath(orbShape, orbEdge.copy(alpha = 0.76f), style = Stroke(width = 1.15f))

            // Tiny orbiting planet dots move independently with frequency bands.
            val orbitCount = when { neon -> 14; starfield -> 8; nebula -> 12; aurora -> 12; else -> 10 }
            for (i in 0 until orbitCount) {
                val sample = waveform[(i * 7) % waveform.size]
                val band = spectrum[(i * 3) % spectrum.size]
                val escapePulse = if (neon) sin(phase * 0.82f + i * 1.31f) * (0.06f + level * 0.07f) else if (starfield) sin(phase * 0.42f + i * 1.31f) * (0.07f + level * 0.10f) else if (nebula) sin(phase * (0.30f + mids * 0.20f) + i * 1.31f) * (0.08f + level * 0.14f + bass * 0.08f) else 0f
                val orbit = pulseRadius * (1.62f + (i % 4) * 0.42f + escapePulse) + sample * minDim * 0.034f + (if (neon) bass * minDim * 0.025f else if (starfield) bass * minDim * 0.014f else if (nebula) bass * minDim * 0.020f else 0f)
                val angle = phase * (if (neon) (0.92f + (i % 4) * 0.26f + level * 0.32f) else if (starfield) (0.72f + (i % 4) * 0.13f + level * 0.16f) else if (nebula) (0.46f + (i % 4) * 0.10f + mids * 0.24f + level * 0.10f) else (0.15f + (i % 4) * 0.032f)) + i * 2.399f + band * 0.40f
                val x = center.x + cos(angle) * orbit
                val y = center.y + sin(angle * (if (neon) 1.12f else 1.07f)) * orbit * 0.72f
                val radius = if (neon) 1.5f + sample * 4.2f + band * 3.0f else 1.8f + sample * 4.0f + band * 2.4f
                val color = when {
                    neon -> when (i % 4) {
                        0 -> Color(0xFF60A5FA)
                        1 -> Color(0xFF8B5CF6)
                        2 -> Color(0xFF3B82F6)
                        else -> Color(0xFF7C3AED)
                    }
                    starfield -> when (i % 3) { 0 -> Color(0xFF8CCBC5); 1 -> Color(0xFFE0A7BC); else -> Color(0xFFA8B5D0) }
                    nebula -> when (i % 5) { 0 -> nebulaBassColor; 1 -> nebulaMidColor; 2 -> nebulaHighColor; 3 -> nebulaTealColor; else -> Color(0xFF60A5FA) }
                    aurora -> if (i % 2 == 0) Color(0xFF9BE5DC) else Color(0xFFEFBBCF)
                    else -> if (i % 2 == 0) Color(0xFF8FDAD0) else Color(0xFFE8B2CE)
                }
                if (starfield) {
                    for (trail in 1..2) {
                        val trailAngle = angle - trail * 0.075f
                        val trailRadius = orbit * (1f - trail * 0.018f)
                        drawCircle(
                            color.copy(alpha = 0.13f / trail + sample * 0.035f),
                            radius * (1f - trail * 0.20f),
                            Offset(center.x + cos(trailAngle) * trailRadius, center.y + sin(trailAngle * 1.08f) * trailRadius * 0.72f)
                        )
                    }
                    val softHalo = radius * (2.8f + band * 1.1f)
                    drawCircle(
                        Brush.radialGradient(
                            listOf(color.copy(alpha = 0.13f + band * 0.07f), Color.Transparent),
                            center = Offset(x, y), radius = softHalo
                        ), softHalo, Offset(x, y)
                    )
                }
                if (nebula) {
                    for (trail in 1..3) {
                        val trailAngle = angle - trail * (0.055f + mids * 0.025f)
                        val trailOrbit = orbit * (1f - trail * 0.014f)
                        drawCircle(color.copy(alpha = 0.12f / trail + sample * 0.055f), radius * (1f - trail * 0.16f),
                            Offset(center.x + cos(trailAngle) * trailOrbit, center.y + sin(trailAngle * 1.06f) * trailOrbit * 0.72f))
                    }
                    val dissolveRadius = radius * (3.2f + band * 1.6f)
                    drawCircle(
                        Brush.radialGradient(listOf(color.copy(alpha = 0.18f + band * 0.10f), Color.Transparent), center = Offset(x, y), radius = dissolveRadius),
                        dissolveRadius, Offset(x, y)
                    )
                }
                if (neon) {
                    for (trail in 1..3) {
                        val trailAngle = angle - trail * 0.09f
                        val trailRadius = orbit * (1f - trail * 0.012f)
                        drawCircle(color.copy(alpha = 0.20f / trail + sample * 0.06f), radius * (1f - trail * 0.18f),
                            Offset(center.x + cos(trailAngle) * trailRadius, center.y + sin(trailAngle * 1.12f) * trailRadius * 0.72f))
                    }
                    val glowRadius = radius * (3.6f + band * 1.8f)
                    drawCircle(
                        Brush.radialGradient(listOf(color.copy(alpha = 0.34f + band * 0.20f), Color.Transparent), center = Offset(x, y), radius = glowRadius),
                        glowRadius, Offset(x, y)
                    )
                }
                drawCircle(color.copy(alpha = if (neon) 0.96f else if (nebula) 0.74f + sample * 0.18f + band * 0.08f else 0.65f + sample * 0.22f), radius, Offset(x, y))
                drawCircle(Color.White.copy(alpha = if (neon) 0.62f else if (nebula) 0.48f + highs * 0.20f else 0.34f), radius * 0.25f,
                    Offset(x - radius * 0.25f, y - radius * 0.25f))
            }

            // Stronger spectrum arc, with each bar tied to both FFT and waveform data.
            // Full-screen non-Aurora spectrum bars share a low bottom rail. This
            // leaves an unobstructed band for station identity below the orbit field.
            // Aurora's original bar geometry is intentionally retained.
            val fullWidthBottomBars = fullScreen && !aurora
            val bars = if (fullWidthBottomBars) 64 else if (neon) 52 else if (starfield) 56 else if (nebula) 56 else 64
            val arcY = h * if (fullWidthBottomBars) 0.94f else if (fullScreen) 0.855f else 0.86f
            val arcWidth = w * (if (fullWidthBottomBars) 0.478f else if (fullScreen) 0.36f else 0.29f)
            for (i in 0 until bars) {
                val normalized = i / (bars - 1f)
                val x = center.x - arcWidth + normalized * arcWidth * 2f
                val envelope = if (fullWidthBottomBars) 0.54f + 0.46f * sin(normalized * PI).toFloat() else sin(normalized * PI).toFloat()
                val band = spectrum[(i * spectrum.size / bars).coerceIn(0, spectrum.lastIndex)]
                val wave = waveform[(i * waveform.size / bars).coerceIn(0, waveform.lastIndex)]
                val bassShape = if (fullWidthBottomBars) (1.30f - normalized * 0.66f) else if (neon) (1.24f - normalized * 0.36f) else if (starfield) (1.18f - normalized * 0.34f) else if (nebula) (1.22f - normalized * 0.40f) else 1f
                val trebleFlicker = if (fullWidthBottomBars) (0.78f + 0.22f * sin(phase * (2.8f + highs * 1.8f) + i * 0.73f)) else if (neon) (0.86f + 0.14f * sin(phase * 3.8f + i * 0.73f)) else if (starfield) (0.90f + 0.10f * sin(phase * 2.4f + i * 0.61f + highs)) else if (nebula) (0.84f + 0.16f * sin(phase * (2.2f + highs * 1.2f) + i * 0.63f)) else 1f
                val rawBarHeight = (4f + envelope * (if (fullWidthBottomBars) 9f + band * 64f + wave * 19f else 7f + band * 58f + wave * 28f) * (0.42f + level)) * bassShape * trebleFlicker
                val barHeight = if (fullWidthBottomBars) rawBarHeight.coerceAtMost(minDim * 0.060f) else rawBarHeight
                val color = when {
                    neon -> androidx.compose.ui.graphics.lerp(Color(0xFF3B82F6), Color(0xFF8B5CF6), normalized)
                    starfield -> androidx.compose.ui.graphics.lerp(Color(0xFF2DD4BF), Color(0xFFF472B6), normalized)
                    nebula -> {
                        val purpleViolet = androidx.compose.ui.graphics.lerp(Color(0xFF6D28D9), Color(0xFF8B5CF6), (normalized / 0.34f).coerceIn(0f, 1f))
                        val pinkMagenta = androidx.compose.ui.graphics.lerp(Color(0xFFD946EF), Color(0xFFF472B6), ((normalized - 0.34f) / 0.38f).coerceIn(0f, 1f))
                        val pinkToBlue = androidx.compose.ui.graphics.lerp(pinkMagenta, Color(0xFF60A5FA), ((normalized - 0.72f) / 0.28f).coerceIn(0f, 1f))
                        val paletteColor = if (normalized < 0.34f) purpleViolet else pinkToBlue
                        androidx.compose.ui.graphics.lerp(paletteColor, Color(0xFF2DD4BF), if (band > 0.72f && normalized > 0.82f) 0.18f else 0f)
                    }
                    aurora -> androidx.compose.ui.graphics.lerp(Color(0xFFA8DCD2), Color(0xFFE6B7C9), normalized)
                    else -> androidx.compose.ui.graphics.lerp(Color(0xFF75B7AD), Color(0xFFD69BB7), normalized)
                }
                if (neon) {
                    drawLine(color.copy(alpha = 0.16f + band * 0.16f), Offset(x, arcY), Offset(x, arcY - barHeight), strokeWidth = 5.2f)
                    drawCircle(Color(0xFFC4B5FD).copy(alpha = 0.48f + band * 0.36f), 1.05f + band * 0.55f, Offset(x, arcY - barHeight))
                } else if (nebula) {
                    drawLine(color.copy(alpha = if (fullWidthBottomBars) 0.09f + band * 0.16f else 0.08f + band * 0.10f),
                        Offset(x, arcY), Offset(x, arcY - barHeight),
                        strokeWidth = if (fullWidthBottomBars) 5.8f else 4.0f)
                    drawCircle(color.copy(alpha = 0.28f + band * 0.26f + highs * 0.10f),
                        (if (fullWidthBottomBars) 1.05f else 0.85f) + band * 0.62f, Offset(x, arcY - barHeight))
                }
                val coreBarAlpha = when {
                    neon -> 0.98f
                    nebula && fullWidthBottomBars -> 0.88f + band * 0.10f
                    nebula -> 0.82f + band * 0.12f
                    aurora -> 0.70f
                    else -> 0.66f
                }
                drawLine(
                    color.copy(alpha = coreBarAlpha),
                    Offset(x, arcY),
                    Offset(x, arcY - barHeight),
                    strokeWidth = if (starfield) 1.35f else if (nebula && fullWidthBottomBars) 2.0f else if (nebula) 1.55f else if (fullScreen) 1.9f else 1.55f
                )
            }
        }
    }
}

@Composable
private fun TvRoundControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.size(if (primary) 58.dp else 48.dp).clip(CircleShape)
                .background(if (primary) Brush.linearGradient(listOf(MatteTeal, MattePink)) else Brush.linearGradient(listOf(if (amoled) Color(0xFF080808) else Color(0xFF272C34), if (amoled) Color(0xFF080808) else Color(0xFF272C34))))
                .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, CircleShape)
                .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Icon(icon, null, tint = if (primary) MatteInk else MatteText,
                modifier = Modifier.size(if (primary) 26.dp else 21.dp))
        }
        Text(label, color = MatteMuted, fontSize = 8.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvControlText(
    label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (primary) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(if (amoled) Color(0xCC080808) else Color(0xCC27323B), if (amoled) Color(0xCC080808) else Color(0xCC27323B))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0xAA9BA9AD), RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 15.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (primary) MatteInk else MatteText, modifier = Modifier.size(17.dp))
        Text(label, color = if (primary) MatteInk else MatteText, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvPillButton(label: String, onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (amoled) Color(0xFF050505) else Color(0xFF272C34))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 11.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = MatteTeal, modifier = Modifier.size(16.dp))
        Text(label, color = MatteText, fontSize = 9.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: androidx.compose.ui.unit.Dp = 50.dp,
    iconSize: androidx.compose.ui.unit.Dp = 23.dp,
    onFocusActivity: () -> Unit = {},
    neon: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier.size(buttonSize).clip(CircleShape)
            .background(if (focused) if (neon) Color(0xFF30206C) else Color(0xFFE0EEE9) else if (neon) Color(0xAA0A0A1F) else Color(0x88202B35))
            .border(if (focused) 1.5.dp else 0.7.dp, if (focused) if (neon) Color(0xFFBFDBFE) else MatteText else if (neon) Color(0xCC8B5CF6) else Color(0x667A8990), CircleShape)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocusActivity() }
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            icon, description,
            tint = if (neon) Color(0xFFE0E7FF) else if (focused) MatteInk else Color(0xFFF4F6F7),
            modifier = Modifier.size(iconSize)
        )
    }
}

@Composable
private fun TvVisualizerStyleChoice(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    buttonWidth: androidx.compose.ui.unit.Dp = 104.dp,
    buttonHeight: androidx.compose.ui.unit.Dp = 36.dp
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    val neon = label == "NEON"
    val selectedBrush = when {
        selected && neon -> Brush.horizontalGradient(listOf(Color(0xFF4338CA), Color(0xFF7C3AED), Color(0xFF3B82F6)))
        selected -> Brush.horizontalGradient(listOf(MatteTeal, MattePink))
        else -> Brush.horizontalGradient(
            listOf(if (amoled) Color(0xFF080808) else Color(0xFF303640),
                   if (amoled) Color(0xFF080808) else Color(0xFF303640))
        )
    }
    Box(
        Modifier.width(buttonWidth).height(buttonHeight)
            .clip(RoundedCornerShape(8.dp))
            .background(selectedBrush)
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) Color.White else MatteLine,
                shape = RoundedCornerShape(8.dp)
            )
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (selected) if (neon) Color.White else MatteInk else MatteText,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 0.25.sp,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip
        )
    }
}

@Composable
private fun TvSmallTextButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier.clip(RoundedCornerShape(30.dp))
            .background(if (focused) Color(0x334D5958) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0x557A8584), RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) androidx.compose.material3.Icon(icon, null, tint = MatteText, modifier = Modifier.size(14.dp))
        Text(label, color = MatteText, fontSize = 8.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvVolumeControl(
    volume: Float, onValue: (Float) -> Unit, compact: Boolean, miniVisualizer: Boolean = false,
    neon: Boolean = false,
    starfield: Boolean = false,
    nebula: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Column(
        Modifier.width(when { miniVisualizer -> 108.dp; compact -> 178.dp; else -> 245.dp }),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            androidx.compose.material3.Icon(
                Icons.Default.VolumeUp, null, tint = if (neon) Color(0xFFC4B5FD) else if (starfield) Color(0xFFD7C8D4) else if (nebula) Color(0xFFE8C6F3) else MatteMuted,
                modifier = Modifier.size(if (miniVisualizer) 9.dp else 17.dp)
            )
            Slider(
                value = volume, onValueChange = onValue,
                colors = SliderDefaults.colors(
                    thumbColor = if (neon) Color(0xFF8B5CF6) else if (starfield) Color(0xFFA78BFA) else if (nebula) Color(0xFFD946EF) else MatteTeal,
                    activeTrackColor = if (neon) Color(0xFF3B82F6) else if (starfield) Color(0xFF2DD4BF) else if (nebula) Color(0xFF8B5CF6) else MatteTeal,
                    inactiveTrackColor = if (neon) Color(0x665B4A91) else if (starfield) Color(0x665A4B5A) else if (nebula) Color(0x665D285E) else if (amoled) Color(0xFF303030) else Color(0xFF626B70)
                ),
                modifier = Modifier.weight(1f)
                    .onFocusChanged { focused = it.isFocused }
                    .onPreviewKeyEvent { event ->
                        if (event.type == KeyEventType.KeyDown) {
                            when (event.key) {
                                Key.DirectionLeft -> { onValue((volume - 0.04f).coerceAtLeast(0f)); true }
                                Key.DirectionRight -> { onValue((volume + 0.04f).coerceAtMost(1f)); true }
                                else -> false
                            }
                        } else false
                    }.focusable(),
            )
            if (!miniVisualizer) Text("${(volume * 100).toInt()}%", color = MatteMuted, fontSize = 10.sp)
        }
        if (focused && !miniVisualizer) Text("VOLUME", color = if (neon) Color(0xFF8B5CF6) else MatteTeal, fontSize = 8.sp, letterSpacing = 1.1.sp)
    }
}

@Composable
private fun TvSettingsDialog(
    backgroundPlayback: Boolean, onBackgroundPlayback: (Boolean) -> Unit,
    hideVolume: Boolean, onHideVolume: (Boolean) -> Unit,
    hideSkip: Boolean, onHideSkip: (Boolean) -> Unit,
    keepScreenAwake: Boolean, onKeepScreenAwake: (Boolean) -> Unit,
    shuffleEnabled: Boolean, onShuffleEnabled: (Boolean) -> Unit,
    visualizerStyle: String, onVisualizerStyle: (String) -> Unit,
    appTheme: String, onAppTheme: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.width(370.dp),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        shape = RoundedCornerShape(20.dp),
        containerColor = if (amoled) Color(0x80000000) else Color(0x8020252C),
        tonalElevation = 0.dp,
        title = {
            Text("Settings", color = MatteText, fontSize = 17.sp, fontWeight = FontWeight.Medium)
        },
        text = {
            Column(Modifier.width(326.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                TvSettingRow("Background playback", "Keep radio playing when the app is in the background", backgroundPlayback, onBackgroundPlayback)
                TvSettingRow("Hide volume in full screen", "Only affects the full-screen visualizer", hideVolume, onHideVolume)
                TvSettingRow("Hide previous / next in full screen", "Only affects the full-screen visualizer", hideSkip, onHideSkip)
                TvSettingRow("Keep screen awake", "Prevent the TV screensaver while visible", keepScreenAwake, onKeepScreenAwake)
                TvSettingRow("Shuffle stations", "Play a random station; failed streams are skipped", shuffleEnabled, onShuffleEnabled)

                Spacer(Modifier.height(3.dp))
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("Visualizer style", color = MatteText, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("Four audio-reactive looks. App theme remains independent.", color = MatteMuted, fontSize = 7.5.sp, maxLines = 1)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        TvVisualizerStyleChoice("NEBULA", visualizerStyle == "NEBULA", { onVisualizerStyle("NEBULA") }, 75.dp, 28.dp)
                        TvVisualizerStyleChoice("AURORA", visualizerStyle == "AURORA", { onVisualizerStyle("AURORA") }, 75.dp, 28.dp)
                        TvVisualizerStyleChoice("NEON", visualizerStyle == "NEON", { onVisualizerStyle("NEON") }, 75.dp, 28.dp)
                        TvVisualizerStyleChoice("STARFIELD", visualizerStyle == VISUALIZER_STARFIELD, { onVisualizerStyle(VISUALIZER_STARFIELD) }, 82.dp, 28.dp)
                    }
                }

                Spacer(Modifier.height(2.dp))
                Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("App theme", color = MatteText, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    Text("Default or true-black AMOLED. Does not change the visualizer.", color = MatteMuted, fontSize = 7.5.sp, maxLines = 1)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TvVisualizerStyleChoice("DEFAULT", appTheme == "DEFAULT", { onAppTheme("DEFAULT") }, 92.dp, 28.dp)
                        TvVisualizerStyleChoice("AMOLED", appTheme == "AMOLED", { onAppTheme("AMOLED") }, 92.dp, 28.dp)
                    }
                }
            }
        },
        confirmButton = {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                TvVisualizerStyleChoice("DONE", true, onDismiss, 70.dp, 27.dp)
            }
        }
    )
}

@Composable
private fun TvSettingRow(
    title: String,
    description: String,
    checked: Boolean,
    onChecked: (Boolean) -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.height(31.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                title, color = MatteText, fontSize = 9.5.sp, lineHeight = 10.sp,
                fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false,
                overflow = TextOverflow.Clip
            )
            Text(
                description, color = MatteMuted, fontSize = 7.sp, lineHeight = 8.sp,
                maxLines = 1, softWrap = false, overflow = TextOverflow.Clip
            )
        }
        Box(
            Modifier.width(38.dp).height(21.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(if (checked) MatteTeal else Color(0xFF4A505A))
                .border(if (focused) 1.5.dp else 0.6.dp,
                    if (focused) Color.White else MatteLine, RoundedCornerShape(20.dp))
                .onFocusChanged { focused = it.isFocused }
                .clickable { onChecked(!checked) }
                .focusable(),
            contentAlignment = if (checked) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            Box(
                Modifier.padding(horizontal = 3.dp).size(15.dp)
                    .background(if (checked) Color(0xFF19353A) else Color(0xFFE5E7EA), CircleShape)
            )
        }
    }
}

@Composable
private fun TvSleepDialog(
    remaining: Int,
    selectedAction: String,
    onActionChange: (String) -> Unit,
    onSet: (Int) -> Unit,
    onCancelTimer: () -> Unit,
    onDismiss: () -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.width(350.dp),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        containerColor = if (amoled) Color.Black else Color(0xFF20252C),
        title = { Text("Sleep timer", color = MatteText, fontSize = 18.sp, fontWeight = FontWeight.Medium) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    if (remaining > 0) "Current timer: ${formatTime(remaining)}" else "Choose what happens when the timer ends",
                    color = MatteMuted, fontSize = 10.sp
                )
                Text("AFTER TIMER", color = MatteTeal, fontSize = 8.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    TvVisualizerStyleChoice(
                        "STOP PLAYING", selectedAction == "STOP_PLAYING",
                        { onActionChange("STOP_PLAYING") }, 104.dp, 29.dp
                    )
                    TvVisualizerStyleChoice(
                        "EXIT APP", selectedAction == "EXIT_APP",
                        { onActionChange("EXIT_APP") }, 82.dp, 29.dp
                    )
                    TvVisualizerStyleChoice(
                        "TURN OFF TV", selectedAction == "TURN_OFF_TV",
                        { onActionChange("TURN_OFF_TV") }, 94.dp, 29.dp
                    )
                }
                Text(
                    "At timer end, playback stops and the screen is darkened. Android TV enters standby using its own power timeout; ordinary apps cannot force hardware power-off.",
                    color = MatteMuted, fontSize = 7.5.sp, lineHeight = 9.sp
                )
                Text("TIMER DURATION", color = MatteTeal, fontSize = 8.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(15, 30, 45, 60, 90).forEach { minutes ->
                        TextButton(
                            onClick = { onSet(minutes) },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text("${minutes}m", color = MatteTeal, fontSize = 11.sp)
                        }
                    }
                }
                if (remaining > 0) {
                    TextButton(onClick = onCancelTimer) {
                        Text("CANCEL TIMER", color = MattePink, fontSize = 9.sp, letterSpacing = 0.8.sp)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("DONE", color = MatteMuted, fontSize = 9.sp, letterSpacing = 1.sp)
            }
        }
    )
}

private fun formatTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    return "%02d:%02d".format(safe / 60, safe % 60)
}
