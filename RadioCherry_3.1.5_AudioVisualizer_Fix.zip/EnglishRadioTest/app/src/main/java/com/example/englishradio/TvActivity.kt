package com.example.englishradio

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

private enum class TvPage { NOW_PLAYING, BROWSE, FAVORITES }

private val MatteInk = Color(0xFF11141B)
private val MatteCard = Color(0xFF20242D)
private val MatteLine = Color(0xFF484E59)
private val MatteText = Color(0xFFF4F3F2)
private val MatteMuted = Color(0xFFB6BAC2)
private val MatteTeal = Color(0xFF9BCFC6)
private val MattePink = Color(0xFFE7B9C9)
private val MatteMint = Color(0xFFB8DED4)
private val LocalTvAmoledTheme = compositionLocalOf { false }
private val LocalTvNeonTheme = compositionLocalOf { false }

class TvActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private val preferences by lazy {
        getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        applyKeepScreenAwake(preferences.getBoolean("tv_keep_screen_awake", true))
        val artwork = runCatching { assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
        PlaybackService.configureStationQueue(stations, artwork)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({ runCatching { future.get() }.onSuccess { controller = it } }, ContextCompat.getMainExecutor(this))
        }
        setContent {
            TvRadioCherry(
                player = controller,
                onKeepScreenAwake = ::applyKeepScreenAwake,
                onExit = ::exitApplication
            )
        }
    }

    private fun applyKeepScreenAwake(enabled: Boolean) {
        if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onStop() {
        if (!preferences.getBoolean("tv_background_playback", true)) {
            controller?.let { active ->
                active.pause()
                active.clearMediaItems()
            }
        }
        super.onStop()
    }

    private fun exitApplication() {
        runCatching {
            controller?.pause()
            controller?.clearMediaItems()
            stopService(Intent(this, PlaybackService::class.java))
        }
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        finishAndRemoveTask()
        Handler(Looper.getMainLooper()).postDelayed({ Process.killProcess(Process.myPid()) }, 180L)
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun TvRadioCherry(
    player: MediaController?,
    onKeepScreenAwake: (Boolean) -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", Context.MODE_PRIVATE)
    }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }
    var audioPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioPermission = it }
    var waveform by remember { mutableStateOf(FloatArray(64) { 0.012f }) }
    var spectrum by remember { mutableStateOf(FloatArray(32) { 0.008f }) }
    var audioEnergy by remember { mutableFloatStateOf(0.012f) }
    var page by remember { mutableStateOf(TvPage.NOW_PLAYING) }
    var fullScreen by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf(player?.currentMediaItem?.mediaId) }
    var playing by remember { mutableStateOf(player?.isPlaying == true) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet()) }
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf("All") }
    var settingsOpen by remember { mutableStateOf(false) }
    var sleepDialogOpen by remember { mutableStateOf(false) }
    var sleepUntil by remember { mutableStateOf<Long?>(null) }
    var sleepRemaining by remember { mutableIntStateOf(0) }
    var volume by remember { mutableFloatStateOf(prefs.getFloat("tv_volume", 0.72f).coerceIn(0f, 1f)) }
    var backgroundPlayback by remember { mutableStateOf(prefs.getBoolean("tv_background_playback", true)) }
    var hideVolume by remember { mutableStateOf(prefs.getBoolean("tv_hide_volume", false)) }
    var hideSkip by remember { mutableStateOf(prefs.getBoolean("tv_hide_previous_next", false)) }
    var keepScreenAwake by remember { mutableStateOf(prefs.getBoolean("tv_keep_screen_awake", true)) }
    var visualizerDarker by remember { mutableStateOf(prefs.getBoolean("tv_visualizer_darker", false)) }
    var appTheme by remember {
        mutableStateOf(
            prefs.getString(
                "tv_app_theme",
                if (prefs.getBoolean("tv_theme_amoled", false)) "AMOLED" else "DEFAULT"
            ) ?: "DEFAULT"
        )
    }
    val amoledTheme = appTheme == "AMOLED"
    val neonTheme = appTheme == "NEON"
    var visualizerChromeVisible by remember { mutableStateOf(true) }
    var visualizerActivityRevision by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("CHOOSE A STATION TO BEGIN") }
    val scope = rememberCoroutineScope()
    val selected = stations.firstOrNull { it.id == selectedId }
    val visibleStations = remember(page, search, selectedGenre, favorites) {
        val base = if (page == TvPage.FAVORITES) stations.filter { it.id in favorites } else stations
        base.filter { station ->
            val matchesSearch = search.isBlank() ||
                station.name.contains(search, true) || station.genre.contains(search, true) ||
                station.broadcaster.contains(search, true) || station.category.contains(search, true)
            val text = "${station.category} ${station.genre} ${station.name}".lowercase()
            val matchesGenre = selectedGenre == "All" || when (selectedGenre) {
                "Ambient" -> text.contains("ambient") || text.contains("chill") || text.contains("downtempo")
                "Electronic" -> text.contains("electronic") || text.contains("dance") || text.contains("house")
                "Indie" -> text.contains("indie") || text.contains("alternative") || text.contains("rock")
                "80s" -> text.contains("80") || text.contains("new wave") || text.contains("throwback")
                "Classical" -> text.contains("classical") || text.contains("instrumental") || text.contains("orchestra")
                "Sleep" -> text.contains("sleep") || text.contains("nature") || text.contains("soundscape")
                "Nature" -> text.contains("nature") || text.contains("field recording") || text.contains("bird")
                "Jazz" -> text.contains("jazz")
                else -> true
            }
            matchesSearch && matchesGenre
        }
    }

    LaunchedEffect(Unit) {
        if (!audioPermission) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(keepScreenAwake) {
        prefs.edit().putBoolean("tv_keep_screen_awake", keepScreenAwake).apply()
        onKeepScreenAwake(keepScreenAwake)
    }

    LaunchedEffect(visualizerDarker) {
        prefs.edit().putBoolean("tv_visualizer_darker", visualizerDarker).apply()
    }

    LaunchedEffect(appTheme) {
        prefs.edit()
            .putString("tv_app_theme", appTheme)
            .putBoolean("tv_theme_amoled", appTheme == "AMOLED")
            .putBoolean("tv_theme_neon", appTheme == "NEON")
            .apply()
    }

    LaunchedEffect(fullScreen, visualizerActivityRevision) {
        if (!fullScreen) {
            visualizerChromeVisible = true
        } else {
            delay(60_000L)
            visualizerChromeVisible = false
        }
    }

    LaunchedEffect(backgroundPlayback, hideVolume, hideSkip) {
        prefs.edit()
            .putBoolean("tv_background_playback", backgroundPlayback)
            .putBoolean("tv_hide_volume", hideVolume)
            .putBoolean("tv_hide_previous_next", hideSkip)
            .apply()
    }

    LaunchedEffect(player, playing, audioPermission) {
        waveform = FloatArray(64) { 0.012f }
        spectrum = FloatArray(32) { 0.008f }
        audioEnergy = 0.012f
        if (!audioPermission || player == null || !playing) return@LaunchedEffect
        var sessionId = PlaybackService.currentAudioSessionId
        repeat(20) {
            if (sessionId <= 0) {
                delay(120)
                sessionId = PlaybackService.currentAudioSessionId
            }
        }
        if (sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        val mainHandler = Handler(Looper.getMainLooper())
        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(512)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    if (bytes.isEmpty()) return
                    val samples = FloatArray(64) { i ->
                        val index = (i * (bytes.size - 1) / 63).coerceIn(0, bytes.lastIndex)
                        abs((bytes[index].toInt() and 0xFF) - 128) / 128f
                    }
                    val level = (samples.average().toFloat() * 2.15f).coerceIn(0.012f, 1f)
                    mainHandler.post {
                        waveform = samples
                        audioEnergy = level
                    }
                }

                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) {
                    if (fft.size < 4) return
                    val bands = FloatArray(32) { index ->
                        val bin = (index + 1).coerceAtMost((fft.size / 2) - 1)
                        val real = fft[2 * bin].toInt().toFloat()
                        val imaginary = fft[2 * bin + 1].toInt().toFloat()
                        (sqrt(real * real + imaginary * imaginary) / 92f).coerceIn(0f, 1f)
                    }
                    mainHandler.post { spectrum = bands }
                }
            }, Visualizer.getMaxCaptureRate() / 2, true, true)
            visualizer.enabled = true
            kotlinx.coroutines.awaitCancellation()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (_: Exception) {
        } finally {
            runCatching { visualizer.enabled = false; visualizer.release() }
        }
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isNowPlaying: Boolean) {
                playing = isNowPlaying
                status = if (isNowPlaying) "ON AIR  ·  LIVE STREAM" else "PAUSED"
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
            }
            override fun onPlaybackStateChanged(state: Int) {
                status = when (state) {
                    Player.STATE_BUFFERING -> "CONNECTING TO STATION…"
                    Player.STATE_READY -> if (player.isPlaying) "ON AIR  ·  LIVE STREAM" else "READY TO PLAY"
                    Player.STATE_IDLE -> "CHOOSE A STATION TO BEGIN"
                    Player.STATE_ENDED -> "STREAM ENDED"
                    else -> status
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status = "STREAM UNAVAILABLE"
            }
        }
        player.addListener(listener)
        selectedId = player.currentMediaItem?.mediaId
        playing = player.isPlaying
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(favorites) {
        prefs.edit().putStringSet("favorite_station_ids", favorites).apply()
    }

    LaunchedEffect(player, volume) {
        player?.volume = volume
        prefs.edit().putFloat("tv_volume", volume).apply()
    }

    LaunchedEffect(sleepUntil) {
        val deadline = sleepUntil ?: return@LaunchedEffect
        while (true) {
            val remaining = ((deadline - System.currentTimeMillis()) / 1000L).toInt()
            if (remaining <= 0) {
                player?.pause()
                player?.clearMediaItems()
                sleepUntil = null
                sleepRemaining = 0
                status = "SLEEP TIMER ENDED · PLAYBACK STOPPED"
                break
            }
            sleepRemaining = remaining
            delay(1000)
        }
    }

    fun toggleFavorite(station: Station) {
        favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
    }

    suspend fun playStation(station: Station, keepVisualizerOpen: Boolean = false) {
        val active = player ?: return
        status = "CONNECTING TO STATION…"
        val resolved = withContext(Dispatchers.IO) {
            runCatching { PlaylistResolver.resolve(station.stream) }.getOrDefault(station.stream)
        }
        selectedId = station.id
        active.setMediaItem(PlaybackService.mediaItem(station.copy(stream = resolved), orbArtwork))
        active.prepare()
        active.play()
        if (!keepVisualizerOpen) {
            page = TvPage.NOW_PLAYING
            fullScreen = false
        }
    }

    fun stepStation(direction: Int) {
        val current = selected
        val group = current?.let { station ->
            stations.filter { it.category.equals(station.category, ignoreCase = true) }
        }.orEmpty().ifEmpty { stations }
        val index = group.indexOfFirst { it.id == selectedId }
        val nextIndex = if (index < 0) 0 else (index + direction + group.size) % group.size
        val next = group.getOrNull(nextIndex) ?: return
        val keepVisualizerOpen = fullScreen
        scope.launch { playStation(next, keepVisualizerOpen = keepVisualizerOpen) }
    }

    fun togglePlayback() {
        val active = player ?: return
        if (active.isPlaying) active.pause()
        else if (active.mediaItemCount > 0) active.play()
        else selected?.let { scope.launch { playStation(it) } } ?: stepStation(0)
    }

    fun registerVisualizerActivity() {
        visualizerChromeVisible = true
        visualizerActivityRevision++
    }

    BackHandler(enabled = fullScreen || settingsOpen || sleepDialogOpen || page != TvPage.NOW_PLAYING) {
        when {
            sleepDialogOpen -> sleepDialogOpen = false
            settingsOpen -> settingsOpen = false
            fullScreen -> fullScreen = false
            page != TvPage.NOW_PLAYING -> page = TvPage.NOW_PLAYING
        }
    }

    CompositionLocalProvider(LocalTvAmoledTheme provides amoledTheme, LocalTvNeonTheme provides neonTheme) {
      MaterialTheme {
        Box(
            Modifier.fillMaxSize()
                .background(when { amoledTheme -> Color.Black; neonTheme -> Color(0xFF050511); else -> MatteInk })
                .onPreviewKeyEvent { event ->
                    if (fullScreen && event.type == KeyEventType.KeyDown) registerVisualizerActivity()
                    false
                }
        ) {
            if (fullScreen) {
                TvFullScreenVisualizer(
                    selected = selected, playing = playing, status = status,
                    waveform = waveform, spectrum = spectrum, audioEnergy = audioEnergy,
                    visualizerDarker = visualizerDarker,
                    chromeVisible = visualizerChromeVisible,
                    onUserActivity = ::registerVisualizerActivity,
                    hideSkip = hideSkip, hideVolume = hideVolume, volume = volume,
                    favorite = selected?.id?.let { it in favorites } == true,
                    sleepRemaining = sleepRemaining,
                    onBack = { fullScreen = false }, onPlayPause = ::togglePlayback,
                    onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                    onFavorite = { selected?.let(::toggleFavorite) },
                    onVolume = { volume = it }, onSleep = { sleepDialogOpen = true },
                    onSettings = { settingsOpen = true }, onExit = onExit
                )
            } else {
                Row(
                    Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 27.dp),
                    horizontalArrangement = Arrangement.spacedBy(34.dp)
                ) {
                    TvSidebar(
                        page = page,
                        onPage = { page = it; if (it != TvPage.BROWSE) { search = ""; selectedGenre = "All" } },
                        onSettings = { settingsOpen = true }, onExit = onExit
                    )
                    Box(Modifier.weight(1f).fillMaxHeight()) {
                        when (page) {
                            TvPage.NOW_PLAYING -> TvNowPlaying(
                                selected = selected, playing = playing, status = status,
                                waveform = waveform, spectrum = spectrum, audioEnergy = audioEnergy,
                                visualizerDarker = visualizerDarker,
                                volume = volume, favorite = selected?.id?.let { it in favorites } == true,
                                sleepRemaining = sleepRemaining,
                                onPlayPause = ::togglePlayback,
                                onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                                onFavorite = { selected?.let(::toggleFavorite) },
                                onVolume = { volume = it },
                                onBrowse = { page = TvPage.BROWSE },
                                onFullscreen = { fullScreen = true },
                                onSleep = { sleepDialogOpen = true }
                            )
                            TvPage.BROWSE, TvPage.FAVORITES -> TvBrowsePage(
                                isFavorites = page == TvPage.FAVORITES,
                                stations = visibleStations, totalCount = if (page == TvPage.BROWSE) stations.size else visibleStations.size,
                                selectedId = selectedId, favorites = favorites,
                                search = search, onSearch = { search = it },
                                selectedGenre = selectedGenre, onGenre = { selectedGenre = it },
                                onSelect = { station -> scope.launch { playStation(station) } },
                                onFavorite = ::toggleFavorite
                            )
                        }
                    }
                }
            }

            if (settingsOpen) {
                TvSettingsDialog(
                    backgroundPlayback = backgroundPlayback, onBackgroundPlayback = { backgroundPlayback = it },
                    hideVolume = hideVolume, onHideVolume = { hideVolume = it },
                    hideSkip = hideSkip, onHideSkip = { hideSkip = it },
                    keepScreenAwake = keepScreenAwake, onKeepScreenAwake = { keepScreenAwake = it },
                    visualizerDarker = visualizerDarker, onVisualizerDarker = { visualizerDarker = it },
                    appTheme = appTheme, onAppTheme = { appTheme = it },
                    onDismiss = { settingsOpen = false }
                )
            }

            if (sleepDialogOpen) {
                TvSleepDialog(
                    remaining = sleepRemaining,
                    onSet = { minutes -> sleepUntil = System.currentTimeMillis() + minutes * 60_000L; sleepDialogOpen = false },
                    onCancelTimer = { sleepUntil = null; sleepRemaining = 0; sleepDialogOpen = false },
                    onDismiss = { sleepDialogOpen = false }
                )
            }
        }
      }
    }
}

@Composable
private fun TvSidebar(
    page: TvPage, onPage: (TvPage) -> Unit, onSettings: () -> Unit, onExit: () -> Unit
) {
    val initialFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { initialFocus.requestFocus() }
    Column(Modifier.width(205.dp).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("radio", color = MatteText, fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 1.7.sp)
                Text("cherry", color = MattePink, fontSize = 27.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
            }
            Spacer(Modifier.height(10.dp))
            TvNavItem("NOW PLAYING", page == TvPage.NOW_PLAYING, { onPage(TvPage.NOW_PLAYING) }, Icons.Default.Radio, Modifier.focusRequester(initialFocus))
            TvNavItem("BROWSE", page == TvPage.BROWSE, { onPage(TvPage.BROWSE) }, Icons.Default.Explore)
            TvNavItem("FAVOURITES", page == TvPage.FAVORITES, { onPage(TvPage.FAVORITES) }, Icons.Default.Favorite)
        }
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("INTERNET RADIO", color = Color(0xFF858B95), fontSize = 10.sp, letterSpacing = 2.sp,
                modifier = Modifier.padding(start = 5.dp, bottom = 5.dp))
            TvUtilityButton("SETTINGS", onSettings, Icons.Default.Settings)
            TvUtilityButton("EXIT APP", onExit, Icons.Default.Close, accent = false)
        }
    }
}

@Composable
private fun TvNavItem(
    label: String, selected: Boolean, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    val neon = LocalTvNeonTheme.current
    val selectedBrush = if (neon) Brush.horizontalGradient(listOf(Color(0xFF263BFF), Color(0xFF8438FF), Color(0xFF00CFFF)))
        else Brush.horizontalGradient(listOf(MatteTeal, MattePink))
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(brush = if (selected) selectedBrush else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else if (selected) Color.Transparent else if (neon) Color(0xFF5450A8) else MatteLine, RoundedCornerShape(14.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (selected && !neon) MatteInk else if (selected) Color.White else MatteMuted, modifier = Modifier.size(19.dp))
        Text(label, color = if (selected && !neon) MatteInk else MatteText, fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvUtilityButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector, accent: Boolean = true
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    val neon = LocalTvNeonTheme.current
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (focused) if (amoled) Color(0xFF141414) else Color(0xFF2A3038) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else if (neon) Color(0xFF5751A8) else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (accent) MatteTeal else MatteMuted, modifier = Modifier.size(17.dp))
        Text(label, color = MatteMuted, fontSize = 10.sp, letterSpacing = 1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvNowPlaying(
    selected: Station?, playing: Boolean, status: String,
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float, visualizerDarker: Boolean,
    volume: Float, favorite: Boolean, sleepRemaining: Int,
    onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit,
    onBrowse: () -> Unit, onFullscreen: () -> Unit, onSleep: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("NOW PLAYING", color = MatteTeal, fontSize = 10.sp, letterSpacing = 2.5.sp, fontWeight = FontWeight.SemiBold)
            TvSmallTextButton("FULL SCREEN VISUALIZER", onFullscreen, Icons.Default.Fullscreen)
        }
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth().height(278.dp).clip(RoundedCornerShape(20.dp))) {
            ReactiveVisualScene(waveform, spectrum, audioEnergy, Modifier.fillMaxSize(), fullScreen = false, darker = visualizerDarker)
        }
        Spacer(Modifier.height(17.dp))
        Text("radio cherry LIVE", color = Color(0xFFE9EEF0), fontSize = 13.sp,
            fontWeight = FontWeight.Medium, letterSpacing = 1.1.sp)
        Spacer(Modifier.height(4.dp))
        Text(selected?.name ?: "Choose a station to begin",
            color = MatteText, fontSize = 29.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(5.dp))
        Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Discover more than 200 stations from around the world",
            color = Color(0xFFD7DCE0), fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(8.dp))
        Text(status, color = Color(0xFFC4E6DD), fontSize = 11.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.SemiBold)
        if (sleepRemaining > 0) {
            Text("SLEEP TIMER  ·  ${formatTime(sleepRemaining)}", color = MattePink, fontSize = 10.sp,
                letterSpacing = 1.3.sp, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(17.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            TvRoundControl(Icons.Default.SkipPrevious, "PREVIOUS", onPrevious)
            TvRoundControl(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "PAUSE" else "PLAY", onPlayPause, primary = true)
            TvRoundControl(Icons.Default.SkipNext, "NEXT", onNext)
            TvRoundControl(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "FAVOURITE", onFavorite)
            Spacer(Modifier.width(4.dp))
            TvPillButton(if (sleepRemaining > 0) "SLEEP ${formatTime(sleepRemaining)}" else "SLEEP TIMER", onSleep, Icons.Default.Timer)
            TvPillButton("BROWSE", onBrowse, Icons.Default.Explore)
            Spacer(Modifier.weight(1f))
            TvVolumeControl(volume = volume, onValue = onVolume, compact = true)
        }
    }
}

@Composable
private fun TvBrowsePage(
    isFavorites: Boolean, stations: List<Station>, totalCount: Int,
    selectedId: String?, favorites: Set<String>, search: String, onSearch: (String) -> Unit,
    selectedGenre: String, onGenre: (String) -> Unit,
    onSelect: (Station) -> Unit, onFavorite: (Station) -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    val genres = listOf("All", "Ambient", "Electronic", "Indie", "80s", "Classical", "Sleep", "Nature", "Jazz")
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
            Column(horizontalAlignment = Alignment.End) {
                Text(if (isFavorites) "Your favourites" else "Explore stations", color = MatteText, fontSize = 30.sp, fontWeight = FontWeight.Light)
                Text("$totalCount STATIONS", color = MatteMuted, fontSize = 10.sp, letterSpacing = 2.sp,
                    modifier = Modifier.padding(top = 5.dp))
            }
        }
        Spacer(Modifier.height(17.dp))
        if (!isFavorites) {
            OutlinedTextField(
                value = search, onValueChange = onSearch,
                modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp),
                singleLine = true, shape = RoundedCornerShape(15.dp),
                placeholder = { Text("Search stations...", color = MatteMuted, fontSize = 14.sp) },
                leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Search, null, tint = MatteTeal) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MatteText, unfocusedTextColor = MatteText,
                    focusedBorderColor = MatteTeal, unfocusedBorderColor = MatteLine,
                    cursorColor = MatteTeal, focusedContainerColor = if (amoled) Color.Black else Color(0xFF1B2027),
                    unfocusedContainerColor = if (amoled) Color.Black else Color(0xFF1B2027)
                )
            )
            Spacer(Modifier.height(11.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                genres.forEach { genre -> TvGenreChip(genre, selectedGenre == genre, { onGenre(genre) }) }
            }
            Spacer(Modifier.height(13.dp))
        }
        if (stations.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(if (isFavorites) "No favourites yet. Save stations with the heart." else "No stations match your search.",
                    color = MatteMuted, fontSize = 16.sp)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(stations, key = { it.id }) { station ->
                    TvStationRow(
                        station = station, active = station.id == selectedId,
                        favorite = station.id in favorites,
                        onClick = { onSelect(station) }, onFavorite = { onFavorite(station) }
                    )
                }
            }
        }
    }
}

@Composable
private fun TvGenreChip(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Box(
        Modifier.clip(RoundedCornerShape(30.dp))
            .background(if (selected) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(if (amoled) Color(0xFF050505) else Color(0xFF282D35), if (amoled) Color(0xFF050505) else Color(0xFF282D35))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color.Transparent, RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (selected) MatteInk else MatteText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvStationRow(
    station: Station, active: Boolean, favorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.fillMaxWidth().height(70.dp).clip(RoundedCornerShape(15.dp))
            .background(if (active) Brush.horizontalGradient(listOf(Color(0xFF293A3B), Color(0xFF38313A))) else Brush.horizontalGradient(listOf(if (amoled) Color(0xFF050505) else MatteCard, if (amoled) Color(0xFF050505) else MatteCard)))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(15.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(station.name, color = MatteText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${station.genre}  ·  ${station.broadcaster}", color = MatteMuted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
        }
        if (active) Text("ON AIR", color = MatteTeal, fontSize = 9.sp, letterSpacing = 1.4.sp,
            modifier = Modifier.padding(end = 18.dp))
        TvFavoriteButton(
            selected = favorite, onClick = onFavorite
        )
    }
}

@Composable
private fun TvFavoriteButton(selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(if (focused) Color(0xFF3B3940) else Color.Transparent)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(if (selected) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Favourite", tint = if (selected) MattePink else MatteMuted, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun TvFullScreenVisualizer(
    selected: Station?, playing: Boolean, status: String,
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float, visualizerDarker: Boolean,
    chromeVisible: Boolean, onUserActivity: () -> Unit,
    hideSkip: Boolean, hideVolume: Boolean,
    volume: Float, favorite: Boolean, sleepRemaining: Int,
    onBack: () -> Unit, onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    onFavorite: () -> Unit, onVolume: (Float) -> Unit, onSleep: () -> Unit,
    onSettings: () -> Unit, onExit: () -> Unit
) {
    val controlAlpha by animateFloatAsState(
        targetValue = if (chromeVisible) 0.88f else 0.0f,
        animationSpec = tween(750), label = "visualizer-control-idle-alpha"
    )
    // Only interactive chrome fades after inactivity. Station identity and the
    // entire audio-reactive scene remain fully visible at all times.
    val backFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { backFocus.requestFocus() }
    Box(Modifier.fillMaxSize()) {
        ReactiveVisualScene(waveform, spectrum, audioEnergy, Modifier.fillMaxSize(), fullScreen = true, darker = visualizerDarker)

        TvIconButton(
            icon = Icons.Default.ArrowBack,
            description = "Back to normal mode",
            onClick = { onUserActivity(); onBack() },
            modifier = Modifier.align(Alignment.TopEnd).focusRequester(backFocus)
                .padding(end = 22.dp, top = 16.dp).graphicsLayer(alpha = controlAlpha),
            buttonSize = 25.dp, iconSize = 12.dp, onFocusActivity = onUserActivity
        )
        TvIconButton(
            icon = Icons.Default.Settings,
            description = "Settings",
            onClick = { onUserActivity(); onSettings() },
            modifier = Modifier.align(Alignment.TopStart)
                .padding(start = 22.dp, top = 16.dp).graphicsLayer(alpha = controlAlpha),
            buttonSize = 25.dp, iconSize = 12.dp, onFocusActivity = onUserActivity
        )

        Column(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 104.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("radio cherry LIVE", color = Color(0xFFF4F6F7), fontSize = 23.sp,
                fontWeight = FontWeight.Medium, letterSpacing = 0.35.sp)
            Spacer(Modifier.height(5.dp))
            Text(selected?.name ?: "Choose a station", color = Color(0xFFF4F6F7),
                fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Internet radio",
                color = Color(0xFFE0E5E8), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Text(status, color = Color(0xFFD0EEE5), fontSize = 9.sp, letterSpacing = 1.25.sp,
                modifier = Modifier.padding(top = 5.dp))
            if (sleepRemaining > 0) Text("SLEEP TIMER  ·  ${formatTime(sleepRemaining)}",
                color = Color(0xFFF0CBD8), fontSize = 9.sp, letterSpacing = 1.1.sp,
                modifier = Modifier.padding(top = 4.dp))
        }

        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 17.dp)
                .graphicsLayer(alpha = controlAlpha),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!hideSkip) TvMiniVisualizerButton(Icons.Default.SkipPrevious, "Previous station", { onUserActivity(); onPrevious() }, onUserActivity)
            TvMiniVisualizerButton(
                if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                if (playing) "Pause" else "Play",
                { onUserActivity(); onPlayPause() }, onUserActivity, primary = true
            )
            if (!hideSkip) TvMiniVisualizerButton(Icons.Default.SkipNext, "Next station", { onUserActivity(); onNext() }, onUserActivity)
            TvMiniVisualizerButton(
                if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "Favourite", { onUserActivity(); onFavorite() }, onUserActivity
            )
            TvMiniVisualizerButton(Icons.Default.Timer, "Sleep timer", { onUserActivity(); onSleep() }, onUserActivity)
            if (!hideVolume) {
                TvVolumeControl(volume = volume, onValue = { onUserActivity(); onVolume(it) }, compact = true, miniVisualizer = true)
            }
            TvMiniVisualizerButton(Icons.Default.Close, "Exit app", { onUserActivity(); onExit() }, onUserActivity)
        }
    }
}

@Composable
private fun TvMiniVisualizerButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    onFocusActivity: () -> Unit,
    primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val neon = LocalTvNeonTheme.current
    Box(
        Modifier.size(27.dp).clip(CircleShape)
            .background(
                if (primary && neon) Brush.linearGradient(listOf(Color(0xFF00EFFF), Color(0xFF8A36FF), Color(0xFFFF31B8)))
                else if (primary) Brush.linearGradient(listOf(MatteTeal.copy(alpha = 0.82f), MattePink.copy(alpha = 0.82f)))
                else Brush.linearGradient(listOf(Color(0x77333D49), Color(0x77333D49)))
            )
            .border(if (focused) 1.3.dp else 0.7.dp,
                if (focused) Color.White else if (neon) Color(0xBB8F63FF) else Color(0x667A8990), CircleShape)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocusActivity() }
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            imageVector = icon, contentDescription = description,
            tint = if (primary) MatteInk else Color(0xFFE8EEF0),
            modifier = Modifier.size(13.dp)
        )
    }
}

@Composable
private fun rememberVisualizerPhase(): State<Float> {
    // Cap the visual scene at ~25 fps instead of invalidating the whole Canvas at
    // every display refresh. The phase remains continuous and independent of audio.
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val started = System.nanoTime()
        while (true) {
            val elapsed = (System.nanoTime() - started) / 1_000_000_000f
            phase.floatValue = (elapsed * 0.23f) % (2f * PI.toFloat())
            delay(40L)
        }
    }
    return phase
}

@Composable
private fun ReactiveVisualScene(
    waveform: FloatArray, spectrum: FloatArray, audioEnergy: Float,
    modifier: Modifier, fullScreen: Boolean, darker: Boolean
) {
    val phase by rememberVisualizerPhase()
    val level = audioEnergy.coerceIn(0.01f, 1f)
    val amoled = LocalTvAmoledTheme.current
    val neon = LocalTvNeonTheme.current
    fun averageBand(from: Int, until: Int): Float {
        val end = until.coerceAtMost(spectrum.size)
        val start = from.coerceAtMost(end)
        if (end <= start) return 0f
        var total = 0f
        for (index in start until end) total += spectrum[index]
        return (total / (end - start)).coerceIn(0f, 1f)
    }
    val bass = averageBand(0, 7)
    val mids = averageBand(7, 25)
    val highs = averageBand(25, spectrum.size)

    // A deep-space base replaces the washed-out pastel wash. Hue and luminance
    // drift slowly with the visualizer phase and react to the incoming audio.
    val colourDrift = (0.5f + 0.5f * sin(phase * 0.43f)).coerceIn(0f, 1f)
    val audioTint = (bass * 0.42f + mids * 0.34f + highs * 0.24f).coerceIn(0f, 1f)
    val start = when {
        amoled -> Color.Black
        neon -> androidx.compose.ui.graphics.lerp(Color(0xFF030516), Color(0xFF08062B), colourDrift * 0.42f + audioTint * 0.12f)
        darker -> androidx.compose.ui.graphics.lerp(Color(0xFF06101C), Color(0xFF0B1423), colourDrift * 0.20f)
        else -> androidx.compose.ui.graphics.lerp(Color(0xFF102D38), Color(0xFF1C3548), colourDrift * 0.24f + audioTint * 0.06f)
    }
    val middle = when {
        amoled -> Color(0xFF010106)
        neon -> androidx.compose.ui.graphics.lerp(Color(0xFF090B2A), Color(0xFF18082F), (0.5f + 0.5f * cos(phase * 0.31f)) * 0.62f)
        darker -> Color(0xFF121522)
        else -> androidx.compose.ui.graphics.lerp(Color(0xFF29263A), Color(0xFF393044), (0.5f + 0.5f * cos(phase * 0.31f)) * 0.30f)
    }
    val end = when {
        amoled -> Color(0xFF030006)
        neon -> androidx.compose.ui.graphics.lerp(Color(0xFF230A39), Color(0xFF410A43), (0.5f + 0.5f * sin(phase * 0.37f + 1.2f)) * 0.70f)
        darker -> Color(0xFF21172B)
        else -> androidx.compose.ui.graphics.lerp(Color(0xFF47344B), Color(0xFF5B3C54), (0.5f + 0.5f * sin(phase * 0.37f + 1.2f)) * 0.28f)
    }

    Box(
        modifier.background(
            Brush.linearGradient(
                colorStops = arrayOf(0f to start, 0.52f to middle, 1f to end),
                start = Offset(0f, 0f), end = Offset(1800f, 980f)
            )
        )
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val minDim = size.minDimension
            val center = Offset(w * 0.5f, if (fullScreen) h * 0.385f else h * 0.47f)
            val localLevel = level

            val nebulaMotion = minDim * (0.022f + bass * 0.055f + mids * 0.035f)
            val cloudScale = if (fullScreen) 1f else 0.78f
            val cloudBaseAlpha = when {
                neon -> 0.76f
                amoled -> 0.34f
                darker -> 0.29f
                else -> 0.43f
            }

            fun nebulaCloud(
                color: Color, point: Offset, radius: Float,
                energy: Float, phaseOffset: Float, alphaBoost: Float = 1f
            ) {
                val shimmer = (0.70f + 0.30f * sin(phase * 0.92f + phaseOffset)).coerceIn(0.30f, 1f)
                val energyLift = (energy.coerceIn(0f, 1f) * 0.22f + localLevel * 0.08f)
                val alpha = ((cloudBaseAlpha + energyLift) * shimmer * alphaBoost).coerceIn(0.10f, 0.78f)
                val inner = color.copy(alpha = alpha)
                val mid = color.copy(alpha = alpha * 0.64f)
                val outer = color.copy(alpha = alpha * 0.20f)
                if (neon) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colorStops = arrayOf(
                                0f to color.copy(alpha = alpha * 0.48f),
                                0.42f to color.copy(alpha = alpha * 0.22f),
                                1f to Color.Transparent
                            ),
                            center = point, radius = radius * 1.48f
                        ),
                        radius = radius * 1.48f, center = point
                    )
                }
                drawCircle(
                    brush = Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to inner, 0.24f to mid, 0.62f to outer, 1f to Color.Transparent
                        ),
                        center = point, radius = radius
                    ),
                    radius = radius, center = point
                )
            }

            val driftA = sin(phase * 0.42f) * nebulaMotion
            val driftB = cos(phase * 0.34f) * nebulaMotion
            val driftC = sin(phase * 0.27f + 1.4f) * nebulaMotion * 0.72f

            // Large gas formations. Several overlapping lobes make the clouds
            // irregular and layered rather than smooth geometric colour circles.
            val teal = when { neon -> Color(0xFF00F5D4); darker -> Color(0xFF39777A); else -> Color(0xFF579C97) }
            val cyan = if (neon) Color(0xFF00BFFF) else if (darker) Color(0xFF426E86) else Color(0xFF6D9EB1)
            val blue = if (neon) Color(0xFF315BFF) else if (darker) Color(0xFF3D4F75) else Color(0xFF667D9E)
            val indigo = if (neon) Color(0xFF7040FF) else if (darker) Color(0xFF55466F) else Color(0xFF756C91)
            val violet = when { neon -> Color(0xFF9B35FF); darker -> Color(0xFF76547F); else -> Color(0xFF987EA8) }
            val plum = when { neon -> Color(0xFFFF2CBF); darker -> Color(0xFF87546F); else -> Color(0xFFB17F9E) }
            val rose = if (neon) Color(0xFFFF4FB8) else if (darker) Color(0xFF9F718A) else Color(0xFFD0A0B4)

            nebulaCloud(teal, Offset(w * 0.08f + driftA, h * 0.58f + mids * minDim * 0.055f), minDim * 0.66f * cloudScale, bass + mids * 0.55f, 0.1f)
            nebulaCloud(cyan, Offset(w * 0.19f - driftB, h * 0.82f + driftC), minDim * 0.48f * cloudScale, mids + bass * 0.3f, 1.1f, 0.90f)
            nebulaCloud(blue, Offset(w * 0.34f + driftC, h * 0.19f - driftA * 0.3f), minDim * 0.43f * cloudScale, highs + mids * 0.4f, 2.0f, 0.85f)
            nebulaCloud(indigo, Offset(w * 0.54f - driftB * 0.45f, h * 0.08f + driftC), minDim * 0.38f * cloudScale, mids + highs * 0.3f, 2.8f, 0.82f)
            nebulaCloud(violet, Offset(w * 0.82f + driftB, h * 0.22f + highs * minDim * 0.05f), minDim * 0.62f * cloudScale, highs + mids * 0.45f, 3.5f)
            nebulaCloud(plum, Offset(w * 0.94f - driftA, h * 0.60f - bass * minDim * 0.04f), minDim * 0.61f * cloudScale, highs + bass * 0.4f, 4.2f)
            nebulaCloud(rose, Offset(w * 0.74f + driftC, h * 0.88f), minDim * 0.36f * cloudScale, highs + mids * 0.3f, 5.1f, 0.82f)
            nebulaCloud(teal, Offset(w * 0.30f + driftB * 0.7f, h * 0.42f + driftA * 0.2f), minDim * 0.34f * cloudScale, highs + mids, 5.8f, 0.72f)
            nebulaCloud(plum, Offset(w * 0.66f - driftA * 0.6f, h * 0.68f - driftC), minDim * 0.34f * cloudScale, bass + highs, 6.4f, 0.80f)
            nebulaCloud(cyan, Offset(w * 0.47f + driftC, h * 0.98f), minDim * 0.27f * cloudScale, mids + bass * 0.2f, 7.0f, 0.66f)

            // Smaller cloudlets add turbulent texture and make the nebula visibly
            // change shape with bass, midrange, treble and the slow phase drift.
            for (i in 0 until 9) {
                val sample = waveform[(i * 9) % waveform.size]
                val band = spectrum[(i * 5) % spectrum.size]
                val baseX = ((i * 37 + 11) % 97) / 96f
                val baseY = ((i * 53 + 7) % 89) / 88f
                val x = baseX * w + sin(phase * (0.19f + (i % 4) * 0.04f) + i) * nebulaMotion * (0.55f + sample)
                val y = baseY * h + cos(phase * (0.15f + (i % 3) * 0.035f) + i * 0.73f) * nebulaMotion * 0.65f
                val radius = minDim * (0.11f + band * 0.12f + sample * 0.055f) * cloudScale
                val tint = when (i % 4) { 0 -> teal; 1 -> cyan; 2 -> violet; else -> plum }
                nebulaCloud(tint, Offset(x, y), radius, sample + band, i * 0.31f, 0.55f)
            }

            // Starfield and dust motes remain visible between the coloured gas clouds.
            for (i in 0 until 84) {
                val baseX = ((i * 47 + 13) % 997) / 996f
                val baseY = ((i * 71 + 19) % 991) / 990f
                val sample = waveform[(i * 11) % waveform.size]
                val band = spectrum[(i * 5) % spectrum.size]
                val twinkle = (0.45f + 0.55f * sin(phase * (0.45f + (i % 5) * 0.08f) + i)).coerceIn(0.05f, 1f)
                val x = baseX * w + sin(phase * 0.11f + i * 0.7f) * nebulaMotion * 0.32f
                val y = baseY * h + cos(phase * 0.13f + i * 0.47f) * nebulaMotion * 0.26f
                val radius = 0.8f + band * 2.8f + sample * 1.5f
                val alpha = (0.22f + highs * 0.36f + band * 0.28f) * twinkle
                val star = when (i % 4) {
                    0 -> Color(0xFFFFB8D6)
                    1 -> Color(0xFF8BECE4)
                    2 -> Color(0xFF9BBEFF)
                    else -> Color(0xFFE9E8F6)
                }
                drawCircle(star.copy(alpha = alpha.coerceIn(0.08f, 0.88f)), radius, Offset(x, y))
                if (i % 17 == 0) {
                    drawLine(star.copy(alpha = 0.34f + highs * 0.35f),
                        Offset(x, y - radius * 3.2f), Offset(x, y + radius * 3.2f),
                        strokeWidth = 0.8f + band * 0.8f)
                }
            }

            // Layered flowing sound ribbons. Their shape and amplitude are taken
            // from the captured waveform, with FFT bands modulating each filament.
            val lineCount = if (fullScreen) 17 else 12
            val baseWaveY = h * if (fullScreen) 0.455f else 0.555f
            for (line in 0 until lineCount) {
                val path = Path()
                val lineOffset = (line - (lineCount - 1) / 2f) * (if (fullScreen) 5.5f else 4.3f)
                val linePhase = line * 0.19f
                for (step in 0..84) {
                    val t = step / 84f
                    val x = w * t
                    val index = (t * (waveform.size - 1)).toInt().coerceIn(0, waveform.lastIndex)
                    val wave = waveform[index]
                    val band = spectrum[(index * 3) % spectrum.size]
                    val envelope = (0.22f + 0.78f * sin(t * PI).toFloat()).coerceIn(0f, 1f)
                    val broad = sin(t * PI * 2.25f + phase * 0.75f + linePhase).toFloat()
                    val fine = sin(t * PI * 8.0f - phase * 0.55f + linePhase * 1.7f).toFloat()
                    val sound = (wave - 0.10f) * h * (0.14f + localLevel * 0.055f) * envelope
                    val y = baseWaveY + lineOffset +
                        broad * h * (0.045f + mids * 0.025f) +
                        fine * h * (0.012f + highs * 0.018f) +
                        sound + (band - 0.02f) * h * 0.035f
                    if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                val tint = if (neon) when (line % 4) {
                    0 -> Color(0xFF00F5FF)
                    1 -> Color(0xFF4277FF)
                    2 -> Color(0xFFCB45FF)
                    else -> Color(0xFFFF3CB9)
                } else if (darker) {
                    if (line % 2 == 0) Color(0xFF759A9A) else Color(0xFF9A7A91)
                } else {
                    if (line % 2 == 0) Color(0xFF9DBBB6) else Color(0xFFC1A0B0)
                }
                val ribbonAlpha = if (neon) 0.66f + localLevel * 0.22f else if (darker) 0.22f + localLevel * 0.14f else 0.31f + localLevel * 0.18f
                drawPath(path, tint.copy(alpha = ribbonAlpha), style = Stroke(width = if (fullScreen) 1.35f else 1.1f))
            }

            // A second, quieter high-frequency filament bank gives the ribbon
            // the braided multi-layer appearance from the supplied reference.
            for (line in 0 until 7) {
                val path = Path()
                for (step in 0..72) {
                    val t = step / 72f
                    val x = w * t
                    val index = (t * (spectrum.size - 1)).toInt().coerceIn(0, spectrum.lastIndex)
                    val band = spectrum[index]
                    val sample = waveform[(index * 2).coerceIn(0, waveform.lastIndex)]
                    val envelope = sin(t * PI).toFloat()
                    val offset = (line - 3) * 2.5f
                    val y = baseWaveY + offset +
                        sin(t * PI * 3.1f + phase * 0.68f + line * 0.29f) * h * 0.047f +
                        (sample - 0.08f) * h * 0.10f * envelope +
                        band * h * 0.045f * sin(phase + line * 0.22f)
                    if (step == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
                }
                val tint = if (neon) {
                    if (line % 2 == 0) Color(0xFF00DFFF) else Color(0xFFEB45FF)
                } else if (darker) {
                    if (line % 2 == 0) Color(0xFF688E91) else Color(0xFF98778C)
                } else {
                    if (line % 2 == 0) Color(0xFF9BC5BD) else Color(0xFFC6A0B5)
                }
                drawPath(path, tint.copy(alpha = if (neon) 0.60f + mids * 0.20f else 0.20f + mids * 0.12f), style = Stroke(width = 0.85f))
            }

            // Multiple clearly visible circular orbits. Radius subtly expands with
            // the bass and the waveform so the centre looks alive, not static.
            val orbRadius = minDim * (if (fullScreen) 0.112f else 0.135f) + bass * minDim * 0.018f
            val ringCount = if (fullScreen) 8 else 7
            for (ring in 0 until ringCount) {
                val sample = waveform[(ring * 13) % waveform.size]
                val radius = orbRadius * (1.34f + ring * 0.235f) + sample * minDim * 0.022f + mids * ring * 1.4f
                val ringColor = if (neon) {
                    if (ring % 2 == 0) Color(0xFF00EFFF) else Color(0xFFFF4AD8)
                } else if (darker) {
                    if (ring % 2 == 0) Color(0xFF6D9992) else Color(0xFF96758A)
                } else {
                    if (ring % 2 == 0) Color(0xFFA8D1C8) else Color(0xFFD7B0C2)
                }
                drawCircle(
                    ringColor.copy(alpha = if (neon) 0.78f + sample * 0.16f else 0.30f + sample * 0.15f),
                    radius, center, style = Stroke(width = if (fullScreen) 1.15f else 1.0f)
                )
            }

            // Three-dimensional orb: offset key-light, soft specular highlight,
            // coloured terminator and lower-right shadow give it a spherical form.
            val pulseRadius = orbRadius * (1f + bass * 0.05f + mids * 0.018f)
            if (neon) {
                drawCircle(
                    Brush.radialGradient(
                        colorStops = arrayOf(
                            0f to Color(0xFF13DFFF).copy(alpha = 0.42f + bass * 0.18f),
                            0.48f to Color(0xFF9A35FF).copy(alpha = 0.23f),
                            1f to Color.Transparent
                        ),
                        center = center, radius = pulseRadius * 1.85f
                    ),
                    radius = pulseRadius * 1.85f, center = center
                )
            }
            val shadowCenter = Offset(center.x + pulseRadius * 0.13f, center.y + pulseRadius * 0.18f)
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to Color(0xFF030612).copy(alpha = 0.50f),
                        0.55f to Color(0xFF050817).copy(alpha = 0.25f),
                        1f to Color.Transparent
                    ),
                    center = shadowCenter, radius = pulseRadius * 1.52f
                ),
                radius = pulseRadius * 1.52f, center = shadowCenter
            )
            drawCircle(
                Brush.radialGradient(
                    colorStops = if (neon) arrayOf(
                        0f to Color(0xFFFFFFFF),
                        0.24f to Color(0xFFD9FFFF),
                        0.50f to Color(0xFF9BBEFF),
                        0.76f to Color(0xFFB17BFF),
                        0.93f to Color(0xFFFF69D2),
                        1f to Color(0xFF32114D)
                    ) else if (darker) arrayOf(
                        0f to Color(0xFFE5EEE9),
                        0.24f to Color(0xFFC0D5D0),
                        0.50f to Color(0xFF9CB8BC),
                        0.76f to Color(0xFFB7A1B9),
                        0.93f to Color(0xFF786781),
                        1f to Color(0xFF302A3B)
                    ) else arrayOf(
                        0f to Color(0xFFFFFFFF),
                        0.24f to Color(0xFFDDFBF1),
                        0.50f to Color(0xFFC2DFE4),
                        0.76f to Color(0xFFD8B8D8),
                        0.93f to Color(0xFF947A9F),
                        1f to Color(0xFF4B3B59)
                    ),
                    center = Offset(center.x - pulseRadius * 0.30f, center.y - pulseRadius * 0.38f),
                    radius = pulseRadius * 1.30f
                ),
                radius = pulseRadius, center = center
            )
            drawCircle(
                Brush.radialGradient(
                    colorStops = arrayOf(
                        0f to Color.White.copy(alpha = 0.52f + highs * 0.12f),
                        0.38f to Color(0xFFDFFFF9).copy(alpha = 0.22f),
                        1f to Color.Transparent
                    ),
                    center = Offset(center.x - pulseRadius * 0.34f, center.y - pulseRadius * 0.43f),
                    radius = pulseRadius * 0.62f
                ),
                radius = pulseRadius * 0.62f,
                center = Offset(center.x - pulseRadius * 0.34f, center.y - pulseRadius * 0.43f)
            )
            drawCircle(
                (if (neon) Color(0xFF65F7FF) else if (darker) Color(0xFF789C98) else Color(0xFFC3DDD5)).copy(alpha = if (neon) 0.88f else 0.42f + localLevel * 0.12f),
                pulseRadius * 1.025f, center, style = Stroke(width = 1.1f)
            )

            // Planet-like particles travel around the orb on audio-driven orbits.
            val particleCount = if (fullScreen) 18 else 14
            for (i in 0 until particleCount) {
                val sample = waveform[(i * 7) % waveform.size]
                val band = spectrum[(i * 3) % spectrum.size]
                val orbit = pulseRadius * (1.72f + (i % 5) * 0.48f) + sample * minDim * 0.04f
                val angle = phase * (0.17f + (i % 4) * 0.038f) + i * 2.399f + band * 0.48f
                val x = center.x + cos(angle) * orbit
                val y = center.y + sin(angle * 1.07f) * orbit * 0.72f
                val r = 2.1f + sample * 4.8f + band * 2.7f
                val particleColor = if (neon) {
                    when (i % 3) { 0 -> Color(0xFF00F5FF); 1 -> Color(0xFF9B48FF); else -> Color(0xFFFF3EBF) }
                } else if (darker) {
                    if (i % 2 == 0) Color(0xFF7AB7B0) else Color(0xFFB38BA8)
                } else {
                    if (i % 2 == 0) Color(0xFFA7DED5) else Color(0xFFE6B6CC)
                }
                drawCircle(particleColor.copy(alpha = if (neon) 0.90f else 0.48f + sample * 0.26f), r, Offset(x, y))
                drawCircle(Color.White.copy(alpha = 0.30f), r * 0.28f, Offset(x - r * 0.24f, y - r * 0.25f))
            }

            // Frequency arc is deliberately more legible; bar heights and colours
            // follow the live FFT while waveform energy adds a second modulation.
            val bars = 64
            val arcY = if (fullScreen) h * 0.855f else h * 0.86f
            val arcWidth = w * (if (fullScreen) 0.38f else 0.30f)
            for (i in 0 until bars) {
                val normalized = i / (bars - 1f)
                val x = center.x - arcWidth + normalized * arcWidth * 2f
                val envelope = sin(normalized * PI).toFloat()
                val band = spectrum[(i * spectrum.size / bars).coerceIn(0, spectrum.lastIndex)]
                val wave = waveform[(i * waveform.size / bars).coerceIn(0, waveform.lastIndex)]
                val barHeight = 5f + envelope * (8f + band * 66f + wave * 32f) * (0.55f + localLevel)
                val colour = if (neon) {
                    androidx.compose.ui.graphics.lerp(Color(0xFF00F5FF), Color(0xFFFF36C9), normalized)
                } else if (darker) {
                    androidx.compose.ui.graphics.lerp(Color(0xFF79A8A1), Color(0xFFB0849E), normalized)
                } else {
                    androidx.compose.ui.graphics.lerp(Color(0xFFA7D4C9), Color(0xFFE0B9CC), normalized)
                }
                drawLine(
                    colour.copy(alpha = if (neon) 0.90f else 0.52f + band * 0.22f + wave * 0.06f),
                    Offset(x, arcY), Offset(x, arcY - barHeight),
                    strokeWidth = if (fullScreen) 2.0f else 1.6f
                )
            }
        }
    }
}

@Composable
private fun TvRoundControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    val neon = LocalTvNeonTheme.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(
            Modifier.size(if (primary) 58.dp else 48.dp).clip(CircleShape)
                .background(if (primary && neon) Brush.linearGradient(listOf(Color(0xFF00EFFF), Color(0xFF8A36FF), Color(0xFFFF31B8))) else if (primary) Brush.linearGradient(listOf(MatteTeal, MattePink)) else Brush.linearGradient(listOf(if (amoled) Color(0xFF080808) else Color(0xFF272C34), if (amoled) Color(0xFF080808) else Color(0xFF272C34))))
                .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else if (neon) Color(0xFF6856C6) else MatteLine, CircleShape)
                .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
            contentAlignment = Alignment.Center
        ) {
            androidx.compose.material3.Icon(icon, null, tint = if (primary && !neon) MatteInk else MatteText,
                modifier = Modifier.size(if (primary) 26.dp else 21.dp))
        }
        Text(label, color = MatteMuted, fontSize = 8.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvControlText(
    label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, primary: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.clip(RoundedCornerShape(10.dp))
            .background(if (primary) Brush.horizontalGradient(listOf(MatteTeal, MattePink)) else Brush.horizontalGradient(listOf(if (amoled) Color(0xCC080808) else Color(0xCC27323B), if (amoled) Color(0xCC080808) else Color(0xCC27323B))))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0xAA9BA9AD), RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 15.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = if (primary) MatteInk else MatteText, modifier = Modifier.size(17.dp))
        Text(label, color = if (primary) MatteInk else MatteText, fontSize = 9.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvPillButton(label: String, onClick: () -> Unit, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Row(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (amoled) Color(0xFF050505) else Color(0xFF272C34))
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else MatteLine, RoundedCornerShape(10.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 11.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        androidx.compose.material3.Icon(icon, null, tint = MatteTeal, modifier = Modifier.size(16.dp))
        Text(label, color = MatteText, fontSize = 9.sp, letterSpacing = 0.8.sp)
    }
}

@Composable
private fun TvIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    buttonSize: androidx.compose.ui.unit.Dp = 50.dp,
    iconSize: androidx.compose.ui.unit.Dp = 23.dp,
    onFocusActivity: () -> Unit = {}
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier.size(buttonSize).clip(CircleShape)
            .background(if (focused) Color(0xFFE0EEE9) else Color(0x88202B35))
            .border(if (focused) 1.5.dp else 0.7.dp, if (focused) MatteText else Color(0x667A8990), CircleShape)
            .onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocusActivity() }
            .clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Icon(
            icon, description,
            tint = if (focused) MatteInk else Color(0xFFF4F6F7),
            modifier = Modifier.size(iconSize)
        )
    }
}

@Composable
private fun TvVisualizerStyleChoice(label: String, selected: Boolean, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    val neon = LocalTvNeonTheme.current
    val selectedContainer = if (selected && neon) Color(0xFF7138E8) else if (selected) MatteTeal else if (amoled) Color(0xFF101010) else Color(0xFF303640)
    val unselectedContent = if (selected && neon) Color.White else if (selected) MatteInk else MatteText

    Button(
        onClick = onClick,
        modifier = Modifier.width(104.dp).height(36.dp)
            .onFocusChanged { focused = it.isFocused }
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) Color.White else MatteLine,
                shape = RoundedCornerShape(10.dp)
            ),
        shape = RoundedCornerShape(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = selectedContainer,
            contentColor = unselectedContent,
            disabledContainerColor = selectedContainer,
            disabledContentColor = unselectedContent
        ),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
    ) {
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
    }
}

@Composable
private fun TvSmallTextButton(
    label: String, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    modifier: Modifier = Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        modifier.clip(RoundedCornerShape(30.dp))
            .background(if (focused) Color(0x334D5958) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) MatteText else Color(0x557A8584), RoundedCornerShape(30.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (icon != null) androidx.compose.material3.Icon(icon, null, tint = MatteText, modifier = Modifier.size(14.dp))
        Text(label, color = MatteText, fontSize = 8.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun TvVolumeControl(
    volume: Float, onValue: (Float) -> Unit, compact: Boolean, miniVisualizer: Boolean = false
) {
    var focused by remember { mutableStateOf(false) }
    val amoled = LocalTvAmoledTheme.current
    Column(
        Modifier.width(when { miniVisualizer -> 108.dp; compact -> 178.dp; else -> 245.dp }),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            androidx.compose.material3.Icon(
                Icons.Default.VolumeUp, null, tint = MatteMuted,
                modifier = Modifier.size(if (miniVisualizer) 9.dp else 17.dp)
            )
            Slider(
                value = volume, onValueChange = onValue,
                colors = SliderDefaults.colors(
                    thumbColor = MatteTeal, activeTrackColor = MatteTeal,
                    inactiveTrackColor = if (amoled) Color(0xFF303030) else Color(0xFF626B70)
                ),
                modifier = Modifier.weight(1f).onFocusChanged { focused = it.isFocused }
                    .onPreviewKeyEvent { event ->
                        if (event.type == KeyEventType.KeyDown) {
                            when (event.key) {
                                Key.DirectionLeft -> { onValue((volume - 0.04f).coerceAtLeast(0f)); true }
                                Key.DirectionRight -> { onValue((volume + 0.04f).coerceAtMost(1f)); true }
                                else -> false
                            }
                        } else false
                    }.focusable(),
            )
            if (!miniVisualizer) Text("${(volume * 100).toInt()}%", color = MatteMuted, fontSize = 10.sp)
        }
        if (focused && !miniVisualizer) Text("VOLUME", color = MatteTeal, fontSize = 8.sp, letterSpacing = 1.1.sp)
    }
}

@Composable
private fun TvSettingsDialog(
    backgroundPlayback: Boolean, onBackgroundPlayback: (Boolean) -> Unit,
    hideVolume: Boolean, onHideVolume: (Boolean) -> Unit,
    hideSkip: Boolean, onHideSkip: (Boolean) -> Unit,
    keepScreenAwake: Boolean, onKeepScreenAwake: (Boolean) -> Unit,
    visualizerDarker: Boolean, onVisualizerDarker: (Boolean) -> Unit,
    appTheme: String, onAppTheme: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    val neon = LocalTvNeonTheme.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = when { amoled -> Color.Black; neon -> Color(0xFF09091B); else -> Color(0xFF20252C) },
        title = { Text("Settings", color = MatteText, fontSize = 20.sp, fontWeight = FontWeight.Light) },
        text = {
            Column(Modifier.widthIn(min = 430.dp, max = 520.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                TvSettingRow("Background playback", "Keep radio playing when the app is in the background", backgroundPlayback, onBackgroundPlayback)
                TvSettingRow("Hide volume in full screen", "Only affects the full-screen visualizer", hideVolume, onHideVolume)
                TvSettingRow("Hide previous / next in full screen", "Only affects the full-screen visualizer", hideSkip, onHideSkip)
                TvSettingRow("Keep screen awake", "Prevent the TV screensaver while visible", keepScreenAwake, onKeepScreenAwake)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Visualizer appearance", color = MatteText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        TvVisualizerStyleChoice("CURRENT", !visualizerDarker) { onVisualizerDarker(false) }
                        TvVisualizerStyleChoice("DARKER", visualizerDarker) { onVisualizerDarker(true) }
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("App theme", color = MatteText, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        TvVisualizerStyleChoice("DEFAULT", appTheme == "DEFAULT") { onAppTheme("DEFAULT") }
                        TvVisualizerStyleChoice("AMOLED", appTheme == "AMOLED") { onAppTheme("AMOLED") }
                        TvVisualizerStyleChoice("NEON", appTheme == "NEON") { onAppTheme("NEON") }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("DONE", color = MatteTeal, letterSpacing = 1.sp) } }
    )
}

@Composable
private fun TvSettingRow(title: String, description: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.heightIn(min = 34.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MatteText, fontSize = 11.sp, fontWeight = FontWeight.Medium)
            Text(description, color = MatteMuted, fontSize = 8.sp, lineHeight = 10.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 1.dp))
        }
        Switch(
            checked = checked, onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MatteInk, checkedTrackColor = MatteTeal,
                uncheckedThumbColor = MatteMuted, uncheckedTrackColor = MatteLine
            )
        )
    }
}

@Composable
private fun TvSleepDialog(
    remaining: Int, onSet: (Int) -> Unit, onCancelTimer: () -> Unit, onDismiss: () -> Unit
) {
    val amoled = LocalTvAmoledTheme.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = if (amoled) Color.Black else Color(0xFF20252C),
        title = { Text("Sleep timer", color = MatteText, fontSize = 22.sp, fontWeight = FontWeight.Light) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(if (remaining > 0) "Current timer: ${formatTime(remaining)}" else "Stop playback automatically after:",
                    color = MatteMuted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(15, 30, 45).forEach { minutes ->
                        TextButton(onClick = { onSet(minutes) }) { Text("${minutes}m", color = MatteTeal) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf(60, 90).forEach { minutes ->
                        TextButton(onClick = { onSet(minutes) }) { Text("${minutes}m", color = MatteTeal) }
                    }
                    if (remaining > 0) TextButton(onClick = onCancelTimer) { Text("CANCEL", color = MattePink) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("CLOSE", color = MatteMuted) } }
    )
}

private fun formatTime(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    return "%02d:%02d".format(safe / 60, safe % 60)
}
