package com.example.englishradio

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import kotlinx.coroutines.awaitCancellation
import kotlin.math.abs

private enum class TvPage { NOW_PLAYING, BROWSE, FAVORITES }

class TvActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.keepScreenOn = false
        val artwork = runCatching { assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
        PlaybackService.configureStationQueue(stations, artwork)
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                runCatching { future.get() }.onSuccess { controller = it }
            }, ContextCompat.getMainExecutor(this))
        }
        setContent { TvRadioCherry(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun TvRadioCherry(player: MediaController?) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var audioPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioPermission = it }
    var waveform by remember { mutableStateOf(FloatArray(96) { 0.025f }) }
    var audioEnergy by remember { mutableFloatStateOf(0.035f) }
    val prefs = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", android.content.Context.MODE_PRIVATE)
    }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }
    val playbackScope = rememberCoroutineScope()
    var page by remember { mutableStateOf(TvPage.NOW_PLAYING) }
    var selectedId by remember { mutableStateOf(player?.currentMediaItem?.mediaId) }
    var playing by remember { mutableStateOf(player?.isPlaying == true) }
    var favorites by remember {
        mutableStateOf(prefs.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    var status by remember { mutableStateOf("Choose a station to begin") }
    val selected = stations.firstOrNull { it.id == selectedId }
    val visibleStations = when (page) {
        TvPage.FAVORITES -> stations.filter { it.id in favorites }
        else -> stations
    }

    LaunchedEffect(Unit) {
        if (!audioPermission) permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(player, playing, audioPermission) {
        waveform = FloatArray(96) { 0.025f }
        audioEnergy = 0.035f
        if (!audioPermission || player == null || !playing) return@LaunchedEffect
        var sessionId = PlaybackService.currentAudioSessionId
        repeat(15) {
            if (sessionId > 0) return@repeat
            delay(120)
            sessionId = PlaybackService.currentAudioSessionId
        }
        if (sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    val samples = FloatArray(96) { i ->
                        val index = (i * (bytes.size - 1) / 95).coerceIn(0, bytes.lastIndex)
                        abs((bytes[index].toInt() and 0xFF) - 128) / 128f
                    }
                    val energy = (samples.average().toFloat() * 1.8f).coerceIn(0.025f, 1f)
                    android.os.Handler(android.os.Looper.getMainLooper()).post {
                        waveform = samples
                        audioEnergy = energy
                    }
                }
                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) = Unit
            }, Visualizer.getMaxCaptureRate(), true, false)
            visualizer.enabled = true
            awaitCancellation()
        } catch (_: Exception) {
        } finally {
            runCatching { visualizer.enabled = false; visualizer.release() }
        }
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isNowPlaying: Boolean) {
                playing = isNowPlaying
                status = if (isNowPlaying) "ON AIR  ·  LIVE STREAM" else "PAUSED"
            }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
            }
            override fun onPlaybackStateChanged(state: Int) {
                status = when (state) {
                    Player.STATE_BUFFERING -> "CONNECTING TO STATION…"
                    Player.STATE_READY -> if (player.isPlaying) "ON AIR  ·  LIVE STREAM" else "READY"
                    Player.STATE_IDLE -> "CHOOSE A STATION TO BEGIN"
                    Player.STATE_ENDED -> "STREAM ENDED"
                    else -> status
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status = "STREAM UNAVAILABLE"
            }
        }
        player.addListener(listener)
        selectedId = player.currentMediaItem?.mediaId
        playing = player.isPlaying
        onDispose { player.removeListener(listener) }
    }

    LaunchedEffect(favorites) {
        prefs.edit().putStringSet("favorite_station_ids", favorites).apply()
    }

    fun toggleFavorite(station: Station) {
        favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
    }
    suspend fun playStation(station: Station) {
        val active = player ?: return
        status = "CONNECTING TO STATION…"
        val resolved = withContext(Dispatchers.IO) {
            runCatching { PlaylistResolver.resolve(station.stream) }.getOrDefault(station.stream)
        }
        selectedId = station.id
        active.setMediaItem(PlaybackService.mediaItem(station.copy(stream = resolved), orbArtwork))
        active.prepare()
        active.play()
        page = TvPage.NOW_PLAYING
    }
    fun stepStation(direction: Int) {
        val index = stations.indexOfFirst { it.id == selectedId }
        val next = if (index < 0) 0 else (index + direction + stations.size) % stations.size
        val target = stations.getOrNull(next) ?: return
        playbackScope.launch { playStation(target) }
    }

    MaterialTheme {
        Row(
            Modifier.fillMaxSize().background(Color(0xFF07090E))
                .padding(horizontal = 42.dp, vertical = 30.dp),
            horizontalArrangement = Arrangement.spacedBy(34.dp)
        ) {
            Column(
                Modifier.width(190.dp).fillMaxHeight(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(22.dp)) {
                    Text("radio", color = Color(0xFFF5F3F8), fontSize = 28.sp, fontWeight = FontWeight.Light, letterSpacing = 2.sp)
                    Text("cherry", color = Color(0xFFE9C5FF), fontSize = 28.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
                    Spacer(Modifier.height(20.dp))
                    TvNavItem("NOW PLAYING", page == TvPage.NOW_PLAYING, { page = TvPage.NOW_PLAYING }, Icons.Default.Radio)
                    TvNavItem("BROWSE", page == TvPage.BROWSE, { page = TvPage.BROWSE }, Icons.Default.Explore)
                    TvNavItem("FAVOURITES", page == TvPage.FAVORITES, { page = TvPage.FAVORITES }, Icons.Default.Favorite)
                }
                Text("INTERNET RADIO", color = Color(0xFF737783), fontSize = 10.sp, letterSpacing = 2.sp)
            }

            Box(Modifier.weight(1f).fillMaxHeight()) {
                when (page) {
                    TvPage.NOW_PLAYING -> TvNowPlaying(
                        selected = selected, playing = playing, status = status,
                        waveform = waveform, audioEnergy = audioEnergy,
                        onPlayPause = {
                            if (player != null) {
                                if (player.isPlaying) player.pause()
                                else if (player.mediaItemCount > 0) player.play()
                                else selected?.let { stepStation(0) }
                            }
                        },
                        onPrevious = { stepStation(-1) }, onNext = { stepStation(1) },
                        favorite = selected?.id?.let { it in favorites } == true,
                        onFavorite = { selected?.let(::toggleFavorite) },
                        onBrowse = { page = TvPage.BROWSE }
                    )
                    TvPage.BROWSE, TvPage.FAVORITES -> {
                        Column(Modifier.fillMaxSize()) {
                            Text(if (page == TvPage.BROWSE) "Explore stations" else "Your favourites",
                                color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Light)
                            Text("${visibleStations.size} STATIONS", color = Color(0xFF858A96), fontSize = 11.sp, letterSpacing = 2.sp,
                                modifier = Modifier.padding(top = 8.dp, bottom = 22.dp))
                            if (visibleStations.isEmpty()) {
                                Text("No favourites yet. Add stations using the heart on Now Playing.",
                                    color = Color(0xFFB8BBC5), fontSize = 18.sp)
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    contentPadding = PaddingValues(bottom = 20.dp)
                                ) {
                                    items(visibleStations, key = { it.id }) { station ->
                                        TvStationRow(
                                            station = station, active = station.id == selectedId,
                                            favorite = station.id in favorites,
                                            onClick = { playbackScope.launch { playStation(station) } },
                                            onFavorite = { toggleFavorite(station) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TvNavItem(
    label: String, selected: Boolean, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp))
            .background(if (selected) Color(0xFF25212D) else Color.Transparent)
            .border(if (focused) 2.dp else 1.dp, if (focused) Color(0xFFE9C5FF) else Color(0xFF292C34), RoundedCornerShape(15.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 15.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(icon, null, tint = if (selected) Color(0xFFE9C5FF) else Color(0xFF9BA0AA), modifier = Modifier.size(20.dp))
        Text(label, color = if (selected) Color.White else Color(0xFFB7BBC4), fontSize = 12.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, letterSpacing = 1.sp)
    }
}

@Composable
private fun TvNowPlaying(
    selected: Station?, playing: Boolean, status: String,
    waveform: FloatArray, audioEnergy: Float,
    onPlayPause: () -> Unit, onPrevious: () -> Unit, onNext: () -> Unit,
    favorite: Boolean, onFavorite: () -> Unit, onBrowse: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        Text("NOW PLAYING", color = Color(0xFFE9C5FF), fontSize = 11.sp, letterSpacing = 3.sp)
        Spacer(Modifier.height(20.dp))
        val motion = androidx.compose.animation.core.rememberInfiniteTransition(label = "radio-gradient")
        val phase by motion.animateFloat(0f, 1f, androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(18000, easing = androidx.compose.animation.core.LinearEasing)
        ), label = "gradient-phase")
        val glow = (0.10f + audioEnergy * 0.48f).coerceIn(0.10f, 0.62f)
        val palette = listOf(
            Color(0xFF8B5CF6), Color(0xFF4263D8), Color(0xFF28B7C9),
            Color(0xFFB45AD8), Color(0xFF8B5CF6)
        )
        val colorPosition = phase * 4f
        val shift = colorPosition.toInt().coerceIn(0, 3)
        val blend = colorPosition - shift
        val gradientColors = (0..4).map { index ->
            androidx.compose.ui.graphics.lerp(
                palette[(index + shift) % palette.size],
                palette[(index + shift + 1) % palette.size], blend
            )
        }
        Box(
            Modifier.fillMaxWidth().height(230.dp).clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(gradientColors, start = Offset(0f, phase * 180f), end = Offset(1400f, 230f - phase * 180f))),
            contentAlignment = Alignment.Center
        ) {
            // Full-panel aurora responds to the same live audio energy as the circular waveform.
            Canvas(Modifier.fillMaxSize()) {
                val cx = size.width * (0.5f + 0.12f * kotlin.math.sin(phase * 6.283f))
                val cy = size.height * (0.5f + 0.10f * kotlin.math.cos(phase * 6.283f))
                drawCircle(Color(0xFFBCEBFF).copy(alpha = glow * 0.22f), size.minDimension * (0.42f + audioEnergy * 0.10f), Offset(cx, cy))
                drawCircle(Color(0xFFFFB9F2).copy(alpha = glow * 0.18f), size.minDimension * (0.30f + audioEnergy * 0.08f), Offset(size.width * 0.72f, size.height * 0.36f))
                drawCircle(Color(0xFFB8A2FF).copy(alpha = glow * 0.16f), size.minDimension * (0.26f + audioEnergy * 0.06f), Offset(size.width * 0.24f, size.height * 0.68f))
            }
            Canvas(Modifier.size(260.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val base = size.minDimension * 0.19f
                for (ring in 0 until 9) {
                    val sample = waveform[(ring * 11) % waveform.size]
                    val radius = base + ring * 7.2f + sample * 24f + audioEnergy * (ring + 1) * 1.6f
                    val tint = listOf(Color(0xFFE7C8FF), Color(0xFF9BE8FF), Color(0xFFFFB9E8))[ring % 3]
                    drawCircle(tint.copy(alpha = 0.16f + sample * 0.46f), radius, center, style = Stroke(width = 1.5f + sample * 2.2f))
                }
                for (i in 0 until 96) {
                    val sample = waveform[i]
                    val angle = i * (6.283185f / 96f)
                    val inner = base + 48f
                    val outer = inner + 8f + sample * 34f + audioEnergy * 10f
                    val start = Offset(center.x + kotlin.math.cos(angle) * inner, center.y + kotlin.math.sin(angle) * inner)
                    val end = Offset(center.x + kotlin.math.cos(angle) * outer, center.y + kotlin.math.sin(angle) * outer)
                    drawLine(Color(0xFFF6DFFF).copy(alpha = 0.22f + sample * 0.70f), start, end, strokeWidth = 2f + sample * 2f)
                }
                drawCircle(Color(0xFFB98BFF).copy(alpha = 0.22f + audioEnergy * 0.24f), base * 0.86f, center)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("radio cherry", color = Color(0xFFF8F3FC), fontSize = 21.sp, letterSpacing = 3.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.height(8.dp))
                Text(if (playing) "LIVE" else "YOUR SOUND, YOUR SPACE", color = Color(0xFFE9C5FF), fontSize = 10.sp, letterSpacing = 3.sp)
            }
        }
        Spacer(Modifier.height(26.dp))
        Text(selected?.name ?: "Choose a station to start listening",
            color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Light,
            maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(7.dp))
        Text(selected?.let { "${it.genre}   ·   ${it.broadcaster}" } ?: "More than 200 stations from around the world",
            color = Color(0xFF9BA0AA), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(12.dp))
        Text(status, color = Color(0xFFE9C5FF), fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(25.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
            TvControl(Icons.Default.SkipPrevious, "Previous station", onPrevious, false)
            TvControl(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                if (playing) "Pause" else "Play", onPlayPause, true)
            TvControl(Icons.Default.SkipNext, "Next station", onNext, false)
            TvControl(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "Toggle favourite", onFavorite, false)
            Spacer(Modifier.width(10.dp))
            TvTextButton("BROWSE", onBrowse)
        }
    }
}

@Composable
private fun TvControl(
    icon: androidx.compose.ui.graphics.vector.ImageVector, description: String,
    onClick: () -> Unit, primary: Boolean
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        Modifier.size(if (primary) 68.dp else 54.dp).clip(CircleShape)
            .background(if (primary) Color(0xFFE9C5FF) else Color(0xFF242630))
            .border(if (focused) 3.dp else 1.dp, if (focused) Color.White else Color(0xFF41434D), CircleShape)
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable(),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, description, tint = if (primary) Color(0xFF17121E) else Color.White,
            modifier = Modifier.size(if (primary) 30.dp else 23.dp))
    }
}

@Composable
private fun TvTextButton(label: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    Text(label, color = Color.White, fontSize = 11.sp, letterSpacing = 2.sp,
        modifier = Modifier.clip(RoundedCornerShape(12.dp))
            .border(if (focused) 2.dp else 1.dp, if (focused) Color(0xFFE9C5FF) else Color(0xFF41434D), RoundedCornerShape(12.dp))
            .onFocusChanged { focused = it.isFocused }.clickable(onClick = onClick).focusable()
            .padding(horizontal = 18.dp, vertical = 15.dp))
}

@Composable
private fun TvStationRow(
    station: Station, active: Boolean, favorite: Boolean,
    onClick: () -> Unit, onFavorite: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp))
            .background(if (active) Color(0xFF25212D) else Color(0xFF151820))
            .border(if (focused) 3.dp else 1.dp,
                if (focused) Color(0xFFE9C5FF) else Color(0xFF292D38), RoundedCornerShape(17.dp))
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).focusable()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(station.name, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${station.genre}  ·  ${station.broadcaster}", color = Color(0xFF9BA0AA),
                fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp))
        }
        if (active) Text("ON AIR", color = Color(0xFFE9C5FF), fontSize = 10.sp, letterSpacing = 1.sp,
            modifier = Modifier.padding(end = 18.dp))
        Text(if (favorite) "♥" else "♡", color = if (favorite) Color(0xFFE9C5FF) else Color(0xFF8C909B),
            fontSize = 22.sp, modifier = Modifier.clickable(onClick = onFavorite).padding(horizontal = 8.dp))
    }
}
