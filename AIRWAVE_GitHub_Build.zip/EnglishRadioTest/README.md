# Radio Cherry

A native Android music-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Release 2.0 changes

- App identity updated to **Radio Cherry**. The application ID remains `com.example.englishradio` so this release can update the existing installation instead of appearing as a separate app.
- macOS-inspired dark glass interface with a lavender, periwinkle and cyan liquid-cell orb.
- Slow, organic orb motion across the app, with an Appearance & motion setting to pause it.
- Persistent Now Playing mini-player docked at the bottom of the app.
- Expressive press feedback on station cards and Material controls.
- Media3 background playback service and media session.
- Explicit Stop custom command exposed to Android media controls.
- Media-session activity PendingIntent so tapping the system media card opens Radio Cherry.
- Shared orb artwork embedded in media metadata for the notification shade and lock-screen media card.
- Existing free music station catalogue retained, including western and Indian classical selections. No news stations are included.

## Build locally

Requirements: JDK 17, Android SDK platform 36, Android Build Tools 36.0.0, and Gradle 8.13.

From this folder:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## Build with GitHub Actions

Keep the uploaded source archive named `AIRWAVE_GitHub_Build.zip` to match the repository workflow used for the previous AIRWAVE builds. The standalone workflow file supplied with this release must be committed in the repository at:

`.github/workflows/build-apk.yml`

The workflow extracts the archive, compiles the Android project and publishes the artifact `Radio-Cherry-2.0-debug-APK`.

## Media artwork note

Android's system media notification and lock-screen controls use a still artwork bitmap supplied by the media session. Radio Cherry supplies the same liquid-orb artwork there. The in-app orb uses Compose Canvas animation and can be paused in Settings; Android System UI does not host a continuously animated Compose view inside its media card.
