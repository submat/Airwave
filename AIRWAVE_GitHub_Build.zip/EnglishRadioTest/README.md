# Radio Cherry 2.1

A native Android music-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Release 2.1 visual refresh

- Full-screen liquid-glass atmosphere with moving, colour-shifting ambient fields and translucent bubble cells.
- Siri-inspired fluid orb made from overlapping glossy gradient bubbles, with independently drifting cells and slowly changing colours.
- Glass treatment across the header, hero, search, category controls, station tiles and bottom player: layered translucent fills, luminous gradient rims, soft reflections and ambient glow.
- Expressive press feedback with spring-scale and light response on station cards, chips and icon actions.
- Persistent Now Playing mini-player docked at the bottom.
- Appearance setting to freeze the ambient fields and bubble animation.
- Radio Cherry app identity; application ID remains `com.example.englishradio` to update the existing installation.
- Existing Radio Cherry 2.0 Media3 background session, notification artwork and lock-screen integration retained.
- Existing free music station catalogue retained, including western and Indian classical selections. No news stations.

## Build

Requirements: JDK 17, Android SDK platform 36, Android Build Tools 36, Gradle 8.13.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

Keep the uploaded source archive named `AIRWAVE_GitHub_Build.zip` if your existing workflow extracts that filename. The workflow must live at repository root under `.github/workflows/build-apk.yml`.

## Glass and artwork rendering note

The app uses translucent gradient layers, luminous edge strokes, reflective overlays and soft radial light fields to create its glass appearance. Android's system media notification and lock-screen card use static artwork supplied through the media session; continuously animated Compose content cannot run inside those system-owned controls.


## Radio Cherry 2.2 catalogue update

- Preserved the original curated station IDs and streams.
- Added 199 new, unique stations from the four supplied M3U lists and the English-language CSV.
- Excluded obvious news, talk and sports services from the CSV import; the four user-supplied music M3U playlists are imported by their playlist group.
- Categories are derived dynamically from the catalogue.
- Added a resolver for `.m3u` and `.pls` station list URLs. `.m3u8` remains an HLS stream and is handled by Media3 HLS.
- Enabled cleartext HTTP for legacy radio streams in the supplied lists; HTTPS URLs remain preferred when available.
- The imported playlist files and CSV are retained in `app/src/main/assets/playlists/` for reference.

Catalogue count: 24 original stations + 199 newly imported stations = 223 total unique station entries in the app catalogue.
