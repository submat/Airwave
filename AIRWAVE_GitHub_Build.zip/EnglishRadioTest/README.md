# radio cherry — Android project

This project contains the native Android app for **radio cherry**.

## UI

The app has three reference-matched destinations: `radio` (Now Playing), `browse`, and `favorites`. The bottom navigation is persistent. Browse includes station search, station rows, and working genre shortcuts. Long-press a station row in Browse to save or remove it from Favorites. Favorites contains saved stations. Now Playing contains the station visualizer, live metadata, transport controls, and Up Next.

The waveform is drawn in Compose. While a station is playing, Android's audio-session `Visualizer` supplies per-band RMS levels to the layered waveform and blurred colour pulses. The app requests `RECORD_AUDIO` permission for this capture. If the permission is denied or audio capture is unavailable, the visualizer remains in a gentle idle mode. It can be disabled in Settings by tapping the small radio symbol below the waveform.

The app label and launcher name are `radio cherry`. The adaptive and round launcher icon resources are included in `app/src/main/res`.

## Build locally

Use Android Studio with JDK 17, Android SDK 36, Android Gradle Plugin 8.13.2, Kotlin 2.2.21 and Gradle 8.13. Then build `:app:assembleDebug`.

## GitHub Actions

The repository workflow is provided separately as `build-apk.yml`. Place it in the repository root at `.github/workflows/build-apk.yml`. Upload this project archive to the repository root as `radio-cherry_GitHub_Build.zip`; the workflow extracts it and builds `EnglishRadioTest/app`.
