# AIRWAVE 1.0

A native Android internet-radio player built with Kotlin, Jetpack Compose and AndroidX Media3.

## What's included

- App and launcher label: **AIRWAVE** (no test-build wording in the UI).
- Redesigned macOS-inspired glass interface with translucent surfaces, soft ambient light, rounded panels and edge-to-edge safe insets. The header respects the Android status bar and display cutout.
- 26 free radio streams across ambient, indie, alternative, 70s/80s, folk, jazz, electronic, world, news and classical.
- Western classical: Radio Swiss Classic (German announcements), WCRB Classical and Classical KUSC.
- Indian classical: AIR Raagam, an Akashvani channel listed by Prasar Bharati as a live-streamed service.
- Additional English-language music and spoken-word services: KEXP, Radio Paradise mixes and NPR News.
- Background playback hosted by `MediaSessionService`.
- Android media notification, lock-screen controls and system media controls via Media3 MediaSession.
- HLS playback support for AIR Raagam.
- Primary/fallback stream handling for SomaFM and KEXP.
- Station search, category filters and locally saved favourites.

## Broadcaster sources

- SomaFM: https://somafm.com/listen/
- KEXP official livestream URLs: https://www.kexp.org/streaming-urls/
- Radio Paradise official stream links: https://www8.radioparadise.com/rp3.php?file=links&name=Listen
- Radio Swiss Classic official stream information: https://www.radioswissclassic.ch/en/reception/internet
- WCRB Classical official listening page: https://www.classicalwcrb.org/ways-to-listen
- Classical KUSC: https://www.kusc.org/
- Prasar Bharati live-streaming list (includes AIR Raagam): https://prasarbharati.gov.in/en/livestreaming-services/

Stations are third-party broadcasts. Availability, regional restrictions and stream formats may change. AIRWAVE does not host or re-transmit audio.

## Build APK with GitHub Actions

1. Keep `AIRWAVE_GitHub_Build.zip` in the root of your GitHub repository.
2. Keep the workflow at `.github/workflows/build-apk.yml` in the repository root. If it already exists, replace its contents with the workflow supplied in this package.
3. The workflow extracts the ZIP, installs Java 17, Android SDK 36 and Gradle 8.13, then builds `:app:assembleDebug`.
4. Open **Actions → Build AIRWAVE APK → Run workflow**.
5. When successful, download the `AIRWAVE-1.0-debug-APK` artifact and extract `app-debug.apk` from it.
6. Install the APK over the previous AIRWAVE build. The application ID is unchanged, so it should update in place.

No signing secret is required for the debug APK. GitHub retains the artifact for 14 days.

## Technical notes

- Min SDK: 26 (Android 8.0)
- Compile/target SDK: 36
- Kotlin: 2.2.21
- Material 3: 1.5.0
- Compose BOM: 2026.09.00
- Media3: 1.5.1
- Application ID remains `com.example.englishradio` to allow in-place upgrades from the earlier AIRWAVE builds.


## Free music-source review (Clementine-inspired)

Clementine's current feature list identifies SomaFM, Digitally Imported, RadioTunes, JAZZRADIO.com, ROCKRADIO.com, ClassicalRadio.com, Intergalactic FM, Radio-Browser.info and Icecast as internet-radio integrations, and Jamendo/Magnatune as music catalog integrations. AIRWAVE currently keeps direct music-radio streams and does not add news/talk.

Candidate sources for future AIRWAVE expansion:
- **SomaFM** — free listener-supported music radio; existing AIRWAVE stations retained.
- **Radio Browser / Icecast** — open community radio directory and public API; station streams are supplied by individual broadcasters, so each station's availability and rights need checking.
- **Jamendo** — Creative Commons catalogue with a developer API/client ID. Its dedicated radio-stream API documentation currently warns that returned radio links no longer work; use the track API only after implementing the required client ID and license-aware playback.
- **Magnatune** — not included as a free default; its streaming membership is paid.
- **Digitally Imported / RadioTunes / JAZZRADIO / ROCKRADIO / ClassicalRadio** — Clementine supports these integrations, but access may be tiered or subscription-based; do not label them free without checking each service's current terms.

NPR News has been removed from the station list and category filters.
