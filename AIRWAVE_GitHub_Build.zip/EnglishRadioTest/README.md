# Radio Cherry 2.1

A native Android music-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Release 2.1 visual refresh

- Full-screen liquid-glass atmosphere with moving, colour-shifting ambient fields and translucent bubble cells.
- Siri-inspired fluid orb made from overlapping glossy gradient bubbles, with independently drifting cells and slowly changing colours.
- Glass treatment across the header, hero, search, category controls, station tiles and bottom player: layered translucent fills, luminous gradient rims, soft reflections and ambient glow.
- Expressive press feedback with spring-scale and light response on station cards, chips and icon actions.
- Persistent Now Playing mini-player docked at the bottom.
- Appearance setting to freeze the ambient fields and bubble animation.
- Radio Cherry app identity; application ID remains `com.example.englishradio` to update the existing installation.
- Existing Radio Cherry 2.0 Media3 background session, notification artwork and lock-screen integration retained.
- Existing free music station catalogue retained, including western and Indian classical selections. No news stations.

## Build

Requirements: JDK 17, Android SDK platform 36, Android Build Tools 36, Gradle 8.13.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

Keep the uploaded source archive named `AIRWAVE_GitHub_Build.zip` if your existing workflow extracts that filename. The workflow must live at repository root under `.github/workflows/build-apk.yml`.

## Glass and artwork rendering note

The app uses translucent gradient layers, luminous edge strokes, reflective overlays and soft radial light fields to create its glass appearance. Android's system media notification and lock-screen card use static artwork supplied through the media session; continuously animated Compose content cannot run inside those system-owned controls.
