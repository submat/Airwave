# Radio Cherry 2.3.1

A native Android music-radio app built with Kotlin, Jetpack Compose and AndroidX Media3.

## Release 2.3.1 fluid-motion correction

- Full-screen liquid-glass atmosphere with moving, colour-shifting ambient light fields.
- Replaced the low-motion orb graphic with a live Canvas-rendered fluid sphere. Three wide translucent silk ribbons morph continuously, gradient colours cycle across pink, violet, blue, cyan and teal, the sphere breathes, and the specular highlight travels around the membrane.
- The animated sphere is a full-screen ambient layer behind the whole interface; the hero is no longer a small orb parked at the right edge.
- Removed miniature orb art from station rows. The active mini-player retains a live Canvas orb.
- Reduced repeated heavy card outlines and shadows so the glass surfaces read as layers over the moving light field, rather than a stack of outlined tiles.
- Expressive press feedback with spring-scale and light response on station cards, chips and icon actions.
- Persistent Now Playing mini-player docked at the bottom.
- Appearance setting genuinely freezes the full-screen orb and ambient light animation; the animated composable is not running when the setting is off.
- Radio Cherry app identity; application ID remains `com.example.englishradio` to update the existing installation.
- Existing Radio Cherry 2.0 Media3 background session, notification artwork and lock-screen integration retained.
- Existing free music station catalogue retained, including western and Indian classical selections. No news stations.

## Build

Requirements: JDK 17, Android SDK platform 36, Android Build Tools 36, Gradle 8.13.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

Keep the uploaded source archive named `AIRWAVE_GitHub_Build.zip` if your existing workflow extracts that filename. The workflow must live at repository root under `.github/workflows/build-apk.yml`.

## Glass, animation and system media note

The app uses translucent gradient layers, restrained edge strokes, reflective overlays and soft radial light fields. The in-app liquid sphere is drawn and animated at runtime with Compose Canvas paths; it is not a PNG/GIF displayed in place of animation. Android's system-owned media notification and lock-screen player accept static artwork through Media3 metadata. Those native surfaces cannot host the app's continuously animated Compose Canvas, so they use a matching static still while the in-app sphere continues to move.


## Radio Cherry 2.2 catalogue update

- Preserved the original curated station IDs and streams.
- Added 199 new, unique stations from the four supplied M3U lists and the English-language CSV.
- Excluded obvious news, talk and sports services from the CSV import; the four user-supplied music M3U playlists are imported by their playlist group.
- Categories are derived dynamically from the catalogue.
- Added a resolver for `.m3u` and `.pls` station list URLs. `.m3u8` remains an HLS stream and is handled by Media3 HLS.
- Enabled cleartext HTTP for legacy radio streams in the supplied lists; HTTPS URLs remain preferred when available.
- The imported playlist files and CSV are retained in `app/src/main/assets/playlists/` for reference.

Catalogue count: 24 original stations + 199 newly imported stations = 223 total unique station entries in the app catalogue.


## Radio Cherry 2.3.1 motion correction

- The in-app orb is now a runtime-rendered Canvas animation with larger fluid deformation, faster visible ribbon movement, shifting gradients, breathing scale and a traveling highlight.
- The animated sphere spans the main screen as an ambient layer behind the header, hero, search, categories, station list and player.
- The hero no longer places a small standalone orb on its right side.
- The bottom in-app player uses the live Canvas orb when playback is active.
- The Android notification shade and lock-screen media card continue to use a still artwork image because their presentation is controlled by Android's system media UI.
