# AIRWAVE — Android radio app

Native Android application built with Kotlin, Jetpack Compose and AndroidX Media3.

## UI reference implementation

The app UI has been rebuilt around the supplied AIRWAVE reference screens:

- **Now Playing** — centered `radio` title, multicolour blurred waveform visualizer, station title and live metadata, progress line, previous/play-next controls, and `up next` list.
- **Browse** — `browse` heading, matching waveform visualizer, search field, station list and genre shortcuts.
- **Favorites** — `favorites` heading, matching visualizer, saved station count and saved-station rows with heart controls.
- Light and dark appearances follow the two reference variants. Tap the small appearance glyph in the upper-right corner to switch.
- The waveform remains an in-app Canvas animation and responds to the active audio visualizer data while playing.

The existing station catalogue, Media3 playback service, stream fallback handling, playlist resolver, favorites persistence and background media session are retained.

## Build locally

Requirements: JDK 17, Android SDK platform 36, Android Build Tools 36, Gradle 8.13.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions

The included workflow is `.github/workflows/build-apk.yml`. Add the contents of this project directory to the root of your GitHub repository. The workflow builds the debug APK and publishes it as an Actions artifact named `AIRWAVE-debug-apk`.

## Notes

The supplied reference images contain Swedish station labels and FM frequencies. The existing project catalogue is preserved rather than assigning those labels to unrelated stream URLs. The visual layout and UI wording from the references are followed; actual station names and metadata continue to come from the station catalogue.
