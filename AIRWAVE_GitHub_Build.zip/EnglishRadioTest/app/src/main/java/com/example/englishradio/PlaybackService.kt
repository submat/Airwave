package com.example.englishradio

import android.os.Bundle
import androidx.media3.common.C
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private var fallbackAttemptedFor: String? = null

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(AudioAttributes.DEFAULT, true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                val item = player.currentMediaItem ?: return
                val stationId = item.mediaId
                if (fallbackAttemptedFor == stationId) return
                val fallback = item.mediaMetadata.extras?.getString(EXTRA_FALLBACK) ?: return
                fallbackAttemptedFor = stationId
                val fallbackItem = item.buildUpon().setUri(fallback).build()
                player.setMediaItem(fallbackItem)
                player.prepare()
                player.play()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (mediaItem?.mediaId != fallbackAttemptedFor) fallbackAttemptedFor = null
            }
        })
        mediaSession = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.release()
            release()
        }
        mediaSession = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_FALLBACK = "airwave_fallback_stream"

        fun mediaItem(station: Station): MediaItem {
            val extras = Bundle().apply {
                station.fallback?.let { putString(EXTRA_FALLBACK, it) }
            }
            val metadata = MediaMetadata.Builder()
                .setTitle(station.name)
                .setArtist(station.genre)
                .setAlbumTitle("AIRWAVE · ${station.region}")
                .setExtras(extras)
                .build()
            return MediaItem.Builder()
                .setMediaId(station.id)
                .setUri(station.stream)
                .setMediaMetadata(metadata)
                .build()
        }
    }
}
