package com.example.englishradio

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

private val stations = listOf(
    Station("groove-salad", "Groove Salad", "Ambient · Downtempo", "SomaFM", "https://ice5.somafm.com/groovesalad-128-mp3", "https://ice.somafm.com/groovesalad", "Chill"),
    Station("lush", "Lush", "Mellow · Electronic", "SomaFM", "https://ice5.somafm.com/lush-128-mp3", "https://ice.somafm.com/lush", "Chill"),
    Station("indie-pop", "Indie Pop Rocks!", "Indie · Alternative", "SomaFM", "https://ice5.somafm.com/indiepop-128-mp3", "https://ice.somafm.com/indiepop", "Indie"),
    Station("underground-80s", "Underground 80s", "80s · New Wave", "SomaFM", "https://ice5.somafm.com/u80s-128-mp3", "https://ice.somafm.com/u80s", "Throwbacks"),
    Station("left-coast-70s", "Left Coast 70s", "Classic · Album Rock", "SomaFM", "https://ice5.somafm.com/seventies-128-mp3", "https://ice.somafm.com/seventies", "Throwbacks"),
    Station("folk-forward", "Folk Forward", "Folk · Americana", "SomaFM", "https://ice5.somafm.com/folkfwd-128-mp3", "https://ice.somafm.com/folkfwd", "Acoustic"),
    Station("drone-zone", "Drone Zone", "Atmospheric · Ambient", "SomaFM", "https://ice5.somafm.com/dronezone-128-mp3", "https://ice.somafm.com/dronezone", "Chill"),
    Station("secret-agent", "Secret Agent", "Spy · Soundtracks", "SomaFM", "https://ice5.somafm.com/secretagent-128-mp3", "https://ice.somafm.com/secretagent", "Discovery"),
    Station("mission-control", "Mission Control", "Space · Ambient", "SomaFM", "https://ice5.somafm.com/missioncontrol-128-mp3", "https://ice.somafm.com/missioncontrol", "Chill"),
    Station("space-station", "Space Station Soma", "Space · Electronic", "SomaFM", "https://ice5.somafm.com/spacestation-128-mp3", "https://ice.somafm.com/spacestation", "Chill"),
    Station("beat-blender", "Beat Blender", "Deep · House", "SomaFM", "https://ice5.somafm.com/beatblender-128-mp3", "https://ice.somafm.com/beatblender", "Electronic"),
    Station("poptron", "PopTron", "Indie · Pop", "SomaFM", "https://ice5.somafm.com/poptron-128-mp3", "https://ice.somafm.com/poptron", "Indie"),
    Station("sonic-universe", "Sonic Universe", "Modern · Jazz", "SomaFM", "https://ice5.somafm.com/sonicuniverse-128-mp3", "https://ice.somafm.com/sonicuniverse", "Jazz"),
    Station("suburbs-of-goa", "Suburbs of Goa", "Psychedelic · Indian", "SomaFM", "https://ice5.somafm.com/suburbsofgoa-128-mp3", "https://ice.somafm.com/suburbsofgoa", "World"),
    Station("sf-10-33", "SF 10-33", "Ambient · Police Scanner", "SomaFM", "https://ice5.somafm.com/sf1033-128-mp3", "https://ice.somafm.com/sf1033", "Discovery"),
    Station("defcon", "DEF CON Radio", "Electronic · Hacker culture", "SomaFM", "https://ice5.somafm.com/defcon-128-mp3", "https://ice.somafm.com/defcon", "Electronic"),
    Station("radio-paradise-main", "Radio Paradise · Main Mix", "Eclectic · Alternative", "Radio Paradise", "https://stream.radioparadise.com/mp3-128", null, "Indie", region = "USA"),
    Station("radio-paradise-mellow", "Radio Paradise · Mellow Mix", "Mellow · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/mellow-128", null, "Chill", region = "USA"),
    Station("radio-paradise-rock", "Radio Paradise · Rock Mix", "Alternative · Rock", "Radio Paradise", "https://stream.radioparadise.com/rock-128", null, "Indie", region = "USA"),
    Station("radio-paradise-global", "Radio Paradise · Global Mix", "World · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/eclectic-128", null, "World", region = "USA"),
    Station("kexp", "KEXP 90.3", "Alternative · Discovery", "KEXP", "https://kexp.streamguys1.com/kexp160.aac", "https://kexp.streamguys1.com/kexp64.aac", "Indie", region = "Seattle"),
    Station("swiss-classic", "Radio Swiss Classic", "Western classical · German announcements", "Switzerland", "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128", null, "Classical", region = "Switzerland"),
    Station("wcrb", "WCRB Classical", "Symphonic · Chamber · Opera", "CRB · Boston", "https://wgbh-live.streamguys1.com/classical-hi/", null, "Classical", region = "Boston"),
    Station("kusc", "Classical KUSC", "Orchestral · Classical favourites", "Classical California", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3", null, "Classical", region = "Los Angeles"),
    Station("air-raagam", "AIR Raagam", "Hindustani · Carnatic", "Akashvani · India", "https://airhlspush.pc.cdn.bitgravity.com/httppush/hlspbaudioragam/hlspbaudioragam64kbps.m3u8", null, "Indian Classical", region = "India"),
)

data class Station(
    val id: String,
    val name: String,
    val genre: String,
    val broadcaster: String,
    val stream: String,
    val fallback: String?,
    val category: String,
    val region: String = "USA"
)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                runCatching { future.get() }.onSuccess { controller = it }
            }, ContextCompat.getMainExecutor(this))
        }
        setContent { AirwaveApp(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun AirwaveApp(player: MediaController?) {
    var selectedId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackStatus by remember { mutableStateOf("Choose a station to begin") }
    var search by remember { mutableStateOf("") }
    val context = LocalContext.current
    val preferences = remember(context) { context.getSharedPreferences("airwave_preferences", android.content.Context.MODE_PRIVATE) }
    var favorites by remember {
        mutableStateOf(preferences.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    LaunchedEffect(favorites) {
        preferences.edit().putStringSet("favorite_station_ids", favorites).apply()
    }
    var showFavorites by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                playbackStatus = if (playing) "On air" else "Paused"
            }
            override fun onPlaybackStateChanged(state: Int) {
                playbackStatus = when (state) {
                    Player.STATE_BUFFERING -> "Tuning in…"
                    Player.STATE_READY -> if (player.isPlaying) "On air" else "Ready when you are"
                    Player.STATE_ENDED -> "Stream ended"
                    else -> playbackStatus
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isPlaying = false
                playbackStatus = "Stream unavailable · ${error.errorCodeName}"
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
            }
        }
        player.addListener(listener)
        isPlaying = player.isPlaying
        selectedId = player.currentMediaItem?.mediaId
        onDispose { player.removeListener(listener) }
    }

    val selected = stations.firstOrNull { it.id == selectedId }
    val filtered = stations.filter {
        (search.isBlank() || (it.name + it.genre + it.category + it.broadcaster).contains(search, true)) &&
            (!showFavorites || it.id in favorites)
    }
    val categories = listOf("All", "Classical", "Indian Classical", "Chill", "Indie", "Throwbacks", "Jazz", "Electronic", "Acoustic", "World", "Discovery")
    var activeCategory by remember { mutableStateOf("All") }
    val visibleStations = filtered.filter { activeCategory == "All" || it.category == activeCategory }

    val ink = Color(0xFFE9F0F1)
    val muted = Color(0xFF9EAFB3)
    val mint = Color(0xFFC2F2A0)
    val aqua = Color(0xFF8FD7D0)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = mint,
            secondary = aqua,
            background = Color(0xFF091216),
            surface = Color(0xFF142127),
            onBackground = ink,
            onSurface = ink
        )
    ) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF17352F), Color(0xFF101E26), Color(0xFF080E13))))) {
            // Soft ambient light pools behind the translucent surfaces.
            Box(Modifier.offset(x = 210.dp, y = 150.dp).size(210.dp).blur(70.dp).background(Color(0xFF3E8E78).copy(alpha = .25f), CircleShape))
            Box(Modifier.offset(x = (-90).dp, y = 500.dp).size(220.dp).blur(80.dp).background(Color(0xFF416A91).copy(alpha = .18f), CircleShape))

            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 20.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(mint.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Radio, null, tint = mint, modifier = Modifier.size(23.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Text("AIRWAVE", color = mint, fontWeight = FontWeight.ExtraBold, letterSpacing = 3.sp, fontSize = 17.sp)
                    Spacer(Modifier.weight(1f))
                    Text("LIVE RADIO", color = muted, fontSize = 10.sp, letterSpacing = 1.7.sp)
                }

                Text("Your world.\nOn the air.", color = ink, fontSize = 34.sp, lineHeight = 39.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-.7).sp)
                Spacer(Modifier.height(8.dp))
                Text("Independent radio, classical traditions and sounds worth discovering.", color = muted, fontSize = 13.sp, lineHeight = 19.sp)
                Spacer(Modifier.height(20.dp))

                GlassPanel(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("NOW PLAYING", color = muted, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.weight(1f))
                            if (isPlaying) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(6.dp).background(mint, CircleShape))
                                    Spacer(Modifier.width(6.dp))
                                    Text("ON AIR", color = mint, fontSize = 9.sp, letterSpacing = 1.4.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(selected?.name ?: "Find your frequency", color = ink, fontSize = 23.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(selected?.let { "${it.genre}  ·  ${it.broadcaster}" } ?: "Choose a station and settle in", color = muted, fontSize = 12.sp)
                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                onClick = {
                                    if (player != null) {
                                        if (player.isPlaying) player.pause()
                                        else if (player.mediaItemCount > 0) player.play()
                                        else selected?.let { player.setMediaItem(PlaybackService.mediaItem(it)); player.prepare(); player.play() }
                                    }
                                },
                                shape = CircleShape,
                                color = mint,
                                modifier = Modifier.size(54.dp),
                                enabled = player != null && selected != null
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF102019), modifier = Modifier.size(30.dp))
                                }
                            }
                            Spacer(Modifier.width(13.dp))
                            Column(Modifier.weight(1f)) {
                                Text(if (isPlaying) "PLAYING LIVE" else "${playbackStatus.uppercase()}", color = mint, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                Text("Audio continues when you leave the app", color = muted, fontSize = 10.sp)
                            }
                            Icon(Icons.Default.Headphones, null, tint = aqua.copy(alpha = .8f), modifier = Modifier.size(25.dp))
                        }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("EXPLORE STATIONS", color = mint, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    Text("${visibleStations.size} CHANNELS", color = muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search stations or genres", color = muted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = muted) },
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = mint.copy(alpha = .55f), unfocusedBorderColor = Color.White.copy(alpha = .10f),
                        focusedContainerColor = Color.White.copy(alpha = .06f), unfocusedContainerColor = Color.White.copy(alpha = .045f),
                        focusedTextColor = ink, unfocusedTextColor = ink, cursorColor = mint
                    )
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = !showFavorites, onClick = { showFavorites = false }, label = { Text("All stations") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = showFavorites, onClick = { showFavorites = true }, label = { Text("Favourites ♥") })
                }
                Spacer(Modifier.height(6.dp))
                androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(vertical = 3.dp)) {
                    items(categories) { category ->
                        FilterChip(selected = activeCategory == category, onClick = { activeCategory = category }, label = { Text(category, fontSize = 11.sp) })
                    }
                }
                Spacer(Modifier.height(6.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 18.dp)
                ) {
                    items(visibleStations, key = { it.id }) { station ->
                        val active = selectedId == station.id
                        StationCard(
                            station = station,
                            active = active,
                            favorite = station.id in favorites,
                            onFavorite = { favorites = if (station.id in favorites) favorites - station.id else favorites + station.id },
                            onClick = {
                                if (player != null) {
                                    selectedId = station.id
                                    playbackStatus = "Tuning in…"
                                    player.setMediaItem(PlaybackService.mediaItem(station))
                                    player.prepare()
                                    player.play()
                                }
                            }
                        )
                    }
                    if (visibleStations.isEmpty()) item { Text("No stations match that search.", color = muted, modifier = Modifier.padding(16.dp)) }
                }
            }
        }
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(
        modifier = modifier.border(BorderStroke(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .20f), Color.White.copy(alpha = .035f)))), RoundedCornerShape(27.dp)),
        shape = RoundedCornerShape(27.dp),
        color = Color.White.copy(alpha = .075f),
        content = { Column(content = content) }
    )
}

@Composable
private fun StationCard(station: Station, active: Boolean, favorite: Boolean, onFavorite: () -> Unit, onClick: () -> Unit) {
    val mint = Color(0xFFC2F2A0)
    val muted = Color(0xFF9EAFB3)
    Surface(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().border(
            1.dp,
            if (active) mint.copy(alpha = .42f) else Color.White.copy(alpha = .075f),
            RoundedCornerShape(20.dp)
        ),
        shape = RoundedCornerShape(20.dp),
        color = if (active) Color(0xFFBDEDA0).copy(alpha = .13f) else Color.White.copy(alpha = .055f)
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(if (active) mint.copy(alpha = .18f) else Color.White.copy(alpha = .07f)), contentAlignment = Alignment.Center) {
                Icon(if (station.category.contains("Classical")) Icons.Default.GraphicEq else Icons.Default.Radio, null, tint = mint, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(station.name, color = Color(0xFFE9F0F1), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Spacer(Modifier.height(3.dp))
                Text("${station.genre}  ·  ${station.broadcaster}", color = muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (active) {
                Icon(Icons.Default.GraphicEq, null, tint = mint, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(5.dp))
            }
            IconButton(onClick = onFavorite, modifier = Modifier.size(34.dp)) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) mint else muted, modifier = Modifier.size(18.dp))
            }
        }
    }
}
