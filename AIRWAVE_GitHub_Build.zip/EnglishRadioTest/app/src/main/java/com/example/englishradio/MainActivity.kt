package com.example.englishradio

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private val stations = listOf(
    Station("groove-salad", "Groove Salad", "Ambient · Downtempo", "SomaFM", "https://ice5.somafm.com/groovesalad-128-mp3", "https://ice.somafm.com/groovesalad", "Chill"),
    Station("lush", "Lush", "Mellow · Electronic", "SomaFM", "https://ice5.somafm.com/lush-128-mp3", "https://ice.somafm.com/lush", "Chill"),
    Station("indie-pop", "Indie Pop Rocks!", "Indie · Alternative", "SomaFM", "https://ice5.somafm.com/indiepop-128-mp3", "https://ice.somafm.com/indiepop", "Indie"),
    Station("underground-80s", "Underground 80s", "80s · New Wave", "SomaFM", "https://ice5.somafm.com/u80s-128-mp3", "https://ice.somafm.com/u80s", "Throwbacks"),
    Station("left-coast-70s", "Left Coast 70s", "Classic · Album Rock", "SomaFM", "https://ice5.somafm.com/seventies-128-mp3", "https://ice.somafm.com/seventies", "Throwbacks"),
    Station("folk-forward", "Folk Forward", "Folk · Americana", "SomaFM", "https://ice5.somafm.com/folkfwd-128-mp3", "https://ice.somafm.com/folkfwd", "Acoustic"),
    Station("drone-zone", "Drone Zone", "Atmospheric · Ambient", "SomaFM", "https://ice5.somafm.com/dronezone-128-mp3", "https://ice.somafm.com/dronezone", "Chill"),
    Station("secret-agent", "Secret Agent", "Spy · Soundtracks", "SomaFM", "https://ice5.somafm.com/secretagent-128-mp3", "https://ice.somafm.com/secretagent", "Discovery"),
    Station("mission-control", "Mission Control", "Space · Ambient", "SomaFM", "https://ice5.somafm.com/missioncontrol-128-mp3", "https://ice.somafm.com/missioncontrol", "Chill"),
    Station("space-station", "Space Station Soma", "Space · Electronic", "SomaFM", "https://ice5.somafm.com/spacestation-128-mp3", "https://ice.somafm.com/spacestation", "Chill"),
    Station("beat-blender", "Beat Blender", "Deep · House", "SomaFM", "https://ice5.somafm.com/beatblender-128-mp3", "https://ice.somafm.com/beatblender", "Electronic"),
    Station("poptron", "PopTron", "Indie · Pop", "SomaFM", "https://ice5.somafm.com/poptron-128-mp3", "https://ice.somafm.com/poptron", "Indie"),
    Station("sonic-universe", "Sonic Universe", "Modern · Jazz", "SomaFM", "https://ice5.somafm.com/sonicuniverse-128-mp3", "https://ice.somafm.com/sonicuniverse", "Jazz"),
    Station("suburbs-of-goa", "Suburbs of Goa", "Psychedelic · Indian", "SomaFM", "https://ice5.somafm.com/suburbsofgoa-128-mp3", "https://ice.somafm.com/suburbsofgoa", "World"),
    Station("defcon", "DEF CON Radio", "Electronic · Hacker culture", "SomaFM", "https://ice5.somafm.com/defcon-128-mp3", "https://ice.somafm.com/defcon", "Electronic"),
    Station("radio-paradise-main", "Radio Paradise · Main Mix", "Eclectic · Alternative", "Radio Paradise", "https://stream.radioparadise.com/mp3-128", null, "Indie", region = "USA"),
    Station("radio-paradise-mellow", "Radio Paradise · Mellow Mix", "Mellow · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/mellow-128", null, "Chill", region = "USA"),
    Station("radio-paradise-rock", "Radio Paradise · Rock Mix", "Alternative · Rock", "Radio Paradise", "https://stream.radioparadise.com/rock-128", null, "Indie", region = "USA"),
    Station("radio-paradise-global", "Radio Paradise · Global Mix", "World · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/eclectic-128", null, "World", region = "USA"),
    Station("kexp", "KEXP 90.3", "Alternative · Discovery", "KEXP", "https://kexp.streamguys1.com/kexp160.aac", "https://kexp.streamguys1.com/kexp64.aac", "Indie", region = "Seattle"),
    Station("swiss-classic", "Radio Swiss Classic", "Western classical · Instrumental", "Switzerland", "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128", null, "Classical", region = "Switzerland"),
    Station("wcrb", "WCRB Classical", "Symphonic · Chamber · Opera", "CRB · Boston", "https://wgbh-live.streamguys1.com/classical-hi/", null, "Classical", region = "Boston"),
    Station("kusc", "Classical KUSC", "Orchestral · Classical favourites", "Classical California", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3", null, "Classical", region = "Los Angeles"),
    Station("air-raagam", "AIR Raagam", "Hindustani · Carnatic", "Akashvani · India", "https://airhlspush.pc.cdn.bitgravity.com/httppush/hlspbaudioragam/hlspbaudioragam64kbps.m3u8", null, "Indian Classical", region = "India")
)

data class Station(
    val id: String,
    val name: String,
    val genre: String,
    val broadcaster: String,
    val stream: String,
    val fallback: String?,
    val category: String,
    val region: String = "USA"
)

private val liquidPalette = listOf(
    Color(0xFFE8C9FF), Color(0xFFB5A0FF), Color(0xFF8A9DFF),
    Color(0xFF63C8F5), Color(0xFF8CE9E1), Color(0xFFC6B5FF),
    Color(0xFFFFB9E8)
)

private fun colorBlend(a: Color, b: Color, fraction: Float): Color {
    val t = fraction.coerceIn(0f, 1f)
    return Color(
        red = a.red + (b.red - a.red) * t,
        green = a.green + (b.green - a.green) * t,
        blue = a.blue + (b.blue - a.blue) * t,
        alpha = a.alpha + (b.alpha - a.alpha) * t
    )
}

private fun shiftingColor(index: Float): Color {
    val base = floor(index).toInt()
    val fraction = index - floor(index)
    val first = ((base % liquidPalette.size) + liquidPalette.size) % liquidPalette.size
    val second = (first + 1) % liquidPalette.size
    return colorBlend(liquidPalette[first], liquidPalette[second], fraction)
}

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                runCatching { future.get() }.onSuccess { controller = it }
            }, ContextCompat.getMainExecutor(this))
        }
        setContent { RadioCherryApp(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun RadioCherryApp(player: MediaController?) {
    val context = LocalContext.current
    val preferences = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", android.content.Context.MODE_PRIVATE)
    }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackStatus by remember { mutableStateOf("Choose a station to begin") }
    var search by remember { mutableStateOf("") }
    var showFavorites by remember { mutableStateOf(false) }
    var activeCategory by remember { mutableStateOf("All") }
    var showSettings by remember { mutableStateOf(false) }
    var favorites by remember {
        mutableStateOf(preferences.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    var orbMotionEnabled by remember {
        mutableStateOf(preferences.getBoolean("orb_motion_enabled", true))
    }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }

    LaunchedEffect(favorites) {
        preferences.edit().putStringSet("favorite_station_ids", favorites).apply()
    }
    LaunchedEffect(orbMotionEnabled) {
        preferences.edit().putBoolean("orb_motion_enabled", orbMotionEnabled).apply()
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                playbackStatus = if (playing) "Playing live" else if (player.mediaItemCount > 0) "Paused" else "Choose a station"
            }
            override fun onPlaybackStateChanged(state: Int) {
                playbackStatus = when (state) {
                    Player.STATE_BUFFERING -> "Connecting to station…"
                    Player.STATE_READY -> if (player.isPlaying) "Playing live" else "Ready to play"
                    Player.STATE_ENDED -> "Stream ended"
                    Player.STATE_IDLE -> if (player.mediaItemCount == 0) "Choose a station" else "Stopped"
                    else -> playbackStatus
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isPlaying = false
                playbackStatus = "Stream unavailable · ${error.errorCodeName}"
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
                if (mediaItem == null) isPlaying = false
            }
        }
        player.addListener(listener)
        isPlaying = player.isPlaying
        selectedId = player.currentMediaItem?.mediaId
        onDispose { player.removeListener(listener) }
    }

    val selected = stations.firstOrNull { it.id == selectedId }
    val categories = listOf("All", "Chill", "Indie", "Throwbacks", "Electronic", "Acoustic", "Jazz", "World", "Classical", "Indian Classical", "Discovery")
    val visibleStations = stations.filter { station ->
        (search.isBlank() || (station.name + station.genre + station.category + station.broadcaster).contains(search, true)) &&
            (!showFavorites || station.id in favorites) &&
            (activeCategory == "All" || station.category == activeCategory)
    }

    fun playStation(station: Station) {
        if (player == null) return
        selectedId = station.id
        playbackStatus = "Connecting to station…"
        player.setMediaItem(PlaybackService.mediaItem(station, orbArtwork))
        player.prepare()
        player.play()
    }

    fun togglePlayback() {
        if (player == null) return
        if (player.isPlaying) {
            player.pause()
        } else if (player.mediaItemCount > 0) {
            player.play()
        } else {
            selected?.let { playStation(it) }
        }
    }

    fun stopPlayback() {
        player?.let {
            it.pause()
            it.clearMediaItems()
        }
        selectedId = null
        isPlaying = false
        playbackStatus = "Playback stopped"
    }

    val background = Color(0xFF07070D)
    val ink = Color(0xFFF7F3FF)
    val muted = Color(0xFFB9B1C9)
    val lavender = Color(0xFFD9BBFF)
    val cyan = Color(0xFF8BDFF1)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = lavender,
            secondary = cyan,
            background = background,
            surface = Color(0xFF171321),
            onBackground = ink,
            onSurface = ink
        )
    ) {
        Box(Modifier.fillMaxSize().background(background)) {
            LiquidAtmosphere(Modifier.fillMaxSize(), motionEnabled = orbMotionEnabled)

            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(7.dp))
                HeaderBar(onSettings = { showSettings = true })
                Spacer(Modifier.height(13.dp))
                HeroGlassPanel(motionEnabled = orbMotionEnabled)
                Spacer(Modifier.height(13.dp))
                GlassSearchField(
                    value = search,
                    onValueChange = { search = it },
                    onClear = { search = "" }
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    GlassChip(
                        label = "Explore all",
                        selected = !showFavorites,
                        onClick = { showFavorites = false }
                    )
                    Spacer(Modifier.width(8.dp))
                    GlassChip(
                        label = "Favourites  ♥",
                        selected = showFavorites,
                        onClick = { showFavorites = true }
                    )
                    Spacer(Modifier.weight(1f))
                    Text("${visibleStations.size} CHANNELS", color = Color(0xFFACA4BD), fontSize = 9.sp, letterSpacing = 1.1.sp)
                }
                Spacer(Modifier.height(7.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(vertical = 2.dp)) {
                    items(categories) { category ->
                        GlassChip(
                            label = category,
                            selected = activeCategory == category,
                            onClick = { activeCategory = category },
                            compact = true
                        )
                    }
                }
                Spacer(Modifier.height(11.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("FREQUENCIES", color = Color(0xFFE6D6FF), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 2.1.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (showFavorites) "YOUR COLLECTION" else "CURATED MUSIC RADIO", color = Color(0xFF938AA8), fontSize = 8.sp, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 12.dp, top = 2.dp)
                ) {
                    items(visibleStations, key = { it.id }) { station ->
                        StationCard(
                            station = station,
                            active = selectedId == station.id,
                            favorite = station.id in favorites,
                            motionEnabled = orbMotionEnabled,
                            onFavorite = {
                                favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
                            },
                            onClick = { playStation(station) }
                        )
                    }
                    if (visibleStations.isEmpty()) {
                        item {
                            GlassPanel(Modifier.fillMaxWidth().padding(top = 5.dp), radius = 22.dp) {
                                Text("No stations found. Try another search or category.", color = muted, modifier = Modifier.padding(18.dp), fontSize = 13.sp)
                            }
                        }
                    }
                }
                BottomMiniPlayer(
                    station = selected,
                    isPlaying = isPlaying,
                    status = playbackStatus,
                    motionEnabled = orbMotionEnabled,
                    onPlayPause = { togglePlayback() },
                    onStop = { stopPlayback() }
                )
                Spacer(Modifier.height(7.dp))
            }

            if (showSettings) {
                SettingsDialog(
                    motionEnabled = orbMotionEnabled,
                    onMotionChange = { orbMotionEnabled = it },
                    onDismiss = { showSettings = false }
                )
            }
        }
    }
}

@Composable
private fun LiquidAtmosphere(modifier: Modifier = Modifier, motionEnabled: Boolean) {
    val transition = rememberInfiniteTransition(label = "full-screen-liquid-atmosphere")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 36000, easing = LinearEasing)),
        label = "ambient-drift"
    )
    val hue by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 29000, easing = LinearEasing)),
        label = "ambient-colour"
    )
    val phase = if (motionEnabled) drift else 0f
    val colourPhase = if (motionEnabled) hue else .12f

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0D0A18), Color(0xFF080911), Color(0xFF05070D))))
        val centers = listOf(
            Offset(w * (.15f + .045f * cos(phase * .72f)), h * (.20f + .08f * sin(phase * .55f))),
            Offset(w * (.82f + .05f * sin(phase * .46f + 1.1f)), h * (.37f + .09f * cos(phase * .62f))),
            Offset(w * (.34f + .09f * sin(phase * .31f + 2.3f)), h * (.79f + .06f * cos(phase * .83f))),
            Offset(w * (.91f + .04f * cos(phase * .51f + 2f)), h * (.91f + .04f * sin(phase * .71f)))
        )
        val radius = max(w, h) * .43f
        for (i in centers.indices) {
            val color = shiftingColor(colourPhase * liquidPalette.size + i * 1.65f)
            val second = shiftingColor(colourPhase * liquidPalette.size + i * 1.65f + 1.7f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(color.copy(alpha = .27f), second.copy(alpha = .11f), Color.Transparent),
                    center = centers[i],
                    radius = radius
                ),
                radius = radius,
                center = centers[i]
            )
        }
        // Scattered translucent cells let the liquid colour breathe through every glass surface.
        for (i in 0 until 9) {
            val orbit = phase * (0.18f + i * .009f) + i * 2.399f
            val x = w * (.5f + .43f * cos(orbit))
            val y = h * (.5f + .47f * sin(orbit * .83f + i * .2f))
            val bubbleRadius = min(w, h) * (.035f + .018f * (1f + sin(orbit * .7f + i)) * .5f)
            val bubble = shiftingColor(colourPhase * liquidPalette.size + i * .74f)
            val bubbleAlt = shiftingColor(colourPhase * liquidPalette.size + i * .74f + 2.0f)
            val bubbleCenter = Offset(x, y)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = .12f), bubble.copy(alpha = .15f), bubbleAlt.copy(alpha = .055f), Color.Transparent),
                    center = Offset(x - bubbleRadius * .25f, y - bubbleRadius * .32f),
                    radius = bubbleRadius * 1.75f
                ),
                radius = bubbleRadius,
                center = bubbleCenter
            )
            drawCircle(
                color = Color.White.copy(alpha = .075f),
                radius = bubbleRadius * .98f,
                center = bubbleCenter,
                style = Stroke(width = max(1f, bubbleRadius * .025f))
            )
        }
        // Faint long-exposure ribbons give the full screen its liquid-glass atmosphere.
        drawArc(
            brush = Brush.sweepGradient(listOf(Color.Transparent, Color(0xFF9D82FF).copy(alpha = .12f), Color(0xFF70D7F5).copy(alpha = .10f), Color.Transparent)),
            startAngle = 190f + phase * 8f,
            sweepAngle = 155f,
            useCenter = false,
            topLeft = Offset(w * .08f, h * .18f),
            size = Size(w * .92f, h * .58f),
            style = Stroke(width = max(1f, w * .006f))
        )
    }
}

@Composable
private fun FluidOrb(modifier: Modifier = Modifier, animated: Boolean) {
    val transition = rememberInfiniteTransition(label = "siri-liquid-bubble-orb")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 18500, easing = LinearEasing)),
        label = "bubble-drift"
    )
    val colour by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 23000, easing = LinearEasing)),
        label = "bubble-gradient-cycle"
    )
    val breathe by transition.animateFloat(
        initialValue = .94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 4700, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse),
        label = "bubble-breath"
    )
    val phase = if (animated) drift else 0f
    val hue = if (animated) colour else .16f
    val pulse = if (animated) breathe else 1f

    Canvas(modifier) {
        val d = min(size.width, size.height)
        if (d <= 0f) return@Canvas
        val center = Offset(size.width / 2f, size.height / 2f)
        val glowA = shiftingColor(hue * liquidPalette.size + .5f)
        val glowB = shiftingColor(hue * liquidPalette.size + 3.2f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(glowA.copy(alpha = .36f), glowB.copy(alpha = .18f), Color.Transparent),
                center = center,
                radius = d * .56f
            ),
            radius = d * .56f,
            center = center
        )

        // A soft connected core makes the individual gel cells read as one fluid organism.
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = .24f), glowA.copy(alpha = .42f), glowB.copy(alpha = .20f), Color.Transparent),
                center = Offset(center.x - d * .08f, center.y - d * .10f),
                radius = d * .48f
            ),
            topLeft = Offset(center.x - d * .34f, center.y - d * .29f),
            size = Size(d * .68f, d * .58f)
        )

        for (i in 0 until 5) {
            val phaseOffset = i * (2f * PI.toFloat() / 5f)
            val angle = phase * (if (i % 2 == 0) .68f else .83f) + phaseOffset
            val orbitX = d * (.145f + .018f * sin(phase * .47f + i))
            val orbitY = d * (.13f + .018f * cos(phase * .39f + i * .6f))
            val x = center.x + cos(angle) * orbitX
            val y = center.y + sin(angle * .88f + i * .17f) * orbitY
            val radius = d * (.185f + .025f * sin(phase * .72f + i * 1.3f)) * pulse
            val c1 = shiftingColor(hue * liquidPalette.size + i * .93f + phase * .07f)
            val c2 = shiftingColor(hue * liquidPalette.size + i * .93f + 1.75f + phase * .04f)
            val bubbleCenter = Offset(x, y)

            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c1.copy(alpha = .21f), c2.copy(alpha = .10f), Color.Transparent),
                    center = bubbleCenter,
                    radius = radius * 1.72f
                ),
                radius = radius * 1.72f,
                center = bubbleCenter
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = .76f),
                        c1.copy(alpha = .91f),
                        c2.copy(alpha = .73f),
                        Color(0xFF4588E8).copy(alpha = .40f),
                        Color.Transparent
                    ),
                    center = Offset(x - radius * .31f, y - radius * .37f),
                    radius = radius * 1.28f
                ),
                radius = radius,
                center = bubbleCenter
            )
            drawCircle(
                color = Color.White.copy(alpha = .28f),
                radius = radius * .985f,
                center = bubbleCenter,
                style = Stroke(width = (d * .004f).coerceAtLeast(1f))
            )
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = .42f), Color.White.copy(alpha = .10f), Color.Transparent),
                    center = Offset(x - radius * .30f, y - radius * .36f),
                    radius = radius * .64f
                ),
                topLeft = Offset(x - radius * .55f, y - radius * .63f),
                size = Size(radius * .98f, radius * .56f)
            )
        }
        drawArc(
            color = Color.White.copy(alpha = .20f),
            startAngle = 198f + phase * 12f,
            sweepAngle = 112f,
            useCenter = false,
            topLeft = Offset(center.x - d * .44f, center.y - d * .43f),
            size = Size(d * .88f, d * .84f),
            style = Stroke(width = max(1f, d * .006f))
        )
    }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    radius: androidx.compose.ui.unit.Dp = 25.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier = modifier
            .shadow(17.dp, shape, clip = false)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = .135f),
                        Color.White.copy(alpha = .055f),
                        Color(0xFF9F83E8).copy(alpha = .065f),
                        Color(0xFF10111D).copy(alpha = .52f)
                    )
                )
            )
            .border(
                BorderStroke(
                    1.dp,
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = .48f),
                            Color(0xFFBFA7FF).copy(alpha = .29f),
                            Color.White.copy(alpha = .065f),
                            Color(0xFF86E1F7).copy(alpha = .24f)
                        )
                    )
                ),
                shape
            )
    ) {
        Canvas(Modifier.matchParentSize()) {
            val corner = CornerRadius(radius.toPx())
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = .115f), Color.White.copy(alpha = .025f), Color.Transparent),
                    startY = 0f,
                    endY = size.height * .52f
                ),
                cornerRadius = corner,
                size = size
            )
            drawRoundRect(
                color = Color.White.copy(alpha = .055f),
                topLeft = Offset(1.dp.toPx(), 1.dp.toPx()),
                size = Size((size.width - 2.dp.toPx()).coerceAtLeast(0f), (size.height - 2.dp.toPx()).coerceAtLeast(0f)),
                cornerRadius = CornerRadius((radius - 1.dp).toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
            drawLine(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = .24f), Color.Transparent)),
                start = Offset(size.width * .14f, 1.dp.toPx()),
                end = Offset(size.width * .86f, 1.dp.toPx()),
                strokeWidth = 1.dp.toPx()
            )
        }
        content()
    }
}

@Composable
private fun HeaderBar(onSettings: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().height(62.dp), radius = 22.dp) {
        Row(
            Modifier.fillMaxSize().padding(start = 14.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFFDCC5FF).copy(alpha = .28f), Color(0xFF74DBF0).copy(alpha = .17f)))).border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Radio, null, tint = Color(0xFFE6D5FF), modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("RADIO CHERRY", color = Color(0xFFF8F3FF), fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp, fontSize = 14.sp)
                Text("SOUND IN A DIFFERENT LIGHT", color = Color(0xFFB7ADC8), fontSize = 8.sp, letterSpacing = 1.25.sp)
            }
            Spacer(Modifier.weight(1f))
            GlassIconButton(Icons.Default.Settings, "Settings", onSettings, size = 42.dp)
        }
    }
}

@Composable
private fun HeroGlassPanel(motionEnabled: Boolean) {
    GlassPanel(Modifier.fillMaxWidth().height(164.dp), radius = 27.dp) {
        Box(Modifier.fillMaxSize()) {
            // The colour field and bubble mass intentionally span the hero, rather than sitting in a small badge.
            FluidOrb(Modifier.align(Alignment.CenterEnd).offset(x = 13.dp).size(218.dp).alpha(.88f), animated = motionEnabled)
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF090A13).copy(alpha = .20f), Color.Transparent, Color.Transparent))))
            Column(
                Modifier.align(Alignment.CenterStart).fillMaxWidth(.66f).padding(start = 19.dp, top = 14.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("A LITTLE MORE WONDER", color = Color(0xFFE2CEFF), fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp, fontSize = 9.sp)
                Spacer(Modifier.height(9.dp))
                Text("Let sound\nsurround you.", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 25.sp, lineHeight = 28.sp, letterSpacing = (-.5).sp)
                Spacer(Modifier.height(8.dp))
                Text("Independent music radio,\nfrom ambient to orchestral.", color = Color(0xFFC4BBD2), fontSize = 10.sp, lineHeight = 15.sp)
            }
            Box(Modifier.align(Alignment.BottomStart).padding(start = 19.dp, bottom = 10.dp).width(62.dp).height(2.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(Color(0xFFBFA4FF), Color(0xFF72D9F1), Color.Transparent))))
        }
    }
}

@Composable
private fun GlassSearchField(value: String, onValueChange: (String) -> Unit, onClear: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().height(55.dp), radius = 19.dp) {
        Row(Modifier.fillMaxSize().padding(horizontal = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Color(0xFFD4C2F4), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(11.dp))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = TextStyle(color = Color(0xFFF5F0FF), fontSize = 13.sp),
                cursorBrush = SolidColor(Color(0xFFD9BBFF)),
                decorationBox = { innerTextField ->
                    Box {
                        if (value.isEmpty()) Text("Search music, stations or moods", color = Color(0xFFAAA2B9), fontSize = 13.sp)
                        innerTextField()
                    }
                }
            )
            if (value.isNotEmpty()) {
                GlassIconButton(Icons.Default.Close, "Clear search", onClear, size = 30.dp)
            }
        }
    }
}

@Composable
private fun GlassChip(label: String, selected: Boolean, onClick: () -> Unit, compact: Boolean = false) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .94f else 1f,
        animationSpec = spring(dampingRatio = .58f, stiffness = 650f),
        label = "glass-chip-press"
    )
    val shape = CircleShape
    Box(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(Color(0xFFA78BFA).copy(alpha = .35f), Color(0xFF69CBEA).copy(alpha = .19f)))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = .10f), Color.White.copy(alpha = .035f)))
            )
            .border(1.dp, if (selected) Brush.linearGradient(listOf(Color.White.copy(alpha = .58f), Color(0xFFBDA7FF).copy(alpha = .45f), Color(0xFF78DDF0).copy(alpha = .32f))) else Brush.linearGradient(listOf(Color.White.copy(alpha = .23f), Color.White.copy(alpha = .055f))), shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = if (compact) 13.dp else 14.dp, vertical = if (compact) 8.dp else 9.dp)
    ) {
        Text(label, color = if (selected) Color(0xFFFFFAFF) else Color(0xFFC2B9D0), fontSize = if (compact) 10.sp else 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
    }
}

@Composable
private fun GlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp = 44.dp,
    tint: Color = Color(0xFFE7D8FF),
    enabled: Boolean = true
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .86f else 1f,
        animationSpec = spring(dampingRatio = .48f, stiffness = 700f),
        label = "glass-button-press"
    )
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color.White.copy(alpha = if (pressed) .24f else .15f), Color(0xFF9F84E8).copy(alpha = .10f), Color.White.copy(alpha = .035f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .38f), Color(0xFFBBA4FF).copy(alpha = .18f), Color.White.copy(alpha = .05f))), CircleShape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = if (enabled) tint else tint.copy(alpha = .35f), modifier = Modifier.size(size * .47f))
    }
}

@Composable
private fun StationCard(
    station: Station,
    active: Boolean,
    favorite: Boolean,
    motionEnabled: Boolean,
    onFavorite: () -> Unit,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .978f else 1f,
        animationSpec = spring(dampingRatio = .54f, stiffness = 620f),
        label = "station-glass-press"
    )
    val shape = RoundedCornerShape(21.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (active) 16.dp else 9.dp, shape, clip = false)
            .clip(shape)
            .background(
                if (active) Brush.linearGradient(listOf(Color(0xFFBBA3FF).copy(alpha = .22f), Color(0xFF70D8ED).copy(alpha = .10f), Color.White.copy(alpha = .055f)))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = .105f), Color.White.copy(alpha = .035f), Color(0xFF9D83D7).copy(alpha = .035f)))
            )
            .border(
                BorderStroke(
                    1.dp,
                    if (active) Brush.linearGradient(listOf(Color.White.copy(alpha = .62f), Color(0xFFB8A1FF).copy(alpha = .48f), Color(0xFF72DDF0).copy(alpha = .30f)))
                    else Brush.linearGradient(listOf(Color.White.copy(alpha = .31f), Color.White.copy(alpha = .055f), Color(0xFF9A8AC6).copy(alpha = .13f)))
                ),
                shape
            )
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = .09f), Color.Transparent, Color.Black.copy(alpha = .10f))),
                cornerRadius = CornerRadius(21.dp.toPx()),
                size = size
            )
            if (active) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0xFFB79CFF).copy(alpha = .19f), Color.Transparent)),
                    radius = size.height * .86f,
                    center = Offset(size.width * .08f, size.height * .46f)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(49.dp).clip(RoundedCornerShape(15.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .17f), Color(0xFF8A75C6).copy(alpha = .10f))))
                    .border(1.dp, Color.White.copy(alpha = .17f), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (active && motionEnabled) FluidOrb(Modifier.size(57.dp), animated = true)
                else Icon(if (station.category.contains("Classical")) Icons.Default.GraphicEq else Icons.Default.Radio, null, tint = Color(0xFFD2BFFF), modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(station.name, color = Color(0xFFF8F4FF), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (active) {
                        Spacer(Modifier.width(7.dp))
                        Text("ON AIR", color = Color(0xFFBCEDEB), fontWeight = FontWeight.Bold, fontSize = 7.sp, letterSpacing = 1.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("${station.genre}  ·  ${station.broadcaster}", color = Color(0xFFBDB4CB), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            GlassIconButton(
                icon = if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (favorite) "Remove favourite" else "Add favourite",
                onClick = onFavorite,
                size = 36.dp,
                tint = if (favorite) Color(0xFFFFB6DF) else Color(0xFFD4C9E6)
            )
        }
    }
}

@Composable
private fun BottomMiniPlayer(
    station: Station?,
    isPlaying: Boolean,
    status: String,
    motionEnabled: Boolean,
    onPlayPause: () -> Unit,
    onStop: () -> Unit
) {
    GlassPanel(Modifier.fillMaxWidth().heightIn(min = 86.dp), radius = 25.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(61.dp).clip(RoundedCornerShape(19.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .13f), Color(0xFF8D73CE).copy(alpha = .10f))))
                    .border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(19.dp)),
                contentAlignment = Alignment.Center
            ) {
                FluidOrb(Modifier.size(62.dp), animated = motionEnabled && isPlaying)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("NOW PLAYING", color = Color(0xFFE1CFFF), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.55.sp)
                Spacer(Modifier.height(3.dp))
                Text(station?.name ?: "Radio Cherry", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (station == null) "Choose a frequency" else if (isPlaying) "${station.genre}  ·  LIVE" else status,
                    color = Color(0xFFBDB4CA), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            GlassIconButton(
                icon = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                onClick = onPlayPause,
                size = 43.dp,
                enabled = station != null,
                tint = Color(0xFFE6D5FF)
            )
            Spacer(Modifier.width(5.dp))
            GlassIconButton(
                icon = Icons.Default.Stop,
                contentDescription = "Stop playback",
                onClick = onStop,
                size = 38.dp,
                enabled = station != null,
                tint = Color(0xFFC4B9D4)
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    motionEnabled: Boolean,
    onMotionChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = true)
    ) {
        GlassPanel(Modifier.fillMaxWidth(), radius = 29.dp) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("APPEARANCE", color = Color(0xFFDCC5FF), fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 2.sp)
                    Text("Make it move.", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Tune the atmosphere of Radio Cherry.", color = Color(0xFFC0B8CE), fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Liquid glass motion", color = Color(0xFFF8F3FF), fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        Text("Animate the shifting Siri-style bubbles and colour fields across the whole app.", fontSize = 11.sp, color = Color(0xFFC0B8CE), lineHeight = 16.sp)
                    }
                    Switch(
                        checked = motionEnabled,
                        onCheckedChange = onMotionChange,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF171222),
                            checkedTrackColor = Color(0xFFC6A8FF),
                            uncheckedThumbColor = Color(0xFFB8AFC4),
                            uncheckedTrackColor = Color.White.copy(alpha = .15f)
                        )
                    )
                }
                Text("Android's native notification and lock-screen media cards use static artwork. The in-app bubbles remain animated and follow this setting.", fontSize = 10.sp, color = Color(0xFFAAA1BB), lineHeight = 15.sp)
                GlassChip(label = "Done", selected = true, onClick = onDismiss)
            }
        }
    }
}
