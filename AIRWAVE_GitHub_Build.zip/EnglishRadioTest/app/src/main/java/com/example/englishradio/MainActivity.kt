package com.example.englishradio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

data class Station(val name: String, val genre: String, val location: String, val stream: String)

private val stations = listOf(
    Station("Groove Salad", "Ambient · Downtempo", "SomaFM · USA", "https://ice.somafm.com/groovesalad"),
    Station("Drone Zone", "Atmospheric · Ambient", "SomaFM · USA", "https://ice.somafm.com/dronezone"),
    Station("Indie Pop Rocks!", "Indie · Alternative", "SomaFM · USA", "https://ice.somafm.com/indiepop"),
    Station("Lush", "Mellow · Electronic", "SomaFM · USA", "https://ice.somafm.com/lush"),
    Station("Underground 80s", "80s · New Wave", "SomaFM · USA", "https://ice.somafm.com/u80s"),
    Station("Left Coast 70s", "Classic · Album Rock", "SomaFM · USA", "https://ice.somafm.com/seventies"),
    Station("Folk Forward", "Folk · Americana", "SomaFM · USA", "https://ice.somafm.com/folkfwd"),
)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent { RadioApp(player) }
    }
    override fun onStop() { super.onStop(); player.pause() }
    override fun onDestroy() { player.release(); super.onDestroy() }
}

@Composable
fun RadioApp(player: ExoPlayer) {
    var selected by remember { mutableStateOf<Station?>(null) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Choose a station to start listening") }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
                if (isPlaying) status = "Playing live"
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                status = when (playbackState) {
                    Player.STATE_BUFFERING -> "Connecting to station…"
                    Player.STATE_READY -> if (player.isPlaying) "Playing live" else "Ready"
                    Player.STATE_ENDED -> "Stream ended"
                    else -> status
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                status = "Stream unavailable — try another station"
                playing = false
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    val bg = Color(0xFF0A1014)
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFB7F397), background = bg, surface = Color(0xFF151F24),
        onBackground = Color(0xFFEAF1EC), onSurface = Color(0xFFEAF1EC)
    )) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1A302B), bg, bg))).padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(34.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Radio, null, tint = Color(0xFFB7F397), modifier = Modifier.size(25.dp))
                Spacer(Modifier.width(9.dp))
                Text("AIRWAVE", color = Color(0xFFB7F397), fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Spacer(Modifier.weight(1f))
                Text("TEST BUILD 01", color = Color(0xFF8A9A94), fontSize = 10.sp, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(30.dp))
            Text("Radio,\nwithout borders.", fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text("A handpicked selection of free English-language radio.", color = Color(0xFF9BAAA4), fontSize = 13.sp)
            Spacer(Modifier.height(24.dp))
            Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFF1B2928), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("NOW TUNED TO", color = Color(0xFF9BAAA4), fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(10.dp))
                    Text(selected?.name ?: "Nothing playing yet", fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                    Text(if (selected == null) status else "${selected!!.genre}  ·  $status", color = Color(0xFFB7C4BE), fontSize = 12.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(50), color = Color(0xFFB7F397), modifier = Modifier.size(52.dp).clickable {
                            if (player.isPlaying) player.pause()
                            else if (player.mediaItemCount > 0) player.play()
                            else selected?.let { s -> player.setMediaItem(MediaItem.fromUri(s.stream)); player.prepare(); player.play() }
                        }) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color(0xFF102017), modifier = Modifier.size(30.dp))
                            }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text(if (playing) "LIVE STREAM" else "READY TO PLAY", color = Color(0xFFB7F397), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(selected?.location ?: "Select a station below", color = Color(0xFF9BAAA4), fontSize = 11.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(25.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("STATIONS", fontSize = 11.sp, letterSpacing = 2.sp, color = Color(0xFFB7F397), fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("${stations.size} FREE CHANNELS", fontSize = 10.sp, color = Color(0xFF8A9A94))
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(stations) { station ->
                    val active = selected == station
                    Surface(
                        color = if (active) Color(0xFF263A33) else Color(0xFF141E22),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth().clickable {
                            selected = station
                            status = "Connecting…"
                            player.setMediaItem(MediaItem.fromUri(station.stream))
                            player.prepare()
                            player.play()
                        }
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(40.dp).background(Color(0xFF26352F), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Radio, null, tint = Color(0xFFB7F397))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(station.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text(station.genre + "  ·  " + station.location, color = Color(0xFF91A19A), fontSize = 10.sp)
                            }
                            if (active && playing) Text("LIVE", color = Color(0xFFB7F397), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
