package com.example.englishradio

import android.content.ComponentName
import android.media.audiofx.Visualizer
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.SystemBarStyle
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.pow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val stations = listOf(
    Station("groove-salad", "Groove Salad", "Ambient · Downtempo", "SomaFM", "https://ice5.somafm.com/groovesalad-128-mp3", "https://ice.somafm.com/groovesalad", "Chill"),
    Station("lush", "Lush", "Mellow · Electronic", "SomaFM", "https://ice5.somafm.com/lush-128-mp3", "https://ice.somafm.com/lush", "Chill"),
    Station("indie-pop", "Indie Pop Rocks!", "Indie · Alternative", "SomaFM", "https://ice5.somafm.com/indiepop-128-mp3", "https://ice.somafm.com/indiepop", "Indie"),
    Station("underground-80s", "Underground 80s", "80s · New Wave", "SomaFM", "https://ice5.somafm.com/u80s-128-mp3", "https://ice.somafm.com/u80s", "Throwbacks"),
    Station("left-coast-70s", "Left Coast 70s", "Classic · Album Rock", "SomaFM", "https://ice5.somafm.com/seventies-128-mp3", "https://ice.somafm.com/seventies", "Throwbacks"),
    Station("folk-forward", "Folk Forward", "Folk · Americana", "SomaFM", "https://ice5.somafm.com/folkfwd-128-mp3", "https://ice.somafm.com/folkfwd", "Acoustic"),
    Station("drone-zone", "Drone Zone", "Atmospheric · Ambient", "SomaFM", "https://ice5.somafm.com/dronezone-128-mp3", "https://ice.somafm.com/dronezone", "Chill"),
    Station("secret-agent", "Secret Agent", "Spy · Soundtracks", "SomaFM", "https://ice5.somafm.com/secretagent-128-mp3", "https://ice.somafm.com/secretagent", "Discovery"),
    Station("mission-control", "Mission Control", "Space · Ambient", "SomaFM", "https://ice5.somafm.com/missioncontrol-128-mp3", "https://ice.somafm.com/missioncontrol", "Chill"),
    Station("space-station", "Space Station Soma", "Space · Electronic", "SomaFM", "https://ice5.somafm.com/spacestation-128-mp3", "https://ice.somafm.com/spacestation", "Chill"),
    Station("beat-blender", "Beat Blender", "Deep · House", "SomaFM", "https://ice5.somafm.com/beatblender-128-mp3", "https://ice.somafm.com/beatblender", "Electronic"),
    Station("poptron", "PopTron", "Indie · Pop", "SomaFM", "https://ice5.somafm.com/poptron-128-mp3", "https://ice.somafm.com/poptron", "Indie"),
    Station("sonic-universe", "Sonic Universe", "Modern · Jazz", "SomaFM", "https://ice5.somafm.com/sonicuniverse-128-mp3", "https://ice.somafm.com/sonicuniverse", "Jazz"),
    Station("suburbs-of-goa", "Suburbs of Goa", "Psychedelic · Indian", "SomaFM", "https://ice5.somafm.com/suburbsofgoa-128-mp3", "https://ice.somafm.com/suburbsofgoa", "World"),
    Station("defcon", "DEF CON Radio", "Electronic · Hacker culture", "SomaFM", "https://ice5.somafm.com/defcon-128-mp3", "https://ice.somafm.com/defcon", "Electronic"),
    Station("radio-paradise-main", "Radio Paradise · Main Mix", "Eclectic · Alternative", "Radio Paradise", "https://stream.radioparadise.com/mp3-128", null, "Indie", region = "USA"),
    Station("radio-paradise-mellow", "Radio Paradise · Mellow Mix", "Mellow · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/mellow-128", null, "Chill", region = "USA"),
    Station("radio-paradise-rock", "Radio Paradise · Rock Mix", "Alternative · Rock", "Radio Paradise", "https://stream.radioparadise.com/rock-128", null, "Indie", region = "USA"),
    Station("radio-paradise-global", "Radio Paradise · Global Mix", "World · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/eclectic-128", null, "World", region = "USA"),
    Station("kexp", "KEXP 90.3", "Alternative · Discovery", "KEXP", "https://kexp.streamguys1.com/kexp160.aac", "https://kexp.streamguys1.com/kexp64.aac", "Indie", region = "Seattle"),
    Station("swiss-classic", "Radio Swiss Classic", "Western classical · Instrumental", "Switzerland", "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128", null, "Classical", region = "Switzerland"),
    Station("wcrb", "WCRB Classical", "Symphonic · Chamber · Opera", "CRB · Boston", "https://wgbh-live.streamguys1.com/classical-hi/", null, "Classical", region = "Boston"),
    Station("kusc", "Classical KUSC", "Orchestral · Classical favourites", "Classical California", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3", null, "Classical", region = "Los Angeles"),
    Station("air-raagam", "AIR Raagam", "Hindustani · Carnatic", "Akashvani · India", "https://airhlspush.pc.cdn.bitgravity.com/httppush/hlspbaudioragam/hlspbaudioragam64kbps.m3u8", null, "Indian Classical", region = "India")
) + importedStations

data class Station(
    val id: String,
    val name: String,
    val genre: String,
    val broadcaster: String,
    val stream: String,
    val fallback: String?,
    val category: String,
    val region: String = "USA"
)

private val liquidPalette = listOf(
    Color(0xFFFF78D4), Color(0xFFC27BFF), Color(0xFF7E8BFF),
    Color(0xFF25AFFF), Color(0xFF43DCDD), Color(0xFF62E6BA),
    Color(0xFFFFB2E9)
)

private fun colorBlend(a: Color, b: Color, fraction: Float): Color {
    val t = fraction.coerceIn(0f, 1f)
    return Color(
        red = a.red + (b.red - a.red) * t,
        green = a.green + (b.green - a.green) * t,
        blue = a.blue + (b.blue - a.blue) * t,
        alpha = a.alpha + (b.alpha - a.alpha) * t
    )
}

private fun shiftingColor(index: Float): Color {
    val base = floor(index).toInt()
    val fraction = index - floor(index)
    val first = ((base % liquidPalette.size) + liquidPalette.size) % liquidPalette.size
    val second = (first + 1) % liquidPalette.size
    return colorBlend(liquidPalette[first], liquidPalette[second], fraction)
}

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                runCatching { future.get() }.onSuccess { controller = it }
            }, ContextCompat.getMainExecutor(this))
        }
        setContent { RadioCherryApp(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun RadioCherryApp(player: MediaController?) {
    val context = LocalContext.current
    var audioPermissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val audioPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        audioPermissionGranted = granted
    }
    var audioWaveform by remember { mutableStateOf(FloatArray(96) { 0.04f }) }
    var audioLevel by remember { mutableFloatStateOf(0.08f) }
    val preferences = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", android.content.Context.MODE_PRIVATE)
    }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackStatus by remember { mutableStateOf("Choose a station to begin") }
    var search by remember { mutableStateOf("") }
    var showFavorites by remember { mutableStateOf(false) }
    var activeCategory by remember { mutableStateOf("All") }
    var showSettings by remember { mutableStateOf(false) }
    var favorites by remember {
        mutableStateOf(preferences.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    var orbMotionEnabled by remember {
        mutableStateOf(preferences.getBoolean("orb_motion_enabled", true))
    }
    val playbackScope = rememberCoroutineScope()
    var playlistResolveJob by remember { mutableStateOf<Job?>(null) }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }

    LaunchedEffect(selectedId, isPlaying, audioPermissionGranted) {
        audioWaveform = FloatArray(96) { 0.035f }
        audioLevel = 0.06f
        val sessionId = PlaybackService.currentAudioSessionId
        if (!audioPermissionGranted || !isPlaying || sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    val values = FloatArray(96) { i ->
                        val index = (i * (bytes.size - 1) / 95).coerceIn(0, bytes.lastIndex)
                        kotlin.math.abs((bytes[index].toInt() and 0xFF) - 128) / 128f
                    }
                    audioWaveform = values
                    audioLevel = (values.sum() / values.size).coerceIn(0.03f, 0.95f)
                }
                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) = Unit
            }, Visualizer.getMaxCaptureRate() / 2, true, false)
            visualizer.enabled = true
        } catch (_: Throwable) {
            runCatching { visualizer.release() }
            return@LaunchedEffect
        }
        try {
            kotlinx.coroutines.awaitCancellation()
        } finally {
            runCatching { visualizer.enabled = false }
            runCatching { visualizer.release() }
        }
    }

    LaunchedEffect(favorites) {
        preferences.edit().putStringSet("favorite_station_ids", favorites).apply()
    }
    LaunchedEffect(orbMotionEnabled) {
        preferences.edit().putBoolean("orb_motion_enabled", orbMotionEnabled).apply()
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                playbackStatus = if (playing) "Playing live" else if (player.mediaItemCount > 0) "Paused" else "Choose a station"
            }
            override fun onPlaybackStateChanged(state: Int) {
                playbackStatus = when (state) {
                    Player.STATE_BUFFERING -> "Connecting to station…"
                    Player.STATE_READY -> if (player.isPlaying) "Playing live" else "Ready to play"
                    Player.STATE_ENDED -> "Stream ended"
                    Player.STATE_IDLE -> if (player.mediaItemCount == 0) "Choose a station" else "Stopped"
                    else -> playbackStatus
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isPlaying = false
                playbackStatus = "Stream unavailable · ${error.errorCodeName}"
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
                if (mediaItem == null) isPlaying = false
            }
        }
        player.addListener(listener)
        isPlaying = player.isPlaying
        selectedId = player.currentMediaItem?.mediaId
        onDispose { player.removeListener(listener) }
    }

    val selected = stations.firstOrNull { it.id == selectedId }
    val categories = listOf("All") + stations.map { it.category }.distinct().sorted()
    val visibleStations = stations.filter { station ->
        (search.isBlank() || (station.name + station.genre + station.category + station.broadcaster).contains(search, true)) &&
            (!showFavorites || station.id in favorites) &&
            (activeCategory == "All" || station.category == activeCategory)
    }

    fun playStation(station: Station) {
        if (!audioPermissionGranted) audioPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        val activePlayer = player ?: return
        playlistResolveJob?.cancel()
        selectedId = station.id
        val requiresPlaylistResolution = PlaylistResolver.isPlaylistUrl(station.stream)
        playbackStatus = if (requiresPlaylistResolution) "Opening station playlist…" else "Connecting to station…"
        playlistResolveJob = playbackScope.launch {
            val resolvedUrl = runCatching {
                withContext(Dispatchers.IO) { PlaylistResolver.resolve(station.stream) }
            }.getOrElse { station.stream }
            if (selectedId != station.id) return@launch
            val resolvedStation = station.copy(stream = resolvedUrl, fallback = station.fallback)
            activePlayer.setMediaItem(PlaybackService.mediaItem(resolvedStation, orbArtwork))
            activePlayer.prepare()
            activePlayer.play()
        }
    }

    fun togglePlayback() {
        if (player == null) return
        if (player.isPlaying) {
            player.pause()
        } else if (player.mediaItemCount > 0) {
            player.play()
        } else {
            selected?.let { playStation(it) }
        }
    }

    fun stopPlayback() {
        playlistResolveJob?.cancel()
        playlistResolveJob = null
        player?.let {
            it.pause()
            it.clearMediaItems()
        }
        selectedId = null
        isPlaying = false
        playbackStatus = "Playback stopped"
    }


    var activeTab by remember { mutableStateOf("now playing") }
    var darkMode by remember { mutableStateOf(true) }
    val background = if (darkMode) Color(0xFF17191D) else Color(0xFFFAFAFA)
    val foreground = if (darkMode) Color(0xFFF5F5F5) else Color(0xFF222326)
    val secondary = if (darkMode) Color(0xFFB6B7BC) else Color(0xFF77787D)
    val rowSurface = if (darkMode) Color(0xFF303238) else Color.White
    val line = if (darkMode) Color(0xFF42444A) else Color(0xFFD8D8DA)

    MaterialTheme(
        colorScheme = if (darkMode) darkColorScheme(primary = Color(0xFFBDA2E8), background = background, surface = rowSurface, onSurface = foreground)
                     else lightColorScheme(primary = Color(0xFF8C66B8), background = background, surface = rowSurface, onSurface = foreground)
    ) {
        Box(Modifier.fillMaxSize().background(background)) {
            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
            ) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (activeTab) {
                        "now playing" -> NowPlayingScreen(
                            selected = selected ?: stations.first(),
                            upcoming = stations.filter { it.id != selectedId }.take(3),
                            isPlaying = isPlaying,
                            status = playbackStatus,
                            waveform = audioWaveform,
                            level = audioLevel,
                            darkMode = darkMode,
                            foreground = foreground,
                            secondary = secondary,
                            line = line,
                            onPrevious = {
                                val list = stations
                                val index = list.indexOfFirst { it.id == selectedId }.let { if (it < 0) 0 else it }
                                playStation(list[(index - 1 + list.size) % list.size])
                            },
                            onNext = {
                                val list = stations
                                val index = list.indexOfFirst { it.id == selectedId }.let { if (it < 0) -1 else it }
                                playStation(list[(index + 1) % list.size])
                            },
                            onPlayPause = { togglePlayback() },
                            onSelect = { playStation(it) }
                        )
                        "browse" -> BrowseScreen(
                            stations = visibleStations,
                            favorites = favorites,
                            search = search,
                            onSearch = { search = it },
                            onSelect = { playStation(it); activeTab = "now playing" },
                            foreground = foreground,
                            secondary = secondary,
                            rowSurface = rowSurface,
                            line = line,
                            darkMode = darkMode
                        )
                        else -> FavoritesScreen(
                            stations = stations.filter { it.id in favorites },
                            favorites = favorites,
                            onSelect = { playStation(it); activeTab = "now playing" },
                            onFavorite = { station ->
                                favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
                            },
                            foreground = foreground,
                            secondary = secondary,
                            rowSurface = rowSurface,
                            line = line,
                            darkMode = darkMode
                        )
                    }
                }
                Row(
                    Modifier.fillMaxWidth().height(76.dp)
                        .background(if (darkMode) Color(0xFF202226) else Color.White)
                        .border(BorderStroke(0.6.dp, line)),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("now playing", "browse", "favorites").forEach { item ->
                        val active = activeTab == item
                        Column(
                            Modifier.weight(1f).fillMaxHeight().clickable { activeTab = item },
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                when (item) { "now playing" -> "◉"; "browse" -> "♢"; else -> "♥" },
                                color = if (active) foreground else secondary,
                                fontSize = 25.sp
                            )
                            Spacer(Modifier.height(3.dp))
                            Text(item, color = if (active) foreground else secondary, fontSize = 11.sp,
                                fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal)
                            if (active) Spacer(Modifier.height(2.dp))
                            if (active) Box(Modifier.width(54.dp).height(2.dp).background(foreground))
                        }
                    }
                }
            }
            // A small appearance switch is kept discreetly accessible from the top edge.
            Text(
                if (darkMode) "◐" else "◑",
                modifier = Modifier.align(Alignment.TopEnd).windowInsetsPadding(WindowInsets.statusBars)
                    .padding(end = 20.dp, top = 5.dp).clickable { darkMode = !darkMode },
                color = secondary, fontSize = 18.sp
            )
        }
    }
}

@Composable
private fun ReferenceWaveHeader(
    pageTitle: String,
    darkMode: Boolean,
    modifier: Modifier = Modifier,
    showRadioMark: Boolean = true,
    waveform: FloatArray = FloatArray(96) { 0.08f },
    level: Float = 0.08f
) {
    val waveTransition = rememberInfiniteTransition(label = "reference-wave-motion")
    val wavePhase by waveTransition.animateFloat(0f, (2f * PI).toFloat(),
        infiniteRepeatable(tween(5200, easing = LinearEasing)), label = "reference-wave-phase")
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(20.dp))
        Text(pageTitle, color = if (darkMode) Color(0xFFF4F4F5) else Color(0xFF26262A),
            fontSize = 30.sp, fontWeight = FontWeight.Light, letterSpacing = 8.sp)
        Spacer(Modifier.height(18.dp))
        Canvas(Modifier.fillMaxWidth().height(190.dp)) {
            val w = size.width; val h = size.height
            val colors = listOf(Color(0xFF24D8D2), Color(0xFF3C9BFF), Color(0xFF9A50E8), Color(0xFFE36BCB))
            val centers = listOf(Offset(w*.25f,h*.48f),Offset(w*.52f,h*.48f),Offset(w*.77f,h*.48f))
            centers.forEachIndexed { i, c ->
                val radius = h*.72f
                drawCircle(Brush.radialGradient(listOf(colors[i].copy(alpha=if(darkMode).30f else .25f), colors[i].copy(alpha=.12f), Color.Transparent), c, radius), radius, c)
            }
            val mid = h*.52f
            for (layer in 0 until 11) {
                val path = Path()
                val phase = layer*.045f
                for (i in 0..220) {
                    val x = w*i/220f
                    val t = i/220f
                    val envelope = (0.14f + .86f * (sin(PI*t).toFloat().coerceAtLeast(0f).pow(0.7f)))
                    val sample = waveform[(i * (waveform.size - 1) / 220).coerceIn(0, waveform.lastIndex)].coerceIn(0f, 1f)
                    val fundamental = sin(t.toDouble()*PI*5.0 + wavePhase + phase.toDouble()).toFloat()*(.22f + level.coerceIn(0f, .8f)*.24f)
                    val secondaryWave = sin(t.toDouble()*PI*9.0 + wavePhase*.7 + phase.toDouble()).toFloat()*.055f
                    val audioShape = (sample - .12f).coerceAtLeast(0f) * .10f
                    val y = mid + (fundamental+secondaryWave+audioShape)*h*envelope
                    if (i==0) path.moveTo(x,y) else path.lineTo(x,y)
                }
                drawPath(path, (if(darkMode) Color.White else Color(0xFF24242A)).copy(alpha=if(layer==5).92f else .58f),
                    style=Stroke(width=if(layer==5)1.35.dp.toPx() else .85.dp.toPx()))
            }
        }
        if (showRadioMark) {
            Box(Modifier.size(48.dp).offset(y = (-15).dp).border(1.dp, if(darkMode) Color.White.copy(.8f) else Color(0xFF28282C), CircleShape),
                contentAlignment = Alignment.Center) {
                Text("◉", color = if(darkMode) Color.White else Color(0xFF28282C), fontSize = 20.sp)
            }
        }
    }
}

@Composable
private fun NowPlayingScreen(
    selected: Station, upcoming: List<Station>, isPlaying: Boolean, status: String,
    waveform: FloatArray, level: Float, darkMode: Boolean, foreground: Color, secondary: Color,
    line: Color, onPrevious: () -> Unit, onNext: () -> Unit, onPlayPause: () -> Unit,
    onSelect: (Station) -> Unit
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 38.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        ReferenceWaveHeader("radio", darkMode, showRadioMark = true, waveform = waveform, level = level)
        Spacer(Modifier.height(0.dp))
        Text(selected.name.uppercase(), color = foreground, fontSize = 21.sp, letterSpacing = 5.sp,
            fontWeight = FontWeight.Light, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(18.dp))
        Text("${selected.broadcaster} • LIVE", color = secondary, fontSize = 14.sp, letterSpacing = 1.1.sp)
        Spacer(Modifier.height(40.dp))
        Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape).background(line)) {
            Box(Modifier.fillMaxWidth(.22f).fillMaxHeight().background(foreground))
        }
        Row(Modifier.fillMaxWidth().padding(top=8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("LIVE", color=secondary, fontSize=12.sp)
            Text(status, color=secondary, fontSize=12.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(34.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment=Alignment.CenterVertically) {
            Text("◀", modifier=Modifier.clickable { onPrevious() }.padding(10.dp), color=foreground, fontSize=27.sp)
            Box(Modifier.size(60.dp).border(1.3.dp, foreground, CircleShape).clickable { onPlayPause() }, contentAlignment=Alignment.Center) {
                Text(if(isPlaying) "Ⅱ" else "▶", color=foreground, fontSize=26.sp)
            }
            Text("▶", modifier=Modifier.clickable { onNext() }.padding(10.dp), color=foreground, fontSize=27.sp)
        }
        Spacer(Modifier.height(74.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment=Alignment.CenterStart) {
            Text("up next", color=secondary, fontSize=14.sp, letterSpacing=1.2.sp)
        }
        Spacer(Modifier.height(20.dp))
        upcoming.forEach { station ->
            Row(Modifier.fillMaxWidth().height(74.dp).clickable { onSelect(station) },
                verticalAlignment=Alignment.CenterVertically) {
                Text(station.name.uppercase(), color=foreground, fontSize=14.sp, letterSpacing=1.4.sp,
                    modifier=Modifier.weight(1f), maxLines=1, overflow=TextOverflow.Ellipsis)
                Text(station.category.uppercase(), color=secondary, fontSize=12.sp, letterSpacing=.5.sp)
            }
            Box(Modifier.fillMaxWidth().height(.7.dp).background(line))
        }
    }
}

@Composable
private fun BrowseScreen(
    stations: List<Station>, favorites: Set<String>, search: String, onSearch: (String)->Unit,
    onSelect: (Station)->Unit, foreground: Color, secondary: Color, rowSurface: Color,
    line: Color, darkMode: Boolean
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=30.dp)) {
        ReferenceWaveHeader("browse", darkMode)
        Row(Modifier.fillMaxWidth().clip(CircleShape).background(if(darkMode) Color(0xFF303238) else Color(0xFFEDEDEF)).padding(horizontal=15.dp, vertical=12.dp),
            verticalAlignment=Alignment.CenterVertically) {
            Text("⌕", color=secondary, fontSize=22.sp)
            Spacer(Modifier.width(10.dp))
            BasicTextField(value=search, onValueChange=onSearch, singleLine=true,
                textStyle=TextStyle(color=foreground,fontSize=14.sp),
                decorationBox={ inner -> Box { if(search.isEmpty()) Text("Search stations, podcasts, genres", color=secondary, fontSize=14.sp); inner() } })
        }
        Spacer(Modifier.height(24.dp))
        Text("Stations", color=foreground, fontSize=18.sp)
        Spacer(Modifier.height(14.dp))
        stations.take(3).forEach { station ->
            Row(Modifier.fillMaxWidth().padding(bottom=18.dp).shadow(10.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp)).background(rowSurface).clickable { onSelect(station) }
                .padding(horizontal=22.dp, vertical=20.dp), verticalAlignment=Alignment.CenterVertically) {
                Text("◉", color=secondary, fontSize=23.sp)
                Spacer(Modifier.width(20.dp))
                Column {
                    Text(station.name.uppercase(), color=foreground, fontSize=17.sp, letterSpacing=.7.sp)
                    Spacer(Modifier.height(4.dp))
                    Text("${station.category.uppercase()} • ${station.region}", color=secondary, fontSize=13.sp)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("Genres", color=foreground, fontSize=18.sp)
        Spacer(Modifier.height(28.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceAround) {
            listOf("♫" to "Pop", "♬" to "Klassisk", "▤" to "Nyheter").forEach { (glyph,label) ->
                Column(horizontalAlignment=Alignment.CenterHorizontally) {
                    Text(glyph, color=secondary, fontSize=28.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(label, color=foreground, fontSize=15.sp)
                }
            }
        }
        Spacer(Modifier.height(26.dp))
    }
}

@Composable
private fun FavoritesScreen(
    stations: List<Station>, favorites: Set<String>, onSelect: (Station)->Unit,
    onFavorite: (Station)->Unit, foreground: Color, secondary: Color, rowSurface: Color,
    line: Color, darkMode: Boolean
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=30.dp)) {
        ReferenceWaveHeader("favorites", darkMode, showRadioMark = false)
        Spacer(Modifier.height(6.dp))
        Text("Favorites", color=foreground, fontSize=24.sp, fontWeight=FontWeight.Medium)
        Text("${stations.size} stations • saved", color=secondary, fontSize=14.sp)
        Spacer(Modifier.height(24.dp))
        stations.forEach { station ->
            Row(Modifier.fillMaxWidth().padding(bottom=20.dp).shadow(12.dp, RoundedCornerShape(22.dp))
                .clip(RoundedCornerShape(22.dp)).background(rowSurface).clickable { onSelect(station) }
                .padding(horizontal=20.dp, vertical=21.dp), verticalAlignment=Alignment.CenterVertically) {
                Text("◉", color=secondary, fontSize=22.sp)
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(station.name.uppercase(), color=foreground, fontSize=17.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("${station.category.uppercase()} • ${station.region}", color=secondary, fontSize=13.sp)
                }
                Text("♥", modifier=Modifier.clickable { onFavorite(station) }.padding(6.dp),
                    color=Color(0xFFB97AE8), fontSize=27.sp)
            }
        }
        if (stations.isEmpty()) Text("No saved stations", color=secondary, fontSize=15.sp)
    }
}

@Composable
private fun LiquidAtmosphere(modifier: Modifier = Modifier, motionEnabled: Boolean) {
    if (!motionEnabled) {
        Canvas(modifier) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0B20), Color(0xFF101025), Color(0xFF080A14))))
            val w = size.width
            val h = size.height
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFF7E75E8).copy(alpha = .11f), Color.Transparent)),
                radius = max(w, h) * .56f,
                center = Offset(w * .18f, h * .18f)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFF31CFE0).copy(alpha = .08f), Color.Transparent)),
                radius = max(w, h) * .54f,
                center = Offset(w * .86f, h * .48f)
            )
        }
        return
    }
    val transition = rememberInfiniteTransition(label = "radio-cherry-atmosphere")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 42000, easing = LinearEasing)),
        label = "ambient-drift"
    )
    val hue by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 34000, easing = LinearEasing)),
        label = "ambient-colour"
    )
    val phase = if (motionEnabled) drift else 0f
    val colourPhase = if (motionEnabled) hue else .12f

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0B20), Color(0xFF101025), Color(0xFF080A14))))
        val fields = listOf(
            Triple(Offset(w * (.14f + .035f * cos(phase * .62f)), h * (.17f + .035f * sin(phase * .47f))), .58f, .18f),
            Triple(Offset(w * (.86f + .04f * sin(phase * .39f + 1.2f)), h * (.43f + .065f * cos(phase * .51f))),  .52f, .15f),
            Triple(Offset(w * (.38f + .07f * sin(phase * .28f + 2.1f)), h * (.86f + .035f * cos(phase * .71f))), .62f, .13f)
        )
        fields.forEachIndexed { index, field ->
            val colourA = shiftingColor(colourPhase * liquidPalette.size + index * 1.8f)
            val colourB = shiftingColor(colourPhase * liquidPalette.size + index * 1.8f + 2.1f)
            val radius = max(w, h) * field.second
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(colourA.copy(alpha = field.third), colourB.copy(alpha = field.third * .48f), Color.Transparent),
                    center = field.first,
                    radius = radius
                ),
                radius = radius,
                center = field.first
            )
        }
        // A low-contrast atmospheric sheen: light, not decorative particles.
        drawRect(
            brush = Brush.horizontalGradient(
                listOf(Color(0xFFB38BFF).copy(alpha = .025f), Color.Transparent, Color(0xFF4DE4E2).copy(alpha = .025f))
            )
        )
    }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    radius: androidx.compose.ui.unit.Dp = 25.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier = modifier
            .shadow(11.dp, shape, clip = false)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = .075f),
                        Color.White.copy(alpha = .028f),
                        Color(0xFF9F83E8).copy(alpha = .038f),
                        Color(0xFF10111D).copy(alpha = .30f)
                    )
                )
            )
            .border(
                BorderStroke(
                    1.dp,
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = .23f),
                            Color(0xFFBFA7FF).copy(alpha = .13f),
                            Color.White.copy(alpha = .025f),
                            Color(0xFF86E1F7).copy(alpha = .10f)
                        )
                    )
                ),
                shape
            )
    ) {
        Canvas(Modifier.matchParentSize()) {
            val corner = CornerRadius(radius.toPx())
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = .075f), Color.White.copy(alpha = .018f), Color.Transparent),
                    startY = 0f,
                    endY = size.height * .52f
                ),
                cornerRadius = corner,
                size = size
            )
            drawRoundRect(
                color = Color.White.copy(alpha = .035f),
                topLeft = Offset(1.dp.toPx(), 1.dp.toPx()),
                size = Size((size.width - 2.dp.toPx()).coerceAtLeast(0f), (size.height - 2.dp.toPx()).coerceAtLeast(0f)),
                cornerRadius = CornerRadius((radius - 1.dp).toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
            drawLine(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = .14f), Color.Transparent)),
                start = Offset(size.width * .14f, 1.dp.toPx()),
                end = Offset(size.width * .86f, 1.dp.toPx()),
                strokeWidth = 1.dp.toPx()
            )
        }
        content()
    }
}

@Composable
private fun HeaderBar(onSettings: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().height(62.dp), radius = 22.dp) {
        Row(
            Modifier.fillMaxSize().padding(start = 14.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFFDCC5FF).copy(alpha = .28f), Color(0xFF74DBF0).copy(alpha = .17f)))).border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Radio, null, tint = Color(0xFFE6D5FF), modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("RADIO CHERRY", color = Color(0xFFF8F3FF), fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp, fontSize = 14.sp)
                Text("SOUND IN A DIFFERENT LIGHT", color = Color(0xFFB7ADC8), fontSize = 8.sp, letterSpacing = 1.25.sp)
            }
            Spacer(Modifier.weight(1f))
            GlassIconButton(Icons.Default.Settings, "Settings", onSettings, size = 42.dp)
        }
    }
}

@Composable
private fun AudioVisualizerHero(waveform: FloatArray, level: Float, playing: Boolean) {
    GlassPanel(Modifier.fillMaxWidth().height(174.dp), radius = 27.dp) {
        Box(Modifier.fillMaxSize()) {
            AudioWaveCanvas(Modifier.fillMaxSize(), waveform, level, playing, darkBackdrop = false)
            Text("b r o w s e", modifier = Modifier.align(Alignment.TopCenter).padding(top = 13.dp), color = Color(0xFFF4ECFF), fontSize = 16.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp)
            Text("LIVE SOUND · CURATED RADIO", modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp), color = Color(0xFFC9BEDA), fontSize = 8.sp, letterSpacing = 1.8.sp)
        }
    }
}

@Composable
private fun AudioPulseField(modifier: Modifier, level: Float, enabled: Boolean) {
    val transition = rememberInfiniteTransition(label = "music-pulse-field")
    val phase by transition.animateFloat(0f, (2f * PI).toFloat(), infiniteRepeatable(tween(5200, easing = LinearEasing)), label = "pulse-phase")
    Canvas(modifier) {
        val energy = if (enabled) level.coerceIn(.03f, .9f) else .07f
        val blobs = listOf(
            Triple(.18f, .25f, Color(0xFF21D8D0)),
            Triple(.78f, .32f, Color(0xFFB44DFF)),
            Triple(.53f, .70f, Color(0xFF477BFF)),
            Triple(.12f, .78f, Color(0xFF8B5BDB))
        )
        blobs.forEachIndexed { i, blob ->
            val breathe = if (enabled) .82f + .22f * sin(phase + i * 1.4f) + energy * .65f else 1f
            val center = Offset(size.width * blob.first, size.height * blob.second)
            val radius = size.minDimension * (.27f + energy * .16f) * breathe
            drawCircle(Brush.radialGradient(listOf(blob.third.copy(alpha = .12f + energy * .20f), blob.third.copy(alpha = .055f), Color.Transparent), center, radius), radius, center)
        }
    }
}

@Composable
private fun AudioWaveCanvas(modifier: Modifier, waveform: FloatArray, level: Float, playing: Boolean, darkBackdrop: Boolean = true) {
    val transition = rememberInfiniteTransition(label = "waveform-motion")
    val idlePhase by transition.animateFloat(0f, (2f * PI).toFloat(), infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "idle-phase")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val mid = h * .56f
        val energy = if (playing) level.coerceIn(.03f, .9f) else .10f
        val glowColors = listOf(Color(0xFF23D9D0), Color(0xFF477EFF), Color(0xFFBD54E9), Color(0xFFFF75C9))
        val centers = listOf(Offset(w*.25f, mid), Offset(w*.48f, mid), Offset(w*.73f, mid))
        centers.forEachIndexed { i, c ->
            val radius = h * (.44f + energy * .22f) * (1f + .06f * sin(idlePhase + i))
            drawCircle(Brush.radialGradient(listOf(glowColors[i].copy(alpha = .20f + energy*.22f), glowColors[i].copy(alpha = .07f), Color.Transparent), c, radius), radius, c)
        }
        val points = waveform.size.coerceAtLeast(2)
        for (layer in 0 until 9) {
            val path = Path()
            for (i in 0 until points) {
                val x = w * i / (points - 1f)
                val sample = waveform.getOrElse(i) { .05f }.coerceIn(0f, 1f)
                val envelope = .25f + .75f * sin(PI * i / (points - 1f)).toFloat().coerceAtLeast(0f)
                val wave = if (playing) (sample - .22f) * 1.9f else sin(i * .18f + idlePhase).toFloat() * .08f
                val y = mid + wave * h * .46f * envelope + (layer - 4) * h * .006f
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val tint = glowColors[layer % glowColors.size]
            drawPath(path, tint.copy(alpha = if (layer == 4) .88f else .22f), style = Stroke(width = if (layer == 4) 1.8.dp.toPx() else 1.dp.toPx()))
        }
        // Fine central glow line, brighter on transients.
        drawLine(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xFF8BE9F0).copy(alpha = .55f + energy*.35f), Color(0xFFDCA2FF).copy(alpha = .48f), Color.Transparent)), Offset(0f, mid), Offset(w, mid), strokeWidth = 1.dp.toPx())
    }
}

@Composable
private fun GlassSearchField(value: String, onValueChange: (String) -> Unit, onClear: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().height(55.dp), radius = 19.dp) {
        Row(Modifier.fillMaxSize().padding(horizontal = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Color(0xFFD4C2F4), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(11.dp))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = TextStyle(color = Color(0xFFF5F0FF), fontSize = 13.sp),
                cursorBrush = SolidColor(Color(0xFFD9BBFF)),
                decorationBox = { innerTextField ->
                    Box {
                        if (value.isEmpty()) Text("Search music, stations or moods", color = Color(0xFFAAA2B9), fontSize = 13.sp)
                        innerTextField()
                    }
                }
            )
            if (value.isNotEmpty()) {
                GlassIconButton(Icons.Default.Close, "Clear search", onClear, size = 30.dp)
            }
        }
    }
}

@Composable
private fun GlassChip(label: String, selected: Boolean, onClick: () -> Unit, compact: Boolean = false) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .94f else 1f,
        animationSpec = spring(dampingRatio = .58f, stiffness = 650f),
        label = "glass-chip-press"
    )
    val shape = CircleShape
    Box(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(Color(0xFFA78BFA).copy(alpha = .26f), Color(0xFF69CBEA).copy(alpha = .14f)))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = .075f), Color.White.copy(alpha = .025f)))
            )
            .border(1.dp, if (selected) Brush.linearGradient(listOf(Color.White.copy(alpha = .42f), Color(0xFFBDA7FF).copy(alpha = .30f), Color(0xFF78DDF0).copy(alpha = .22f))) else Brush.linearGradient(listOf(Color.White.copy(alpha = .16f), Color.White.copy(alpha = .04f))), shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = if (compact) 13.dp else 14.dp, vertical = if (compact) 8.dp else 9.dp)
    ) {
        Text(label, color = if (selected) Color(0xFFFFFAFF) else Color(0xFFC2B9D0), fontSize = if (compact) 10.sp else 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
    }
}

@Composable
private fun GlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp = 44.dp,
    tint: Color = Color(0xFFE7D8FF),
    enabled: Boolean = true
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .86f else 1f,
        animationSpec = spring(dampingRatio = .48f, stiffness = 700f),
        label = "glass-button-press"
    )
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color.White.copy(alpha = if (pressed) .21f else .105f), Color(0xFF9F84E8).copy(alpha = .10f), Color.White.copy(alpha = .035f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .38f), Color(0xFFBBA4FF).copy(alpha = .14f), Color.White.copy(alpha = .035f))), CircleShape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = if (enabled) tint else tint.copy(alpha = .35f), modifier = Modifier.size(size * .47f))
    }
}

@Composable
private fun StationCard(
    station: Station,
    active: Boolean,
    favorite: Boolean,
    motionEnabled: Boolean,
    onFavorite: () -> Unit,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .978f else 1f,
        animationSpec = spring(dampingRatio = .54f, stiffness = 620f),
        label = "station-glass-press"
    )
    val shape = RoundedCornerShape(21.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (active) 7.dp else 2.dp, shape, clip = false)
            .clip(shape)
            .background(
                if (active) Brush.linearGradient(listOf(Color(0xFFBBA3FF).copy(alpha = .13f), Color(0xFF70D8ED).copy(alpha = .055f), Color.White.copy(alpha = .025f)))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = .045f), Color.White.copy(alpha = .016f), Color(0xFF9D83D7).copy(alpha = .018f)))
            )
            .border(
                BorderStroke(
                    1.dp,
                    if (active) Brush.linearGradient(listOf(Color.White.copy(alpha = .30f), Color(0xFFB8A1FF).copy(alpha = .20f), Color(0xFF72DDF0).copy(alpha = .14f)))
                    else Brush.linearGradient(listOf(Color.White.copy(alpha = .12f), Color.White.copy(alpha = .025f), Color(0xFF9A8AC6).copy(alpha = .06f)))
                ),
                shape
            )
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = .06f), Color.Transparent, Color.Black.copy(alpha = .08f))),
                cornerRadius = CornerRadius(21.dp.toPx()),
                size = size
            )
            if (active) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0xFFB79CFF).copy(alpha = .19f), Color.Transparent)),
                    radius = size.height * .86f,
                    center = Offset(size.width * .08f, size.height * .46f)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(49.dp).clip(RoundedCornerShape(15.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .17f), Color(0xFF8A75C6).copy(alpha = .10f))))
                    .border(1.dp, Color.White.copy(alpha = .17f), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (active) Icons.Default.GraphicEq else if (station.category.contains("Classical")) Icons.Default.GraphicEq else Icons.Default.Radio,
                    null,
                    tint = if (active) Color(0xFF8FE7E2) else Color(0xFFD2BFFF),
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(station.name, color = Color(0xFFF8F4FF), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (active) {
                        Spacer(Modifier.width(7.dp))
                        Text("ON AIR", color = Color(0xFFBCEDEB), fontWeight = FontWeight.Bold, fontSize = 7.sp, letterSpacing = 1.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("${station.genre}  ·  ${station.broadcaster}", color = Color(0xFFBDB4CB), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            GlassIconButton(
                icon = if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (favorite) "Remove favourite" else "Add favourite",
                onClick = onFavorite,
                size = 36.dp,
                tint = if (favorite) Color(0xFFFFB6DF) else Color(0xFFD4C9E6)
            )
        }
    }
}

@Composable
private fun BottomMiniPlayer(
    station: Station?,
    isPlaying: Boolean,
    status: String,
    motionEnabled: Boolean,
    waveform: FloatArray,
    level: Float,
    onPlayPause: () -> Unit,
    onStop: () -> Unit
) {
    GlassPanel(Modifier.fillMaxWidth().heightIn(min = 86.dp), radius = 25.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(61.dp).clip(RoundedCornerShape(19.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .13f), Color(0xFF8D73CE).copy(alpha = .10f))))
                    .border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(19.dp)),
                contentAlignment = Alignment.Center
            ) {
                AudioWaveCanvas(Modifier.fillMaxSize(), waveform, level, motionEnabled && isPlaying)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("NOW PLAYING", color = Color(0xFFE1CFFF), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.55.sp)
                Spacer(Modifier.height(3.dp))
                Text(station?.name ?: "Radio Cherry", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (station == null) "Choose a frequency" else if (isPlaying) "${station.genre}  ·  LIVE" else status,
                    color = Color(0xFFBDB4CA), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            GlassIconButton(
                icon = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                onClick = onPlayPause,
                size = 43.dp,
                enabled = station != null,
                tint = Color(0xFFE6D5FF)
            )
            Spacer(Modifier.width(5.dp))
            GlassIconButton(
                icon = Icons.Default.Stop,
                contentDescription = "Stop playback",
                onClick = onStop,
                size = 38.dp,
                enabled = station != null,
                tint = Color(0xFFC4B9D4)
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    motionEnabled: Boolean,
    onMotionChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = true)
    ) {
        GlassPanel(Modifier.fillMaxWidth(), radius = 29.dp) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("APPEARANCE", color = Color(0xFFDCC5FF), fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 2.sp)
                    Text("Make it move.", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Tune the atmosphere of Radio Cherry.", color = Color(0xFFC0B8CE), fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Music-reactive visualizer", color = Color(0xFFF8F3FF), fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        Text("Capture the playing stream waveform and let the coloured light pulses breathe with its energy. Microphone/audio visualizer permission is requested when playback starts.", fontSize = 11.sp, color = Color(0xFFC0B8CE), lineHeight = 16.sp)
                    }
                    Switch(
                        checked = motionEnabled,
                        onCheckedChange = onMotionChange,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF171222),
                            checkedTrackColor = Color(0xFFC6A8FF),
                            uncheckedThumbColor = Color(0xFFB8AFC4),
                            uncheckedTrackColor = Color.White.copy(alpha = .15f)
                        )
                    )
                }
                Text("The waveform uses Android audio-session capture when permission is granted. If permission is declined, a subtle idle animation is shown instead.", fontSize = 10.sp, color = Color(0xFFAAA1BB), lineHeight = 15.sp)
                GlassChip(label = "Done", selected = true, onClick = onDismiss)
            }
        }
    }
}
