package com.example.englishradio

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private val stations = listOf(
    Station("groove-salad", "Groove Salad", "Ambient · Downtempo", "SomaFM", "https://ice5.somafm.com/groovesalad-128-mp3", "https://ice.somafm.com/groovesalad", "Chill"),
    Station("lush", "Lush", "Mellow · Electronic", "SomaFM", "https://ice5.somafm.com/lush-128-mp3", "https://ice.somafm.com/lush", "Chill"),
    Station("indie-pop", "Indie Pop Rocks!", "Indie · Alternative", "SomaFM", "https://ice5.somafm.com/indiepop-128-mp3", "https://ice.somafm.com/indiepop", "Indie"),
    Station("underground-80s", "Underground 80s", "80s · New Wave", "SomaFM", "https://ice5.somafm.com/u80s-128-mp3", "https://ice.somafm.com/u80s", "Throwbacks"),
    Station("left-coast-70s", "Left Coast 70s", "Classic · Album Rock", "SomaFM", "https://ice5.somafm.com/seventies-128-mp3", "https://ice.somafm.com/seventies", "Throwbacks"),
    Station("folk-forward", "Folk Forward", "Folk · Americana", "SomaFM", "https://ice5.somafm.com/folkfwd-128-mp3", "https://ice.somafm.com/folkfwd", "Acoustic"),
    Station("drone-zone", "Drone Zone", "Atmospheric · Ambient", "SomaFM", "https://ice5.somafm.com/dronezone-128-mp3", "https://ice.somafm.com/dronezone", "Chill"),
    Station("secret-agent", "Secret Agent", "Spy · Soundtracks", "SomaFM", "https://ice5.somafm.com/secretagent-128-mp3", "https://ice.somafm.com/secretagent", "Discovery"),
    Station("mission-control", "Mission Control", "Space · Ambient", "SomaFM", "https://ice5.somafm.com/missioncontrol-128-mp3", "https://ice.somafm.com/missioncontrol", "Chill"),
    Station("space-station", "Space Station Soma", "Space · Electronic", "SomaFM", "https://ice5.somafm.com/spacestation-128-mp3", "https://ice.somafm.com/spacestation", "Chill"),
    Station("beat-blender", "Beat Blender", "Deep · House", "SomaFM", "https://ice5.somafm.com/beatblender-128-mp3", "https://ice.somafm.com/beatblender", "Electronic"),
    Station("poptron", "PopTron", "Indie · Pop", "SomaFM", "https://ice5.somafm.com/poptron-128-mp3", "https://ice.somafm.com/poptron", "Indie"),
    Station("sonic-universe", "Sonic Universe", "Modern · Jazz", "SomaFM", "https://ice5.somafm.com/sonicuniverse-128-mp3", "https://ice.somafm.com/sonicuniverse", "Jazz"),
    Station("suburbs-of-goa", "Suburbs of Goa", "Psychedelic · Indian", "SomaFM", "https://ice5.somafm.com/suburbsofgoa-128-mp3", "https://ice.somafm.com/suburbsofgoa", "World"),
    Station("defcon", "DEF CON Radio", "Electronic · Hacker culture", "SomaFM", "https://ice5.somafm.com/defcon-128-mp3", "https://ice.somafm.com/defcon", "Electronic"),
    Station("radio-paradise-main", "Radio Paradise · Main Mix", "Eclectic · Alternative", "Radio Paradise", "https://stream.radioparadise.com/mp3-128", null, "Indie", region = "USA"),
    Station("radio-paradise-mellow", "Radio Paradise · Mellow Mix", "Mellow · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/mellow-128", null, "Chill", region = "USA"),
    Station("radio-paradise-rock", "Radio Paradise · Rock Mix", "Alternative · Rock", "Radio Paradise", "https://stream.radioparadise.com/rock-128", null, "Indie", region = "USA"),
    Station("radio-paradise-global", "Radio Paradise · Global Mix", "World · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/eclectic-128", null, "World", region = "USA"),
    Station("kexp", "KEXP 90.3", "Alternative · Discovery", "KEXP", "https://kexp.streamguys1.com/kexp160.aac", "https://kexp.streamguys1.com/kexp64.aac", "Indie", region = "Seattle"),
    Station("swiss-classic", "Radio Swiss Classic", "Western classical · Instrumental", "Switzerland", "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128", null, "Classical", region = "Switzerland"),
    Station("wcrb", "WCRB Classical", "Symphonic · Chamber · Opera", "CRB · Boston", "https://wgbh-live.streamguys1.com/classical-hi/", null, "Classical", region = "Boston"),
    Station("kusc", "Classical KUSC", "Orchestral · Classical favourites", "Classical California", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3", null, "Classical", region = "Los Angeles"),
    Station("air-raagam", "AIR Raagam", "Hindustani · Carnatic", "Akashvani · India", "https://airhlspush.pc.cdn.bitgravity.com/httppush/hlspbaudioragam/hlspbaudioragam64kbps.m3u8", null, "Indian Classical", region = "India")
)

data class Station(
    val id: String,
    val name: String,
    val genre: String,
    val broadcaster: String,
    val stream: String,
    val fallback: String?,
    val category: String,
    val region: String = "USA"
)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                runCatching { future.get() }.onSuccess { controller = it }
            }, ContextCompat.getMainExecutor(this))
        }
        setContent { RadioCherryApp(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun RadioCherryApp(player: MediaController?) {
    val context = LocalContext.current
    val preferences = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", android.content.Context.MODE_PRIVATE)
    }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackStatus by remember { mutableStateOf("Choose a station to begin") }
    var search by remember { mutableStateOf("") }
    var showFavorites by remember { mutableStateOf(false) }
    var activeCategory by remember { mutableStateOf("All") }
    var showSettings by remember { mutableStateOf(false) }
    var favorites by remember {
        mutableStateOf(preferences.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    var orbMotionEnabled by remember {
        mutableStateOf(preferences.getBoolean("orb_motion_enabled", true))
    }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }

    LaunchedEffect(favorites) {
        preferences.edit().putStringSet("favorite_station_ids", favorites).apply()
    }
    LaunchedEffect(orbMotionEnabled) {
        preferences.edit().putBoolean("orb_motion_enabled", orbMotionEnabled).apply()
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                playbackStatus = if (playing) "Playing live" else if (player.mediaItemCount > 0) "Paused" else "Choose a station"
            }
            override fun onPlaybackStateChanged(state: Int) {
                playbackStatus = when (state) {
                    Player.STATE_BUFFERING -> "Connecting to station…"
                    Player.STATE_READY -> if (player.isPlaying) "Playing live" else "Ready to play"
                    Player.STATE_ENDED -> "Stream ended"
                    Player.STATE_IDLE -> if (player.mediaItemCount == 0) "Choose a station" else "Stopped"
                    else -> playbackStatus
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isPlaying = false
                playbackStatus = "Stream unavailable · ${error.errorCodeName}"
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
                if (mediaItem == null) isPlaying = false
            }
        }
        player.addListener(listener)
        isPlaying = player.isPlaying
        selectedId = player.currentMediaItem?.mediaId
        onDispose { player.removeListener(listener) }
    }

    val selected = stations.firstOrNull { it.id == selectedId }
    val categories = listOf("All", "Chill", "Indie", "Throwbacks", "Electronic", "Acoustic", "Jazz", "World", "Classical", "Indian Classical", "Discovery")
    val visibleStations = stations.filter { station ->
        (search.isBlank() || (station.name + station.genre + station.category + station.broadcaster).contains(search, true)) &&
            (!showFavorites || station.id in favorites) &&
            (activeCategory == "All" || station.category == activeCategory)
    }

    fun playStation(station: Station) {
        if (player == null) return
        selectedId = station.id
        playbackStatus = "Connecting to station…"
        player.setMediaItem(PlaybackService.mediaItem(station, orbArtwork))
        player.prepare()
        player.play()
    }

    fun togglePlayback() {
        if (player == null) return
        if (player.isPlaying) {
            player.pause()
        } else if (player.mediaItemCount > 0) {
            player.play()
        } else {
            selected?.let { playStation(it) }
        }
    }

    fun stopPlayback() {
        player?.let {
            it.pause()
            it.clearMediaItems()
        }
        selectedId = null
        isPlaying = false
        playbackStatus = "Playback stopped"
    }

    val background = Color(0xFF080A16)
    val ink = Color(0xFFF2F0FA)
    val muted = Color(0xFFB4B0C7)
    val lavender = Color(0xFFD2B9FF)
    val periwinkle = Color(0xFF9BAEFF)
    val cyan = Color(0xFF87DFFF)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = lavender,
            secondary = cyan,
            background = background,
            surface = Color(0xFF17172B),
            onBackground = ink,
            onSurface = ink
        )
    ) {
        Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF101326), Color(0xFF090B19), Color(0xFF090914))))) {
            if (orbMotionEnabled) {
                FluidOrb(
                    Modifier.align(Alignment.TopEnd).offset(x = 120.dp, y = 20.dp).size(380.dp).alpha(.18f),
                    animated = true
                )
                Box(Modifier.align(Alignment.BottomStart).offset(x = (-110).dp, y = 20.dp).size(260.dp).blur(90.dp).background(Color(0xFF3A5DCE).copy(alpha = .11f), CircleShape))
            }

            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 18.dp)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFFB987FF), Color(0xFF5EC9F5)))), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Radio, null, tint = Color(0xFF111426), modifier = Modifier.size(23.dp))
                    }
                    Spacer(Modifier.width(11.dp))
                    Column {
                        Text("RADIO CHERRY", color = ink, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.4.sp, fontSize = 15.sp)
                        Text("MUSIC WITHOUT BORDERS", color = muted, fontSize = 8.sp, letterSpacing = 1.45.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = muted)
                    }
                }

                GlassPanel(Modifier.fillMaxWidth().height(164.dp)) {
                    Row(
                        Modifier.fillMaxSize().padding(start = 18.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("SOUND IN MOTION", color = lavender, fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 2.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("Find your\nfrequency.", color = ink, fontSize = 27.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-.5).sp)
                            Spacer(Modifier.height(7.dp))
                            Text("Independent music radio,\nfrom ambient to orchestral.", color = muted, fontSize = 10.sp, lineHeight = 15.sp)
                        }
                        FluidOrb(Modifier.size(156.dp), animated = orbMotionEnabled)
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search stations or genres", color = muted) },
                    leadingIcon = { Icon(Icons.Default.Search, null, tint = muted) },
                    shape = RoundedCornerShape(18.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = lavender.copy(alpha = .65f),
                        unfocusedBorderColor = Color.White.copy(alpha = .10f),
                        focusedContainerColor = Color.White.copy(alpha = .075f),
                        unfocusedContainerColor = Color.White.copy(alpha = .045f),
                        focusedTextColor = ink,
                        unfocusedTextColor = ink,
                        cursorColor = lavender
                    )
                )

                Spacer(Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(selected = !showFavorites, onClick = { showFavorites = false }, label = { Text("All stations") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = showFavorites, onClick = { showFavorites = true }, label = { Text("Favourites  ♥") })
                    Spacer(Modifier.weight(1f))
                    Text("${visibleStations.size} STATIONS", color = muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(vertical = 3.dp)) {
                    items(categories) { category ->
                        FilterChip(
                            selected = activeCategory == category,
                            onClick = { activeCategory = category },
                            label = { Text(category, fontSize = 11.sp) }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(top = 4.dp, bottom = 14.dp)
                ) {
                    items(visibleStations, key = { it.id }) { station ->
                        StationCard(
                            station = station,
                            active = selectedId == station.id,
                            favorite = station.id in favorites,
                            motionEnabled = orbMotionEnabled,
                            onFavorite = {
                                favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
                            },
                            onClick = { playStation(station) }
                        )
                    }
                    if (visibleStations.isEmpty()) {
                        item {
                            Text("No stations match that search.", color = muted, modifier = Modifier.padding(18.dp))
                        }
                    }
                }

                BottomMiniPlayer(
                    station = selected,
                    isPlaying = isPlaying,
                    status = playbackStatus,
                    motionEnabled = orbMotionEnabled,
                    onPlayPause = { togglePlayback() },
                    onStop = { stopPlayback() }
                )
                Spacer(Modifier.height(8.dp))
            }

            if (showSettings) {
                SettingsDialog(
                    motionEnabled = orbMotionEnabled,
                    onMotionChange = { orbMotionEnabled = it },
                    onDismiss = { showSettings = false }
                )
            }
        }
    }
}

@Composable
private fun FluidOrb(modifier: Modifier = Modifier, animated: Boolean) {
    val transition = rememberInfiniteTransition(label = "radio-cherry-liquid-orb")
    val phaseSpec: androidx.compose.animation.core.AnimationSpec<Float> =
        if (animated) infiniteRepeatable<Float>(
            animation = tween(durationMillis = 24000, easing = LinearEasing)
        ) else tween(durationMillis = 0)
    val pulseSpec: androidx.compose.animation.core.AnimationSpec<Float> =
        if (animated) infiniteRepeatable<Float>(
            animation = tween(durationMillis = 9500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ) else tween(durationMillis = 0)
    val phaseValue by transition.animateFloat(
        initialValue = 0f,
        targetValue = if (animated) (2f * PI).toFloat() else 0f,
        animationSpec = phaseSpec,
        label = "orb-phase"
    )
    val pulseValue by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (animated) 1.04f else 1f,
        animationSpec = pulseSpec,
        label = "orb-breathe"
    )
    val phase = phaseValue
    val pulse = pulseValue

    Canvas(modifier) {
        val d = min(size.width, size.height)
        if (d <= 0f) return@Canvas
        val center = Offset(size.width / 2f, size.height / 2f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0xFF9C83FF).copy(alpha = .26f), Color(0xFF4ABBEF).copy(alpha = .13f), Color.Transparent),
                center = center,
                radius = d * .52f
            ),
            radius = d * .50f,
            center = center
        )

        val palette = listOf(
            Color(0xFFD6B7FF), Color(0xFF9B8DFF), Color(0xFF5DBBFF),
            Color(0xFF8BE5F0), Color(0xFF8D9DFF), Color(0xFFBD9BFF)
        )
        for (i in 0 until 6) {
            val p = phase + i * 1.047f
            val drift = if (animated) 1f else .88f
            val x = center.x + cos(p * (if (i % 2 == 0) .72f else .58f) + i * .19f).toFloat() * d * .145f * drift
            val y = center.y + sin(p * (if (i % 2 == 0) .63f else .81f) + i * .23f).toFloat() * d * .15f * drift
            val radius = d * (.205f + .014f * sin(p * .7f + i).toFloat()) * pulse
            val c = palette[i]
            val cellCenter = Offset(x - radius * .12f, y - radius * .13f)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White.copy(alpha = .84f),
                        c.copy(alpha = .83f),
                        c.copy(alpha = .52f),
                        Color(0xFF4B6BE0).copy(alpha = .20f),
                        Color.Transparent
                    ),
                    center = Offset(x - radius * .28f, y - radius * .34f),
                    radius = radius * 1.20f
                ),
                radius = radius,
                center = cellCenter
            )
            drawCircle(
                color = Color.White.copy(alpha = .19f),
                radius = radius * .985f,
                center = cellCenter,
                style = Stroke(width = (d * .004f).coerceAtLeast(1f))
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White.copy(alpha = .24f), Color.White.copy(alpha = .02f), Color.Transparent),
                    center = Offset(x - radius * .34f, y - radius * .39f),
                    radius = radius * .55f
                ),
                radius = radius * .52f,
                center = Offset(x - radius * .23f, y - radius * .24f)
            )
        }
        drawCircle(
            color = Color.White.copy(alpha = .13f),
            radius = d * .475f,
            center = center,
            style = Stroke(width = d * .003f)
        )
    }
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.border(
            BorderStroke(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .25f), Color.White.copy(alpha = .035f), Color(0xFFAC9AFF).copy(alpha = .13f)))),
            RoundedCornerShape(27.dp)
        ),
        shape = RoundedCornerShape(27.dp),
        color = Color.White.copy(alpha = .075f),
        content = { Column(content = content) }
    )
}

@Composable
private fun StationCard(
    station: Station,
    active: Boolean,
    favorite: Boolean,
    motionEnabled: Boolean,
    onFavorite: () -> Unit,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .975f else 1f,
        animationSpec = spring(dampingRatio = .62f, stiffness = Spring.StiffnessMediumLow),
        label = "station-touch-scale"
    )
    Surface(
        onClick = onClick,
        interactionSource = interaction,
        modifier = Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale }
            .border(
                1.dp,
                if (active) Color(0xFFD2B9FF).copy(alpha = .56f) else Color.White.copy(alpha = .075f),
                RoundedCornerShape(20.dp)
            ),
        shape = RoundedCornerShape(20.dp),
        color = if (active) Color(0xFF9F8BFF).copy(alpha = .17f) else Color.White.copy(alpha = .052f)
    ) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha = .045f)), contentAlignment = Alignment.Center) {
                if (active && motionEnabled) FluidOrb(Modifier.size(48.dp), animated = true)
                else Icon(if (station.category.contains("Classical")) Icons.Default.GraphicEq else Icons.Default.Radio, null, tint = Color(0xFFBCA5FF), modifier = Modifier.size(23.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(station.name, color = Color(0xFFF2F0FA), fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text("${station.genre}  ·  ${station.broadcaster}", color = Color(0xFFB4B0C7), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (active) {
                Icon(Icons.Default.GraphicEq, null, tint = Color(0xFFD2B9FF), modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onFavorite, modifier = Modifier.size(38.dp)) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = if (favorite) "Remove favourite" else "Add favourite", tint = if (favorite) Color(0xFFEAB4E8) else Color(0xFFB4B0C7), modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun BottomMiniPlayer(
    station: Station?,
    isPlaying: Boolean,
    status: String,
    motionEnabled: Boolean,
    onPlayPause: () -> Unit,
    onStop: () -> Unit
) {
    GlassPanel(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().heightIn(min = 82.dp).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .035f)), contentAlignment = Alignment.Center) {
                FluidOrb(Modifier.size(56.dp), animated = motionEnabled)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("NOW PLAYING", color = Color(0xFFBCA5FF), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
                Spacer(Modifier.height(3.dp))
                Text(station?.name ?: "Radio Cherry", color = Color(0xFFF2F0FA), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (station == null) "Choose a station" else if (isPlaying) "${station.genre}  ·  LIVE" else status, color = Color(0xFFB4B0C7), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onPlayPause, enabled = station != null) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (isPlaying) "Pause" else "Play", tint = Color(0xFFDAC7FF), modifier = Modifier.size(27.dp))
            }
            IconButton(onClick = onStop, enabled = station != null) {
                Icon(Icons.Default.Stop, contentDescription = "Stop playback", tint = Color(0xFFB4B0C7), modifier = Modifier.size(22.dp))
            }
        }
    }
}

@Composable
private fun SettingsDialog(
    motionEnabled: Boolean,
    onMotionChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF19192D),
        titleContentColor = Color(0xFFF2F0FA),
        textContentColor = Color(0xFFB4B0C7),
        title = { Text("Appearance & motion", fontWeight = FontWeight.SemiBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Living glass orb", color = Color(0xFFF2F0FA), fontWeight = FontWeight.Medium)
                        Text("Slow, flowing cells across the app and player artwork.", fontSize = 12.sp, color = Color(0xFFB4B0C7))
                    }
                    Switch(checked = motionEnabled, onCheckedChange = onMotionChange)
                }
                Text("The Android notification and lock-screen artwork uses a still image. The orb remains animated inside Radio Cherry.", fontSize = 11.sp, color = Color(0xFF9C98B0), lineHeight = 16.sp)
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done", color = Color(0xFFD2B9FF)) }
        },
        properties = DialogProperties(usePlatformDefaultWidth = true)
    )
}
