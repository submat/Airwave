package com.example.englishradio

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.SystemBarStyle
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val stations = listOf(
    Station("groove-salad", "Groove Salad", "Ambient · Downtempo", "SomaFM", "https://ice5.somafm.com/groovesalad-128-mp3", "https://ice.somafm.com/groovesalad", "Chill"),
    Station("lush", "Lush", "Mellow · Electronic", "SomaFM", "https://ice5.somafm.com/lush-128-mp3", "https://ice.somafm.com/lush", "Chill"),
    Station("indie-pop", "Indie Pop Rocks!", "Indie · Alternative", "SomaFM", "https://ice5.somafm.com/indiepop-128-mp3", "https://ice.somafm.com/indiepop", "Indie"),
    Station("underground-80s", "Underground 80s", "80s · New Wave", "SomaFM", "https://ice5.somafm.com/u80s-128-mp3", "https://ice.somafm.com/u80s", "Throwbacks"),
    Station("left-coast-70s", "Left Coast 70s", "Classic · Album Rock", "SomaFM", "https://ice5.somafm.com/seventies-128-mp3", "https://ice.somafm.com/seventies", "Throwbacks"),
    Station("folk-forward", "Folk Forward", "Folk · Americana", "SomaFM", "https://ice5.somafm.com/folkfwd-128-mp3", "https://ice.somafm.com/folkfwd", "Acoustic"),
    Station("drone-zone", "Drone Zone", "Atmospheric · Ambient", "SomaFM", "https://ice5.somafm.com/dronezone-128-mp3", "https://ice.somafm.com/dronezone", "Chill"),
    Station("secret-agent", "Secret Agent", "Spy · Soundtracks", "SomaFM", "https://ice5.somafm.com/secretagent-128-mp3", "https://ice.somafm.com/secretagent", "Discovery"),
    Station("mission-control", "Mission Control", "Space · Ambient", "SomaFM", "https://ice5.somafm.com/missioncontrol-128-mp3", "https://ice.somafm.com/missioncontrol", "Chill"),
    Station("space-station", "Space Station Soma", "Space · Electronic", "SomaFM", "https://ice5.somafm.com/spacestation-128-mp3", "https://ice.somafm.com/spacestation", "Chill"),
    Station("beat-blender", "Beat Blender", "Deep · House", "SomaFM", "https://ice5.somafm.com/beatblender-128-mp3", "https://ice.somafm.com/beatblender", "Electronic"),
    Station("poptron", "PopTron", "Indie · Pop", "SomaFM", "https://ice5.somafm.com/poptron-128-mp3", "https://ice.somafm.com/poptron", "Indie"),
    Station("sonic-universe", "Sonic Universe", "Modern · Jazz", "SomaFM", "https://ice5.somafm.com/sonicuniverse-128-mp3", "https://ice.somafm.com/sonicuniverse", "Jazz"),
    Station("suburbs-of-goa", "Suburbs of Goa", "Psychedelic · Indian", "SomaFM", "https://ice5.somafm.com/suburbsofgoa-128-mp3", "https://ice.somafm.com/suburbsofgoa", "World"),
    Station("defcon", "DEF CON Radio", "Electronic · Hacker culture", "SomaFM", "https://ice5.somafm.com/defcon-128-mp3", "https://ice.somafm.com/defcon", "Electronic"),
    Station("radio-paradise-main", "Radio Paradise · Main Mix", "Eclectic · Alternative", "Radio Paradise", "https://stream.radioparadise.com/mp3-128", null, "Indie", region = "USA"),
    Station("radio-paradise-mellow", "Radio Paradise · Mellow Mix", "Mellow · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/mellow-128", null, "Chill", region = "USA"),
    Station("radio-paradise-rock", "Radio Paradise · Rock Mix", "Alternative · Rock", "Radio Paradise", "https://stream.radioparadise.com/rock-128", null, "Indie", region = "USA"),
    Station("radio-paradise-global", "Radio Paradise · Global Mix", "World · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/eclectic-128", null, "World", region = "USA"),
    Station("kexp", "KEXP 90.3", "Alternative · Discovery", "KEXP", "https://kexp.streamguys1.com/kexp160.aac", "https://kexp.streamguys1.com/kexp64.aac", "Indie", region = "Seattle"),
    Station("swiss-classic", "Radio Swiss Classic", "Western classical · Instrumental", "Switzerland", "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128", null, "Classical", region = "Switzerland"),
    Station("wcrb", "WCRB Classical", "Symphonic · Chamber · Opera", "CRB · Boston", "https://wgbh-live.streamguys1.com/classical-hi/", null, "Classical", region = "Boston"),
    Station("kusc", "Classical KUSC", "Orchestral · Classical favourites", "Classical California", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3", null, "Classical", region = "Los Angeles"),
    Station("air-raagam", "AIR Raagam", "Hindustani · Carnatic", "Akashvani · India", "https://airhlspush.pc.cdn.bitgravity.com/httppush/hlspbaudioragam/hlspbaudioragam64kbps.m3u8", null, "Indian Classical", region = "India")
) + importedStations

data class Station(
    val id: String,
    val name: String,
    val genre: String,
    val broadcaster: String,
    val stream: String,
    val fallback: String?,
    val category: String,
    val region: String = "USA"
)

private val liquidPalette = listOf(
    Color(0xFFFF78D4), Color(0xFFC27BFF), Color(0xFF7E8BFF),
    Color(0xFF25AFFF), Color(0xFF43DCDD), Color(0xFF62E6BA),
    Color(0xFFFFB2E9)
)

private fun colorBlend(a: Color, b: Color, fraction: Float): Color {
    val t = fraction.coerceIn(0f, 1f)
    return Color(
        red = a.red + (b.red - a.red) * t,
        green = a.green + (b.green - a.green) * t,
        blue = a.blue + (b.blue - a.blue) * t,
        alpha = a.alpha + (b.alpha - a.alpha) * t
    )
}

private fun shiftingColor(index: Float): Color {
    val base = floor(index).toInt()
    val fraction = index - floor(index)
    val first = ((base % liquidPalette.size) + liquidPalette.size) % liquidPalette.size
    val second = (first + 1) % liquidPalette.size
    return colorBlend(liquidPalette[first], liquidPalette[second], fraction)
}

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({
                runCatching { future.get() }.onSuccess { controller = it }
            }, ContextCompat.getMainExecutor(this))
        }
        setContent { RadioCherryApp(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun RadioCherryApp(player: MediaController?) {
    val context = LocalContext.current
    val preferences = remember(context) {
        context.getSharedPreferences("radio_cherry_preferences", android.content.Context.MODE_PRIVATE)
    }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackStatus by remember { mutableStateOf("Choose a station to begin") }
    var search by remember { mutableStateOf("") }
    var showFavorites by remember { mutableStateOf(false) }
    var activeCategory by remember { mutableStateOf("All") }
    var showSettings by remember { mutableStateOf(false) }
    var favorites by remember {
        mutableStateOf(preferences.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    var orbMotionEnabled by remember {
        mutableStateOf(preferences.getBoolean("orb_motion_enabled", true))
    }
    val playbackScope = rememberCoroutineScope()
    var playlistResolveJob by remember { mutableStateOf<Job?>(null) }
    val orbArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_orb.png").use { it.readBytes() } }.getOrNull()
    }

    LaunchedEffect(favorites) {
        preferences.edit().putStringSet("favorite_station_ids", favorites).apply()
    }
    LaunchedEffect(orbMotionEnabled) {
        preferences.edit().putBoolean("orb_motion_enabled", orbMotionEnabled).apply()
    }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                playbackStatus = if (playing) "Playing live" else if (player.mediaItemCount > 0) "Paused" else "Choose a station"
            }
            override fun onPlaybackStateChanged(state: Int) {
                playbackStatus = when (state) {
                    Player.STATE_BUFFERING -> "Connecting to station…"
                    Player.STATE_READY -> if (player.isPlaying) "Playing live" else "Ready to play"
                    Player.STATE_ENDED -> "Stream ended"
                    Player.STATE_IDLE -> if (player.mediaItemCount == 0) "Choose a station" else "Stopped"
                    else -> playbackStatus
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isPlaying = false
                playbackStatus = "Stream unavailable · ${error.errorCodeName}"
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
                if (mediaItem == null) isPlaying = false
            }
        }
        player.addListener(listener)
        isPlaying = player.isPlaying
        selectedId = player.currentMediaItem?.mediaId
        onDispose { player.removeListener(listener) }
    }

    val selected = stations.firstOrNull { it.id == selectedId }
    val categories = listOf("All") + stations.map { it.category }.distinct().sorted()
    val visibleStations = stations.filter { station ->
        (search.isBlank() || (station.name + station.genre + station.category + station.broadcaster).contains(search, true)) &&
            (!showFavorites || station.id in favorites) &&
            (activeCategory == "All" || station.category == activeCategory)
    }

    fun playStation(station: Station) {
        val activePlayer = player ?: return
        playlistResolveJob?.cancel()
        selectedId = station.id
        val requiresPlaylistResolution = PlaylistResolver.isPlaylistUrl(station.stream)
        playbackStatus = if (requiresPlaylistResolution) "Opening station playlist…" else "Connecting to station…"
        playlistResolveJob = playbackScope.launch {
            val resolvedUrl = runCatching {
                withContext(Dispatchers.IO) { PlaylistResolver.resolve(station.stream) }
            }.getOrElse { station.stream }
            if (selectedId != station.id) return@launch
            val resolvedStation = station.copy(stream = resolvedUrl, fallback = station.fallback)
            activePlayer.setMediaItem(PlaybackService.mediaItem(resolvedStation, orbArtwork))
            activePlayer.prepare()
            activePlayer.play()
        }
    }

    fun togglePlayback() {
        if (player == null) return
        if (player.isPlaying) {
            player.pause()
        } else if (player.mediaItemCount > 0) {
            player.play()
        } else {
            selected?.let { playStation(it) }
        }
    }

    fun stopPlayback() {
        playlistResolveJob?.cancel()
        playlistResolveJob = null
        player?.let {
            it.pause()
            it.clearMediaItems()
        }
        selectedId = null
        isPlaying = false
        playbackStatus = "Playback stopped"
    }

    val background = Color(0xFF07070D)
    val ink = Color(0xFFF7F3FF)
    val muted = Color(0xFFB9B1C9)
    val lavender = Color(0xFFD9BBFF)
    val cyan = Color(0xFF8BDFF1)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = lavender,
            secondary = cyan,
            background = background,
            surface = Color(0xFF171321),
            onBackground = ink,
            onSurface = ink
        )
    ) {
        Box(Modifier.fillMaxSize().background(background)) {
            LiquidAtmosphere(Modifier.fillMaxSize(), motionEnabled = orbMotionEnabled)
            // The liquid form is a full-screen ambient layer, not a static badge in one card.
            FluidOrb(
                Modifier.align(Alignment.TopCenter)
                    .offset(y = 72.dp)
                    .size(470.dp)
                    .alpha(.46f),
                animated = orbMotionEnabled
            )

            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(Modifier.height(7.dp))
                HeaderBar(onSettings = { showSettings = true })
                Spacer(Modifier.height(13.dp))
                HeroGlassPanel()
                Spacer(Modifier.height(13.dp))
                GlassSearchField(
                    value = search,
                    onValueChange = { search = it },
                    onClear = { search = "" }
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    GlassChip(
                        label = "Explore all",
                        selected = !showFavorites,
                        onClick = { showFavorites = false }
                    )
                    Spacer(Modifier.width(8.dp))
                    GlassChip(
                        label = "Favourites  ♥",
                        selected = showFavorites,
                        onClick = { showFavorites = true }
                    )
                    Spacer(Modifier.weight(1f))
                    Text("${visibleStations.size} CHANNELS", color = Color(0xFFACA4BD), fontSize = 9.sp, letterSpacing = 1.1.sp)
                }
                Spacer(Modifier.height(7.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(vertical = 2.dp)) {
                    items(categories) { category ->
                        GlassChip(
                            label = category,
                            selected = activeCategory == category,
                            onClick = { activeCategory = category },
                            compact = true
                        )
                    }
                }
                Spacer(Modifier.height(11.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("FREQUENCIES", color = Color(0xFFE6D6FF), fontWeight = FontWeight.Bold, fontSize = 10.sp, letterSpacing = 2.1.sp)
                    Spacer(Modifier.weight(1f))
                    Text(if (showFavorites) "YOUR COLLECTION" else "CURATED MUSIC RADIO", color = Color(0xFF938AA8), fontSize = 8.sp, letterSpacing = 1.sp)
                }
                Spacer(Modifier.height(8.dp))
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 12.dp, top = 2.dp)
                ) {
                    items(visibleStations, key = { it.id }) { station ->
                        StationCard(
                            station = station,
                            active = selectedId == station.id,
                            favorite = station.id in favorites,
                            motionEnabled = orbMotionEnabled,
                            onFavorite = {
                                favorites = if (station.id in favorites) favorites - station.id else favorites + station.id
                            },
                            onClick = { playStation(station) }
                        )
                    }
                    if (visibleStations.isEmpty()) {
                        item {
                            GlassPanel(Modifier.fillMaxWidth().padding(top = 5.dp), radius = 22.dp) {
                                Text("No stations found. Try another search or category.", color = muted, modifier = Modifier.padding(18.dp), fontSize = 13.sp)
                            }
                        }
                    }
                }
                BottomMiniPlayer(
                    station = selected,
                    isPlaying = isPlaying,
                    status = playbackStatus,
                    motionEnabled = orbMotionEnabled,
                    onPlayPause = { togglePlayback() },
                    onStop = { stopPlayback() }
                )
                Spacer(Modifier.height(7.dp))
            }

            if (showSettings) {
                SettingsDialog(
                    motionEnabled = orbMotionEnabled,
                    onMotionChange = { orbMotionEnabled = it },
                    onDismiss = { showSettings = false }
                )
            }
        }
    }
}

@Composable
private fun LiquidAtmosphere(modifier: Modifier = Modifier, motionEnabled: Boolean) {
    if (!motionEnabled) {
        Canvas(modifier) {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0B20), Color(0xFF101025), Color(0xFF080A14))))
            val w = size.width
            val h = size.height
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFF7E75E8).copy(alpha = .11f), Color.Transparent)),
                radius = max(w, h) * .56f,
                center = Offset(w * .18f, h * .18f)
            )
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFF31CFE0).copy(alpha = .08f), Color.Transparent)),
                radius = max(w, h) * .54f,
                center = Offset(w * .86f, h * .48f)
            )
        }
        return
    }
    val transition = rememberInfiniteTransition(label = "radio-cherry-atmosphere")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 42000, easing = LinearEasing)),
        label = "ambient-drift"
    )
    val hue by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(animation = tween(durationMillis = 34000, easing = LinearEasing)),
        label = "ambient-colour"
    )
    val phase = if (motionEnabled) drift else 0f
    val colourPhase = if (motionEnabled) hue else .12f

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0A0B20), Color(0xFF101025), Color(0xFF080A14))))
        val fields = listOf(
            Triple(Offset(w * (.14f + .035f * cos(phase * .62f)), h * (.17f + .035f * sin(phase * .47f))), .58f, .18f),
            Triple(Offset(w * (.86f + .04f * sin(phase * .39f + 1.2f)), h * (.43f + .065f * cos(phase * .51f))),  .52f, .15f),
            Triple(Offset(w * (.38f + .07f * sin(phase * .28f + 2.1f)), h * (.86f + .035f * cos(phase * .71f))), .62f, .13f)
        )
        fields.forEachIndexed { index, field ->
            val colourA = shiftingColor(colourPhase * liquidPalette.size + index * 1.8f)
            val colourB = shiftingColor(colourPhase * liquidPalette.size + index * 1.8f + 2.1f)
            val radius = max(w, h) * field.second
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(colourA.copy(alpha = field.third), colourB.copy(alpha = field.third * .48f), Color.Transparent),
                    center = field.first,
                    radius = radius
                ),
                radius = radius,
                center = field.first
            )
        }
        // A low-contrast atmospheric sheen: light, not decorative particles.
        drawRect(
            brush = Brush.horizontalGradient(
                listOf(Color(0xFFB38BFF).copy(alpha = .025f), Color.Transparent, Color(0xFF4DE4E2).copy(alpha = .025f))
            )
        )
    }
}

@Composable
private fun FluidOrb(modifier: Modifier = Modifier, animated: Boolean) {
    if (animated) {
        AnimatedFluidOrb(modifier)
    } else {
        Canvas(modifier) { drawFluidOrb(phase = .75f, hue = 1.1f, pulse = 1f) }
    }
}

@Composable
private fun AnimatedFluidOrb(modifier: Modifier) {
    val transition = rememberInfiniteTransition(label = "radio-cherry-liquid-orb")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8200, easing = LinearEasing)
        ),
        label = "organic-ribbon-flow"
    )
    val hue by transition.animateFloat(
        initialValue = 0f,
        targetValue = liquidPalette.size.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 18500, easing = LinearEasing)
        ),
        label = "continuous-gradient-shift"
    )
    val pulse by transition.animateFloat(
        initialValue = .955f,
        targetValue = 1.045f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "liquid-sphere-breath"
    )
    Canvas(modifier) { drawFluidOrb(phase, hue, pulse) }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawFluidOrb(
    phase: Float,
    hue: Float,
    pulse: Float
) {
    val diameter = min(size.width, size.height)
    if (diameter <= 0f) return
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = diameter * .455f * pulse
    val bounds = androidx.compose.ui.geometry.Rect(
        center.x - radius, center.y - radius, center.x + radius, center.y + radius
    )
    val pink = shiftingColor(hue + .10f)
    val magenta = shiftingColor(hue + 1.05f)
    val violet = shiftingColor(hue + 2.0f)
    val blue = shiftingColor(hue + 3.0f)
    val cyan = shiftingColor(hue + 4.05f)
    val teal = shiftingColor(hue + 5.15f)

    val a = sin(phase)
    val b = sin(phase * .83f + 1.37f)
    val c = cos(phase * 1.19f - .72f)
    val d = sin(phase * 1.53f + 2.08f)

    // Soft, coloured light spills beyond the sphere to make it feel embedded in the UI.
    drawCircle(
        brush = Brush.radialGradient(
            listOf(blue.copy(alpha = .36f), violet.copy(alpha = .20f), Color.Transparent),
            center = center,
            radius = radius * 1.62f
        ),
        radius = radius * 1.62f,
        center = center
    )
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color(0xFFBFE8FF).copy(alpha = .18f), Color(0xFF334C91).copy(alpha = .34f), Color(0xFF111735).copy(alpha = .78f), Color(0xFF070D25).copy(alpha = .94f)),
            center = Offset(center.x - radius * .28f, center.y - radius * .36f),
            radius = radius * 1.48f
        ),
        radius = radius,
        center = center
    )

    val sphereClip = Path().apply { addOval(bounds) }
    clipPath(sphereClip) {
        // Broad pink-to-violet silk fold. The control points travel far enough to be visibly fluid.
        val upperFold = Path().apply {
            moveTo(center.x - radius * 1.10f, center.y - radius * (.12f + .10f * a))
            cubicTo(
                center.x - radius * .76f, center.y - radius * (.88f + .19f * b),
                center.x - radius * .10f, center.y - radius * (.57f - .20f * c),
                center.x + radius * 1.10f, center.y - radius * (.06f + .15f * a)
            )
            cubicTo(
                center.x + radius * .68f, center.y + radius * (.38f + .17f * c),
                center.x + radius * .05f, center.y - radius * (.02f - .18f * b),
                center.x - radius * 1.10f, center.y + radius * (.28f + .15f * d)
            )
            close()
        }
        drawPath(
            upperFold,
            Brush.linearGradient(
                listOf(pink.copy(alpha = .90f), magenta.copy(alpha = .86f), violet.copy(alpha = .76f), blue.copy(alpha = .62f)),
                start = Offset(center.x - radius, center.y - radius),
                end = Offset(center.x + radius, center.y + radius * .28f)
            )
        )
        drawPath(upperFold, Color.White.copy(alpha = .22f), style = Stroke(width = radius * .012f))

        // Aqua ribbon swells in the opposite direction and folds back across the centre.
        val aquaFold = Path().apply {
            moveTo(center.x - radius * 1.10f, center.y + radius * (.12f + .16f * b))
            cubicTo(
                center.x - radius * .60f, center.y - radius * (.30f + .19f * c),
                center.x + radius * .22f, center.y + radius * (.10f + .20f * d),
                center.x + radius * 1.10f, center.y + radius * (.15f - .13f * a)
            )
            cubicTo(
                center.x + radius * .70f, center.y + radius * (.83f - .18f * b),
                center.x + radius * .02f, center.y + radius * (.29f + .20f * c),
                center.x - radius * 1.10f, center.y + radius * (.48f + .13f * d)
            )
            close()
        }
        drawPath(
            aquaFold,
            Brush.linearGradient(
                listOf(blue.copy(alpha = .86f), cyan.copy(alpha = .90f), teal.copy(alpha = .82f), violet.copy(alpha = .60f)),
                start = Offset(center.x - radius, center.y + radius * .10f),
                end = Offset(center.x + radius, center.y + radius * .78f)
            )
        )
        drawPath(aquaFold, Color.White.copy(alpha = .24f), style = Stroke(width = radius * .011f))

        // A diagonal silk ribbon twists across the sphere, with its width and angle breathing over time.
        val twist = Path().apply {
            moveTo(center.x - radius * (.72f + .09f * b), center.y + radius * (.99f + .04f * c))
            cubicTo(
                center.x - radius * (.54f + .16f * a), center.y + radius * (.37f + .20f * c),
                center.x + radius * (.15f + .15f * d), center.y - radius * (.16f + .20f * b),
                center.x + radius * (.88f + .05f * a), center.y - radius * (.98f)
            )
            cubicTo(
                center.x + radius * (.69f + .10f * c), center.y - radius * (.28f - .18f * d),
                center.x + radius * (.18f - .12f * b), center.y + radius * (.45f + .19f * a),
                center.x - radius * (.72f + .09f * b), center.y + radius * (.99f + .04f * c)
            )
            close()
        }
        drawPath(
            twist,
            Brush.linearGradient(
                listOf(cyan.copy(alpha = .76f), Color.White.copy(alpha = .86f), pink.copy(alpha = .86f), violet.copy(alpha = .74f)),
                start = Offset(center.x - radius, center.y + radius),
                end = Offset(center.x + radius, center.y - radius)
            )
        )
        drawPath(twist, Color.White.copy(alpha = .20f), style = Stroke(width = radius * .010f))

        // Moving refracted light: this highlight visibly travels as the ribbons morph.
        val glint = Offset(
            center.x + radius * (.24f * sin(phase * .71f)),
            center.y + radius * (.20f * cos(phase * .91f))
        )
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Color.White.copy(alpha = .82f), cyan.copy(alpha = .34f), Color.Transparent),
                center = glint,
                radius = radius * .34f
            ),
            radius = radius * .34f,
            center = glint
        )
        drawOval(
            brush = Brush.radialGradient(listOf(Color.White.copy(alpha = .46f), Color.White.copy(alpha = .10f), Color.Transparent)),
            topLeft = Offset(center.x - radius * (.76f + .06f * a), center.y - radius * (.81f + .04f * b)),
            size = Size(radius * .72f, radius * .24f)
        )
    }

    // Iridescent glass membrane, plus a highlight arc that slowly travels around its edge.
    drawCircle(
        brush = Brush.sweepGradient(
            listOf(Color.White.copy(alpha = .92f), pink.copy(alpha = .70f), blue.copy(alpha = .82f), cyan.copy(alpha = .88f), Color.White.copy(alpha = .66f)),
            center
        ),
        radius = radius,
        center = center,
        style = Stroke(width = max(1f, diameter * .012f))
    )
    drawArc(
        color = Color.White.copy(alpha = .62f),
        startAngle = 205f + phase * 24f,
        sweepAngle = 74f,
        useCenter = false,
        topLeft = Offset(center.x - radius * .93f, center.y - radius * .93f),
        size = Size(radius * 1.86f, radius * 1.86f),
        style = Stroke(width = max(1f, diameter * .009f))
    )
}

@Composable
private fun GlassPanel(
    modifier: Modifier = Modifier,
    radius: androidx.compose.ui.unit.Dp = 25.dp,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier = modifier
            .shadow(11.dp, shape, clip = false)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        Color.White.copy(alpha = .075f),
                        Color.White.copy(alpha = .028f),
                        Color(0xFF9F83E8).copy(alpha = .038f),
                        Color(0xFF10111D).copy(alpha = .30f)
                    )
                )
            )
            .border(
                BorderStroke(
                    1.dp,
                    Brush.linearGradient(
                        listOf(
                            Color.White.copy(alpha = .23f),
                            Color(0xFFBFA7FF).copy(alpha = .13f),
                            Color.White.copy(alpha = .025f),
                            Color(0xFF86E1F7).copy(alpha = .10f)
                        )
                    )
                ),
                shape
            )
    ) {
        Canvas(Modifier.matchParentSize()) {
            val corner = CornerRadius(radius.toPx())
            drawRoundRect(
                brush = Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = .075f), Color.White.copy(alpha = .018f), Color.Transparent),
                    startY = 0f,
                    endY = size.height * .52f
                ),
                cornerRadius = corner,
                size = size
            )
            drawRoundRect(
                color = Color.White.copy(alpha = .035f),
                topLeft = Offset(1.dp.toPx(), 1.dp.toPx()),
                size = Size((size.width - 2.dp.toPx()).coerceAtLeast(0f), (size.height - 2.dp.toPx()).coerceAtLeast(0f)),
                cornerRadius = CornerRadius((radius - 1.dp).toPx()),
                style = Stroke(width = 1.dp.toPx())
            )
            drawLine(
                brush = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(alpha = .14f), Color.Transparent)),
                start = Offset(size.width * .14f, 1.dp.toPx()),
                end = Offset(size.width * .86f, 1.dp.toPx()),
                strokeWidth = 1.dp.toPx()
            )
        }
        content()
    }
}

@Composable
private fun HeaderBar(onSettings: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().height(62.dp), radius = 22.dp) {
        Row(
            Modifier.fillMaxSize().padding(start = 14.dp, end = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Color(0xFFDCC5FF).copy(alpha = .28f), Color(0xFF74DBF0).copy(alpha = .17f)))).border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Radio, null, tint = Color(0xFFE6D5FF), modifier = Modifier.size(21.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("RADIO CHERRY", color = Color(0xFFF8F3FF), fontWeight = FontWeight.ExtraBold, letterSpacing = 2.2.sp, fontSize = 14.sp)
                Text("SOUND IN A DIFFERENT LIGHT", color = Color(0xFFB7ADC8), fontSize = 8.sp, letterSpacing = 1.25.sp)
            }
            Spacer(Modifier.weight(1f))
            GlassIconButton(Icons.Default.Settings, "Settings", onSettings, size = 42.dp)
        }
    }
}

@Composable
private fun HeroGlassPanel() {
    GlassPanel(Modifier.fillMaxWidth().height(164.dp), radius = 27.dp) {
        Box(Modifier.fillMaxSize()) {
            // Keep the hero typography clean; the live liquid form is behind the entire screen.
            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xFF090A13).copy(alpha = .16f), Color.Transparent))))
            Column(
                Modifier.align(Alignment.CenterStart).fillMaxWidth(.94f).padding(start = 19.dp, end = 16.dp, top = 14.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text("A LITTLE MORE WONDER", color = Color(0xFFE2CEFF), fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp, fontSize = 9.sp)
                Spacer(Modifier.height(9.dp))
                Text("Let sound\nsurround you.", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 25.sp, lineHeight = 28.sp, letterSpacing = (-.5).sp)
                Spacer(Modifier.height(8.dp))
                Text("Independent music radio,\nfrom ambient to orchestral.", color = Color(0xFFC4BBD2), fontSize = 10.sp, lineHeight = 15.sp)
            }
            Box(Modifier.align(Alignment.BottomStart).padding(start = 19.dp, bottom = 10.dp).width(62.dp).height(2.dp).clip(CircleShape).background(Brush.horizontalGradient(listOf(Color(0xFFBFA4FF), Color(0xFF72D9F1), Color.Transparent))))
        }
    }
}

@Composable
private fun GlassSearchField(value: String, onValueChange: (String) -> Unit, onClear: () -> Unit) {
    GlassPanel(Modifier.fillMaxWidth().height(55.dp), radius = 19.dp) {
        Row(Modifier.fillMaxSize().padding(horizontal = 15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Search, null, tint = Color(0xFFD4C2F4), modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(11.dp))
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                textStyle = TextStyle(color = Color(0xFFF5F0FF), fontSize = 13.sp),
                cursorBrush = SolidColor(Color(0xFFD9BBFF)),
                decorationBox = { innerTextField ->
                    Box {
                        if (value.isEmpty()) Text("Search music, stations or moods", color = Color(0xFFAAA2B9), fontSize = 13.sp)
                        innerTextField()
                    }
                }
            )
            if (value.isNotEmpty()) {
                GlassIconButton(Icons.Default.Close, "Clear search", onClear, size = 30.dp)
            }
        }
    }
}

@Composable
private fun GlassChip(label: String, selected: Boolean, onClick: () -> Unit, compact: Boolean = false) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .94f else 1f,
        animationSpec = spring(dampingRatio = .58f, stiffness = 650f),
        label = "glass-chip-press"
    )
    val shape = CircleShape
    Box(
        Modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(shape)
            .background(
                if (selected) Brush.linearGradient(listOf(Color(0xFFA78BFA).copy(alpha = .26f), Color(0xFF69CBEA).copy(alpha = .14f)))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = .075f), Color.White.copy(alpha = .025f)))
            )
            .border(1.dp, if (selected) Brush.linearGradient(listOf(Color.White.copy(alpha = .42f), Color(0xFFBDA7FF).copy(alpha = .30f), Color(0xFF78DDF0).copy(alpha = .22f))) else Brush.linearGradient(listOf(Color.White.copy(alpha = .16f), Color.White.copy(alpha = .04f))), shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = if (compact) 13.dp else 14.dp, vertical = if (compact) 8.dp else 9.dp)
    ) {
        Text(label, color = if (selected) Color(0xFFFFFAFF) else Color(0xFFC2B9D0), fontSize = if (compact) 10.sp else 11.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium)
    }
}

@Composable
private fun GlassIconButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    size: androidx.compose.ui.unit.Dp = 44.dp,
    tint: Color = Color(0xFFE7D8FF),
    enabled: Boolean = true
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .86f else 1f,
        animationSpec = spring(dampingRatio = .48f, stiffness = 700f),
        label = "glass-button-press"
    )
    Box(
        Modifier
            .size(size)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color.White.copy(alpha = if (pressed) .21f else .105f), Color(0xFF9F84E8).copy(alpha = .10f), Color.White.copy(alpha = .035f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .38f), Color(0xFFBBA4FF).copy(alpha = .14f), Color.White.copy(alpha = .035f))), CircleShape)
            .clickable(interactionSource = interaction, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = if (enabled) tint else tint.copy(alpha = .35f), modifier = Modifier.size(size * .47f))
    }
}

@Composable
private fun StationCard(
    station: Station,
    active: Boolean,
    favorite: Boolean,
    motionEnabled: Boolean,
    onFavorite: () -> Unit,
    onClick: () -> Unit
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) .978f else 1f,
        animationSpec = spring(dampingRatio = .54f, stiffness = 620f),
        label = "station-glass-press"
    )
    val shape = RoundedCornerShape(21.dp)
    Box(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (active) 7.dp else 2.dp, shape, clip = false)
            .clip(shape)
            .background(
                if (active) Brush.linearGradient(listOf(Color(0xFFBBA3FF).copy(alpha = .13f), Color(0xFF70D8ED).copy(alpha = .055f), Color.White.copy(alpha = .025f)))
                else Brush.linearGradient(listOf(Color.White.copy(alpha = .045f), Color.White.copy(alpha = .016f), Color(0xFF9D83D7).copy(alpha = .018f)))
            )
            .border(
                BorderStroke(
                    1.dp,
                    if (active) Brush.linearGradient(listOf(Color.White.copy(alpha = .30f), Color(0xFFB8A1FF).copy(alpha = .20f), Color(0xFF72DDF0).copy(alpha = .14f)))
                    else Brush.linearGradient(listOf(Color.White.copy(alpha = .12f), Color.White.copy(alpha = .025f), Color(0xFF9A8AC6).copy(alpha = .06f)))
                ),
                shape
            )
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Canvas(Modifier.matchParentSize()) {
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = .06f), Color.Transparent, Color.Black.copy(alpha = .08f))),
                cornerRadius = CornerRadius(21.dp.toPx()),
                size = size
            )
            if (active) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(Color(0xFFB79CFF).copy(alpha = .19f), Color.Transparent)),
                    radius = size.height * .86f,
                    center = Offset(size.width * .08f, size.height * .46f)
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(49.dp).clip(RoundedCornerShape(15.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .17f), Color(0xFF8A75C6).copy(alpha = .10f))))
                    .border(1.dp, Color.White.copy(alpha = .17f), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (active) Icons.Default.GraphicEq else if (station.category.contains("Classical")) Icons.Default.GraphicEq else Icons.Default.Radio,
                    null,
                    tint = if (active) Color(0xFF8FE7E2) else Color(0xFFD2BFFF),
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(station.name, color = Color(0xFFF8F4FF), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (active) {
                        Spacer(Modifier.width(7.dp))
                        Text("ON AIR", color = Color(0xFFBCEDEB), fontWeight = FontWeight.Bold, fontSize = 7.sp, letterSpacing = 1.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text("${station.genre}  ·  ${station.broadcaster}", color = Color(0xFFBDB4CB), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            GlassIconButton(
                icon = if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = if (favorite) "Remove favourite" else "Add favourite",
                onClick = onFavorite,
                size = 36.dp,
                tint = if (favorite) Color(0xFFFFB6DF) else Color(0xFFD4C9E6)
            )
        }
    }
}

@Composable
private fun BottomMiniPlayer(
    station: Station?,
    isPlaying: Boolean,
    status: String,
    motionEnabled: Boolean,
    onPlayPause: () -> Unit,
    onStop: () -> Unit
) {
    GlassPanel(Modifier.fillMaxWidth().heightIn(min = 86.dp), radius = 25.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(61.dp).clip(RoundedCornerShape(19.dp))
                    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .13f), Color(0xFF8D73CE).copy(alpha = .10f))))
                    .border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(19.dp)),
                contentAlignment = Alignment.Center
            ) {
                FluidOrb(Modifier.size(62.dp), animated = motionEnabled && isPlaying)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("NOW PLAYING", color = Color(0xFFE1CFFF), fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.55.sp)
                Spacer(Modifier.height(3.dp))
                Text(station?.name ?: "Radio Cherry", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (station == null) "Choose a frequency" else if (isPlaying) "${station.genre}  ·  LIVE" else status,
                    color = Color(0xFFBDB4CA), fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            GlassIconButton(
                icon = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                onClick = onPlayPause,
                size = 43.dp,
                enabled = station != null,
                tint = Color(0xFFE6D5FF)
            )
            Spacer(Modifier.width(5.dp))
            GlassIconButton(
                icon = Icons.Default.Stop,
                contentDescription = "Stop playback",
                onClick = onStop,
                size = 38.dp,
                enabled = station != null,
                tint = Color(0xFFC4B9D4)
            )
        }
    }
}

@Composable
private fun SettingsDialog(
    motionEnabled: Boolean,
    onMotionChange: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = true)
    ) {
        GlassPanel(Modifier.fillMaxWidth(), radius = 29.dp) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("APPEARANCE", color = Color(0xFFDCC5FF), fontWeight = FontWeight.Bold, fontSize = 9.sp, letterSpacing = 2.sp)
                    Text("Make it move.", color = Color(0xFFFFFAFF), fontWeight = FontWeight.SemiBold, fontSize = 22.sp)
                    Text("Tune the atmosphere of Radio Cherry.", color = Color(0xFFC0B8CE), fontSize = 12.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Liquid glass motion", color = Color(0xFFF8F3FF), fontWeight = FontWeight.Medium, fontSize = 14.sp)
                        Text("Animate the full-screen liquid sphere, flowing colour ribbons and ambient light fields.", fontSize = 11.sp, color = Color(0xFFC0B8CE), lineHeight = 16.sp)
                    }
                    Switch(
                        checked = motionEnabled,
                        onCheckedChange = onMotionChange,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF171222),
                            checkedTrackColor = Color(0xFFC6A8FF),
                            uncheckedThumbColor = Color(0xFFB8AFC4),
                            uncheckedTrackColor = Color.White.copy(alpha = .15f)
                        )
                    )
                }
                Text("Android's native notification and lock-screen media cards use static artwork. The in-app bubbles remain animated and follow this setting.", fontSize = 10.sp, color = Color(0xFFAAA1BB), lineHeight = 15.sp)
                GlassChip(label = "Done", selected = true, onClick = onDismiss)
            }
        }
    }
}
