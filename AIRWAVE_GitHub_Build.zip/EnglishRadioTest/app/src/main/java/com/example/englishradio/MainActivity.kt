package com.example.englishradio

import android.app.Activity
import android.content.ComponentName
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.SystemBarStyle
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.graphicsLayer
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val stations = listOf(
    Station("groove-salad", "Groove Salad", "Ambient · Downtempo", "SomaFM", "https://ice5.somafm.com/groovesalad-128-mp3", "https://ice.somafm.com/groovesalad", "Chill"),
    Station("lush", "Lush", "Mellow · Electronic", "SomaFM", "https://ice5.somafm.com/lush-128-mp3", "https://ice.somafm.com/lush", "Chill"),
    Station("indie-pop", "Indie Pop Rocks!", "Indie · Alternative", "SomaFM", "https://ice5.somafm.com/indiepop-128-mp3", "https://ice.somafm.com/indiepop", "Indie"),
    Station("underground-80s", "Underground 80s", "80s · New Wave", "SomaFM", "https://ice5.somafm.com/u80s-128-mp3", "https://ice.somafm.com/u80s", "Throwbacks"),
    Station("left-coast-70s", "Left Coast 70s", "Classic · Album Rock", "SomaFM", "https://ice5.somafm.com/seventies-128-mp3", "https://ice.somafm.com/seventies", "Throwbacks"),
    Station("folk-forward", "Folk Forward", "Folk · Americana", "SomaFM", "https://ice5.somafm.com/folkfwd-128-mp3", "https://ice.somafm.com/folkfwd", "Acoustic"),
    Station("drone-zone", "Drone Zone", "Atmospheric · Ambient", "SomaFM", "https://ice5.somafm.com/dronezone-128-mp3", "https://ice.somafm.com/dronezone", "Chill"),
    Station("secret-agent", "Secret Agent", "Spy · Soundtracks", "SomaFM", "https://ice5.somafm.com/secretagent-128-mp3", "https://ice.somafm.com/secretagent", "Discovery"),
    Station("mission-control", "Mission Control", "Space · Ambient", "SomaFM", "https://ice5.somafm.com/missioncontrol-128-mp3", "https://ice.somafm.com/missioncontrol", "Chill"),
    Station("space-station", "Space Station Soma", "Space · Electronic", "SomaFM", "https://ice5.somafm.com/spacestation-128-mp3", "https://ice.somafm.com/spacestation", "Chill"),
    Station("beat-blender", "Beat Blender", "Deep · House", "SomaFM", "https://ice5.somafm.com/beatblender-128-mp3", "https://ice.somafm.com/beatblender", "Electronic"),
    Station("poptron", "PopTron", "Indie · Pop", "SomaFM", "https://ice5.somafm.com/poptron-128-mp3", "https://ice.somafm.com/poptron", "Indie"),
    Station("sonic-universe", "Sonic Universe", "Modern · Jazz", "SomaFM", "https://ice5.somafm.com/sonicuniverse-128-mp3", "https://ice.somafm.com/sonicuniverse", "Jazz"),
    Station("suburbs-of-goa", "Suburbs of Goa", "Psychedelic · Indian", "SomaFM", "https://ice5.somafm.com/suburbsofgoa-128-mp3", "https://ice.somafm.com/suburbsofgoa", "World"),
    Station("defcon", "DEF CON Radio", "Electronic · Hacker culture", "SomaFM", "https://ice5.somafm.com/defcon-128-mp3", "https://ice.somafm.com/defcon", "Electronic"),
    Station("radio-paradise-main", "Radio Paradise · Main Mix", "Eclectic · Alternative", "Radio Paradise", "https://stream.radioparadise.com/mp3-128", null, "Indie", region = "USA"),
    Station("radio-paradise-mellow", "Radio Paradise · Mellow Mix", "Mellow · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/mellow-128", null, "Chill", region = "USA"),
    Station("radio-paradise-rock", "Radio Paradise · Rock Mix", "Alternative · Rock", "Radio Paradise", "https://stream.radioparadise.com/rock-128", null, "Indie", region = "USA"),
    Station("radio-paradise-global", "Radio Paradise · Global Mix", "World · Eclectic", "Radio Paradise", "https://stream.radioparadise.com/eclectic-128", null, "World", region = "USA"),
    Station("kexp", "KEXP 90.3", "Alternative · Discovery", "KEXP", "https://kexp.streamguys1.com/kexp160.aac", "https://kexp.streamguys1.com/kexp64.aac", "Indie", region = "Seattle"),
    Station("swiss-classic", "Radio Swiss Classic", "Western classical · Instrumental", "Switzerland", "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128", null, "Classical", region = "Switzerland"),
    Station("wcrb", "WCRB Classical", "Symphonic · Chamber · Opera", "CRB · Boston", "https://wgbh-live.streamguys1.com/classical-hi/", null, "Classical", region = "Boston"),
    Station("kusc", "Classical KUSC", "Orchestral · Classical favourites", "Classical California", "https://playerservices.streamtheworld.com/api/livestream-redirect/KUSCMP128.mp3", null, "Classical", region = "Los Angeles"),
    Station("air-raagam", "AIR Raagam", "Hindustani · Carnatic", "Akashvani · India", "https://airhlspush.pc.cdn.bitgravity.com/httppush/hlspbaudioragam/hlspbaudioragam64kbps.m3u8", null, "Indian Classical", region = "India")
) + importedStations

data class Station(
    val id: String,
    val name: String,
    val genre: String,
    val broadcaster: String,
    val stream: String,
    val fallback: String?,
    val category: String,
    val region: String = "USA"
)


private val pulseColors = listOf(
    Color(0xFF20D9D0), Color(0xFF299CEB), Color(0xFF8B63F6), Color(0xFFC74CE5), Color(0xFFEE70C9)
)

private enum class AppTab { NOW_PLAYING, BROWSE, FAVORITES }

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)
    private var controllerFuture: ListenableFuture<MediaController>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync().also { future ->
            future.addListener({ runCatching { future.get() }.onSuccess { controller = it } }, ContextCompat.getMainExecutor(this))
        }
        setContent { RadioCherryApp(controller) }
    }

    override fun onDestroy() {
        controller = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onDestroy()
    }
}

@Composable
private fun RadioCherryApp(player: MediaController?) {
    val context = LocalContext.current
    val activity = context as? Activity
    var audioPermissionGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val audioPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { audioPermissionGranted = it }
    var waveform by remember { mutableStateOf(FloatArray(128) { 0f }) }
    var audioLevel by remember { mutableFloatStateOf(.06f) }
    val preferences = remember(context) { context.getSharedPreferences("radio_cherry_preferences", android.content.Context.MODE_PRIVATE) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var playbackStatus by remember { mutableStateOf("Choose a station to begin") }
    var search by remember { mutableStateOf("") }
    var selectedGenre by remember { mutableStateOf<String?>(null) }
    var currentTab by remember { mutableStateOf(AppTab.BROWSE) }
    var showSettings by remember { mutableStateOf(false) }
    var favorites by remember {
        mutableStateOf(preferences.getStringSet("favorite_station_ids", emptySet())?.toSet() ?: emptySet())
    }
    var visualizerEnabled by remember { mutableStateOf(preferences.getBoolean("music_visualizer_enabled", true)) }
    var darkTheme by remember { mutableStateOf(preferences.getBoolean("dark_theme", true)) }
    val scope = rememberCoroutineScope()
    var resolveJob by remember { mutableStateOf<Job?>(null) }
    val mediaArtwork = remember(context) {
        runCatching { context.assets.open("radio_cherry_waveform_artwork.png").use { it.readBytes() } }.getOrNull()
    }

    SideEffect {
        activity?.window?.let { window ->
            WindowInsetsControllerCompat(window, window.decorView).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    LaunchedEffect(selectedId, isPlaying, audioPermissionGranted, visualizerEnabled) {
        waveform = FloatArray(128) { 0f }
        audioLevel = .06f
        val sessionId = PlaybackService.currentAudioSessionId
        if (!visualizerEnabled || !audioPermissionGranted || !isPlaying || sessionId <= 0) return@LaunchedEffect
        val visualizer = runCatching { Visualizer(sessionId) }.getOrNull() ?: return@LaunchedEffect
        try {
            visualizer.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            visualizer.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer, bytes: ByteArray, samplingRate: Int) {
                    val values = FloatArray(128) { i ->
                        val start = (i * bytes.size / 128).coerceIn(0, bytes.lastIndex)
                        val end = (((i + 1) * bytes.size / 128) - 1).coerceIn(start, bytes.lastIndex)
                        var energy = 0.0
                        var count = 0
                        for (sampleIndex in start..end) {
                            val sample = bytes[sampleIndex].toInt() / 128.0
                            energy += sample * sample
                            count++
                        }
                        // Per-band RMS envelope: smoother and more legible than raw PCM spikes.
                        (sqrt(energy / count.coerceAtLeast(1)) * 4.5).toFloat().coerceIn(.04f, 1f)
                    }
                    waveform = values
                    audioLevel = (values.sum() / values.size).coerceIn(.04f, .95f)
                }
                override fun onFftDataCapture(v: Visualizer, fft: ByteArray, samplingRate: Int) = Unit
            }, Visualizer.getMaxCaptureRate() / 2, true, false)
            visualizer.enabled = true
        } catch (_: Throwable) {
            runCatching { visualizer.release() }
            return@LaunchedEffect
        }
        try { kotlinx.coroutines.awaitCancellation() }
        finally {
            runCatching { visualizer.enabled = false }
            runCatching { visualizer.release() }
        }
    }

    LaunchedEffect(favorites) { preferences.edit().putStringSet("favorite_station_ids", favorites).apply() }
    LaunchedEffect(visualizerEnabled) { preferences.edit().putBoolean("music_visualizer_enabled", visualizerEnabled).apply() }
    LaunchedEffect(darkTheme) { preferences.edit().putBoolean("dark_theme", darkTheme).apply() }

    DisposableEffect(player) {
        if (player == null) return@DisposableEffect onDispose { }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
                playbackStatus = if (playing) "LIVE" else if (player.mediaItemCount > 0) "Paused" else "Choose a station"
            }
            override fun onPlaybackStateChanged(state: Int) {
                playbackStatus = when (state) {
                    Player.STATE_BUFFERING -> "Connecting…"
                    Player.STATE_READY -> if (player.isPlaying) "LIVE" else "Ready to play"
                    Player.STATE_ENDED -> "Stream ended"
                    Player.STATE_IDLE -> if (player.mediaItemCount == 0) "Choose a station" else "Stopped"
                    else -> playbackStatus
                }
            }
            override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                isPlaying = false
                playbackStatus = "Stream unavailable · ${error.errorCodeName}"
            }
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                selectedId = mediaItem?.mediaId
                if (mediaItem == null) isPlaying = false
            }
        }
        player.addListener(listener)
        isPlaying = player.isPlaying
        selectedId = player.currentMediaItem?.mediaId
        onDispose { player.removeListener(listener) }
    }

    val selected = stations.firstOrNull { it.id == selectedId }
    val genreOptions = listOf(
        "Pop", "Rock", "Indie & Alternative", "Electronic & Dance", "Ambient & Chill",
        "Jazz & Soul", "Classical", "Indian Classical", "Country & Folk", "Lo-Fi",
        "Throwbacks", "World Music", "Nature & Sleep", "Seasonal"
    )

    fun matchesGenre(station: Station, genre: String): Boolean {
        val text = "${station.name} ${station.genre} ${station.category}".lowercase()
        return when (genre) {
            "Pop" -> listOf("pop", "hits", "chart").any { it in text }
            "Rock" -> listOf("rock", "metal", "punk").any { it in text }
            "Indie & Alternative" -> listOf("indie", "alternative", "independent").any { it in text }
            "Electronic & Dance" -> listOf("electronic", "dance", "house", "techno", "trance", "disco", "edm", "ebm").any { it in text }
            "Ambient & Chill" -> listOf("ambient", "chill", "downtempo", "mellow", "easy listening", "space").any { it in text }
            "Jazz & Soul" -> listOf("jazz", "soul", "blues", "funk", "r&b").any { it in text }
            "Classical" -> listOf("classical", "orchestral", "symphonic", "opera", "instrumental", "chamber").any { it in text } && !listOf("carnatic", "hindustani", "indian classical").any { it in text }
            "Indian Classical" -> listOf("carnatic", "hindustani", "indian classical", "raagam").any { it in text }
            "Country & Folk" -> listOf("country", "folk", "americana", "acoustic").any { it in text }
            "Lo-Fi" -> listOf("lo-fi", "lofi", "study beats").any { it in text }
            "Throwbacks" -> listOf("throwback", "classic hits", "80s", "70s", "60s", "90s", "oldies", "retro").any { it in text }
            "World Music" -> listOf("world", "global", "reggae", "latin", "goa", "indian").any { it in text }
            "Nature & Sleep" -> listOf("nature", "sleep", "soundscape", "rain", "drone", "birdsong", "waves").any { it in text }
            "Seasonal" -> listOf("christmas", "holiday", "seasonal").any { it in text }
            else -> false
        }
    }

    fun playStation(station: Station) {
        if (!audioPermissionGranted && visualizerEnabled) audioPermissionLauncher.launch(android.Manifest.permission.RECORD_AUDIO)
        val activePlayer = player ?: return
        resolveJob?.cancel()
        selectedId = station.id
        currentTab = AppTab.NOW_PLAYING
        playbackStatus = if (PlaylistResolver.isPlaylistUrl(station.stream)) "Opening station playlist…" else "Connecting…"
        resolveJob = scope.launch {
            val url = runCatching { withContext(Dispatchers.IO) { PlaylistResolver.resolve(station.stream) } }.getOrElse { station.stream }
            if (selectedId != station.id) return@launch
            val resolvedStation = station.copy(stream = url)
            activePlayer.setMediaItem(PlaybackService.mediaItem(resolvedStation, mediaArtwork))
            activePlayer.prepare()
            activePlayer.play()
        }
    }

    fun togglePlayback() {
        val active = player ?: return
        if (active.isPlaying) active.pause() else if (active.mediaItemCount > 0) active.play() else selected?.let { playStation(it) }
    }

    fun playRelative(step: Int) {
        val base = stations.indexOfFirst { it.id == selectedId }.let { if (it < 0) 0 else it }
        val next = (base + step + stations.size) % stations.size
        playStation(stations[next])
    }

    val pageBg = if (darkTheme) Color(0xFF17191E) else Color(0xFFF8F8F8)
    val mainText = if (darkTheme) Color(0xFFF3F3F5) else Color(0xFF1D1D20)
    val secondaryText = if (darkTheme) Color(0xFFB9BBC2) else Color(0xFF686A70)
    val cardColor = if (darkTheme) Color(0xFF2D3036) else Color.White

    MaterialTheme(colorScheme = if (darkTheme) darkColorScheme(primary = Color(0xFFE6E6E9), background = pageBg, surface = cardColor, onSurface = mainText) else lightColorScheme(primary = Color(0xFF26272B), background = pageBg, surface = cardColor, onSurface = mainText)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(if (darkTheme) listOf(Color(0xFF17191F), Color(0xFF1B1D23), Color(0xFF15171B)) else listOf(Color(0xFFFFFFFF), Color(0xFFF7F7F8), Color(0xFFF1F1F3))))) {
            Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
                when (currentTab) {
                    AppTab.NOW_PLAYING -> NowPlayingPage(
                        station = selected,
                        playing = isPlaying,
                        playbackStatus = playbackStatus,
                        waveform = waveform,
                        level = audioLevel,
                        darkTheme = darkTheme,
                        visualizerEnabled = visualizerEnabled,
                        onSettings = { showSettings = true },
                        onToggle = { togglePlayback() },
                        onPrevious = { playRelative(-1) },
                        onNext = { playRelative(1) },
                        onStation = { playStation(it) },
                        stations = stations,
                        modifier = Modifier.weight(1f)
                    )
                    AppTab.BROWSE -> BrowsePage(
                        stations = stations,
                        selectedId = selectedId,
                        playing = isPlaying,
                        favorites = favorites,
                        search = search,
                        onSearch = { search = it },
                        selectedGenre = selectedGenre,
                        genreOptions = genreOptions,
                        onGenre = { selectedGenre = it },
                        onStation = { playStation(it) },
                        onFavorite = { id -> favorites = if (id in favorites) favorites - id else favorites + id },
                        waveform = waveform,
                        level = audioLevel,
                        darkTheme = darkTheme,
                        onSettings = { showSettings = true },
                        modifier = Modifier.weight(1f)
                    )
                    AppTab.FAVORITES -> FavoritesPage(
                        favoriteStations = stations.filter { it.id in favorites },
                        selectedId = selectedId,
                        playing = isPlaying,
                        favorites = favorites,
                        onStation = { playStation(it) },
                        onFavorite = { id -> favorites = favorites - id },
                        waveform = waveform,
                        level = audioLevel,
                        darkTheme = darkTheme,
                        onSettings = { showSettings = true },
                        modifier = Modifier.weight(1f)
                    )
                }
                BottomNavigationBar(currentTab, darkTheme) { currentTab = it }
            }
            if (showSettings) {
                SettingsDialog(
                    darkTheme = darkTheme,
                    onDarkTheme = { darkTheme = it },
                    visualizerEnabled = visualizerEnabled,
                    onVisualizerEnabled = { visualizerEnabled = it },
                    onDismiss = { showSettings = false },
                    dark = darkTheme
                )
            }
        }
    }
}

@Composable
private fun NowPlayingPage(
    station: Station?, playing: Boolean, playbackStatus: String, waveform: FloatArray, level: Float,
    darkTheme: Boolean, visualizerEnabled: Boolean, onSettings: () -> Unit, onToggle: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit, onStation: (Station) -> Unit,
    stations: List<Station>, modifier: Modifier = Modifier
) {
    val text = if (darkTheme) Color(0xFFF3F3F5) else Color(0xFF202024)
    val muted = if (darkTheme) Color(0xFFB8BAC2) else Color(0xFF74757A)
    val index = stations.indexOfFirst { it.id == station?.id }.let { if (it < 0) 0 else it }
    val upNext = if (stations.isNotEmpty()) (1..3).map { stations[(index + it) % stations.size] } else emptyList()
    LazyColumn(modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 24.dp, top = 4.dp, bottom = 20.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
        item { WaveHeader("radio", waveform, level, playing && visualizerEnabled, darkTheme, onSettings) }
        item {
            Spacer(Modifier.height(8.dp))
            if (station == null) {
                Text("Choose a station to start listening", color = muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 20.dp), textAlign = TextAlign.Center)
            } else {
                Text(station.name.uppercase(), color = text, fontSize = 19.sp, fontWeight = FontWeight.Light, letterSpacing = 3.2.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(10.dp))
                Text("${station.broadcaster}  •  ${station.genre}  •  ${if (playing) "LIVE" else playbackStatus.uppercase()}", color = muted, fontSize = 11.sp, letterSpacing = .6.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(), maxLines = 2)
                Spacer(Modifier.height(24.dp))
                LiveProgressLine(darkTheme)
                Spacer(Modifier.height(9.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("LIVE STREAM", color = muted, fontSize = 10.sp)
                    Text(if (playing) "ON AIR" else playbackStatus.uppercase(), color = muted, fontSize = 10.sp)
                }
            }
        }
        item {
            Spacer(Modifier.height(26.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                RoundControl(Icons.Default.SkipPrevious, "Previous station", onPrevious, darkTheme, 48.dp)
                Spacer(Modifier.width(36.dp))
                RoundControl(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, if (playing) "Pause" else "Play", onToggle, darkTheme, 64.dp, strong = true)
                Spacer(Modifier.width(36.dp))
                RoundControl(Icons.Default.SkipNext, "Next station", onNext, darkTheme, 48.dp)
            }
            Spacer(Modifier.height(35.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("up next", color = text, fontSize = 13.sp, letterSpacing = 1.5.sp)
            }
            Spacer(Modifier.height(9.dp))
        }
        items(upNext, key = { "next-${it.id}" }) { next ->
            UpNextRow(next, darkTheme) { onStation(next) }
        }
    }
}

@Composable
private fun BrowsePage(
    stations: List<Station>, selectedId: String?, playing: Boolean, favorites: Set<String>, search: String, onSearch: (String) -> Unit,
    selectedGenre: String?, genreOptions: List<String>, onGenre: (String?) -> Unit, onStation: (Station) -> Unit,
    onFavorite: (String) -> Unit, waveform: FloatArray, level: Float, darkTheme: Boolean, onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val state = rememberLazyListState()
    val text = if (darkTheme) Color(0xFFF3F3F5) else Color(0xFF202024)
    val muted = if (darkTheme) Color(0xFFB8BAC2) else Color(0xFF74757A)
    val filtered = stations.filter { station ->
        val searchOk = search.isBlank() || "${station.name} ${station.genre} ${station.broadcaster} ${station.region}".contains(search, ignoreCase = true)
        val genreOk = selectedGenre == null || stationMatchesGenre(station, selectedGenre)
        searchOk && genreOk
    }
    val displayed = if (search.isBlank() && selectedGenre == null) stations.take(3) else filtered
    LaunchedEffect(selectedGenre) {
        if (selectedGenre != null) state.animateScrollToItem(2)
    }
    LazyColumn(state = state, modifier = modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 24.dp, top = 4.dp, bottom = 22.dp)) {
        item { WaveHeader("browse", waveform, level, playing, darkTheme, onSettings) }
        item {
            SearchField(search, onSearch, darkTheme)
            Spacer(Modifier.height(25.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Stations", color = text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                if (selectedGenre != null || search.isNotBlank()) {
                    Text("${filtered.size} stations", color = muted, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
        items(displayed, key = { it.id }) { station ->
            StationRow(station, selectedId == station.id, station.id in favorites, darkTheme, showFavorite = false, onClick = { onStation(station) }, onFavorite = { onFavorite(station.id) })
            Spacer(Modifier.height(13.dp))
        }
        if (displayed.isEmpty()) {
            item { Text("No stations found", color = muted, modifier = Modifier.padding(vertical = 18.dp), fontSize = 13.sp) }
        }
        item {
            Spacer(Modifier.height(13.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Genres", color = text, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                if (selectedGenre != null) Text("clear filter", color = muted, fontSize = 11.sp, modifier = Modifier.clickable { onGenre(null) })
            }
            Spacer(Modifier.height(13.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(23.dp), contentPadding = PaddingValues(bottom = 6.dp)) {
                items(genreOptions) { genre ->
                    GenreShortcut(genre, genreIcon(genre), selectedGenre == genre, darkTheme) { onGenre(if (selectedGenre == genre) null else genre) }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun FavoritesPage(
    favoriteStations: List<Station>, selectedId: String?, playing: Boolean, favorites: Set<String>, onStation: (Station) -> Unit,
    onFavorite: (String) -> Unit, waveform: FloatArray, level: Float, darkTheme: Boolean, onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val text = if (darkTheme) Color(0xFFF3F3F5) else Color(0xFF202024)
    val muted = if (darkTheme) Color(0xFFB8BAC2) else Color(0xFF74757A)
    LazyColumn(modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 24.dp, top = 4.dp, bottom = 22.dp)) {
        item {
            WaveHeader("favorites", waveform, level, playing, darkTheme, onSettings)
            Spacer(Modifier.height(12.dp))
            Text("Favorites", color = text, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text("Saved stations • ${favoriteStations.size}", color = muted, fontSize = 12.sp)
            Spacer(Modifier.height(22.dp))
        }
        if (favoriteStations.isEmpty()) {
            item { Text("Your saved stations will appear here.", color = muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 12.dp)) }
        } else {
            items(favoriteStations, key = { it.id }) { station ->
                StationRow(station, selectedId == station.id, station.id in favorites, darkTheme, showFavorite = true, onClick = { onStation(station) }, onFavorite = { onFavorite(station.id) })
                Spacer(Modifier.height(14.dp))
            }
        }
    }
}

@Composable
private fun WaveHeader(title: String, waveform: FloatArray, level: Float, playing: Boolean, darkTheme: Boolean, onSettings: () -> Unit) {
    Box(Modifier.fillMaxWidth().height(224.dp)) {
        WaveformVisual(Modifier.fillMaxSize(), waveform, level, playing, darkTheme)
        Text(title, modifier = Modifier.align(Alignment.TopCenter).padding(top = 22.dp), color = if (darkTheme) Color(0xFFF1F1F3) else Color(0xFF242429), fontSize = 27.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = 8.sp)
        IconButton(onClick = onSettings, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 0.dp).size(42.dp)) {
            Icon(Icons.Default.Radio, contentDescription = "Visualizer and appearance settings", tint = if (darkTheme) Color.White.copy(alpha = .88f) else Color.Black.copy(alpha = .72f), modifier = Modifier.size(35.dp))
        }
    }
}

@Composable
private fun WaveformVisual(modifier: Modifier, waveform: FloatArray, level: Float, playing: Boolean, darkTheme: Boolean) {
    val transition = rememberInfiniteTransition(label = "radio-wave-motion")
    val phase by transition.animateFloat(0f, (2f * PI).toFloat(), infiniteRepeatable(tween(6400, easing = LinearEasing)), label = "wave-idle-phase")
    val colorPhase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(9500, easing = LinearEasing, repeatMode = RepeatMode.Reverse)), label = "pulse-colour-phase")
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val mid = h * .64f
        val energy = if (playing) level.coerceIn(.03f, .95f) else .10f
        val pulseStrength = (.42f + energy * 1.4f).coerceIn(.35f, 1.45f)
        val pulsePoints = listOf(.22f, .49f, .76f)
        pulsePoints.forEachIndexed { i, x ->
            val t = phase + i * 1.7f
            val cx = w * (x + .018f * sin(t))
            val cy = mid + h * .018f * cos(t * .72f)
            val radius = w * (.15f + .018f * sin(t * 1.1f)) * pulseStrength
            val color = pulseColors[(i + (colorPhase * 4).toInt()) % pulseColors.size]
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = .27f), color.copy(alpha = .12f), Color.Transparent), Offset(cx, cy), radius), radius, Offset(cx, cy))
        }
        val count = 128
        fun sampleAt(i: Int, layer: Int): Float {
            val x = i / (count - 1f)
            val carrier = sin(x * PI * 5.2f + phase * .10f + layer * .009f).toFloat()
            if (!playing || waveform.isEmpty()) {
                val envelope = .42f + .58f * sin(x * PI).toFloat().coerceAtLeast(0f)
                return carrier * envelope * .58f
            }
            val index = (i * (waveform.size - 1) / (count - 1f)).toInt().coerceIn(0, waveform.lastIndex)
            var sum = 0f
            var n = 0
            for (j in (index - 2).coerceAtLeast(0)..(index + 2).coerceAtMost(waveform.lastIndex)) { sum += waveform[j]; n++ }
            val envelope = (sum / n.coerceAtLeast(1)).coerceIn(.04f, 1f)
            return carrier * (.22f + envelope * .78f)
        }
        val lineColor = if (darkTheme) Color(0xFFEDEDF2) else Color(0xFF16171B)
        for (layer in 0 until 10) {
            val path = Path()
            val scale = .58f + layer * .047f
            val offset = (layer - 4.5f) * 2.15f
            for (i in 0 until count) {
                val x = w * i / (count - 1f)
                val amp = sampleAt(i, layer)
                val edge = (.52f + .48f * sin(PI * i / (count - 1f)).toFloat().coerceAtLeast(0f))
                val y = mid + amp * h * .28f * scale * edge + offset
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val alpha = if (layer == 4 || layer == 5) .92f else .52f
            drawPath(path, lineColor.copy(alpha = alpha), style = Stroke(width = if (layer == 4 || layer == 5) 1.18.dp.toPx() else .78.dp.toPx()))
        }
    }
}

@Composable
private fun SearchField(value: String, onValueChange: (String) -> Unit, darkTheme: Boolean) {
    val shape = RoundedCornerShape(28.dp)
    val bg = if (darkTheme) Color(0xFF303238) else Color(0xFFF0F0F2)
    val text = if (darkTheme) Color(0xFFF0F0F3) else Color(0xFF242428)
    val muted = if (darkTheme) Color(0xFFB5B6BD) else Color(0xFF77787D)
    Row(Modifier.fillMaxWidth().height(52.dp).clip(shape).background(bg).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Search, null, tint = muted, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(11.dp))
        BasicTextField(
            value = value, onValueChange = onValueChange, modifier = Modifier.weight(1f), singleLine = true,
            textStyle = TextStyle(color = text, fontSize = 14.sp), cursorBrush = SolidColor(text),
            decorationBox = { inner -> Box { if (value.isEmpty()) Text("Search stations, podcasts, genres", color = muted, fontSize = 13.sp); inner() } }
        )
        if (value.isNotEmpty()) IconButton(onClick = { onValueChange("") }, modifier = Modifier.size(28.dp)) { Icon(Icons.Default.Close, null, tint = muted, modifier = Modifier.size(17.dp)) }
    }
}

@Composable
private fun StationRow(station: Station, active: Boolean, favorite: Boolean, darkTheme: Boolean, showFavorite: Boolean, onClick: () -> Unit, onFavorite: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .985f else 1f, spring(dampingRatio = .62f, stiffness = 700f), label = "station-row-press")
    val bg = if (darkTheme) Color(0xFF2C2F35) else Color.White
    val text = if (darkTheme) Color(0xFFF1F1F3) else Color(0xFF242428)
    val muted = if (darkTheme) Color(0xFFC0C1C6) else Color(0xFF6F7076)
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier.fillMaxWidth().graphicsLayer { scaleX = scale; scaleY = scale }
            .shadow(if (darkTheme) 2.dp else 9.dp, shape, clip = false)
            .clip(shape).background(bg)
            .combinedClickable(interactionSource = interaction, indication = null, onClick = onClick, onLongClick = onFavorite)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Radio, null, tint = if (active) Color(0xFF9CE5EA) else muted, modifier = Modifier.size(29.dp))
        Spacer(Modifier.width(19.dp))
        Column(Modifier.weight(1f)) {
            Text(station.name, color = text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text("${station.genre}  •  ${station.broadcaster}", color = muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (showFavorite) {
            IconButton(onClick = onFavorite, modifier = Modifier.size(42.dp)) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Color(0xFFE9A7D7) else muted, modifier = Modifier.size(23.dp))
            }
        }
    }
}

@Composable
private fun GenreShortcut(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, darkTheme: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .93f else 1f, spring(dampingRatio = .55f, stiffness = 650f), label = "genre-press")
    val text = if (darkTheme) Color(0xFFECECF0) else Color(0xFF29292D)
    val muted = if (darkTheme) Color(0xFFB8B9C0) else Color(0xFF74757A)
    Column(
        Modifier.width(86.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(15.dp)).clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(if (selected) (if (darkTheme) Color.White.copy(alpha = .13f) else Color.Black.copy(alpha = .055f)) else Color.Transparent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (selected) text else muted, modifier = Modifier.size(25.dp))
        }
        Text(label, color = if (selected) text else muted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 13.sp)
    }
}

private fun genreIcon(genre: String) = when (genre) {
    "Pop", "Country & Folk" -> Icons.Default.MusicNote
    "Rock", "Electronic & Dance", "Lo-Fi" -> Icons.Default.GraphicEq
    "Classical", "Indian Classical", "Jazz & Soul" -> Icons.Default.LibraryMusic
    "Ambient & Chill", "Nature & Sleep" -> Icons.Default.Album
    else -> Icons.Default.Radio
}

private fun stationMatchesGenre(station: Station, genre: String): Boolean {
    val text = "${station.name} ${station.genre} ${station.category}".lowercase()
    return when (genre) {
        "Pop" -> listOf("pop", "hits", "chart").any { it in text }
        "Rock" -> listOf("rock", "metal", "punk").any { it in text }
        "Indie & Alternative" -> listOf("indie", "alternative", "independent").any { it in text }
        "Electronic & Dance" -> listOf("electronic", "dance", "house", "techno", "trance", "disco", "edm", "ebm").any { it in text }
        "Ambient & Chill" -> listOf("ambient", "chill", "downtempo", "mellow", "easy listening", "space").any { it in text }
        "Jazz & Soul" -> listOf("jazz", "soul", "blues", "funk", "r&b").any { it in text }
        "Classical" -> listOf("classical", "orchestral", "symphonic", "opera", "instrumental", "chamber").any { it in text } && !listOf("carnatic", "hindustani", "indian classical").any { it in text }
        "Indian Classical" -> listOf("carnatic", "hindustani", "indian classical", "raagam").any { it in text }
        "Country & Folk" -> listOf("country", "folk", "americana", "acoustic").any { it in text }
        "Lo-Fi" -> listOf("lo-fi", "lofi", "study beats").any { it in text }
        "Throwbacks" -> listOf("throwback", "classic hits", "80s", "70s", "60s", "90s", "oldies", "retro").any { it in text }
        "World Music" -> listOf("world", "global", "reggae", "latin", "goa", "indian").any { it in text }
        "Nature & Sleep" -> listOf("nature", "sleep", "soundscape", "rain", "drone", "birdsong", "waves").any { it in text }
        "Seasonal" -> listOf("christmas", "holiday", "seasonal").any { it in text }
        else -> false
    }
}

@Composable
private fun UpNextRow(station: Station, darkTheme: Boolean, onClick: () -> Unit) {
    val text = if (darkTheme) Color(0xFFECECF0) else Color(0xFF242428)
    val muted = if (darkTheme) Color(0xFFACADB4) else Color(0xFF77787D)
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(station.name.uppercase(), color = text, fontSize = 12.sp, letterSpacing = 1.4.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(station.genre.uppercase(), color = muted, fontSize = 10.sp, letterSpacing = .5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.height(12.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(if (darkTheme) Color.White.copy(alpha = .17f) else Color.Black.copy(alpha = .12f)))
    }
}

@Composable
private fun LiveProgressLine(darkTheme: Boolean) {
    val track = if (darkTheme) Color.White.copy(alpha = .16f) else Color.Black.copy(alpha = .15f)
    val transition = rememberInfiniteTransition(label = "live-progress")
    val sweep by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "live-sweep")
    Canvas(Modifier.fillMaxWidth().height(3.dp)) {
        drawLine(track, Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 2.dp.toPx())
        val start = size.width * (.10f + sweep * .42f)
        drawLine(if (darkTheme) Color.White.copy(alpha = .85f) else Color.Black.copy(alpha = .72f), Offset(start, size.height / 2), Offset((start + size.width * .20f).coerceAtMost(size.width), size.height / 2), 2.4.dp.toPx())
    }
}

@Composable
private fun RoundControl(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit, darkTheme: Boolean, size: androidx.compose.ui.unit.Dp, strong: Boolean = false) {
    val tint = if (darkTheme) Color(0xFFF1F1F3) else Color(0xFF26272B)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .91f else 1f, spring(dampingRatio = .50f, stiffness = 650f), label = "transport-control")
    Box(Modifier.size(size).graphicsLayer { scaleX = scale; scaleY = scale }.clip(CircleShape).then(if (strong) Modifier.border(1.2.dp, tint.copy(alpha = .8f), CircleShape) else Modifier).clickable(interactionSource = interaction, indication = null, onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(if (strong) 29.dp else 24.dp))
    }
}

@Composable
private fun BottomNavigationBar(current: AppTab, darkTheme: Boolean, onSelect: (AppTab) -> Unit) {
    val bg = if (darkTheme) Color(0xFF202227) else Color(0xFFFFFFFF)
    val divider = if (darkTheme) Color.White.copy(alpha = .10f) else Color.Black.copy(alpha = .12f)
    Row(Modifier.fillMaxWidth().height(73.dp).background(bg).border(width = 0.5.dp, color = divider), verticalAlignment = Alignment.CenterVertically) {
        NavigationItem("now playing", Icons.Default.Radio, current == AppTab.NOW_PLAYING, darkTheme, Modifier.weight(1f)) { onSelect(AppTab.NOW_PLAYING) }
        NavigationItem("browse", Icons.Default.Explore, current == AppTab.BROWSE, darkTheme, Modifier.weight(1f)) { onSelect(AppTab.BROWSE) }
        NavigationItem("favorites", Icons.Default.Favorite, current == AppTab.FAVORITES, darkTheme, Modifier.weight(1f)) { onSelect(AppTab.FAVORITES) }
    }
}

@Composable
private fun NavigationItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, darkTheme: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val active = if (darkTheme) Color(0xFFF1F1F3) else Color(0xFF202024)
    val inactive = if (darkTheme) Color(0xFF888A92) else Color(0xFF929399)
    Column(modifier.fillMaxHeight().clickable(onClick = onClick).padding(top = 8.dp, bottom = 5.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, null, tint = if (selected) active else inactive, modifier = Modifier.size(23.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (selected) active else inactive, fontSize = 10.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
        Spacer(Modifier.height(3.dp))
        Box(Modifier.width(if (selected) 46.dp else 0.dp).height(1.5.dp).background(if (selected) active else Color.Transparent))
    }
}

@Composable
private fun SettingsDialog(darkTheme: Boolean, onDarkTheme: (Boolean) -> Unit, visualizerEnabled: Boolean, onVisualizerEnabled: (Boolean) -> Unit, onDismiss: () -> Unit, dark: Boolean) {
    val bg = if (dark) Color(0xFF292B31) else Color.White
    val text = if (dark) Color(0xFFF1F1F3) else Color(0xFF222328)
    val muted = if (dark) Color(0xFFB7B8BF) else Color(0xFF74757A)
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = true)) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(bg).padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("settings", color = text, fontSize = 22.sp, fontWeight = FontWeight.Light, letterSpacing = 4.sp)
            SettingSwitchRow("Dark appearance", "Use the dark reference-screen appearance.", darkTheme, onDarkTheme, text, muted)
            SettingSwitchRow("Music-reactive waveform", "Animate the waveform and soft colour pulses with the playing station.", visualizerEnabled, onVisualizerEnabled, text, muted)
            Text("Audio-session visualizer data is used while a station is playing. If capture is unavailable, the waveform remains gently animated.", color = muted, fontSize = 11.sp, lineHeight = 16.sp)
            TextButton(onClick = onDismiss, modifier = Modifier.align(Alignment.End)) { Text("Done", color = text) }
        }
    }
}

@Composable
private fun SettingSwitchRow(title: String, detail: String, checked: Boolean, onChecked: (Boolean) -> Unit, text: Color, muted: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = muted, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
